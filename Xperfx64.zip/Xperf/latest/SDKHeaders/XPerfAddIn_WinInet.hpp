/*++

Copyright (c) 2003 Microsoft Corporation

Module Name:

    XPerfAddIn_WinInet.hpp

Abstract:

    XPerf WinInet info source.

Author:

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>            // include XPerfCore main header
#include <XPerfAddIn_Core.hpp>      // core infosources

namespace XPerfAddIn
{

MIDL_INTERFACE("7834747d-8022-49d4-9fd6-f5990f217c66")
IWinInetInfoSource : public IUnknown
{
    struct WINetRead {
        TimeStamp Time;
        ULONG Bytes;
    };

    enum ProtocolType {
        ProtocolType_HTTP,
        ProtocolType_SPDY3,
        ProtocolType_UNKNOWN,
    };

    struct WINetAccess : Temporal {
        LPCWSTR Url;
        LPCWSTR AbsoluteUrl;
        LPCWSTR QueryString;
        LPCWSTR RedirectedUrl;
        LPCWSTR ServerName;
        LPCWSTR HttpRequestVersion;
        LPCWSTR StatusLine;
        ULONG StatusCode;
        LPCWSTR StatusText;
        LPCWSTR HttpResponseVersion;
        ULONG ContentLength;
        LPCWSTR ContentEncoding;
        LPCWSTR ContentType;
        LPCWSTR CacheControl;
        LPCWSTR Expires;
        Temporal CacheLookup;
        Temporal Connect;
        Temporal ResolveHost;
        Temporal TcpConnect;
        Temporal SSLHandshake;
        Temporal SendRequest;
        Temporal WaitResponse;
        Temporal Transfer;
        TimeStamp LastTransferTime;
        TimeStamp LastCacheHitTime;
        ULONG SentBytes;
        ULONG ReadBytes;
        ULONG Socket;
        ProtocolType Protocol;
        ULONG CacheHitCount;
        ULONG AccessIndex;
        ULONG ReadCount;
        ULONG LateReadCount;
        ULONG RequestHeaderSize;
        LPCWSTR RequestHeader;
        ULONG ResponseHeaderSize;
        LPCWSTR ResponseHeader;
        ULONG ConnectionFailures;
        const WINetRead* Reads;

        _Ret_maybenull_
        LPCWSTR
        GetAccessState(
            __in  const TimeStamp& QueryTime
        ) const
        {
            // Define lambda function for checking if TimeStamp is within the limits of Temporal
            auto IsInTimeWindow = [](const TimeStamp& QueryTime, const Temporal& TimeWindow) -> bool { return ((QueryTime > TimeWindow.StartTime) && (QueryTime < TimeWindow.EndTime)); };
            if (IsInTimeWindow(QueryTime, Connect))
            {
                if (IsInTimeWindow(QueryTime, ResolveHost))
                {
                    return L"Resolve Host";
                }
                else if (IsInTimeWindow(QueryTime, TcpConnect))
                {
                    return L"TcpConnect";
                }
                else if (IsInTimeWindow(QueryTime, SSLHandshake))
                {
                    return L"SSL Handshake";
                }
                else
                {
                    return L"Connect";
                }
            }
            else if (IsInTimeWindow(QueryTime, SendRequest))
            {
                return L"Send Request";
            }
            else if (IsInTimeWindow(QueryTime, WaitResponse))
            {
                return L"Wait Response";
            }
            else if (IsInTimeWindow(QueryTime, Transfer))
            {
                return L"Transfer";
            }
            else
            {
                return L"[ERROR: Bad Result]";
            }
        }

    };

    struct WINetDownload : Temporal {
        const IProcessInfoSource::ThreadData* pThread;
        TimeStamp HandleCloseTime;
        LPCWSTR FullUrl;
        LPCWSTR Server;
        LPCWSTR ObjectName;
        LPCWSTR Service;
        LPCWSTR Verb;
        ULONG ServerPort;
        GUID ActivityId;
        bool HandleOverwritten;
        bool HandleClosedById;
        bool HandleClosedByHandle;
        bool UnknownDownload;
        ULONG AccessCount;
        const WINetAccess* Accesses;
    };

    typedef strided_adapter<const WINetDownload> StridedWINetDownloads;

    struct WINetStatusEvent {
        EVENT_DESCRIPTOR StatusEventDescriptor;
        TimeStamp StatusEventTime;
        WINetAccess *Access;
    };

    typedef strided_adapter<const WINetStatusEvent> StridedWINetStatusEvents;

    STDMETHOD(QueryWINetDownloads) (
        __out StridedWINetDownloads* pInfos
        ) PURE;

    STDMETHOD(QueryWINetStatusEvents) (
        __out StridedWINetStatusEvents* pInfos
        ) PURE;

    STDMETHOD(QueryNextWINetStatusEvent) (
        __in  const TimeStamp& QueryTime,
        __in  const TimeStampDelta& MaxTimeWindow,
        __out const WINetAccess*& Access
        ) PURE;

    STDMETHOD_(bool, IsDataAvailable) (
        ) const PURE;

    static
    _Ret_maybenull_
    LPCWSTR
    GetAccessState(
        __in  const WINetAccess* Access,
        __in  const TimeStamp& QueryTime
    );
   
};

};