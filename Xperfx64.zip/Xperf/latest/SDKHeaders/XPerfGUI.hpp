/*++

Copyright (c) 2004 Microsoft Corporation

Module Name:

    XPerfGui.hpp

Abstract:

    XPerfCore UI Extensibility interfaces

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>

namespace XPerfGUI
{
using namespace XPerfCore;

// forward declaration
struct ISelection;
struct ISelection2;
struct ISelection3;

//
// Window Manager
//

MIDL_INTERFACE("0B1CA4E8-6E4E-433E-9C94-1439DA8440C8")
IWindowManager : public IUnknown
{
    STDMETHOD(SetAddInManager)(_In_ IAddInManager* pAddInManager) PURE;

    STDMETHOD(OpenTraces)(SIZE_T nTraces, const LPCWSTR rgszTraceFilenames[], DWORD dwCreateSessionFlags = 0) PURE;

    STDMETHOD(Run)() PURE;
};

MIDL_INTERFACE("295241C8-E992-41D6-A817-135AF533DA89")
IWindowManager2 : public IWindowManager
{
    STDMETHOD(AddEvXmlManifest)(_In_ LPCWSTR wszEvXmlManifest) PURE;
};

MIDL_INTERFACE("1211D4AF-FDBF-476D-BC31-B3D9B36424F5")
IWindowManager3 : public IWindowManager2
{
    STDMETHOD(AddPerfTrackManifest)(_In_ LPCWSTR wszPerfTrackManifest) PURE;
};

MIDL_INTERFACE("5D366F45-5426-4F27-BA49-0A8371653D18")
IWindowManager4 : public IWindowManager3
{
    STDMETHOD(AddIntervalsManifest)(_In_ LPCWSTR wszIntervalsManifest) PURE;
};

MIDL_INTERFACE("CB8BCA91-8BCF-4AC9-B0C4-1BABBBE4BCF3")
IWindowManager5 : public IUnknown
{
    STDMETHOD(InitializeOnExistingSession)(_In_ ISession* pSession) PURE;

    STDMETHOD(CreatePortableSelection)(
        _In_  const TimeStamp& BeginTime,
        _In_  const TimeStamp& EndTime,
        _In_  BOOL  UseManagedSummaryTable,
        _Outptr_ ISelection3** ppSelectionOut
        ) PURE;
};

struct IUISessionInit;

MIDL_INTERFACE("5455302A-684B-45F2-8B5F-168A425EAEB3")
IWindowManager6 : public IUnknown
{
    enum WindowManagerCommand : int
    {
        // pvPayload1 = NULL
        // pvPayload2 = NULL
        WindowManagerCommand_RefreshAllWindows = 1,

        // pvPayload1 = ISession* pointer
        // pvPayload2 = NULL
        WindowManagerCommand_ShowSysConfig = 2,

        // pvPayload1 = ISession* pointer
        // pvPayload2 = HWND parent
        WindowManagerCommand_ShowConfigSymbolPaths = 3,

#ifdef _XPERFCORE_INTERNAL_BUILD
        // pvPayload1 = NULL
        // pvPayload2 = HWND parent
        WindowManagerCommand_ShowConfigWaitAnalysis = 4,
#endif

        // pvPayload1 = DWORD flags (IGraphingEngine2::Flags)
        // pvPayload2 = DWORD mask
        WindowManagerCommand_SetFlags = 5,
    };

    STDMETHOD(SendCommand)(
        WindowManagerCommand dwCommandID,
        _In_ void* pvPayload1 = NULL,
        _In_ void* pvPayload2 = NULL
        ) PURE;

    // Creates an ISession, makes sure all appropriate objects are instantiated,
    // checks for certain errors (and reports them via MessageBox), and processes
    // events while reporting progress into the IUISessionInit. The ISession will
    // be given to the IUISessionInit.
    STDMETHOD(InitializeSession)(
        _In_ IUISessionInit* pUISessionInit,
        _In_ SIZE_T nTraces,
        _In_reads_(nTraces) const LPCWSTR rgszTraceFilenames[],
        _In_ DWORD dwCreateSessionFlags = 0
        ) PURE;
};

MIDL_INTERFACE("62EE4B0A-541A-4B81-8976-6C3428CA2E6D")
IWindowManager7 : public IWindowManager6
{
    // Creates an ISession, makes sure all appropriate objects are instantiated,
    // checks for certain errors, and processes events while reporting progress
    // into the IUISessionInit. The ISession will be given to the IUISessionInit.
    STDMETHOD(InitializeSessionForWPA)(
        _In_ IUISessionInit* pUISessionInit,
        _In_ SIZE_T nTraces,
        _In_reads_(nTraces) const LPCWSTR rgszTraceFilenames[],
        _In_ SIZE_T nSessionServices,
        _In_reads_opt_(nSessionServices) const GUID rgSessionServices[],
        _Out_writes_opt_(nSessionServices) HRESULT rgQuerySessionServiceHRs[],
        _In_ DWORD dwCreateSessionFlags = 0
        ) PURE;
};

MIDL_INTERFACE("DB160EA4-1556-42FC-B690-DC7FCFADA47F")
IWindowManagerAutomation : public IWindowManager4
{
    enum CCommandId
    {
        Command_Symbols = 1,
        Command_OpenSummaryTable,
        Command_OpenDiff,
    };

    STDMETHOD(ValidateCommand)(
        _In_  CCommandId CommandId,
        _In_  ULONG cParameters, 
        _In_reads_(cParameters) LPCWSTR const rgParameters[]
        ) PURE;

    STDMETHOD(ExecuteCommand)(
        _In_  CCommandId CommandId, 
        _In_ ULONG cParameters, 
        _In_reads_(cParameters) LPCWSTR const rgParameters[]
        ) PURE;
};


MIDL_INTERFACE("F633C8AE-18F1-491C-8FE2-DBEA90657845")
IConsoleManager : public IUnknown
{
    STDMETHOD(SetStdErrorHandle)(_In_ HANDLE handle) PURE;

    STDMETHOD(RestoreStdErrorHandleToDefault)() PURE;
};

class DECLSPEC_UUID("8218A8FB-222F-448D-8DB8-604BA8A81194")
CWindowManager;

//
// Legend
//

MIDL_INTERFACE("0FBF6784-4D64-40CF-A2DE-0266007E5585")
ILegend : public IUnknown
{
    struct LegendProperties {
        USHORT              NumRows;
        USHORT              NumColumns;
    };

    enum SeriesType {SERIES_NONE,
                     SERIES_SOLID_LINE, 
                     SERIES_BAR,
                     SERIES_STACKED_BAR,
                     SERIES_STOCK_TICKER,
                     SERIES_DIRECTED_GRAPH,
                     SERIES_CHECKPOINTS};

    enum MarkerType {MARKER_NONE,
                     MARKER_DIAMOND,
                     MARKER_SQUARE,
                     MARKER_CIRCLE,
                     MARKER_TRIANGLE_UP,
                     MARKER_TRIANGLE_DOWN,
                     MARKER_CROSS};

    struct SeriesProperties {
        SeriesType          SeriesStyle;
        MarkerType          MarkerStyle;
        USHORT              SeriesSize;
        USHORT              MarkerSize;
        COLORREF            Color;
        WCHAR               Label[64];
        BOOLEAN             ShowSeries;
        BOOLEAN             EnableSeries;
        USHORT              UniqueId;
    };

    STDMETHOD(AddSeries)(const SeriesProperties& Props, _Out_opt_ PUSHORT pUniqueId = NULL) PURE;
    STDMETHOD(LinkSeries)(USHORT HeadSeriesUID, USHORT LinkedSeriesUID) PURE;
};


MIDL_INTERFACE("3A8B6450-ACA6-4422-9B58-65BA7186C2AA")
ILegend2 : public ILegend
{
    struct SeriesProperties2 : public SeriesProperties
    {
        ULONG               Reserved;
        const PathNode*     Group;
        IUnknown*           KeepAlive;

    public:

        SeriesProperties2()
            : SeriesProperties()
            , Reserved()
            , Group()
            , KeepAlive()
        {
        }

        explicit SeriesProperties2(const SeriesProperties& Props)
            : SeriesProperties(Props)
            , Reserved()
            , Group()
            , KeepAlive()
        {
        }

        SeriesProperties2(const SeriesProperties2& Props)
            : SeriesProperties(Props)
            , Reserved(Props.Reserved)
            , Group(Props.Group)
            , KeepAlive(Props.KeepAlive)
        {
        }
    };

    STDMETHOD(AddSeries)(
        _In_  const SeriesProperties2& Props, 
        _Out_opt_ PUSHORT pUniqueId = NULL
        ) PURE;
};


//
// Axis
//

struct IGraphingEngine;

MIDL_INTERFACE("73DBF2E7-3D78-4233-A396-80B15690429B")
IAxis : public IUnknown
{
    STDMETHOD(SetVisible)(BOOL bVisible) PURE;
    STDMETHOD(SetTitle)(LPCWSTR szAxisLabel) PURE;

    STDMETHOD_(VOID, GetViewPixelExtent)(SIZE_T& nViewPixelExtent) PURE;

    //
    // Intervals
    //

    enum IntervalType {
        BLOCK_INTERVAL,
        SPAN_INTERVAL
    };

    enum IntervalBasePos {
        START_EXTENT,
        END_EXTENT,
        AXIS_LOCATION
    };

    STDMETHOD_(VOID, RemoveIntervals)() PURE;
    STDMETHOD(ConfigIntervals)(IntervalType type, IAxis *refAxis, IntervalBasePos pos) PURE;
};

//
// Basic datatype refinements
//

class TimeStamp_s : public TimeStamp
{
public:
    TimeStamp_s() : TimeStamp() {}
    TimeStamp_s(const LONGLONG s) : TimeStamp() { sec = s; }
    TimeStamp_s(const TimeStamp& ts) : TimeStamp(ts) {}
};

class TimeStamp_ms : public TimeStamp
{
public:
    TimeStamp_ms() : TimeStamp() {}
    TimeStamp_ms(const LONGLONG ms) : TimeStamp() { msec = ms; }
    TimeStamp_ms(const TimeStamp& ts) : TimeStamp(ts) {}
};

class TimeStamp_us : public TimeStamp
{
public:
    TimeStamp_us() : TimeStamp() {}
    TimeStamp_us(const LONGLONG us) : TimeStamp() { usec = us; }
    TimeStamp_us(const TimeStamp& ts) : TimeStamp(ts) {}
};


class TimeStampDelta_s : public TimeStampDelta
{
public:
    TimeStampDelta_s() : TimeStampDelta() {}
    TimeStampDelta_s(const LONGLONG s) : TimeStampDelta() { sec = s; }
    TimeStampDelta_s(const TimeStampDelta& tsd) : TimeStampDelta(tsd) {}
};

class TimeStampDelta_ms : public TimeStampDelta
{
public:
    TimeStampDelta_ms() : TimeStampDelta() {}
    TimeStampDelta_ms(const LONGLONG ms) : TimeStampDelta() { msec = ms; }
    TimeStampDelta_ms(const TimeStampDelta& tsd) : TimeStampDelta(tsd) {}
};

class TimeStampDelta_us : public TimeStampDelta
{
public:
    TimeStampDelta_us() : TimeStampDelta() {}
    TimeStampDelta_us(const LONGLONG us) : TimeStampDelta() { usec = us; }
    TimeStampDelta_us(const TimeStampDelta& tsd) : TimeStampDelta(tsd) {}
};


class Real
{
protected:
    typedef double      _BaseType;
    typedef Real        _Myself;
public:
    Real() : m_value(_BaseType()) {}
    Real(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class Char
{
protected:
    typedef SCHAR   _BaseType;
    typedef Char    _Myself;
public:
    Char() : m_value(_BaseType()) {}
    Char(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class UChar
{
protected:
    typedef UCHAR   _BaseType;
    typedef UChar   _Myself;
public:
    UChar() : m_value(_BaseType()) {}
    UChar(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class UChar_hex : public UChar
{
public:
    UChar_hex() : UChar() {}
    UChar_hex(const _BaseType& value) : UChar(value) {}
};

class Short
{
protected:
    typedef SHORT   _BaseType;
    typedef Short   _Myself;
public:
    Short() : m_value(_BaseType()) {}
    Short(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class UShort
{
protected:
    typedef USHORT  _BaseType;
    typedef UShort  _Myself;
public:
    UShort() : m_value(_BaseType()) {}
    UShort(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class UShort_hex : public UShort
{
public:
    UShort_hex() : UShort() {}
    UShort_hex(const _BaseType& value) : UShort(value) {}
};

class Long
{
protected:
    typedef LONG    _BaseType;
    typedef Long    _Myself;
public:
    Long() : m_value(_BaseType()) {}
    Long(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class ULong
{
protected:
    typedef ULONG   _BaseType;
    typedef ULong   _Myself;
public:
    ULong() : m_value(_BaseType()) {}
    ULong(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class ULong_hex : public ULong
{
public:
    ULong_hex() : ULong() {}
    ULong_hex(const _BaseType& value) : ULong(value) {}
};

class LongLong
{
protected:
    typedef LONGLONG    _BaseType;
    typedef LongLong    _Myself;
public:
    LongLong() : m_value(_BaseType()) {}
    LongLong(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class ULongLong
{
protected:
    typedef ULONGLONG   _BaseType;
    typedef ULongLong   _Myself;
public:
    ULongLong() : m_value(_BaseType()) {}
    ULongLong(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class ULongLong_hex : public ULongLong
{
public:
    ULongLong_hex() : ULongLong() {}
    ULongLong_hex(const _BaseType& value) : ULongLong(value) {}
};

class Label
{
protected:
    typedef LPCWSTR     _BaseType;
    typedef Label       _Myself;
public:
    Label() : m_value(_BaseType()) {}
    Label(const _BaseType& value) : m_value(value) {}
    void Free() { free((LPVOID)m_value); }
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class CaseSensitiveLabel
{
protected:
    typedef LPCWSTR     _BaseType;
    typedef CaseSensitiveLabel _Myself;
public:
    CaseSensitiveLabel() : m_value(_BaseType()) {}
    CaseSensitiveLabel(const _BaseType& value) : m_value(value) {}
    void Free() { free((LPVOID)m_value); }
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

//
// AutoLabel is intended to be used as a self-cleaning storage 
// of objects of type label.  Use AutoLabel as the static type 
// of the objects; do not use AutoLabel as part of an array of
// polymorphic pointers to objects derived from Label, because
// Label does not have a virtual destructor and the AutoLabel
// destructor will not be called.
//
// Please note that the copy constructor and copy assignment 
// operators are inhibited.  Other constructors and assignment
// operators have take-ownership semantics.
//
class AutoLabel : public Label
{
public:
    // Default constructor
    AutoLabel() : Label() {}
    // Initializing constructor -- take ownership
    AutoLabel(const _BaseType& value) : Label(value) {}
    ~AutoLabel() { Free(); }
    Label* operator&() { return this; }
    const Label* operator&() const { return this; }
    // Assignment operator -- take ownership
    const AutoLabel& operator =(const Label::_BaseType& value) { 
        if (m_value != value) {
            Free();
            m_value = value;
        }
        return *this;
    }
    // Assignment operator -- take ownership
    const AutoLabel& operator =(const Label::_Myself& value) { 
        return operator =(static_cast<const Label::_BaseType&>(value));
    }
private:
    // Copy constructor -- inhibited
    AutoLabel(const AutoLabel& value);
    // Copy assignment operator -- inhibited
    AutoLabel& operator=(const AutoLabel& value);
};

class Percent
{
protected:
    typedef double      _BaseType;
    typedef Percent     _Myself;
public:
    Percent() : m_value(_BaseType()) {}
    Percent(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

class ConstOne
{
};

class StackTop; // defined in XPerfAddIn_NTPerf.hpp

class PathNodeCPtr
{
protected:
    typedef const PathNode* _BaseType;
    typedef PathNodeCPtr    _Myself;
public:
    PathNodeCPtr() : m_value(_BaseType()) {}
    PathNodeCPtr(const _BaseType& value) : m_value(value) {}
    operator _BaseType&() { return m_value; }
    operator const _BaseType&() const { return m_value; }
    const PathNode* operator->() const { return m_value; }
    const PathNode& operator*() const { return *m_value; }
    _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
protected:
    _BaseType m_value;
};

//
// Data Type Guids
//

template <typename T> struct _TypeGuid;

template <> 
struct DECLSPEC_UUID("FD1F64B5-4BD1-473D-8D3B-A610DAC08D6C") _TypeGuid<TimeStamp>           {};

template <> 
struct DECLSPEC_UUID("6AAF7360-8583-46D2-9D10-72B3FB09804C") _TypeGuid<TimeStamp_s>         {};

template <> 
struct DECLSPEC_UUID("0F509E2E-2C6F-4F92-AC28-3E0F64973C6E") _TypeGuid<TimeStamp_ms>        {};

template <> 
struct DECLSPEC_UUID("D2C95D4F-0784-4C77-9706-B0AA1BB9DC76") _TypeGuid<TimeStamp_us>        {};

template <> 
struct DECLSPEC_UUID("5D63ECA6-F8A1-4D19-BEEB-D8489985C162") _TypeGuid<TimeStampDelta>      {};

template <> 
struct DECLSPEC_UUID("443031EE-53CC-4341-8CC5-92CC8EEBB619") _TypeGuid<TimeStampDelta_s>    {};

template <> 
struct DECLSPEC_UUID("97BD0995-6ADB-4837-9436-FAF86EE70F55") _TypeGuid<TimeStampDelta_ms>   {};

template <> 
struct DECLSPEC_UUID("DE475791-5B54-4C36-B3C2-00042A933D71") _TypeGuid<TimeStampDelta_us>   {};

template <> 
struct DECLSPEC_UUID("6E95AF6A-3DBA-445C-84C3-5BBEE1DBDA46") _TypeGuid<Real>                {};

template <> 
struct DECLSPEC_UUID("57AF6163-0B76-42D6-A489-82C92EA265FD") _TypeGuid<Char>                {};

template <> 
struct DECLSPEC_UUID("D2999573-595C-4257-9B69-4317226E8D1E") _TypeGuid<UChar>               {};

template <> 
struct DECLSPEC_UUID("51D42317-A57C-4F9C-8DF3-C6041293BE6F") _TypeGuid<UChar_hex>           {};

template <> 
struct DECLSPEC_UUID("909E4461-A527-47A0-A956-1115D462C6E2") _TypeGuid<Short>               {};

template <> 
struct DECLSPEC_UUID("58AA88F0-D275-4BA4-9192-1FA12BAFAF7C") _TypeGuid<UShort>              {};

template <> 
struct DECLSPEC_UUID("18FD1FA6-B101-4306-BCAA-680415D5F209") _TypeGuid<UShort_hex>          {};

template <> 
struct DECLSPEC_UUID("8AD86B84-CAE7-4D9F-B2F1-DAE82E7710EF") _TypeGuid<Long>                {};

template <> 
struct DECLSPEC_UUID("300CD3E0-B7F7-4EF8-AFF2-3DD722AE2690") _TypeGuid<ULong>               {};

template <> 
struct DECLSPEC_UUID("527499D8-ED20-45BE-861C-1A0B9536CCFC") _TypeGuid<ULong_hex>           {};

template <> 
struct DECLSPEC_UUID("847FD57D-5238-43C8-80BD-626A2C3F6710") _TypeGuid<LongLong>            {};

template <> 
struct DECLSPEC_UUID("5C812B43-CBB5-46B5-A58F-86A26AAFDED4") _TypeGuid<ULongLong>           {};

template <> 
struct DECLSPEC_UUID("3AEE5F7C-1788-4D74-A3C0-0B99DCD35F94") _TypeGuid<ULongLong_hex>       {};

#define LabelTypeGuid "E843C527-D327-4C95-97BE-B3168DD38770"

template <> 
struct DECLSPEC_UUID(LabelTypeGuid                     ) _TypeGuid<Label>               {};

// AutoLabel is a representation specialization of Label, identical to Label for interop purposes
template <> 
struct DECLSPEC_UUID(LabelTypeGuid                     ) _TypeGuid<AutoLabel>           {};

#undef LabelTypeGuid

#define CaseSensitiveLabelTypeGuid "E6A49CEC-B128-4cff-BF32-895FF157BC79"

template <>
struct DECLSPEC_UUID(CaseSensitiveLabelTypeGuid        ) _TypeGuid<CaseSensitiveLabel>  {};

#undef CaseSensitiveLabelTypeGuid

template <> 
struct DECLSPEC_UUID("01039240-F1E0-4A63-BA5D-8C1F463CFE1F") _TypeGuid<Percent>             {};

template <> 
struct DECLSPEC_UUID("11F72DA4-7DFF-4ADB-9BEF-034061E53A2C") _TypeGuid<ConstOne>            {};

template <> 
struct DECLSPEC_UUID("51F1B4BE-5D98-49C7-95AC-53CE4F637E18") _TypeGuid<StackTop>            {};

template <> 
struct DECLSPEC_UUID("21299FDF-45F8-4856-BF10-1F7BED13995D") _TypeGuid<PathNodeCPtr>        {};

__declspec(selectany) REFGUID DataType_TimeStamp         = __uuidof(_TypeGuid<TimeStamp>);
__declspec(selectany) REFGUID DataType_TimeStamp_s       = __uuidof(_TypeGuid<TimeStamp_s>);
__declspec(selectany) REFGUID DataType_TimeStamp_ms      = __uuidof(_TypeGuid<TimeStamp_ms>);
__declspec(selectany) REFGUID DataType_TimeStamp_us      = __uuidof(_TypeGuid<TimeStamp_us>);
__declspec(selectany) REFGUID DataType_TimeStampDelta    = __uuidof(_TypeGuid<TimeStampDelta>);
__declspec(selectany) REFGUID DataType_TimeStampDelta_s  = __uuidof(_TypeGuid<TimeStampDelta_s>);
__declspec(selectany) REFGUID DataType_TimeStampDelta_ms = __uuidof(_TypeGuid<TimeStampDelta_ms>);
__declspec(selectany) REFGUID DataType_TimeStampDelta_us = __uuidof(_TypeGuid<TimeStampDelta_us>);
__declspec(selectany) REFGUID DataType_Real              = __uuidof(_TypeGuid<Real>);
__declspec(selectany) REFGUID DataType_Char              = __uuidof(_TypeGuid<Char>);
__declspec(selectany) REFGUID DataType_UChar             = __uuidof(_TypeGuid<UChar>);
__declspec(selectany) REFGUID DataType_UChar_hex         = __uuidof(_TypeGuid<UChar_hex>);
__declspec(selectany) REFGUID DataType_Short             = __uuidof(_TypeGuid<Short>);
__declspec(selectany) REFGUID DataType_UShort            = __uuidof(_TypeGuid<UShort>);
__declspec(selectany) REFGUID DataType_UShort_hex        = __uuidof(_TypeGuid<UShort_hex>);
__declspec(selectany) REFGUID DataType_Long              = __uuidof(_TypeGuid<Long>);
__declspec(selectany) REFGUID DataType_ULong             = __uuidof(_TypeGuid<ULong>);
__declspec(selectany) REFGUID DataType_ULong_hex         = __uuidof(_TypeGuid<ULong_hex>);
__declspec(selectany) REFGUID DataType_LongLong          = __uuidof(_TypeGuid<LongLong>);
__declspec(selectany) REFGUID DataType_ULongLong         = __uuidof(_TypeGuid<ULongLong>);
__declspec(selectany) REFGUID DataType_ULongLong_hex     = __uuidof(_TypeGuid<ULongLong_hex>);
__declspec(selectany) REFGUID DataType_Label             = __uuidof(_TypeGuid<Label>);
__declspec(selectany) REFGUID DataType_AutoLabel         = __uuidof(_TypeGuid<AutoLabel>);
__declspec(selectany) REFGUID DataType_CaseSensitiveLabel = __uuidof(_TypeGuid<CaseSensitiveLabel>);
__declspec(selectany) REFGUID DataType_Percent           = __uuidof(_TypeGuid<Percent>);
__declspec(selectany) REFGUID DataType_ConstOne          = __uuidof(_TypeGuid<ConstOne>);
__declspec(selectany) REFGUID DataType_StackTop          = __uuidof(_TypeGuid<StackTop>);
__declspec(selectany) REFGUID DataType_PathNodeCPtr      = __uuidof(_TypeGuid<PathNodeCPtr>);

//
// (Axis) Type Traits
//

struct _Empty {};

template <typename T> struct _TypeTraits;

template <> struct _TypeTraits<TimeStamp>       { typedef TimeStampDelta    diff_type; };
template <> struct _TypeTraits<Real>            { typedef Real              diff_type; };
template <> struct _TypeTraits<UChar>           { typedef UChar             diff_type; };
template <> struct _TypeTraits<UChar_hex>       { typedef UChar_hex         diff_type; };
template <> struct _TypeTraits<UShort>          { typedef UShort            diff_type; };
template <> struct _TypeTraits<UShort_hex>      { typedef UShort_hex        diff_type; };
template <> struct _TypeTraits<ULong>           { typedef ULong             diff_type; };
template <> struct _TypeTraits<ULong_hex>       { typedef ULong_hex         diff_type; };
template <> struct _TypeTraits<ULongLong>       { typedef ULongLong         diff_type; };
template <> struct _TypeTraits<ULongLong_hex>   { typedef ULongLong_hex     diff_type; };
template <> struct _TypeTraits<Label>           { typedef _Empty            diff_type; };

//
// Axis Typed-Interface Guids
//

template <typename T> struct _AxisGuid;

template <> 
struct DECLSPEC_UUID("30EEADA3-99BD-4C6B-87DA-3FCC39AE56CB") _AxisGuid<TimeStamp>       {};

template <> 
struct DECLSPEC_UUID("6BF7F9FC-8436-46AC-8D50-66D012AA4A17") _AxisGuid<Real>            {};

template <> 
struct DECLSPEC_UUID("2836240B-23CB-46BE-AAB6-27B85FD47CDF") _AxisGuid<UChar>           {};

template <> 
struct DECLSPEC_UUID("9398AC83-B423-4818-95C8-BEDB717C49B4") _AxisGuid<UChar_hex>       {};

template <> 
struct DECLSPEC_UUID("D22C6FDD-D601-4BDB-888E-3E7EB1EB3370") _AxisGuid<UShort>          {};

template <> 
struct DECLSPEC_UUID("ACC20180-A03D-4044-BD3E-5DBDDCD6B923") _AxisGuid<UShort_hex>      {};

template <> 
struct DECLSPEC_UUID("5590B745-8277-411B-B7B1-E6A964FAF5A7") _AxisGuid<ULong>           {};

template <> 
struct DECLSPEC_UUID("1A75207D-FE46-4B56-A426-3E8632ABECED") _AxisGuid<ULong_hex>       {};

template <> 
struct DECLSPEC_UUID("8854CE6B-9525-44AA-ABAA-EC23C6DC8187") _AxisGuid<ULongLong>       {};

template <> 
struct DECLSPEC_UUID("0E13727C-E54F-46E4-9AB1-22CE44EAB095") _AxisGuid<ULongLong_hex>   {};

template <> 
struct DECLSPEC_UUID("BC900078-D035-4051-B2C9-7A178EF07418") _AxisGuid<Label>           {};

template <typename T, typename AxisGuid = _AxisGuid<T> >
struct IAxisT : public IAxis
{
    typedef typename _TypeTraits<T>::diff_type diff_type;

    STDMETHOD(SetAxisRange)(const T& start, const T& end) PURE;
    STDMETHOD_(VOID, GetAxisRange)(T& start, T& end) PURE;
    STDMETHOD(AddInterval)(const T& start, const T& end, LPCWSTR szIntervalLabel) PURE;
    STDMETHOD_(VOID, GetViewRange)(T& start, T& end) PURE;
    STDMETHOD_(VOID, GetUpdateRange)(T& start, T& end) PURE;
    STDMETHOD_(diff_type, GetPreferredResolution)(const diff_type& res) PURE;
    STDMETHOD_(T, GetPreferredMax)(const T& end) PURE;
};

typedef IAxisT< TimeStamp >     IAxisTimeStamp;
typedef IAxisT< Real >          IAxisReal;
typedef IAxisT< UChar >         IAxisUChar;
typedef IAxisT< UChar_hex >     IAxisUChar_hex;
typedef IAxisT< UShort >        IAxisUShort;
typedef IAxisT< UShort_hex >    IAxisUShort_hex;
typedef IAxisT< ULong >         IAxisULong;
typedef IAxisT< ULong_hex >     IAxisULong_hex;
typedef IAxisT< ULongLong >     IAxisULongLong;
typedef IAxisT< ULongLong_hex > IAxisULongLong_hex;
typedef IAxisT< Label >         IAxisLabel;

template <typename T> struct _CAxisGuid;

template <> 
struct DECLSPEC_UUID("33DC4F82-64BE-49EB-B929-6183AB604A64") _CAxisGuid<TimeStamp>      {};

template <> 
struct DECLSPEC_UUID("5092E22D-C53E-4120-BA47-73495A12ABA4") _CAxisGuid<Real>           {};

template <> 
struct DECLSPEC_UUID("0123890F-C1AE-4226-84C2-B561F6F73D5D") _CAxisGuid<UChar>          {};

template <> 
struct DECLSPEC_UUID("BD732599-E66B-49E2-9547-D03A66F28C93") _CAxisGuid<UChar_hex>      {};

template <> 
struct DECLSPEC_UUID("6BC0FD71-326E-4A81-9CAF-8DAA012FACFC") _CAxisGuid<UShort>         {};

template <> 
struct DECLSPEC_UUID("113CF7E3-526D-4127-9EC4-B1990B353E1A") _CAxisGuid<UShort_hex>     {};

template <> 
struct DECLSPEC_UUID("FE3448AC-2B0E-4003-90CA-D3FCD11AF00A") _CAxisGuid<ULong>          {};

template <> 
struct DECLSPEC_UUID("FBD86E43-0F05-44F3-B8BC-29EC7D4D9467") _CAxisGuid<ULong_hex>      {};

template <> 
struct DECLSPEC_UUID("FAE0E260-DEC8-4A6D-8AA4-8F7212596970") _CAxisGuid<ULongLong>      {};

template <> 
struct DECLSPEC_UUID("E8507F1F-49AF-4F53-945E-7A9B54172241") _CAxisGuid<ULongLong_hex>  {};

template <> 
struct DECLSPEC_UUID("2536492D-78B1-477C-8CFD-57395A2E1597") _CAxisGuid<Label>          {};

//
// GraphingEngine
//

MIDL_INTERFACE("EC504AE3-D6C0-44F2-AE9B-5D98A409AD17")
IGraphingEngine : public IUnknown
{
    // Legend
    STDMETHOD(SetupLegend)(
        LPCWSTR Title, 
        const ILegend::LegendProperties& props,
        USHORT NumSeries,
        ILegend** pLegend) PURE;

    // SeriesManager
    STDMETHOD_(USHORT, GetNumSeries)() PURE;

    STDMETHOD(SetNumSeries)(USHORT NumSeries) PURE;

    STDMETHOD(SetSize)(USHORT iSeries, SIZE_T cSize) PURE;

    STDMETHOD(LinkSeriesByDim)(USHORT seriesToLink, USHORT dimToLink, USHORT srcSeries ) PURE;

    STDMETHOD(SetSeriesData)(USHORT iSeries, USHORT iDim, REFGUID rguidData, LPVOID rgObj, SIZE_T count, SIZE_T stride) PURE;
    
    template <typename Q>
    HRESULT SetSeriesData(USHORT iSeries, USHORT iDim, const Q* rgObj, SIZE_T count, SIZE_T stride = sizeof(Q))
    {
        return SetSeriesData(iSeries, iDim, __uuidof(_TypeGuid<Q>), (LPVOID) rgObj, count, stride);
    }

    STDMETHOD(SetAxis)(USHORT dim, IAxis* pAxis) PURE;

    STDMETHOD(GetAxis)(USHORT dim, REFIID riid, LPVOID* ppv) PURE;
    
    template <typename Q>
    HRESULT GetAxis(USHORT dim, Q** ppQ)
    {
        return GetAxis(dim, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    STDMETHOD(CreateAxis)(REFCLSID rclsid, REFIID riid, LPVOID* ppv) PURE;
    
    template <typename Q>
    HRESULT CreateAxis(REFCLSID rclsid, Q** ppQ)
    {
        return CreateAxis(rclsid, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }
    
    template <typename T>
    HRESULT CreateAxis(IAxisT<T>** ppQ)
    {
        return CreateAxis(__uuidof(_CAxisGuid<T>), ppQ);
    }

    STDMETHOD(AddContextMenuItem)(UINT_PTR uIDNewItem, LPCWSTR wszNewItem) PURE;

    STDMETHOD(SetToolTipFormat)( LPCWSTR wszFormat ) PURE;

    STDMETHOD_(BOOL, GetAutomaticRescale)() PURE;

    STDMETHOD_(VOID, InvalidateFrame)() PURE;

    STDMETHOD(SetTitle)(LPCWSTR wszTitle) PURE;
};

MIDL_INTERFACE("10EE9CF6-A4A2-4862-898B-1AC8FC5E7854")
IGraphingEngine2 : public IGraphingEngine
{
    enum Flags
    {
        Flag_LightTooltips         = 0x00000001,
        Flag_AllowSymbolsInLegends = 0x00000002,
    };

    STDMETHOD_(DWORD, GetFlags)() PURE;
};

MIDL_INTERFACE("ADDFEED3-BBCE-4b5e-B4B6-4304C2C7D130")
IGraphingEngine3 : public IGraphingEngine2
{
    enum DialogFlags
    {
        DIALOG_FLAG_NONE                   = 0,
        DIALOG_FLAG_ALLOW_MODIFY_STARTTIME = 0x01,
        DIALOG_FLAG_ALLOW_MODIFY_ENDTIME   = 0x02,
        DIALOG_FLAG_ALLOW_MODIFY_THREAD    = 0x04,
        DIALOG_FLAG_ALLOW_MODIFY_BOTHTIMES = DIALOG_FLAG_ALLOW_MODIFY_STARTTIME | DIALOG_FLAG_ALLOW_MODIFY_ENDTIME,
        DIALOG_FLAG_ALLOW_MODIFY_ALL       = DIALOG_FLAG_ALLOW_MODIFY_BOTHTIMES | DIALOG_FLAG_ALLOW_MODIFY_THREAD
    };

    STDMETHOD(ShowIntervalSelectDialogBox)(
        _Inout_ TimeStamp& StartTime,
        _Inout_ TimeStamp& EndTime,
        _In_  DialogFlags flags
        ) const PURE;

    STDMETHOD(ShowIntervalThreadSelectDialogBox)(
        _Inout_ TimeStamp& StartTime,
        _Inout_ TimeStamp& EndTime,
        _Inout_ LONG& ThreadId,
        _In_  DialogFlags flags
        ) const PURE;
};

struct IMiniGraph;

MIDL_INTERFACE("FB4D7138-D842-4EFE-89C1-FB97DD47C913")
IGraphingEngineFactory : public IUnknown
{
    STDMETHOD(CreateAggGraphingEngine)(
        IMiniGraph* pMiniGraphOuter, 
        USHORT NumDim, 
        USHORT NumSeries,
        REFIID riid, LPVOID* ppv) PURE;

    template <typename Q>
    HRESULT CreateAggGraphingEngine(
        IMiniGraph* pMiniGraphOuter, 
        USHORT NumDim, 
        USHORT NumSeries,
        Q** ppQ)
    {
        return CreateAggGraphingEngine(pMiniGraphOuter, NumDim, NumSeries, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }
};

class DECLSPEC_UUID("78221761-BD88-4FDE-96AA-D385E98107D0")
CGraphingEngineFactory;


//
// Summary Tables
//

MIDL_INTERFACE("5329A79C-41EB-452B-B68E-C8680AAA85A7")
ISummaryTable : public IUnknown
{
    enum ColumnType {COLUMN_TYPE_KEY, COLUMN_TYPE_VALUE};
    enum AggregationMode {NO_AGGREGATION, AVERAGE, SUM, COUNT, MIN, MAX, UNIQUE_COUNT};
    enum SortingMode {UNSORTED, ASCENDING, DESCENDING};
    
    struct ColumnProps {
        GUID                ColGuid;
        const GUID*         pguidDataType;
        WCHAR               Label[64];

        BOOL                bVisible;

        ColumnType          Type;
        AggregationMode     AggrMode;
        SortingMode         SortMode;

        SHORT               SortPriority;
        SHORT               DefDispDepth;
        USHORT              ColWidth;
    };

    STDMETHOD(SetStatusBarText)(LPCWSTR wszText) PURE;

    STDMETHOD(ShowTable)(SIZE_T iInitialSortCol) PURE;

    STDMETHOD(SetData)(SIZE_T iRow, SIZE_T iCol, REFGUID rguidData, LPVOID pObj) PURE;

    template <typename Q>
    HRESULT SetData(SIZE_T iRow, SIZE_T iCol, const Q& obj)
    {
        return SetData(iRow, iCol, __uuidof(_TypeGuid<Q>), (LPVOID) &obj);
    }

    template <typename Q>
    HRESULT SetData(SIZE_T iRow, SIZE_T iCol, const Q* pObj)
    {
        return SetData(iRow, iCol, __uuidof(_TypeGuid<Q>), (LPVOID) pObj);
    }
};


MIDL_INTERFACE("44171DDC-C56D-459C-A015-CA4B14AACA0C")
ISummaryTable2 : public ISummaryTable
{
    STDMETHOD(AddDependency)(
        _In_  IUnknown* pUnk
        ) PURE;
};

MIDL_INTERFACE("68FE04D6-2744-4cb7-9D9B-DC2D83262F80")
ISummaryTableServices : IUnknown
{
    STDMETHOD(GetColumnIdFromLabel)(
        _In_  LPCWSTR wszLabel,
        _Out_ ULONG   *piColumn
        ) const PURE;

    STDMETHOD(GetCellValue)(
        _In_ ULONG iSelectedRow, 
        _In_ ULONG iColumn,
        _Out_ const void** ppResult
        ) const PURE;

    enum DialogFlags
    {
        DIALOG_FLAG_NONE                   = 0,
        DIALOG_FLAG_ALLOW_MODIFY_STARTTIME = 0x01,
        DIALOG_FLAG_ALLOW_MODIFY_ENDTIME   = 0x02,
        DIALOG_FLAG_ALLOW_MODIFY_BOTHTIMES = DIALOG_FLAG_ALLOW_MODIFY_STARTTIME | DIALOG_FLAG_ALLOW_MODIFY_ENDTIME        
    };

    STDMETHOD(ShowIntervalSelectDialogBox)(
        _Inout_ TimeStamp& StartTime,
        _Inout_ TimeStamp& EndTime,
        _In_  DialogFlags flags
        ) const PURE;

    STDMETHOD_(INT, ShowMessageBox)(
        _In_opt_ LPCWSTR wszText,
        _In_opt_ LPCWSTR wszCaption,
        _In_ UINT uType
        ) const PURE;    
};


MIDL_INTERFACE("AE3D8DF2-9644-40AE-B926-B2A7DEFB8ACD")
ISummaryTableServices2 : IUnknown
{
    STDMETHOD(GetDimensions)(
        _Out_opt_ ULONG* piRowCount,
        _Out_opt_ ULONG* piAggregatedRowCount,
        _Out_opt_ ULONG* piColumnCount,
        _Out_opt_ ULONG* piVisibleColumnCount
        ) const PURE;

    STDMETHOD(LoadColumnLayoutFromXPerfViewProfile)(
        _In_ LPCWSTR wszProfileName
        ) PURE;

    STDMETHOD(ApplyColumnLayout)(
        _In_  ULONG nColumns,
        _In_reads_(nColumns) ISummaryTable::ColumnProps Columns[]
        ) PURE;

    STDMETHOD(ExpandAllGroups)() PURE;

    STDMETHOD(ExpandKeys)(
        _In_  ULONG nKeys
        ) PURE;

    STDMETHOD(ExpandRows)(
        _In_  ULONG nColumn,
        _In_  ULONG nMaxRows
        ) PURE;

    enum GetCellValueFlags
    {
        GetCellValueFlags_None = 0,
        GetCellValueFlags_OmitBranchSymbols = 0x01,
        GetCellValueFlags_FillReplicatedCells = 0x02,
        GetCellValueFlags_NoCsvCommaConversion = 0x04,
    };

    STDMETHOD(GetCellValueAsString)(
        _In_    ULONG iRow, 
        _In_    ULONG iColumn,
        _In_    DWORD dwFlags,
        _Out_writes_to_opt_(nChars, nChars) WCHAR StringBuffer[],
        _Inout_ SIZE_T &nChars
        ) const PURE;

    STDMETHOD(GetColumnHeaderAsString)(
        _In_  ULONG iColumn,
        _Out_ LPCWSTR* pwszString
        ) const PURE;
};


MIDL_INTERFACE("0293C7BE-C0C4-4A55-8B35-B50FD3D71D5D")
ISummaryTableServices3 : public ISummaryTableServices2
{
    STDMETHOD(IsBottomRow)(
        _In_  ULONG iRow
        ) const PURE;
};


MIDL_INTERFACE("803A3366-D700-48D4-A766-64315FC3715A")
ISummaryTableFactory : public IUnknown
{
public:
    STDMETHOD(CreateSummaryTable)(
        _In_  LPCWSTR wszTitle, 
        _In_  SIZE_T NumRows,
        _In_  SIZE_T NumCols,
        _In_reads_(NumCols) const ISummaryTable::ColumnProps* rgColumnProps,
        _In_  REFIID riid, 
        _Outptr_ LPVOID* ppv) PURE;

    template <typename Q>
    HRESULT CreateSummaryTable(
        _In_  LPCWSTR wszTitle, 
        _In_  SIZE_T NumRows,
        _In_  SIZE_T NumCols,
        _In_reads_(NumCols) const ISummaryTable::ColumnProps* rgColumnProps,
        _Outptr_ Q** ppQ)
    {
        return CreateSummaryTable(wszTitle, NumRows, NumCols, rgColumnProps, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }
};

MIDL_INTERFACE("51802F44-9927-49D8-8D52-86EB59AA7807")
ISummaryTableFiller : public IUnknown
{
public:

    STDMETHOD(GetColumnSet)(
        _Inout_ SIZE_T &NumEntries,
        _Out_writes_to_opt_(NumEntries, NumEntries) ISummaryTable::ColumnProps rgColumnsOut[]        
        ) PURE;
    
    STDMETHOD(BuildSummaryTable)(
        _In_  TimeStamp& BeginTime,
        _In_  TimeStamp& EndTime,
        _In_  ISummaryTableFactory* SummaryTableFactory,
        _In_opt_ IPropertyBag* ExtraArguments,
        _Out_ ISummaryTable** SummaryTableOut
        ) PURE;

    STDMETHOD(BuildSummaryTableFromSelection)(
        _In_  ISelection* Selection,
        _In_opt_ IPropertyBag* ExtraArguments,
        _Out_ ISummaryTable** SummaryTableOut
        ) PURE;

    HRESULT BuildSummaryTable(
        _In_  ISelection* Selection,
        _In_opt_ IPropertyBag* ExtraArguments,
        _Out_ ISummaryTable** SummaryTableOut
        )
    {
        return BuildSummaryTableFromSelection(Selection, ExtraArguments, SummaryTableOut);
    }
};

// A filler addin that is using a WPA Add-In Manifest must implement this interface in order to show up in WPA's Graph Explorer
MIDL_INTERFACE("932B3811-5F9F-4489-B614-A270A4F525FC")
ISummaryTableFiller2 : public ISummaryTableFiller
{
public:
    STDMETHOD(IsDataAvailable)(
        __out BOOL* pbResult
        );
};

MIDL_INTERFACE("3EC7F7C6-62E3-47AF-8613-8DCFC84A4AEE")
IServiceCallback : IUnknown
{
    // pSummaryTableServices          Allows the callback to query data from the summary table
    //                                that the command was invoked from.
    // wszMenuName:                   The name of the context menu command that was clicked.
    // rgSelectedRows/nSelectedRows:  The array and size of the rows that were selected.
    // wszFocusedColumnLabel:         The name of the column that was focused under the mouse
    //                                when the menu was selected.
    // rgFocusedRows/nFocusedRows:    An array and size which indicates either 
    //                                the focused row, or all rows in the focused group.
    // focusedHierarchicalDepth:      In the case the selected group is heirarchical, this 
    //                                represents the depth in the hierarchy that was selected.
    //                                Currently always 0, which is the root of the hierarchy.
    //

    STDMETHOD(Callback)(
        _In_ ISummaryTableServices* pSummaryTableServices,
        _In_ ISelection* pSelection,
        _In_ LPCWSTR wszMenuName,
        _In_reads_(nSelectedRows) ULONG* rgSelectedRows,
        _In_ SIZE_T nSelectedRows,
        _In_ LPCWSTR wszFocusedColumnLabel,
        _In_reads_(nFocusedRows) ULONG* rgFocusedRows,
        _In_ SIZE_T nFocusedRows,
        _In_ ULONG focusedHierarchicalDepth
        ) PURE;
};

MIDL_INTERFACE("F0716D64-E23B-427F-A7F3-2358444619E1")
ISummaryTable3 : public ISummaryTable2
{
    STDMETHOD(AddAlternativeColumnProperties)(
        _In_  LPCWSTR wszHeaderName,
        _In_  SIZE_T nCols,
        _In_  const ISummaryTable::ColumnProps* rgColumnProps
        ) PURE;

    STDMETHOD(SetTreeIdentityColumn)(
        _In_  LPCWSTR wszColumnLabel,
        _In_opt_ LPCWSTR wszViewName = NULL
        ) PURE;

    STDMETHOD(GetTreeIdentityColumn)(
        _Outptr_ LPCWSTR* pwszColumnLabel,
        _In_opt_ LPCWSTR wszViewName = NULL
        ) PURE;

    STDMETHOD(AddCustomCommand)(
        _In_ LPCWSTR   wszMenuName,
        _In_reads_(nColumnLabel) LPCWSTR* rgColumnLabel, 
        _In_ SIZE_T    nColumnLabel,
        _In_ IServiceCallback* pCallback
        ) PURE;
};

MIDL_INTERFACE("FEDE9337-7D75-4081-AC28-B0D0537BE99A")
ISummaryTable4 : public ISummaryTable3
{
    STDMETHOD(CreateDiffSummaryTableFromBaseline)(
        _In_  ISummaryTable* pBaselineSummaryTable,
        _In_  REFIID riid, 
        _Outptr_ LPVOID* ppvDiffSummaryTable,
        _In_  BOOL fVisible = FALSE
        ) PURE;

    template <typename Q>
    HRESULT CreateDiffSummaryTableFromBaseline(
        _In_  ISummaryTable* pBaselineSummaryTable,
        _Outptr_ Q** ppDiffSummaryTable,
        _In_  BOOL fVisible = FALSE
        )
    {
        return CreateDiffSummaryTableFromBaseline(pBaselineSummaryTable, __uuidof(Q), reinterpret_cast<LPVOID*>(ppDiffSummaryTable), fVisible);
    }
};

MIDL_INTERFACE("A22342B6-C2FD-49E2-A4F4-68AF5A02CD3C")
ISummaryTableDynamicHeadersProvider : public IUnknown
{
    STDMETHOD(GetContextColumn)(
        _Out_ ULONG* pCol
        ) PURE;

    STDMETHOD(MoveToRow)(
        _In_  REFGUID rguidData,
        _In_  LPCVOID pObjContext
        ) PURE;

    STDMETHOD(GetDynamicHeader)(
        _In_  ULONG iCol,
        _Outptr_result_maybenull_ LPCWSTR* pwszHeader
        ) PURE;
};


//
// MiniGraphs
//

struct IGraphFactory;
struct ISidePane;

MIDL_INTERFACE("8C42CE57-98D7-4586-84EA-626BC3B720EE")
ISelection : public IUnknown
{
    STDMETHOD_(VOID, GetSelectedRange)(
        TimeStamp& start, 
        TimeStamp& end) PURE;
    
    STDMETHOD(CreateSummaryTable)(
        _In_  LPCWSTR wszTitle, 
        _In_  SIZE_T NumRows,
        _In_  SIZE_T NumCols,
        _In_reads_(NumCols) const ISummaryTable::ColumnProps* rgColumnProps,
        _In_  REFIID riid, 
        _Outptr_ LPVOID* ppv) PURE;

    template <typename Q>
    HRESULT CreateSummaryTable(
        _In_  LPCWSTR wszTitle, 
        _In_  SIZE_T NumRows,
        _In_  SIZE_T NumCols,
        _In_reads_(NumCols) const ISummaryTable::ColumnProps* rgColumnProps,
        _Outptr_ Q** ppQ)
    {
        return CreateSummaryTable(wszTitle, NumRows, NumCols, rgColumnProps, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    STDMETHOD(CreateDetailGraph)(
        LPCWSTR wszTitle, 
        IUnknown* pGraphUnk,
        ISidePane* pSidePane = NULL) PURE;
};

MIDL_INTERFACE("2B9C9DFE-E3E9-4318-AD46-62F478EAD282")
ISelection2 : public ISelection
{
    STDMETHOD(CreateSelection)(
        _In_  TimeStamp StartTime,
        _In_  TimeStamp EndTime,
        _In_  REFIID riid, 
        _Inout_ LPVOID* ppv) const PURE;

    template <typename Q>
    HRESULT CreateSelection(
        _In_  TimeStamp StartTime,
        _In_  TimeStamp EndTime,
        _Inout_ Q** ppQ) const
    {
        return CreateSelection(StartTime, EndTime, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }
};

MIDL_INTERFACE("3032BB67-5AB6-48D2-AB2E-A5963ABAD955")
ISelection3 : public ISelection2
{
    STDMETHOD(SetTableVisibility)(
        _In_ bool fVisible
        ) PURE;
};

MIDL_INTERFACE("1B9F3780-49B5-4801-9785-C6450E51857A")
IMenuItemWithObjectHandler : public IUnknown
{
    STDMETHOD(IsContextMenuItemEnabled)(
        UINT_PTR cmdId,
        USHORT iSeries,
        SIZE_T iObject) PURE;

    STDMETHOD(HandleContextMenuEvent)(
        UINT_PTR cmdId, 
        ISelection* pSelection,
        USHORT iSeries,
        SIZE_T iObject) PURE;

    static const SIZE_T iSentinel = (SIZE_T)(-1);
};

MIDL_INTERFACE("42939131-1A14-4F4A-AFE1-2D1E0435FA7C")
IMiniGraph : public IUnknown
{
    STDMETHOD(InitializeGraph)() PURE;
    
    STDMETHOD(IsDataAvailable)() PURE;
    
    STDMETHOD(UpdateData)() PURE;
    
    STDMETHOD(HandleContextMenuEvent)(
        UINT_PTR cmdId, 
        ISelection* pSelection ) PURE;
};

MIDL_INTERFACE("61BC9471-0781-4a44-B7E0-140E133DD935")
ISeriesControl : public IUnknown
{
    STDMETHOD(GetSeriesPropsAndName)(
        _In_  USHORT iSeries, 
        _Out_ ILegend::SeriesProperties& seriesProps
        ) PURE;
};

MIDL_INTERFACE("8A888345-6649-4C82-B4D2-0D9FC11E0DC6")
ITooltipHandler : public IUnknown
{
    STDMETHOD(GetTooltip)(
        _In_  USHORT tooltipId,
        _In_  USHORT seriesId,
        _In_  SIZE_T rowId,
        _In_  SIZE_T cchTooltip,
        _Out_writes_(cchTooltip) LPWSTR wchTooltip
        ) PURE;
};

MIDL_INTERFACE("E34E2413-CF07-4417-9D3F-8D404A7CBCF0")
ILegendMonitor : public IUnknown
{
    STDMETHOD(OnSeriesStateChange)(
        _In_  ULONG SeriesId,
        _In_  BOOL fEnabled
        ) PURE;
};

//
// Graph Factories
//

MIDL_INTERFACE("E5304574-0622-4D12-91B5-5C8FD38E6979") 
IGraphFactory : public IUnknown
{
    //
    // The GraphPosition constants define the default position of a 
    // graph in the main XPerfView window.  Positions are structured in 
    // a hierarchy of Classes, Groups and Graphs.  Each constant 
    // represents a base order for elements in that Class or Group.
    //
    // NOTE: Gaps between Classes and Groups are designed to allow
    // for later insertion of new graphs in the sequence. It is 
    // recommended to skip one GraphIncr when defining a new graph,
    // one GroupIncr when defining a new group and one Class when
    // defining a new class.  For instance, first Core group would be 
    // at 1 * GroupIncr, second at 3 * GroupIncr, and so on.

    enum GraphPosition {
        // Guideline spacing
        GraphPos_GraphIncr      = 0x00001000,
        GraphPos_GroupIncr      = 0x01000000,
        GraphPos_ClassIncr      = 0x10000000,

        //
        // Constants defining classes and groups
        //

        // Class Core is reserved for core graphs
        GraphPos_ClassCore      = -0x60000000,
        GraphPos_GroupCpu       = GraphPos_ClassCore + 0x01000000,
        GraphPos_GroupDisk      = GraphPos_ClassCore + 0x03000000,
        GraphPos_GroupGpu       = GraphPos_ClassCore + 0x04000000,
        GraphPos_GroupMemory    = GraphPos_ClassCore + 0x05000000,
        GraphPos_GroupNetwork   = GraphPos_ClassCore + 0x07000000,
        GraphPos_GroupProcess   = GraphPos_ClassCore + 0x09000000,

        // Class User is reserved for user (3rd party) graphs
        GraphPos_ClassUser      = 0x00000000,

        // Class Test is reserved for testing purposes
        GraphPos_ClassTest      = 0x7FFF0000,
    };

    STDMETHOD(CreateGraph)(
        /* [in] */ REFIID riid, 
        /* [out] */ LPVOID* ppv ) PURE;

    template <typename Q>
    HRESULT CreateGraph( Q** ppQ )
    {
        return CreateGraph(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    STDMETHOD_(INT, GetDefaultPosition)() PURE;
    STDMETHOD_(ULONG, GetDefaultHeight)() PURE;
    STDMETHOD_(BOOL, GetDefaultEnabled)() PURE;
    STDMETHOD_(BOOL, GetDefaultVisible)() PURE;
};

//
// SidePanes
//

MIDL_INTERFACE("74E07E13-8A78-4B4E-8E9F-4D0E51540A7B")
ISidePane : public IUnknown
{
    STDMETHOD(OnCreate)(HWND hwndParent) PURE;
    STDMETHOD_(LRESULT, WndProc)(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) PURE;
    STDMETHOD_(LPCWSTR, GetTitle)() PURE;
};

} // namespace XPerfGUI

