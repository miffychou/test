/*++

Copyright (c) 2009 Microsoft Corporation

Module Name:

    XPerfAddIn_d3d.hpp

Abstract:

    D3D (10,11,dxgi) XPerfCore AddIn header publishing infosource interfaces

Author:

    Daniel Roman (danielro)

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>                // include XPerfCore main header
#include <XPerfAddIn_Core.hpp>          // AddIn_D3D references core infosources


namespace XPerfAddIn
{
MIDL_INTERFACE("B01DFD22-539F-4a25-A323-32C3693962F8")
ID3DInfoSource : public IUnknown
{
public:

    typedef enum D3D_DEVICE_INTERFACE
    {
        D3D_DEVICE_INTERFACE_10_0	= 0xa000,
        D3D_DEVICE_INTERFACE_10_1	= 0xa100,
        D3D_DEVICE_INTERFACE_11_0	= 0xb000
    };

    typedef enum D3D_RESOURCE_DIMENSION
    {
        D3D_RESOURCE_DIMENSION_BUFFER		= 1,
        D3D_RESOURCE_DIMENSION_TEXTURE1D	= 2,
        D3D_RESOURCE_DIMENSION_TEXTURE2D	= 3,
        D3D_RESOURCE_DIMENSION_TEXTURE3D	= 4
    };

    struct D3D_BASE_DATA : public Temporal
    {
        ULONG ThreadID;	// Add others if necessary
        ULONG ProcessID;
        D3D_BASE_DATA(): ThreadID ( (ULONG)-1 ), ProcessID( (ULONG)-1 ){};
    };

    struct D3D_BASE_DEVICE_DATA : public D3D_BASE_DATA
    {
        union
        {
            void *pID3D10Device;
            void *pID3D10_1Device;
            void *pID3D11Device;
        };
        D3D_DEVICE_INTERFACE DeviceInterface;
    };

    struct D3D_DEVICE_DATA : public D3D_BASE_DEVICE_DATA
    {
        void *pIDXGIDevice;
        void *pIDXGIAdapter;
        UINT32 CreationFlags;
        UINT32 hKMAdapter;
        void *hUMAdapter;
        UINT64 UMAdapterVersion;
        UINT32 hKMDevice;
        void *hUMDevice;
        UINT64 UMDeviceVersion;
        UINT32 UMDeviceFlags;
        UINT32 FeatureLevel;	// D3D10_1 and D3D11 only
        UINT32 FeatureSupport;	// D3D11 only
    };

    struct D3D_RESOURCE_DATA : public D3D_BASE_DEVICE_DATA
    {
        void *pIDXGISurface;
        UINT32 Dimension;
        UINT32 Usage;
        UINT32 Width;
        UINT32 Height;
        UINT32 Depth;
        UINT32 MipLevels;
        UINT32 ArraySize;
        UINT32 Format;
        UINT32 SampleCount;
        UINT32 SampleQuality;
        UINT32 BindFlags;
        UINT32 CPUAccessFlags;
        UINT32 MiscFlags;
        UINT32 hKMResource;
        void *hUMResource;
        UINT32 UMResourceMiscFlags;
        union
        {
            void *pID3D10Resource;
            void *pID3D11Resource;
        };
        UINT32 StructureByteStride;	// D3D11 only
        D3D_RESOURCE_DIMENSION ResourceDimension;
    };

    struct DXGI_FACTORY_DATA : public D3D_BASE_DATA
    {
        void *pIDXGIFactory;
        UINT32 Mode;
    };

    struct DXGI_ADAPTER_DATA : public D3D_BASE_DATA
    {
        void *pIDXGIAdapter;
        void *pIDXGIFactory;
        UINT32 KMTAdapterHandle;
        void *ThunkDLLHandle;
        bool SharedResources;
    };

    struct DXGI_OUTPUT_DATA : public D3D_BASE_DATA
    {
        void *pIDXGIOutput;
        void *pIDXGIAdapter;
        UINT32 VidPnSourceID;
        LPCWSTR GDIDeviceName;
    };

    struct DXGI_SWAPCHAIN_DATA : public D3D_BASE_DATA
    {
        void *pIDXGISwapChain;
        void *pIDXGIFactory;
        void *pIDXGIDevice;
        void *pIDXGIOutput;
        UINT8 UserBackBufferCount;
        UINT8 BackBufferCount;
        void *ppBackBuffers;
        void *pPrimary;
        void *pProxyPrimary;
        UINT32 Width;
        UINT32 Height;
        UINT32 RefreshNumerator;
        UINT32 RefreshDenominator;
        UINT32 Format;
        UINT32 ScanlineOrdering;
        UINT32 Scaling;
        UINT32 SampleCount;
        UINT32 SampleQuality;
        UINT32 Usage;
        void *OutputWindow;
        bool Windowed;
        UINT32 SwapEffect;
        UINT32 Flags;
    };

    struct DXGI_PRESENT_DATA : public D3D_BASE_DATA
    {
        void* pIDXGISwapChain;
        UINT32 Flags;
        UINT32 SyncInterval;
        UINT32 Result;
    };

    struct DXGI_FRAMESTATISTICS_DATA : public D3D_BASE_DATA
    {
        UINT32 ReturnValue;
        UINT32 PresentCount;
        UINT32 PresentRefreshCount;
        UINT32 SyncRefreshCount;
        UINT64 SyncQPCTime;
    };

    struct DXGI_RESIZEBUFFERS_DATA : public D3D_BASE_DATA
    {
        void *pIDXGISwapChain;
        UINT8 OldUserBackBufferCount;
        UINT8 OldBackBufferCount;
        void *ppOldBackBuffers;
        void *pOldPrimary;
        void *pOldProxyPrimary;
        UINT32 OldWidth;
        UINT32 OldHeight;
        UINT32 OldFormat;
        UINT32 OldFlags;
        UINT8 NewUserBackBufferCount;
        UINT8 NewBackBufferCount;
        void *ppNewBackBuffers;
        void *pNewPrimary;
        void *pNewProxyPrimary;
        UINT32 NewWidth;
        UINT32 NewHeight;
        UINT32 NewFormat;
        UINT32 NewFlags;
        UINT32 ReturnValue;
    };

    struct DXGI_RESIZETARGET_DATA : public D3D_BASE_DATA
    {
        void *pIDXGISwapChain;
        UINT32 Width;
        UINT32 Height;
        UINT32 RefreshNumerator;
        UINT32 RefreshDenominator;
        UINT32 Format;
        UINT32 ScanlineOrdering;
        UINT32 Scaling;
        bool Windowed;
        void *pOldPrimary;
        void *pOldProxyPrimary;
        void *pNewPrimary;
        void *pNewProxyPrimary;
        UINT32 ReturnValue;
    };

    struct DXGI_SETFULLSCREENSTATE_DATA : public D3D_BASE_DATA
    {
        void *pIDXGISwapChain;
        bool OldWindowed;
        void *pOldOutput;
        void *pOldPrimary;
        void *pOldProxyPrimary;
        UINT32 ReturnValue;
        bool NewWindowed;
        void *pNewOutput;
        void *pNewPrimary;
        void *pNewProxyPrimary;
    };

    typedef enum DXGID3DFunctionBracketEvent
    {
        DXGID3D_ETW_FACTORY_CREATE         = 0,
        DXGID3D_ETW_FACTORY_DESTROY        = 1,
        DXGID3D_ETW_SWAPCHAIN_CREATE       = 2,
        DXGID3D_ETW_SWAPCHAIN_DESTROY      = 3,
        DXGID3D_ETW_ADAPTER_CREATE         = 4,
        DXGID3D_ETW_ADAPTER_DESTROY        = 5,
        DXGID3D_ETW_HARDWARE_UMD_LOAD      = 6,

        // D3D events
        DXGID3D_ETW_D3D11COREDEVICECREATE  = 65536,
        DXGID3D_ETW_KMDCREATEDEVICE        = 65537,
        DXGID3D_ETW_UMDCREATEDEVICE        = 65538,
        DXGID3D_ETW_UMD10CREATEDEVICE      = 65539,
        DXGID3D_ETW_UMDOPENADAPTER         = 65540,
        DXGID3D_ETW_UMD9CREATEDEVICE       = 65541,
        DXGID3D_ETW_UMD9POSTCREATEDEVICE   = 65542,
        DXGID3D_ETW_UMD9REOPENADAPTER      = 65543,
        DXGID3D_ETW_UNDEFINED              = 0xffffffff,
    };

    struct DXGID3D_FUNCTIONBRACKETEVENT_DATA : public D3D_BASE_DATA
    {
        DXGID3DFunctionBracketEvent Event;
    };

public:

    typedef bool (*PfnFilterCallback)( const Temporal *pMark, PVOID pvContext );
    
    STDMETHOD(QueryDeviceCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryDeviceData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const D3D_DEVICE_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryResourceCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryResourceData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const D3D_RESOURCE_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryFactoryCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryFactoryData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_FACTORY_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryAdapterCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryAdapterData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_ADAPTER_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryOutputCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryOutputData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_OUTPUT_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QuerySwapChainCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QuerySwapChainData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_SWAPCHAIN_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

        STDMETHOD(QueryPresentCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryPresentData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_PRESENT_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryFrameStatisticsCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryFrameStatisticsData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_FRAMESTATISTICS_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryResizeBuffersCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryResizeBuffersData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_RESIZEBUFFERS_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryResizeTargetCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryResizeTargetData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_RESIZETARGET_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QuerySetFullscreenStateCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QuerySetFullscreenStateData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGI_SETFULLSCREENSTATE_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryDXGID3DFunctionBracketEventCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD(QueryDXGID3DFunctionBracketEventData)(
        // T*[]
        __out_ecount_part_opt(nEntries, nEntries) const DXGID3D_FUNCTIONBRACKETEVENT_DATA* rgpData[],
        __inout SIZE_T& nEntries,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        // general filtering
        __in_opt PfnFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvContext = NULL
        ) const PURE;
};


}
