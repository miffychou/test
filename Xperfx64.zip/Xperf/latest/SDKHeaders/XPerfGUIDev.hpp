/*++

Copyright (c) 2004 Microsoft Corporation

Module Name:

    XPerfGuiDev.hpp

Abstract:

    C++ client-side support for XPerfGUI.hpp

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfCoreDev.hpp>

#include <XPerfGUI.hpp>       // Main XPerfGUI header

#pragma warning(push)
#pragma warning(disable:4245) // 'conversion' : conversion from 'type1' to 'type2', signed/unsigned mismatch
#pragma warning(disable:4995) // 'function': name was marked as #pragma deprecated
#pragma warning(disable:4996) // 'function': was declared deprecated
#include <atlcoll.h>
#include <atlstr.h>
#pragma warning(pop)

#include <map>

namespace XPerfGUI
{
using namespace XPerfAddIn;


//
// Developer support
//

template <typename T, typename D>
inline
void AdjustForPartialRepaint(T& start, T& end, D resolution)
{
    //
    // We are required to return at least one context datapoint on both
    // sides of the requested range so that the lines appear continuous
    // if the graph is performing a partial repaint.  If there are datapoints
    // precisely on the boundary, this is not necessary, so a simple rounding
    // of the times to the nearest resolution will suffice.
    //
    
    start -= start % resolution;
    
    if (end % resolution != D()) {
        end += resolution - end % resolution;
    }
}

template <typename O>
class CAdjustForPartialRepaintClosure
{
    O* const m_pObj;
public:
    CAdjustForPartialRepaintClosure(O* const pObj) : m_pObj(pObj) {}

    template <typename T, typename U>
    void operator()(T& start, T& end, U resolution) const
    {
        return m_pObj->AdjustForPartialRepaint(start, end, resolution);
    }
};

template <typename O>
CAdjustForPartialRepaintClosure<O> CreateAdjustForPartialRepaintClosure(O* const pObj)
{
    return CAdjustForPartialRepaintClosure<O>(pObj);
}

enum PhysicalMultiple {
    PhysMult_Block  = 20,
    PhysMult_Point  = 2,
};

template <typename T>
struct ViewRange
{
    typedef T value_type;
    typedef typename _TypeTraits<value_type>::diff_type diff_type;

    value_type  Start;
    value_type  End;
    diff_type   Resolution;

public:
    ViewRange()
        : Start(), End(), Resolution()
    {
    }

};

template <typename T>
struct CViewRange : public ViewRange<T>
{
public:

    CViewRange()
    {
    }

    template <typename F>
    CViewRange(IAxisT<T>* pAxisT, diff_type MinResolution, SIZE_T PhysicalMultiple, F AdjustForPartialRepaintClosure)
    {
        SIZE_T PixelExtent = 0;

        pAxisT->GetViewRange(Start, End);
        pAxisT->GetViewPixelExtent(PixelExtent);

        diff_type MinRes = max(((End - Start)/PixelExtent + diff_type(1)) * PhysicalMultiple, MinResolution);
        
        Resolution = pAxisT->GetPreferredResolution(MinRes);

        AdjustForPartialRepaintClosure(Start, End, Resolution);
    }

    bool Contains(const CViewRange<T>& other) const
    {
        return Resolution == other.Resolution && Start <= other.Start && End >= other.End;
    }

    bool operator ==(const CViewRange<T>& other) const
    {
        return Resolution == other.Resolution && Start == other.Start && End == other.End;
    }
    bool operator !=(const CViewRange<T>& other) const
    {
        return !((*this) == other);
    }
};

struct CViewSubRange
{
    SIZE_T  Start;
    SIZE_T  End;

    template <typename T>
    CViewSubRange(const CViewRange<T>& View, T* pBegin)
    {
        // Extract indices
        Start = (SIZE_T)((View.Start - *pBegin) / View.Resolution);
        End = (SIZE_T)((View.End - *pBegin) / View.Resolution);
    }
};

struct CUpdateRange
{
    SIZE_T  Start; // inclusive
    SIZE_T  End;   // exclusive

public:
    CUpdateRange() : Start(), End() {}

    template <typename T, typename U, typename F>
    CUpdateRange(IAxisT<T>* pAxisT, T* pBegin, U resolution, F AdjustForPartialRepaintClosure)
    {
        // Retrieve update range
        T start = T(), end = T();
        pAxisT->GetUpdateRange(start, end);

        // Adjust for Partial Repaint
        AdjustForPartialRepaintClosure(start, end, resolution);

        // Extract indices
        Start = (SIZE_T)((start - *pBegin) / resolution); // inclusive Start
        End = (SIZE_T)((end - *pBegin) / resolution);     // exclusive End
    }
};

//
//  Graph support
//

class ATL_NO_VTABLE CMiniGraphRoot : 
    public CComObjectRoot, 
    public IMiniGraph
{
public:
    BEGIN_COM_MAP(CMiniGraphRoot)
        COM_INTERFACE_ENTRY(IMiniGraph)
        COM_INTERFACE_ENTRY_AGGREGATE_BLIND(m_spGraphingEngineUnk.p)
    END_COM_MAP()


    // Define extended interface
    virtual void GetLegendProps(ILegend::LegendProperties& legendProps) const
    {
        legendProps.NumColumns = 1;
        legendProps.NumRows = 0;
    }
    virtual void GetSeriesProps(USHORT iSeries, ILegend::SeriesProperties& seriesProps) const
    {
        UNREFERENCED_PARAMETER(iSeries);

        seriesProps.SeriesStyle = ILegend::SERIES_NONE;
        seriesProps.MarkerSize = 5;
        seriesProps.MarkerStyle = ILegend::MARKER_NONE;
        seriesProps.EnableSeries = TRUE;
        seriesProps.ShowSeries = TRUE;
        seriesProps.SeriesSize = 1; // usually overridden by MiniGraph

        // White allows the legend to choose a color for you.  
        seriesProps.Color = RGB(255, 255, 255);
    }
    virtual void GetSeriesProps(USHORT iSeries, ILegend2::SeriesProperties2& seriesProps) const
    {
        GetSeriesProps(iSeries, static_cast<ILegend::SeriesProperties&>(seriesProps));

        seriesProps.Reserved = 0;
        seriesProps.Group = NULL; // usually overriden by MiniGraph
        seriesProps.KeepAlive = NULL; // usually overriden by MiniGraph
    }
    virtual void GetLegendName(CStringW& LegendName) const
    {
        LegendName.SetString(L"Legend");
    }
    virtual void GetSeriesName(USHORT iSeries, CStringW& SeriesName) const
    {
        SeriesName.Format(L"# %d", iSeries);
    }

    //
    // IMiniGraph
    //

    //
    // InitializeGraph is called after the trace has been parsed and all dependent 
    // infosources are ready.  (For graphs, depedent infosources are retrieved in
    // the corresponding graph factories.)
    //

    STDMETHOD(InitializeGraph)() PURE;

    HRESULT InitializeGraph(USHORT _nSeries)
    {
        try {
            //
            // Tell the Graphing Engine how many series's we're going to have.
            //
            COMGUARD(GraphingEngine->SetNumSeries(_nSeries));

            //
            // Set up the legend.  The legend is used by the graph to determine
            // the drawing order, colors, series type and style, and other things.
            //
            ILegend::LegendProperties legendProps;

            // Retrieve Legend props
            GetLegendProps(legendProps);

            CStringW Name;

            // Retrieve Legend name
            GetLegendName(Name);

            CComPtr<ILegend> spLegend;
            COMGUARD(GraphingEngine->SetupLegend(Name,
                                                legendProps, 
                                                _nSeries,
                                                &spLegend));

            CComPtr<ILegend2> spLegend2 = com_cast<ILegend2>(spLegend);

            // Set up the properties for the series.
            ILegend2::SeriesProperties2 seriesProps2;
            
            static SIZE_T cchSeriesLabel = RTL_NUMBER_OF_FIELD(ILegend::SeriesProperties, Label);
            for (USHORT iSeries = 0; iSeries < _nSeries; ++iSeries) {

                // Get Series props
                GetSeriesProps(iSeries, seriesProps2);

                // Clean Name buffer
                Name.Truncate(0);

                // Retrieve Series name
                GetSeriesName(iSeries, Name);

                // Copy Name string with truncation at Label buffer size
                (void)StringCchCopyW(seriesProps2.Label, cchSeriesLabel, Name.GetString());

                if (spLegend2)
                {
                    COMGUARD(spLegend2->AddSeries(seriesProps2));
                }
                else
                {
                    // ILegend2 is not supported: ignore new ILegend2::SeriesProperties2 properties
                    COMGUARD(spLegend->AddSeries(seriesProps2));
                }

                COMGUARD(LinkSeriesByDim(iSeries));
            }
        } catch(CAtlException& atlExc) {
            return atlExc;
        }

        return S_OK;
    }

    virtual HRESULT LinkSeriesByDim(USHORT iSeries)
    {
        UNREFERENCED_PARAMETER(iSeries);

        // No Series Dimension Linking by default
        return S_OK;
    }

    void PreInitializeGraph() {}
    void PostInitializeGraph() {}

    STDMETHOD(HandleContextMenuEvent)(UINT_PTR cmdId, ISelection* pSelection)
    {
        UNREFERENCED_PARAMETER(cmdId);
        UNREFERENCED_PARAMETER(pSelection);
        return S_FALSE;
    }

    //
    // Declare the number of dimensions of the data presented in the 
    // graph as nDims; default is 2. Declare the number of series in 
    // the graph as nSeries; default is 0, which means unconfigured.
    //

    enum {
        nDims = 2,
    };

    HRESULT SetupAxes()
    {
        return S_OK;
    }

    bool IsXAxisPreConfigured()
    {
        return false;
    }

    HRESULT ResizeXAxis(ITraceInfo* pTraceInfo) 
    {
        UNREFERENCED_PARAMETER(pTraceInfo);

        return S_OK;
    }

protected:
    HRESULT AggregateGraphingEngine( IGraphingEngineFactory* pGraphingEngineFactory, 
                                     USHORT NumDim, 
                                     USHORT NumSeries = 0)
    {
        if (NumDim == 0) {
            return E_INVALIDARG;
        }
        // Create aggregated graphing engine and retrieve the inner IUnknown
        HRESULT hr = pGraphingEngineFactory->CreateAggGraphingEngine(
            static_cast<IMiniGraph*>(this), NumDim, NumSeries, &m_spGraphingEngineUnk);
        if (SUCCEEDED(hr)) {
            ASSERT(m_spGraphingEngineUnk != nullptr);
            
            // Retrieve IGraphingEngine
            hr = m_spGraphingEngineUnk->QueryInterface(&GraphingEngine);
            if (FAILED(hr)) {
                ASSERT(!GraphingEngine);
                m_spGraphingEngineUnk.Release();
            }
        }
        return hr;
    }

    template <typename T>
    HRESULT SetupAxis( USHORT dim, 
                       LPCWSTR szAxisLabel, 
                       T start, 
                       T end, 
                       BOOL bVisible = TRUE, 
                       IAxisT<T>** ppIAxisT = NULL)
    {
        CComPtr< IAxisT<T> > axis;
        COMGUARD(GraphingEngine->CreateAxis(&axis));
        ASSERT(axis != nullptr);

        axis->SetAxisRange(start, end);
        axis->SetTitle(szAxisLabel);

        // At creation time, axis is marked Visible; send visibility command only if non-visible
        if (!bVisible) {
            axis->SetVisible(FALSE);
        }

        HRESULT hr = GraphingEngine->SetAxis(dim, axis);
        
        if (SUCCEEDED(hr)) {

            // if axis reference was requested
            if (ppIAxisT) {
                // transfer ownership of axis interface pointer
                *ppIAxisT = axis.Detach();
            }
        }

        return hr;
    }

protected:
    CComPtr<IGraphingEngine> GraphingEngine;

private:
    CComPtr<IUnknown>       m_spGraphingEngineUnk;
};


//
// Temporal MiniGraph
//

class ATL_NO_VTABLE CTemporalMiniGraph : public CMiniGraphRoot
{
public:
    HRESULT SetupAxes()
    {
        COMGUARD(CMiniGraphRoot::SetupAxes());

        COMGUARD(SetupAxis( 0, 
                            L"Time", 
                            TimeStamp::Min, // effective range is set in ResizeXAxis(), 
                            TimeStamp::Min, //    which is called from InitializeGraph
                            TRUE,
                            &TimeStampAxis));
        
        return S_OK;
    }

    bool IsXAxisPreConfigured()
    {
        TimeStamp XStart, XEnd;

        TimeStampAxis->GetAxisRange(XStart, XEnd);

        return XStart != TimeStamp::Min || XEnd != TimeStamp::Min;
    }

    HRESULT ResizeXAxis(ITraceInfo* pTraceInfo) 
    {
        if (!pTraceInfo) {
            return E_UNEXPECTED;
        }

        COMGUARD(CMiniGraphRoot::ResizeXAxis(pTraceInfo));

        return TimeStampAxis->SetAxisRange(pTraceInfo->FirstEventTimeStamp,
                                           pTraceInfo->LastEventTimeStamp);
    }

    CComPtr<IAxisTimeStamp> TimeStampAxis;
    typedef CViewRange<TimeStamp> _ViewRange;
};


//
// Interval-based Graphs
//

class ATL_NO_VTABLE CIntervalMiniGraph : public CTemporalMiniGraph
{
    //
    // This is called each time the graph needs to be painted.  The 
    // graphing engine supports partial repaint.  All we have to do 
    // is to set (on GraphingEngine) the series data covering the
    // requested update interval.
    //

    STDMETHODIMP UpdateData()
    {
        HRESULT hr = S_OK;

        // Retrieve MinResolution
        TimeStampDelta MinRes = GetMinResolution();

        // Retrieve the current View
        _ViewRange View(TimeStampAxis, MinRes, GetMinPixelsPerDataPoint(), 
            CreateAdjustForPartialRepaintClosure(this));

        USHORT nSeries = GraphingEngine->GetNumSeries();

        // Do we need to retrieve new data?
        if (!DataView.Contains(View)) {
            // Commit to new View
            DataView = View;

            //
            // Retrieve Series data
            //

            SIZE_T nIntervals = (SIZE_T)((DataView.End - DataView.Start) / DataView.Resolution); 
                                         // DataView range is already a multiple of Resolution

            // Allocate Raw Data
            if (!AllocateRawData(nSeries, nIntervals)) {
                ASSERTMSG("Out of memory ", false);
                return E_OUTOFMEMORY;
            }

            // Allocate Graph Data
            if (!AllocateGraphData(nSeries, nIntervals)) {
                ASSERTMSG("Out of memory ", false);
                return E_OUTOFMEMORY;
            }

            // Query raw data
            hr = QueryRawData();

            if (FAILED(hr)) {
                ASSERTMSG("QueryRawData failed ", SUCCEEDED(hr));
                return hr;
            }

            //
            ComputeTimeData();

            //
            // Convert raw data to graph data
            //

            hr = ConvertRawDataToGraphData();

            if (FAILED(hr)) {
                ASSERTMSG("ConvertRawDataToGraphData failed ", SUCCEEDED(hr));
                return hr;
            }
        }

        // Honor automatic rescale policy
        if (GraphingEngine->GetAutomaticRescale()) {
            m_bRescale = true;
        }

        // Do we need to set the axis extent?
        if (m_bRescale && View != LatestView) {
            LatestView = View;
            m_bRescale = false;

            // Identify update interval
            CViewSubRange ViewSubRange(View, m_times.GetData());

            ASSERT(ViewSubRange.End <= m_times.GetCount());

            // Resize Y Axis; comply with scaling policy
            hr = ResizeYAxis(ViewSubRange, nSeries);
            if (FAILED(hr)) {
                ASSERTMSG("ResizeYAxis failed ", SUCCEEDED(hr));
                return hr;
            }
        }

        // Identify update range
        CUpdateRange Update(TimeStampAxis.p, m_times.GetData(), DataView.Resolution, 
            CreateAdjustForPartialRepaintClosure(this));

        ASSERT(Update.End <= m_times.GetCount());

        //
        // Set update data
        //

        const SIZE_T nUpdateIntervals = Update.End - Update.Start; // exclusive End, inclusive Start
        
        hr = GraphingEngine->SetSeriesData(0, 0, &GetTimeData()[Update.Start], nUpdateIntervals);
        if (FAILED(hr)) {
            ASSERTMSG("SetSeriesData/Time failed ", SUCCEEDED(hr));
            return hr;
        }

        hr = SetGraphData(Update.Start, nSeries, nUpdateIntervals);
        if (FAILED(hr)) {
            ASSERTMSG("SetGraphData failed ", SUCCEEDED(hr));
            return hr;
        }
        return S_OK;
    }

public:
    virtual void AdjustForPartialRepaint(TimeStamp& Start, TimeStamp& End, TimeStampDelta Resolution) const
    {
        // Perform basic adjustment for partial repaint
        ::XPerfGUI::AdjustForPartialRepaint(Start, End, Resolution);
    }

protected:
    virtual HRESULT LinkSeriesByDim(USHORT iSeries)
    {
        COMGUARD(CTemporalMiniGraph::LinkSeriesByDim(iSeries));

        //
        // In this graph all the Y values share the same X values 
        // since they are all plotted as a number over a constant interval 
        // in the trace.  The graph provides a way for series's to share
        // common values in cases like these.  By linking series A's Y values 
        // to series 0's X values this is accomplished.  Note this means 
        // Series 0 will store it's Y values at array element 1 whereas any 
        // other series will be storing them at position 0 since they do not 
        // have the X value that series 0 would normally store at index 0.
        //
        if (iSeries > 0) {
            // Link series "iSeries's" "0" dimension to series "0's".
            // There is a seperate type of linking that can be done in the
            // the legend to have series's turn on and off together when
            // checked.  This is not illustrated here.
            COMGUARD(GraphingEngine->LinkSeriesByDim(iSeries, 0, 0));
        }
        
        return S_OK;
    }

    virtual TimeStampDelta GetMinResolution() const
    {
        return TimeStampDelta(1); // 1 nsec
    }
    virtual SIZE_T GetMinPixelsPerDataPoint() const = 0;

    virtual const CAtlArray<TimeStamp>& GetTimeData() const 
    {
        return m_times;
    }
    virtual bool AllocateGraphData(USHORT nSeries, SIZE_T nIntervals)
    {
        UNREFERENCED_PARAMETER(nSeries);
        return m_times.SetCount(nIntervals);
    }
    virtual void ComputeTimeData()
    {
        for (SIZE_T iInterval = 0; iInterval < m_times.GetCount(); ++iInterval) {
            m_times[iInterval] = DataView.Start + iInterval * DataView.Resolution;
        }
    }

    virtual bool AllocateRawData(USHORT nSeries, SIZE_T nIntervals) = 0;
    virtual HRESULT QueryRawData() = 0;
    virtual HRESULT ConvertRawDataToGraphData() = 0;
    virtual HRESULT SetGraphData(SIZE_T iUpdateStart, USHORT nSeries, SIZE_T nUpdateIntervals) = 0;
    virtual HRESULT ResizeYAxis(const CViewSubRange& ViewSubRange, USHORT nSeries) = 0;

    USHORT GetNumSeries() const
    {
        return GraphingEngine->GetNumSeries();
    }

    SIZE_T GetNumIntervals() const
    {
        return m_times.GetCount();
    }

    void ForceQueryData()
    {
        DataView.Resolution = TimeStampDelta::Zero;
    }
    void ForceRescale()
    {
        LatestView.Resolution = TimeStampDelta::Zero;
    }


protected:
    template <typename T>
    T CalculateAccumulatedYMax_NonStackedSeries(const CViewSubRange& ViewSubRange, USHORT nSeries, const CAtlArray<T>& Data, T minAcc) const
    {
        T maxAcc = minAcc;
        
        // Accumulate over series and intervals in view
        for (USHORT iSeries = 0; iSeries < nSeries; ++iSeries) {
            SIZE_T iSeriesStart = GetNumIntervals() * iSeries;
            for (SIZE_T iInterval = ViewSubRange.Start; iInterval < ViewSubRange.End; ++iInterval) {
                T Acc = Data[iSeriesStart + iInterval];
                // Update maxUsage
                maxAcc = max(maxAcc, Acc);
            }
        }
        return maxAcc;
    }

    template <typename T>
    T CalculateAccumulatedYMax_StackedSeries(const CViewSubRange& ViewSubRange, USHORT nSeries, const CAtlArray<T>& Data, T minAcc) const
    {
        T maxAcc = minAcc;
        
        for (SIZE_T iInterval = ViewSubRange.Start; iInterval < ViewSubRange.End; ++iInterval) {
            T Acc = 0;
            // Accumulate over series
            for (USHORT iSeries = 0; iSeries < nSeries; ++iSeries) {
                Acc += Data[GetNumIntervals() * iSeries + iInterval];
            }
            // Update maxCount
            maxAcc = max(maxAcc, Acc);
        }
        return maxAcc;
    }


protected:
    CIntervalMiniGraph()
        : m_bRescale(true)
    {
    }

    _ViewRange              DataView;
    _ViewRange              LatestView;
    CAtlArray<TimeStamp>    m_times; // m_times stores successive starts of intervals in DataView
    bool                    m_bRescale;
};


class ATL_NO_VTABLE CBlockIntervalMiniGraph : public CIntervalMiniGraph
{
public:
    virtual void AdjustForPartialRepaint(TimeStamp& Start, TimeStamp& End, TimeStampDelta Resolution) const
    {
        // Perform basic adjustment for partial repaint
        CIntervalMiniGraph::AdjustForPartialRepaint(Start, End, Resolution);

        // Block graphs need an extra entry to mark the end of 
        // last interval.  Extend end by one resolution.

        End   += Resolution; 
    }
    void PostInitializeGraph() 
    {
        COMGUARDTHROW(GraphingEngine->SetToolTipFormat( L"#oS: #1oV" ));
    }
protected:
    virtual void GetSeriesProps(USHORT iSeries, ILegend::SeriesProperties& seriesProps) const
    {
        CIntervalMiniGraph::GetSeriesProps(iSeries, seriesProps);

        seriesProps.SeriesStyle = ILegend::SERIES_STACKED_BAR;
        seriesProps.MarkerStyle = ILegend::MARKER_NONE;
    }

    template <typename T>
    T CalculateAccumulatedYMax(const CViewSubRange& ViewSubRange, USHORT nSeries, const CAtlArray<T>& Data, T minAcc) const
    {
        return CalculateAccumulatedYMax_StackedSeries(ViewSubRange, nSeries, Data, minAcc);
    }

    virtual SIZE_T GetMinPixelsPerDataPoint() const
    {
        return PhysMult_Block;
    }
};

class ATL_NO_VTABLE CPointIntervalMiniGraph : public CIntervalMiniGraph
{
public:
    virtual void AdjustForPartialRepaint(TimeStamp& Start, TimeStamp& End, TimeStampDelta Resolution) const
    {
        // Perform basic adjustment for partial repaint
        CIntervalMiniGraph::AdjustForPartialRepaint(Start, End, Resolution);

        // To properly align point-interval graphs with block-interval
        // graphs, extend both start and end by one resolution and perform 
        // time shifting of time data by half resolution.

        Start -= Resolution; 
        End   += Resolution; 
    }
protected:
    virtual void GetSeriesProps(USHORT iSeries, ILegend::SeriesProperties& seriesProps) const
    {
        CIntervalMiniGraph::GetSeriesProps(iSeries, seriesProps);

        seriesProps.SeriesStyle = ILegend::SERIES_SOLID_LINE;
        seriesProps.MarkerStyle = ILegend::MARKER_NONE;
    }

    template <typename T>
    T CalculateAccumulatedYMax(const CViewSubRange& ViewSubRange, USHORT nSeries, const CAtlArray<T>& Data, T minAcc) const
    {
        return CalculateAccumulatedYMax_NonStackedSeries(ViewSubRange, nSeries, Data, minAcc);
    }

    virtual SIZE_T GetMinPixelsPerDataPoint() const
    {
        return PhysMult_Point;
    }
    virtual const CAtlArray<TimeStamp>& GetTimeData() const 
    {
        return m_timesShifted;
    }
    virtual bool AllocateGraphData(USHORT nSeries, SIZE_T nIntervals)
    {
        return CIntervalMiniGraph::AllocateGraphData(nSeries, nIntervals) &&
            m_timesShifted.SetCount(nIntervals);
    }
    virtual void ComputeTimeData()
    {
        CIntervalMiniGraph::ComputeTimeData();

        for (SIZE_T iInterval = 0; iInterval < m_timesShifted.GetCount(); ++iInterval) {
            m_timesShifted[iInterval] = DataView.Start + iInterval * DataView.Resolution + DataView.Resolution / 2;
        }
    }
protected:
    CAtlArray<TimeStamp>    m_timesShifted; // m_timesShifted stores successive mids of intervals in DataView
};


template <typename _IntervalMiniGraph = CPointIntervalMiniGraph>
class ATL_NO_VTABLE CUsageMiniGraph : public _IntervalMiniGraph
{
protected:
    HRESULT SetupAxes()
    {
        // X axis (TimeStamp) is setup by CTemporalMiniGraph

        HRESULT hr = _IntervalMiniGraph::SetupAxes();
        if (FAILED(hr)) {
            return hr;
        }

        //
        // Create the Y-Axis.  For usage graphs, Y axis is based on % so in principle 
        // we know the extents of this axis.  To support automatic rescaling though, 
        // the extent of the axis will need to be recalculated for every new View and 
        // set using the Axis's SetAxisRange method in UpdateData(). [Resizing is 
        // performed by ResizeYAxis().]
        //

        // Y axis
        hr = SetupAxis( 1, L"% Usage", Real(0.0), Real(100.0), TRUE, &UsageAxis);

        ASSERTMSG("Setup Y Axis (Usage) failed", SUCCEEDED(hr));

        return hr;

        // NOTE: Graph data can have more than 2 dimensions; while extra dimensions 
        // are not geometrically relevant, they can contain descriptive information 
        // used in generation of tooltips.  When graph data has such extra dimensions, 
        // the axes for extra dimensions have to be setup in this function, as well.
        // See DiskDetailMiniGraph for an example.
    }
    virtual HRESULT ResizeYAxis(const CViewSubRange& ViewSubRange, USHORT nSeries)
    {
        HRESULT hr = UsageAxis->SetAxisRange(Real(0.0), 
                                             // honor axis-preferred sizes
                                             UsageAxis->GetPreferredMax(
                                                 GetYAxisMaxInViewSubRange(ViewSubRange, nSeries)));

        ASSERTMSG("SetAxisRange failed ", SUCCEEDED(hr));

        return hr;
    }
    virtual Real GetYAxisMaxInViewSubRange(const CViewSubRange& ViewSubRange, USHORT nSeries) const
    {
        return GetAccumulatedYMax(ViewSubRange, nSeries);
    }
    Real GetAccumulatedYMax(const CViewSubRange& ViewSubRange, USHORT nSeries) const
    {
        return CalculateAccumulatedYMax(ViewSubRange, nSeries, m_usage, Real(1.0));
    }
    virtual bool AllocateGraphData(USHORT nSeries, SIZE_T nIntervals)
    {
        return _IntervalMiniGraph::AllocateGraphData(nSeries, nIntervals) &&
            m_usage.SetCount(nSeries * nIntervals);
    }

    virtual HRESULT SetGraphData(SIZE_T iUpdateStart, USHORT nSeries, SIZE_T nUpdateIntervals)
    {
        const SIZE_T cbStride = sizeof(m_usage[0]);

        // Series 0: index 0 holds dim 0, index 1 holds dim 1
        // Series 1+: dim 0 is linked, index 0 holds dim 1
        for (USHORT iSeries = 0; iSeries < nSeries; ++iSeries) {
            const SIZE_T iLinearUpdateStart = GetNumIntervals() * iSeries + iUpdateStart;

            // Series 0: dim 1 is located at index 1 (dim 0 is located at index 0)
            // Series 1+: dim 1 is located at index 0 (dim 0 is linked)
            HRESULT hr = GraphingEngine->SetSeriesData(iSeries, !iSeries, &m_usage[iLinearUpdateStart], nUpdateIntervals, cbStride);
            if (FAILED(hr)) {
                ASSERTMSG("SetSeriesData failed ", SUCCEEDED(hr));
                return hr;
            }
        }
        return S_OK;
    }
    Real* GetSeriesData(USHORT iSeries)
    {
        return &m_usage[GetNumIntervals() * iSeries];
    }
protected:
    CComPtr<IAxisReal>          UsageAxis;
    CAtlArray<Real>             m_usage;
};


template <typename _IntervalMiniGraph = CBlockIntervalMiniGraph>
class ATL_NO_VTABLE CCountsMiniGraph : public _IntervalMiniGraph
{
protected:
    HRESULT SetupAxes()
    {
        // X axis (TimeStamp) is setup by CTemporalMiniGraph

        HRESULT hr = _IntervalMiniGraph::SetupAxes();
        if (FAILED(hr)) {
            return hr;
        }

        //
        // Create the Y-Axis.  For count graphs, the extent will need to be 
        // queried from the info source after processing the trace.  Moreover, 
        // to support automatic rescaling, the extent of the axis will need to 
        // be recalculated for every new View and set using the Axis's 
        // SetAxisRange method in UpdateData().  [Resizing is performed by
        // ResizeYAxis().]
        //

        // Y axis
        hr = SetupAxis( 1, L"Counts", ULongLong(0), ULongLong(1), TRUE, &CountsAxis);

        ASSERTMSG("Setup Y Axis (Counts) failed", SUCCEEDED(hr));

        return hr;
    }
    virtual HRESULT ResizeYAxis(const CViewSubRange& ViewSubRange, USHORT nSeries)
    {
        HRESULT hr = CountsAxis->SetAxisRange(ULongLong(0), 
                                              // honor axis-preferred sizes
                                              CountsAxis->GetPreferredMax(
                                                  GetYAxisMaxInViewSubRange(ViewSubRange, nSeries)));

        ASSERTMSG("SetAxisRange failed ", SUCCEEDED(hr));

        return hr;
    }

    virtual ULongLong GetYAxisMaxInViewSubRange(const CViewSubRange& ViewSubRange, USHORT nSeries) const
    {
        return GetAccumulatedYMax(ViewSubRange, nSeries);
    }
    ULongLong GetAccumulatedYMax(const CViewSubRange& ViewSubRange, USHORT nSeries) const
    {
        return CalculateAccumulatedYMax(ViewSubRange, nSeries, m_counts, ULongLong(1));
    }
    virtual bool AllocateGraphData(USHORT nSeries, SIZE_T nIntervals)
    {
        return _IntervalMiniGraph::AllocateGraphData(nSeries, nIntervals) &&
            m_counts.SetCount(nSeries * nIntervals);
    }
    virtual HRESULT SetGraphData(SIZE_T iUpdateStart, USHORT nSeries, SIZE_T nUpdateIntervals)
    {
        const SIZE_T cbStride = sizeof(m_counts[0]);

        // Series 0: index 0 holds dim 0, index 1 holds dim 1
        // Series 1+: dim 0 is linked, index 0 holds dim 1
        for (USHORT iSeries = 0; iSeries < nSeries; ++iSeries) {
            const SIZE_T iLinearUpdateStart = GetNumIntervals() * iSeries + iUpdateStart;

            // Series 0: dim 1 is located at index 1 (dim 0 is located at index 0)
            // Series 1+: dim 1 is located at index 0 (dim 0 is linked)
            HRESULT hr = GraphingEngine->SetSeriesData(iSeries, !iSeries, &m_counts[iLinearUpdateStart], nUpdateIntervals, cbStride);
            if (FAILED(hr)) {
                ASSERTMSG("SetSeriesData failed ", SUCCEEDED(hr));
                return hr;
            }
        }
        return S_OK;
    }

    ULongLong* GetSeriesData(USHORT iSeries)
    {
        return &m_counts[GetNumIntervals() * iSeries];
    }
protected:
    CComPtr<IAxisULongLong>     CountsAxis;
    CAtlArray<ULongLong>        m_counts;
};


template <typename T, typename _Base>
class ATL_NO_VTABLE CQueryDataImpl : public _Base
{
protected:
    bool AllocateRawData(USHORT nSeries, SIZE_T nIntervals)
    {
        return m_queryData.SetCount(nSeries * nIntervals);
    }

    USHORT GetNumRawEntries() const
    {
        return m_queryData.GetCount();
    }

protected:
    CAtlArray<T>            m_queryData;
};


class ATL_NO_VTABLE CDataMiniGraph : public CTemporalMiniGraph
{
protected:
    virtual HRESULT QueryData() = 0;

    void PreInitializeGraph()
    {
        // Retrieve Trace Extent

        TimeStampAxis->GetAxisRange(DataViewStart, DataViewEnd);

        HRESULT hr = QueryData();
        if (FAILED(hr)) {
            ASSERTMSG("QueryData() failed ", SUCCEEDED(hr));
            AtlThrow(hr);
        }
    }

public:
    //
    // This is called each time the graph needs to be painted.  The 
    // graphing engine supports partial repaint.  All we have to do 
    // is to set (on GraphingEngine) the series data covering the
    // requested update interval.
    //

    STDMETHODIMP UpdateData()
    {
        if (m_bForceUpdateData) {
            COMGUARD(QueryData());
            m_bForceUpdateData = false;
        }

        return S_OK;
    }

    void ForceUpdateData()
    {
        m_bForceUpdateData = true;
    }

    CDataMiniGraph() 
        : m_bForceUpdateData(false) 
    {
    }

protected:
    TimeStamp       DataViewStart;
    TimeStamp       DataViewEnd;
    bool            m_bForceUpdateData;
};


//
// CheckPoints Graphs
//

template <typename _Label = XPerfGUI::Label>
class ATL_NO_VTABLE CCheckPointsMiniGraph : public CDataMiniGraph
{
public:
    HRESULT SetupAxes()
    {
        // X axis (TimeStamp) is setup by CTemporalMiniGraph
        COMGUARD(CTemporalMiniGraph::SetupAxes());


        //
        // Create the Y-Axis.  For checkpoint graphs, the Y axis is a hidden 
        // label axis.  The first series of the graph will represent start 
        // points; the second series will represent end points; and the other
        // series represent intermediary points.  
        //

        // Y axis (Label)
        COMGUARD(SetupAxis(1, L"Label (Invisible)", Label(), Label(), FALSE));

        return S_OK;
    }

    virtual HRESULT LinkSeriesByDim(USHORT iSeries)
    {
        COMGUARD(CTemporalMiniGraph::LinkSeriesByDim(iSeries));

        //
        // In this graph all the X values share the same Y values since 
        // they are all plotted as times in the trace corresponding to the 
        // same Y value.  The graph provides a way for series's to share
        // common values in cases like these.  This is accomplished by linking 
        // series A's Y values to series 0's Y values.
        //
        if (iSeries > 0) {
            // Link series "iSeries's" "1" dimension to series "0's".
            // There is a seperate type of linking that can be done in the
            // the legend to have series's turn on and off together when
            // checked.  This is not illustrated here.
            COMGUARD(GraphingEngine->LinkSeriesByDim(iSeries, 1, 0));
        }
        
        return S_OK;
    }

    virtual void GetLegendName(CStringW& LegendName) const
    {
        LegendName.SetString(L"CheckPoints");
    }

    USHORT GetNumSeries() const
    {
        return 2;
    }

    virtual void GetSeriesName(USHORT iSeries, CStringW& SeriesName) const
    {
        const LPCWSTR SeriesNames[] = {
            L"Start",
            L"End",
        };

        if (iSeries >= RTL_NUMBER_OF(SeriesNames)) {
            AtlThrow(E_INVALIDARG);
        }

        SeriesName.SetString(SeriesNames[iSeries]);
    }

    virtual void GetSeriesProps(USHORT iSeries, ILegend::SeriesProperties& seriesProps) const
    {
        CTemporalMiniGraph::GetSeriesProps(iSeries, seriesProps);

        seriesProps.SeriesStyle = ILegend::SERIES_CHECKPOINTS;
        seriesProps.MarkerStyle = ILegend::MARKER_DIAMOND;
        seriesProps.SeriesSize = 3;
        seriesProps.MarkerSize = 6;
    }


    //
    // This is called each time the graph needs to be painted.  The 
    // graphing engine supports partial repaint.  All we have to do 
    // is to set (on GraphingEngine) the series data covering the
    // requested update interval.
    //

    STDMETHODIMP UpdateData()
    {
        HRESULT hr = S_OK;

        COMGUARD(CDataMiniGraph::UpdateData());

        USHORT nSeries = GraphingEngine->GetNumSeries();

        //
        // Set update data
        //

        hr = GraphingEngine->SetSeriesData(0, 1, GetNumItems() ? &m_labels[0] : NULL, GetNumItems());
        if (FAILED(hr)) {
            ASSERTMSG("SetSeriesData/Time failed ", SUCCEEDED(hr));
            return hr;
        }

        hr = SetGraphData(0, nSeries, GetNumItems());
        if (FAILED(hr)) {
            ASSERTMSG("SetGraphData failed ", SUCCEEDED(hr));
            return hr;
        }
        return S_OK;
    }

protected:
    SIZE_T GetNumItems() const
    {
        return m_labels.GetCount();
    }

    virtual bool AllocateGraphData(USHORT nCheckPoints, SIZE_T nItems)
    {
        return m_labels.SetCount(nItems) && 
               m_times.SetCount(nCheckPoints * nItems);
    }

    virtual HRESULT SetGraphData(SIZE_T iUpdateStart, USHORT _nSeries, SIZE_T nUpdateIntervals)
    {
        for (USHORT iSeries = 0; iSeries < _nSeries; ++iSeries) {
            const SIZE_T iSeriesStart = iSeries * GetNumItems();
            COMGUARD(GraphingEngine->SetSeriesData(iSeries, 0, nUpdateIntervals ? &m_times[iSeriesStart + iUpdateStart] : NULL, nUpdateIntervals));
        }
        return S_OK;
    }

protected:
    CAtlArray<TimeStamp>    m_times;
    CAtlArray<_Label>       m_labels;
};


template <typename _Derived>
class CCpuAware
{
    _Derived* _This() { return static_cast<_Derived*>(this); }
public:
    CCpuAware() : m_nCpus(0) {}

    void PreInitializeGraph()
    {
        m_nCpus = _This()->Factory->nCpus;
    }

protected:
    SIZE_T m_nCpus;
};


template <typename _Derived>
class CIndexPerCpu : public CCpuAware<_Derived>
{
public:
    LPCWSTR GetDeviceName() const { return L"CPU"; }

    USHORT GetNumSeries() const
    {
        ASSERT(m_nCpus <= USHRT_MAX);
        return (USHORT)m_nCpus; 
    }
};


template <typename _Derived>
class CDiskAware
{
    _Derived* _This() { return static_cast<_Derived*>(this); }
public:
    CDiskAware() : m_nDisks(0) {}

    void PreInitializeGraph()
    {
        m_nDisks = _This()->Factory->DiskIO->NumPhysicalDisks();
    }

protected:
    SIZE_T m_nDisks;
};


template <typename _Derived>
class CIndexPerDisk : public CDiskAware<_Derived>
{
public:
    LPCWSTR GetDeviceName() const { return L"Disk"; }

    USHORT GetNumSeries() const
    {
        ASSERT(m_nDisks <= USHRT_MAX);
        return (USHORT)m_nDisks;
    }
};


template <typename _PolicyIndex, typename _Base>
class ATL_NO_VTABLE CMiniGraphMixer : 
    public _PolicyIndex, 
    public _Base
{
public:
    void PreInitializeGraph()
    {
        _PolicyIndex::PreInitializeGraph();
        _Base::PreInitializeGraph();
    }
};


template <typename _PolicyIndex, typename _Base>
class ATL_NO_VTABLE CIndexedMiniGraph : public CMiniGraphMixer<_PolicyIndex, _Base>
{
public:
    virtual void GetLegendName(CStringW& LegendName) const
    {
        LegendName.SetString(GetDeviceName());
        LegendName.Append(L" #");
    }

    virtual void GetSeriesName(USHORT iSeries, CStringW& SeriesName) const
    {
        SeriesName.SetString(GetDeviceName());
        SeriesName.AppendFormat(L" %hd", iSeries);
    }
    USHORT GetNumSeries() const
    {
        return _PolicyIndex::GetNumSeries();
    }
};


//
// CMiniGraphFactoryRoot
//

// In XPerfCore, categories should have the same GUID as the base interfaces they stand for
const CATID CATID_IGraphFactory = __uuidof(IGraphFactory);

template <typename _Derived, typename _Graph>
class ATL_NO_VTABLE CMiniGraphFactoryRoot : 
    public CSessionServiceRoot<_Derived>,
    public IGraphFactory
{
public:
    DECLARE_NO_REGISTRY()
    DECLARE_NOT_AGGREGATABLE(_Derived)

    typedef CMiniGraphFactoryRoot<_Derived, _Graph> _GraphFactory;

    BEGIN_COM_MAP(_GraphFactory)
        COM_INTERFACE_ENTRY(IGraphFactory)
        COM_INTERFACE_ENTRY_CHAIN(_SessionService)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_GraphFactory)
        IMPLEMENTED_CATEGORY(CATID_IGraphFactory)
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()
    END_CATEGORY_MAP()

    // ISessionService::
    STDMETHODIMP OnSessionConnect(ISession* pSession)
    {
        TraceInfo = com_cast<ITraceInfo>(pSession);
        ASSERT(TraceInfo);

        return pSession->QueryService(&GraphingEngineFactory);
    }

public:
    CComPtr<ITraceInfo>             TraceInfo;
    CComPtr<IGraphingEngineFactory> GraphingEngineFactory;

public:
    //
    // CreateGraph
    // [Adapted from atlcom.h: CComCreator<T1>::CreateInstance]
    //
    STDMETHOD(CreateGraph)(
        /* [in] */ REFIID riid, 
        /* [out] */ LPVOID* ppv )
    {
        ATLASSERT(ppv != NULL);
        if (ppv == NULL)
            return E_POINTER;
        *ppv = NULL;

        HRESULT hRes = E_OUTOFMEMORY;
        CComObject<_Graph>* p = NULL;
        ATLTRY(p = new CComObject<_Graph>())
        if (p != NULL)
        {
            p->SetVoid(NULL);
            p->InternalFinalConstructAddRef();

            // Set Factory context
            p->Factory = static_cast<_Derived*>(this);
            //

            hRes = p->FinalConstruct();
            if (SUCCEEDED(hRes))
                hRes = p->_AtlFinalConstruct();
            p->InternalFinalConstructRelease();
            if (hRes == S_OK)
                hRes = p->QueryInterface(riid, ppv);
            if (hRes != S_OK)
                delete p;
        }
        return hRes;
    }
    STDMETHOD_(INT, GetDefaultPosition)()
    {
        return IGraphFactory::GraphPos_ClassUser;
    }
    STDMETHOD_(ULONG, GetDefaultHeight)()
    {
        return 300;
    }
    STDMETHOD_(BOOL, GetDefaultEnabled)()
    {
        return TRUE;
    }
    STDMETHOD_(BOOL, GetDefaultVisible)()
    {
        return TRUE;
    }
};


//
// CMiniGraphT
//

template <typename _Derived, typename _Factory, typename _Root>
class ATL_NO_VTABLE CMiniGraphT : public _Root
{
    _Derived* _This() { return static_cast<_Derived*>(this); }
public:
    typedef CMiniGraphT<_Derived, _Factory, _Root> _MiniGraph;

    DECLARE_PROTECT_FINAL_CONSTRUCT()

    HRESULT FinalConstruct()
    {
        HRESULT hr = _This()->AggregateGraphingEngine(_Derived::nDims, 0);
        ASSERTMSG("Failed aggregating GraphingEngine ", SUCCEEDED(hr));

        if (SUCCEEDED(hr)) {
            hr = _This()->SetupAxes();
            ASSERTMSG("Failed setting up axes", SUCCEEDED(hr));
        }

        return hr;
    }

    // Adapters for Overridables
    HRESULT AggregateGraphingEngine(USHORT _nDims, USHORT _nSeries = 0)
    {
        return _Root::AggregateGraphingEngine(Factory->GraphingEngineFactory, _nDims, _nSeries);
    }

    HRESULT ResizeXAxis()
    {
        return _Root::ResizeXAxis(Factory->TraceInfo);
    }

    // IMiniGraph
    STDMETHODIMP InitializeGraph()
    {
        HRESULT hr = S_OK;

        if (!_This()->IsXAxisPreConfigured()) {
            COMGUARD(_This()->ResizeXAxis());
        }

        try {
            // Give graph a chance to retrieve its factory config.
            _This()->PreInitializeGraph();

            // InitializeGraph
            hr = _Root::InitializeGraph(_This()->GetNumSeries());
            if (FAILED(hr)) {
                ASSERTMSG("Failed InitializeGraph ", SUCCEEDED(hr));
                return hr;
            }

            // Give graph a chance to configure ContextMenu, Tooltip format.
            _This()->PostInitializeGraph();

        } catch(CAtlException& atlExc) {
            return atlExc;
        }

        return hr;
    }

private:
    HRESULT QueryRawData()
    {
        SIZE_T nRawEntries = m_queryData.GetCount();

        // Query raw data
        HRESULT hr = _This()->QueryRawData(nRawEntries);

        if (FAILED(hr)) {
            ASSERTMSG("QueryRawData failed ", SUCCEEDED(hr));
            return hr;
        }

        if (nRawEntries != m_queryData.GetCount()) {
            ASSERTMSG("Unexpected number of entries ", nRawEntries == m_queryData.GetCount());
            return E_UNEXPECTED;
        }

        return hr;
    }

public:
    CRefCountedPtr<_Factory> Factory;
};


//
// PerCpuUsage MiniGraph
//

template <typename _Derived, typename _GraphFactory, typename _RawData>
class ATL_NO_VTABLE CPerCpuUsageMiniGraph : 
    public CMiniGraphT<_Derived, _GraphFactory, 
                       CIndexedMiniGraph<CIndexPerCpu<_Derived>, 
                                         CQueryDataImpl<_RawData, CUsageMiniGraph<> > > >
{
};

template <typename _Derived, typename _GraphFactory, typename _RawData>
class ATL_NO_VTABLE CPerCpuCountsMiniGraph : 
    public CMiniGraphT<_Derived, _GraphFactory, 
                       CIndexedMiniGraph<CIndexPerCpu<_Derived>, 
                                         CQueryDataImpl<_RawData, CCountsMiniGraph<> > > >
{
};

template <typename _Derived, typename _GraphFactory, typename _RawData>
class ATL_NO_VTABLE CPerDiskCountsMiniGraph : 
    public CMiniGraphT<_Derived, _GraphFactory, 
                       CIndexedMiniGraph<CIndexPerDisk<_Derived>, 
                                         CQueryDataImpl<_RawData, CCountsMiniGraph<> > > >
{
};

template <typename _Derived, typename _GraphFactory, typename _RawData>
class ATL_NO_VTABLE CPerDiskUsageMiniGraph : 
    public CMiniGraphT<_Derived, _GraphFactory, 
                       CIndexedMiniGraph<CIndexPerDisk<_Derived>, 
                                         CQueryDataImpl<_RawData, CUsageMiniGraph<> > > >
{
};

//
// SummaryTable development support
//

//
// Row access on SummaryTable
//

class CSummaryTableRow;
class CSummaryTableCell
{
    const CSummaryTableRow* m_pRow;
    SIZE_T                  m_iCol;
public:
    CSummaryTableCell(const CSummaryTableRow* pRow, SIZE_T iCol)
        : m_pRow(pRow), m_iCol(iCol)
    {
    }

    template<typename T>
    void operator=(const T& value);

    SIZE_T GetColumnIndex() 
    {
        return m_iCol;
    }
protected:
    CSummaryTableCell()
    {
    }
};

class CSummaryTableRow
{
    ISummaryTable*  m_pTable;
    SIZE_T          m_iRow;
public:
    CSummaryTableRow(ISummaryTable* pTable, SIZE_T iRow)
        : m_pTable(pTable), m_iRow(iRow)
    {
    }

    template <typename Q>
    void SetData(SIZE_T iCol, const Q& value) const
    {
        HRESULT hr = m_pTable->SetData(m_iRow, iCol, value);
        if (FAILED(hr)) {
            AtlThrow(hr);
        }
    }

    CSummaryTableCell operator[](SIZE_T iCol) const
    {
        return CSummaryTableCell(this, iCol);
    }

    SIZE_T GetIndex() const 
    {
        return m_iRow;
    }

    _At_(this->m_iRow, _Const_)
    _Ret_range_(==, this->m_iRow)
    operator SIZE_T () const 
    {
        return m_iRow;
    }

    void operator++() 
    {
        ++m_iRow;
    }
};

template<typename Q>
inline
void CSummaryTableCell::operator =(const Q& value)
{
    m_pRow->SetData(m_iCol, value);
}


// Strongly-typed SummaryTable Cell accessor
template <typename T>
class CCellT : public CSummaryTableCell
{
public:
    void operator=(const T value)
    {
        CSummaryTableCell::operator =(value);
    }
};


// Strongly-typed SummaryTable Row accessor
template <typename R>
class CSummaryTableRowT : public R, public CSummaryTableRow
{
public:
    CSummaryTableRowT(ISummaryTable* pSummaryTable, SIZE_T iRow = 0)
        : CSummaryTableRow(pSummaryTable, iRow)
    {
        CSummaryTableCell* rgCells = reinterpret_cast<CSummaryTableCell*>(static_cast<R*>(this));
        for (SIZE_T iCol = 0; iCol < sizeof(R)/ sizeof(CSummaryTableCell); ++iCol) {
            new (rgCells + iCol) CSummaryTableCell(this, iCol);
        }
    }

    void AdjustForInsertionBefore(SIZE_T iCol, SIZE_T count)
    {
        CSummaryTableCell* rgCells = reinterpret_cast<CSummaryTableCell*>(static_cast<R*>(this));
        for (; iCol < sizeof(R)/ sizeof(CSummaryTableCell); ++iCol) {
            rgCells[iCol] = CSummaryTableCell(this, rgCells[iCol].GetColumnIndex() + count);
        }
    }

    void AdjustForRemovalBefore(SIZE_T iCol, SIZE_T count)
    {
        CSummaryTableCell* rgCells = reinterpret_cast<CSummaryTableCell*>(static_cast<R*>(this));
        for (; iCol < sizeof(R)/ sizeof(CSummaryTableCell); ++iCol) {
            ASSERT(rgCells[iCol].GetColumnIndex() >= count);
            rgCells[iCol] = CSummaryTableCell(this, rgCells[iCol].GetColumnIndex() - count);
        }
    }
};

//
// Optional parameters on ISummaryTable::ColumnProps
//

struct CColumnProps : public ISummaryTable::ColumnProps
{
    static const ISummaryTable::ColumnProps Default;
    CColumnProps(LPCWSTR Name, REFGUID guidDataType, const ISummaryTable::ColumnProps& ColumnProps = Default)
    {
        *static_cast<ISummaryTable::ColumnProps*>(this) = ColumnProps;

        pguidDataType = &guidDataType;

        (void)StringCchCopyW(Label, RTL_NUMBER_OF(Label), Name);
    }
    CColumnProps& Width(USHORT width)
    {
        ColWidth = width;
        return *this;
    }
    CColumnProps& Key()
    {
        Type = ISummaryTable::COLUMN_TYPE_KEY;
        return *this;
    }
    CColumnProps& Ascending()
    {
        SortMode = ISummaryTable::ASCENDING;
        return *this;
    }
    CColumnProps& Descending()
    {
        SortMode = ISummaryTable::DESCENDING;
        return *this;
    }
    CColumnProps& Count()
    {
        AggrMode = ISummaryTable::COUNT;
        return *this;
    }
    CColumnProps& Sum()
    {
        AggrMode = ISummaryTable::SUM;
        return *this;
    }
    CColumnProps& Average()
    {
        AggrMode = ISummaryTable::AVERAGE;
        return *this;
    }
    CColumnProps& Min()
    {
        AggrMode = ISummaryTable::MIN;
        return *this;
    }
    CColumnProps& Max()
    {
        AggrMode = ISummaryTable::MAX;
        return *this;
    }
    CColumnProps& UniqueCount()
    {
        AggrMode = ISummaryTable::UNIQUE_COUNT;
        return *this;
    }
    CColumnProps& Invisible()
    {
        bVisible = false;
        return *this;
    }
    CColumnProps& Priority(USHORT priority)
    {
        SortPriority = priority;
        return *this;
    }
    CColumnProps& ColumnGuid(GUID& columnGuid)
    {
        ColGuid = columnGuid;
        return *this;
    }
    CColumnProps& ColumnGuid(LPCOLESTR wszColumnGuid)
    {
        HRESULT hr = CLSIDFromString(wszColumnGuid, &ColGuid);
        NT_ASSERT(hr == NOERROR);
        UNREFERENCED_PARAMETER(hr);
        return *this;
    }
};

__declspec(selectany) const ISummaryTable::ColumnProps CColumnProps::Default = {
    {},                               // ColGuid
    NULL,                             // pguidDataType
    {},                               // Label
    TRUE,                             // bVisible
    ISummaryTable::COLUMN_TYPE_VALUE, // Type
    ISummaryTable::NO_AGGREGATION,    // AggrMode
    ISummaryTable::UNSORTED,          // SortMode
    -1,                               // SortPriority
    -1,                               // DefDispDepth
    150,                              // ColWidth
};

template <typename T>
CColumnProps ColProps(LPCWSTR Name, const ISummaryTable::ColumnProps& ColumnProps = CColumnProps::Default)
{
    return CColumnProps(Name, __uuidof(_TypeGuid<T>), ColumnProps);
}


//
// Decoders
//

inline
void
GetPathName(
    __inout CStringW& sbPathName, 
    __in  IPathRegistry* pPathRegistry, 
    __in  const PathNode* pPathNode, 
    __in_opt const PathNode* pRelativeTo = 0)
{
    if (pPathNode) {
        SIZE_T  MaxLen = (SIZE_T)sbPathName.GetAllocLength();
        HRESULT hr = pPathRegistry->GetName(pPathNode, sbPathName.GetBuffer((int)MaxLen), MaxLen, pRelativeTo);

        if (hr == HRESULT_FROM_NT(STATUS_BUFFER_TOO_SMALL)) {
            sbPathName.ReleaseBufferSetLength(0);

            hr = pPathRegistry->GetName(pPathNode, sbPathName.GetBuffer((int)MaxLen), MaxLen, pRelativeTo);
        }

        if (FAILED(hr)) {
            ASSERT(SUCCEEDED(hr));
            AtlThrow(hr);
        }

        sbPathName.ReleaseBufferSetLength((int)MaxLen-1); // this length does not include NULL terminator
    } else {
        sbPathName.SetString(L"Unknown");
    }
}

inline
void
GetProcessName(
    __inout CStringW& sbProcessName,
    __in_opt const IProcessInfoSource::ProcessData* pProcess,
    __in_opt const IModernApplicationInfoSource* pModernApplicationInfoSource = NULL)
{
    if (pProcess) {
        const IModernApplicationInfoSource::ModernApplicationData* pModernApplicationData = NULL;
        {
            if (pModernApplicationInfoSource) {
                pModernApplicationData = pModernApplicationInfoSource->QueryModernApplicationData(pProcess);
            }
        }

        if (pModernApplicationData && pModernApplicationData->FriendlyName) {
            sbProcessName.Format(L"%ws <%ws> (%d)", 
                pProcess->ImageName ? pProcess->ImageName : IPathRegistry::Unknown, 
                pModernApplicationData->FriendlyName,
                pProcess->ProcessId);
        } else {
            sbProcessName.Format(L"%ws (%d)", 
                pProcess->ImageName ? pProcess->ImageName : IPathRegistry::Unknown, 
                pProcess->ProcessId);
        }
    } else {
        sbProcessName.SetString(L"<Unknown>");
    }
}

inline
void
GetProcessName(
    __inout CStringW& sbProcessName,
    __in_opt const IProcessInfoSource::ThreadData* pThread,
    __in_opt const IModernApplicationInfoSource* pModernApplicationInfoSource = NULL)
{
    GetProcessName(sbProcessName, pThread ? pThread->Process : NULL, pModernApplicationInfoSource);
}

inline
void
GetProcessNameByProcessID(
    __inout CStringW& sbProcessName,
    __in  IProcessInfoSource* pProcessInfoSource, 
    __in  TimeStamp ts, 
    __in  ULONG ProcessId, 
    __in  Proximity option = Exact,
    __in_opt const IModernApplicationInfoSource* pModernApplicationInfoSource = NULL)
{
    const IProcessInfoSource::ProcessData* pProcess = 
        pProcessInfoSource->QueryProcess(ts, ProcessId, option);

    GetProcessName(sbProcessName, pProcess, pModernApplicationInfoSource);
}

inline
void
GetProcessNameByThreadID(
    __inout CStringW& sbProcessName,
    __in  IProcessInfoSource* pProcessInfoSource, 
    __in  TimeStamp ts, 
    __in  ULONG ThreadId, 
    __in  Proximity option = Exact,
    __in_opt const IModernApplicationInfoSource* pModernApplicationInfoSource = NULL)
{
    const IProcessInfoSource::ThreadData* pThread = 
        pProcessInfoSource->QueryThread(ts, ThreadId, option);

    GetProcessName(sbProcessName, pThread, pModernApplicationInfoSource);
}

inline
void
GetDisplayName(
    __inout CStringW& DisplayName,
    __in  const ISysConfigInfoSource2::StridedServiceData2s& rgServices,
    __in  const IProcessInfoSource::ProcessData* pProcess
    )
{
    if (pProcess->ImageName)
    {
        DisplayName.Empty();

        for (ISysConfigInfoSource2::StridedServiceData2s::iterator itService = rgServices.begin(); itService != rgServices.end(); ++itService)
        {
            if ((pProcess->ProcessId == itService->ProcessId) && (_wcsicmp(pProcess->ImageName, itService->ProcessName) == 0))
            {
                if (!DisplayName.IsEmpty())
                {
                    DisplayName += ", ";
                }

                DisplayName += itService->DisplayName;
            }
        }

        if (DisplayName.IsEmpty())
        {
            DisplayName = pProcess->ImageName;
        }
    }
    else
    {
        DisplayName = IPathRegistry::Unknown;
    }
}

class CServiceDisplayNameDecoder
{
public:

    CServiceDisplayNameDecoder(
        __in  ISysConfigInfoSource2* pSysConfig
        )
    {
        if (FAILED(pSysConfig->QueryServices2(&m_rgServices)))
        {
            m_rgServices = ISysConfigInfoSource2::StridedServiceData2s();
        }
    }

    LPCWSTR GetDisplayName(
        __in_opt const IProcessInfoSource::ProcessData* pProcess
        )
    {
        if (!pProcess || m_rgServices.empty())
        {
            return L"<Unknown>";
        }

        CDisplayNames::iterator itDisplayName = m_mDisplayNames.find(pProcess);

        if (itDisplayName != m_mDisplayNames.end())
        {
            return itDisplayName->second.GetString();
        }
        else
        {
            CStringW& DisplayName = m_mDisplayNames[pProcess];

            XPerfGUI::GetDisplayName(DisplayName, m_rgServices, pProcess);

            return DisplayName.GetString();
        }
    }

private:

    typedef std::map<IProcessInfoSource::ProcessData const*, CStringW> CDisplayNames;

    CDisplayNames                               m_mDisplayNames;
    ISysConfigInfoSource2::StridedServiceData2s m_rgServices;
};


struct CSymbolPresentation
{
    LPCWSTR ImageName;
    LPCWSTR SymbolName;

public:
    CSymbolPresentation()
        : ImageName()
        , SymbolName()
    {
    }

    CSymbolPresentation(__in_opt LPCWSTR wszImageName, __in_opt LPCWSTR wszSymbolName)
        : ImageName(wszImageName)
        , SymbolName(wszSymbolName)
    {
    }
};


class CSymbolPresenter
{
    IProcessInfoSource* const m_pProcessInfoSource;
    ISymbolInfoSource* const m_pSymbolInfoSource;

public:

    CSymbolPresenter(
        __in IProcessInfoSource* pProcessInfoSource, 
        __in_opt ISymbolInfoSource* pSymbolInfoSource
        )
        : m_pProcessInfoSource(pProcessInfoSource)
        , m_pSymbolInfoSource(pSymbolInfoSource)
    {
    }

    static CSymbolPresentation GetUnknown()
    {
        return CSymbolPresentation(L"Unknown", L"Unknown");
    }

    HRESULT Present(
        __out CSymbolPresentation& presentation, 
        __in_opt IProcessInfoSource::ImageData const* pImage,
        __in  ULONG64 Address
        ) const throw()
    {
        presentation = GetUnknown();
                            
        if (pImage)
        {
            if (pImage->ImageName && pImage->ImageName->FileName)
            {
                presentation.ImageName = pImage->ImageName->FileName;
            }

            if (m_pSymbolInfoSource)
            {
                ISymbolInfoSource::SymbolData symData;

                m_pSymbolInfoSource->QuerySymbol(symData, pImage, Address);

                if (symData.SymbolName)
                {
                    presentation.SymbolName = symData.SymbolName;
                }
            }

            return S_OK;
        }

        return S_FALSE;
    }

    CSymbolPresentation Present(
        __in_opt IProcessInfoSource::ImageData const* pImage,
        __in  ULONG64 Address
        ) const
    {
        CSymbolPresentation presentation;

        COMGUARDTHROW(Present(presentation, pImage, Address));

        return presentation;
    }

    HRESULT Present(
        __out CSymbolPresentation& presentation, 
        __in_opt IProcessInfoSource::ProcessData const* pProcess,
        __in  TimeStamp Time,
        __in  ULONG64 Address, 
        __in  Proximity proximity = Exact
        ) const throw()
    {
        auto const pImage = pProcess ? m_pProcessInfoSource->QueryImage(pProcess, Time, Address, proximity) : NULL;

        COMGUARD(Present(presentation, pImage, Address));

        return S_OK;
    }

    CSymbolPresentation Present(
        __in_opt IProcessInfoSource::ProcessData const* pProcess,
        __in  TimeStamp Time,
        __in  ULONG64 Address, 
        __in  Proximity proximity = Exact
        ) const
    {
        CSymbolPresentation presentation;

        COMGUARDTHROW(Present(presentation, pProcess, Time, Address, proximity));

        return presentation;
    }

    HRESULT PresentThreadStart(
        __out CSymbolPresentation& presentation, 
        __in_opt IProcessInfoSource::ThreadData const* pThread
        ) const throw()
    {
        if (pThread)
        {
            COMGUARD(Present(presentation, pThread->Process, pThread->StartTime, pThread->StartAddr, Future));

            return S_OK;
        }
        else
        {
            presentation = GetUnknown();

            return S_FALSE;
        }
    }

    CSymbolPresentation PresentThreadStart(
        __in_opt IProcessInfoSource::ThreadData const* pThread
        ) const
    {
        CSymbolPresentation presentation;

        COMGUARDTHROW(PresentThreadStart(presentation, pThread));

        return presentation;
    }
};


inline
_Ret_maybenull_ ISymbolInfoSource* GetSymbolInfoSourceIfEnabled(__in_opt ISymbolInfoSource* pSymbolInfoSource)
{
    return (pSymbolInfoSource && pSymbolInfoSource->IsEnabled()) ? pSymbolInfoSource : NULL;
}


//
// Summary Table Fillers
//

template <class _Base>
class CFactoryWrapper 
    : public _Base
{
protected:
    _Base* Factory;

    CFactoryWrapper()
    {
        Factory = this;        
    }
};

class ATL_NO_VTABLE CSelectionToSummaryTableFactory :
    public CComObjectRoot,
    public ISummaryTableFactory
{
    CComPtr<ISelection> m_spSel;

public:

    BEGIN_COM_MAP(CSelectionToSummaryTableFactory)
        COM_INTERFACE_ENTRY(ISummaryTableFactory)
    END_COM_MAP()

    void SetSelection(
        __in  ISelection* pSelection
        )
    {
        m_spSel = pSelection;
    }

    //
    // ISummaryTableFactory::
    //

    STDMETHOD(CreateSummaryTable)(
        LPCWSTR wszTitle, 
        SIZE_T NumRows,
        SIZE_T NumCols,
        const ISummaryTable::ColumnProps* rgColumnProps,
        REFIID riid, 
        LPVOID* ppv)
    {
        return m_spSel->CreateSummaryTable(wszTitle, NumRows, NumCols, rgColumnProps, riid, ppv);
    }
};

const CATID CATID_ISummaryTableFiller = __uuidof(ISummaryTableFiller);

//class CPropertyBagImpl;
//template <typename _Derived>
/*class ATL_NO_VTABLE CPropertyBagImpl :
    public CComObjectRoot,
    public IPropertyBag
{

public:
    BEGIN_COM_MAP(CPropertyBagImpl)
        COM_INTERFACE_ENTRY(IPropertyBag)
    END_COM_MAP()

    protected:
        // std::map<LPCOLESTR, CStringW> PropertyMap;
        std::map<CStringW, CComVariant> propertyMap;

    public:
        STDMETHOD(Read)(
            __in LPCOLESTR pszPropName,
            __inout VARIANT* pVar,
            __inout IErrorLog *pErrorLog
        )
        {
            pErrorLog = NULL;
            if(pszPropName == NULL)
            {
                return E_POINTER;
            }

            CComVariant ccv;
            ccv.Attach(pVar);
            CStringW foo = (BSTR)ccv;
                if(PropertyMap.find(pszPropName) != PropertyMap.end())
                {
                    pVar = PropertyMap[pszPropName];
                    return S_OK;
                }
            }
            
            return E_INVALIDARG;
        }

        STDMETHOD(Write)(
            __in LPCOLESTR pszPropName,
            //__in std::string pVar
            __in VARIANT* pVar
        )
        {
            if(pszPropName == NULL)
            {
                return E_POINTER;
            }
            else
            {
                PropertyMap[pszPropName] = pVar;
                return S_OK;
            }
        }
};*/

template <typename _Derived>
class ATL_NO_VTABLE CSummaryTableFillerRoot : 
    public CSessionServiceRoot<_Derived>,
    public ISummaryTableFiller2
{
public:

    DECLARE_NO_REGISTRY()
    DECLARE_NOT_AGGREGATABLE(_Derived)

    typedef CSummaryTableFillerRoot<_Derived> _SummaryTableFiller;

    BEGIN_COM_MAP(_SummaryTableFiller)
        COM_INTERFACE_ENTRY(ISummaryTableFiller)
        COM_INTERFACE_ENTRY(ISummaryTableFiller2)
        COM_INTERFACE_ENTRY_CHAIN(_SessionService)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_SummaryTableFiller)
        IMPLEMENTED_CATEGORY(CATID_ISummaryTableFiller)
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()
    END_CATEGORY_MAP()

public:

    //
    // ISessionService::
    //

    STDMETHOD(OnSessionConnect)(
        __in  ISession* pSession
        )
    {
        UNREFERENCED_PARAMETER(pSession);
        return S_OK;
    }

    STDMETHOD(OnSessionProcessEvents)(
        __in  ISession* pSession
        )
    {
        UNREFERENCED_PARAMETER(pSession);
        return S_OK;
    }

    STDMETHOD(OnSessionReady)()
    {
        return S_OK;
    }

    //
    // ISummaryTableFiller::
    //

    STDMETHOD(GetColumnSet)(
        __inout SIZE_T &NumEntries,
        __out_ecount_part_opt(NumEntries, NumEntries) ISummaryTable::ColumnProps ColumnsOut[]
        )
    {
        ASSERT(ColumnsOut == NULL || (ColumnsOut != NULL && NumEntries > 0));

        if (ColumnsOut == NULL)
        {
            NumEntries = InternalGetNumColumns();
            return S_OK;
        }
        else
        {
            if (NumEntries > InternalGetNumColumns())
            {
                NumEntries = InternalGetNumColumns();
            }

            for (SIZE_T iColumn = 0; iColumn < NumEntries; ++iColumn)
            {
                InternalGetColumn(iColumn, ColumnsOut + iColumn);
            }

            return (NumEntries == InternalGetNumColumns()) ? S_OK : XPERF_E_BUFFER_TOO_SMALL;
        }
    }

    STDMETHOD(BuildSummaryTable)(
        __in  TimeStamp& BeginTime,
        __in  TimeStamp& EndTime,
        __in  ISummaryTableFactory* SummaryTableFactory,
        __in_opt IPropertyBag* ExtraArguments,
        __out ISummaryTable** SummaryTableOut
        )
    {
        UNREFERENCED_PARAMETER(BeginTime);
        UNREFERENCED_PARAMETER(EndTime);
        UNREFERENCED_PARAMETER(SummaryTableFactory);
        UNREFERENCED_PARAMETER(ExtraArguments);
     
        if (SummaryTableOut == NULL)
        {
            return E_POINTER;
        }

        *SummaryTableOut = NULL;

        return E_NOTIMPL;
    }

    STDMETHOD(BuildSummaryTableFromSelection)(
        __in  ISelection* Selection,
        __in_opt IPropertyBag* ExtraArguments,
        __out ISummaryTable** SummaryTableOut
        )
    {
        if (!Selection)
        {
            return E_POINTER;
        }

        TimeStamp tsBegin, tsEnd;        
        Selection->GetSelectedRange(tsBegin, tsEnd);

        if(tsEnd < tsBegin)
        {
            std::swap(tsBegin, tsEnd);
        }

        CComObjectStackEx<CSelectionToSummaryTableFactory> FactoryObject;
        FactoryObject.SetSelection(Selection);

        return BuildSummaryTable(tsBegin, tsEnd, &FactoryObject, ExtraArguments, SummaryTableOut);
    }

    STDMETHOD(IsDataAvailable)(
        __out BOOL* pbResult
        )
    {
        UNREFERENCED_PARAMETER(pbResult);
        return E_NOTIMPL;
    }

protected:

    virtual SIZE_T InternalGetNumColumns()
    {
        return 0;
    }

    virtual void InternalGetColumn(
        __in SIZE_T ColIndex,
        __out ISummaryTable::ColumnProps* ColPropsOut
        )
    {
        UNREFERENCED_PARAMETER(ColIndex);
        UNREFERENCED_PARAMETER(ColPropsOut);
    }
};

} // namespace XPerfGUI
