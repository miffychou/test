/*++

Copyright (c) 2003 Microsoft Corporation

Module Name:

    XPerfAddIn_Heap.hpp

Abstract:

    Heap Infosource header.  This Infosource provides information on events, allocations, and time series
    for outstanding allocation.  Each HeapRealloc event is decomposed into and treated as a HeapAlloc event
    and a HeapFree event.  Some events are marked as ignored.  Ignored events have no effect on allocation
    count and size statistics.  An event could be ignored because it does not contain enough information or
    is a duplicate or otherwise invalid.

Author:

    Joshua Chia (joshchia)  October 2007

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>                // include XPerfCore main header
#include <XPerfAddIn_Core.hpp>          // AddIn_Sample references core infosources

namespace XPerfAddIn
{

MIDL_INTERFACE("7B4B1686-BC3E-4a15-B8EC-5FAFE6F0E778")
IHeapInfoSource : public IUnknown
{
public:
    enum CHeapEventType
    {
        HeapEventType_Alloc = 0,
        HeapEventType_Free  = 1,
        HeapEventType_Destroy = 2
    };

    enum CHeapEventFlag
    {
        HeapEventFlag_Realloc = 1,  // indicates that the event is actually part of realloc event
        HeapEventFlag_Ignored = 2,  // indicates that the event has no effect on allocation statistics
    };

    struct HeapEvent
    {
        TimeStamp           Time;
        ULONG64             Handle;
        ULONG64             Address;
        ULONG64             Size;
        const IProcessInfoSource::ThreadData* Thread;
        const IProcessInfoSource::ProcessData* Process;
        const HeapEvent*    Counterpart;    // pointer to the matching event (alloc is matched to free) if applicable, NULL otherwise
        TimeStamp           FreeTime;
        ULONG               Source;
        ULONG               PointerSize;
        UCHAR               Type;
        UCHAR               Flags;
    };

public:

    typedef strided_adapter<const HeapEvent> StridedEvents;

    typedef bool (*PfnEventFilterCallback)(const HeapEvent& Event, PVOID pvContext);

    // returns events within the given time range
    STDMETHOD(QueryStridedEvents)(
        __out StridedEvents* pStridedEvents,
        __in const TimeStamp &QueryStart = TimeStamp::Min,
        __in const TimeStamp &QueryEnd = TimeStamp::Max
        ) const PURE;

    //
    // returns  i) non-ignored alloc events for allocations that are live for some part of the time range; and
    //         ii) ignored events with timestamps within the time range
    //
    STDMETHOD(QueryAllocations)(
        __out_ecount_part_opt(nEntries, nEntries) const HeapEvent** rgpBuffer,
        __inout SIZE_T& nEntries,
        __in const TimeStamp& QueryStart,
        __in const TimeStamp& QueryEnd,
        __in_opt PfnEventFilterCallback pfnFilter = NULL,
        __in_opt PVOID pvFilterContext = NULL
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

MIDL_INTERFACE("707E5E1E-F857-4C89-A63C-582D71F0A158")
IHeapExtentsInfoSource : public IUnknown
{
    enum ExtentEventType {
        ExtentEventType_Create = 0,
        ExtentEventType_Extend = 1,
        ExtentEventType_Contract = 2,
        ExtentEventType_Destroy = 3
    };

    struct ExtentEvent
    {
        TimeStamp       Time;
        ULONG64         Handle;

        ULONG64         CommittedSize;

        ULONG64         Address;
        ULONG64         FreeSpace;

        ULONG64         CommittedSpace;
        ULONG64         ReservedSpace;

        ULONG           Flags;
        ULONG           NoOfUCRs;

        const IProcessInfoSource::ThreadData* Thread;
        const IProcessInfoSource::ProcessData* Process;
        TimeStamp       FreeTime;

        ExtentEventType Type;
    };

public:
    typedef strided_adapter<const ExtentEvent> StridedEvents;

    // returns events within the given time range
    STDMETHOD(QueryStridedEvents)(
        __out StridedEvents* pStridedEvents,
        __in const TimeStamp &QueryStart = TimeStamp::Min,
        __in const TimeStamp &QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};


MIDL_INTERFACE("28697BFC-1553-4F02-B193-2D3A9EAA3E5E")
ICombinedHeapInfoSource : public IUnknown
{
    struct AffinityAssign
    {
        TimeStamp Time;
        ULONG AffinityIndex;
        
        AffinityAssign(TimeStamp time, ULONG affinityIndex)
        {
            Time = time;
            AffinityIndex = affinityIndex;
        }
    };
    typedef strided_adapter<const AffinityAssign> StridedAffinityAssignData;

    struct CBucketInfo
    {
    public:
        ULONG BucketIndex;
        ULONG MinBytes;
        ULONG MaxBytes;
        CBucketInfo()
            : BucketIndex(0),
              MinBytes(0),
              MaxBytes(0)
        {
        }
    };

    struct SubSegment : public Temporal
    {
    public:
        StridedAffinityAssignData StridedAffinityAssignData;
        ULONG64 Handle;
        ULONG64 BaseAddress;
        ULONG64 Size;       // Total size of the SubSegment in bytes
        ULONG64 SlotCount;
        const IProcessInfoSource::ProcessData* Process;
        CBucketInfo* BucketInfo;
        ULONG BlockSize;
    };

    struct Allocation : public Temporal
    {
    public:
        const IProcessInfoSource::ThreadData* Thread; 
        ULONG64 BaseAddress;
    protected:
        /*
            Following fields have been tightly packed with data to save memory, please refer to CCombinedHeapInfosource::CAllocation implementation for details.
        */
        ULONG64 SizeAndOtherEncodedInfo;        // Size and other information is encoded in the following pattern: |IsReallocated:2| Source:2| Size: 60|
        ULONG64 HandleOrSubsegment;             // Is the Lowest bit is on then it contains Subsegment* else it contains Handle
    };


public:
    typedef strided_adapter<const Allocation> StridedAllocaTionEvents;
    typedef strided_adapter<const SubSegment> StridedSubSegmentEvents;

    STDMETHOD(QueryStridedAllocationEvents)(
        __out StridedAllocaTionEvents* pStridedEvents
        ) const PURE;

    STDMETHOD(QueryLfhOnlyStridedAllocationEvents)(
        __out StridedAllocaTionEvents* pStridedEvents
    ) const PURE;

    STDMETHOD(QueryStridedSegmentEvents)(
        __out StridedSubSegmentEvents* pStridedEvents
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};


MIDL_INTERFACE("5AD5D55B-9515-4A0C-BE62-D3F7176CF982")
IHeapSegmentsInfoSource : public IUnknown
{
    enum SegmentEventType {
        SegmentEventType_Alloc = 0,
        SegmentEventType_Free = 1,
    };

    struct SegmentEvent 
    {
        TimeStamp           Time;
        ULONG64             Handle;

        ULONG64             Subsegment;
        ULONG               SubsegmentSize;
        ULONG               BlockSize;
        ULONG               PointerSize;

        const IProcessInfoSource::ThreadData* Thread;
        const IProcessInfoSource::ProcessData* Process;
        
        SegmentEventType    Type;
    };

public:
    typedef strided_adapter<const SegmentEvent> StridedEvents;


    // returns events within the given time range
    STDMETHOD(QueryStridedEvents)(
        __out StridedEvents* pStridedEvents,
        __in const TimeStamp &QueryStart = TimeStamp::Min,
        __in const TimeStamp &QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

} // namespace XPerfAddIn
