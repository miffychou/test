#pragma once

#include <XPerfAddIn_Core.hpp>
#include <XPerfInfoDev_XmlActions.hpp>

#include "..\..\..\..\eco\asmts\common\inc\EcoTypes.h"

#include <map>
#include <queue>

namespace AnalysisSupport
{
    struct EcoActivity;
}

namespace XPerfAddIn {

//
// Interval definitions
//

#define INTERVALS_INSTANCE_SUFFIX L"InstanceSuffix"
#define GUIDFORMAT   "{%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}"
#define LGUIDFORMAT L"{%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}"
#define GUIDCOMPONENTS(rguid) \
    (rguid).Data1, \
    (rguid).Data2, \
    (rguid).Data3, \
    (rguid).Data4[0], \
    (rguid).Data4[1], \
    (rguid).Data4[2], \
    (rguid).Data4[3], \
    (rguid).Data4[4], \
    (rguid).Data4[5], \
    (rguid).Data4[6], \
    (rguid).Data4[7]

//
// Intervals Infosource
//

MIDL_INTERFACE("EDDD8A57-B085-47D4-A9AC-7D07EFB79E18")
IIntervalsInfoSource : public IUnknown
{
    enum IntervalInstanceType 
    {
        InstanceTypeGeneric = 0,
        InstanceTypePid = 1,
        InstanceTypeClsid = 2,
        InstanceTypeDevice = 3,
        InstanceTypeGuid = 4,
        InstanceTypeMax
    };

    enum ValidateFailureCause
    {
        ValidateFailureChildStartTimeLessThanParent = 0,
        ValidateFailureChildEndTimeGreaterThanParent = 1,
        ValidateFailureStartTimeEqualsMaxTimeStamp = 2,
        ValidateFailureEndTimeEqualsMaxTimeStamp = 3,
        ValidateFailureRequiredIntervalMissing = 4,
        ValidateFailureStartTimeGreaterThanEnd = 5,
        ValidateFailureInvalidIfPresent = 6,
        ValidateFailureMax
    };

    struct IntervalConfiguration
    {
        GUID    Guid;
        LPCWSTR Name;
        LPCWSTR FriendlyName;
        LPCWSTR Tags;
        LPCWSTR Description;
        IntervalInstanceType InstanceType;
    };

    struct Marker
    {
        TimeStamp        Time;
        ULONG            ProcessId;
        ULONG            ThreadId;

        //
        // Fields below are only used if the marker is an actual ETW event
        //

        GUID             ProviderId;
        EVENT_DESCRIPTOR EventDescriptor;
        GUID             ActivityId;
    };

    struct Interval
    {
        TimeStampDelta get_Duration() const { return EndMarker.Time - StartMarker.Time; }
        __declspec(property(get=get_Duration)) TimeStampDelta Duration;

        TimeStamp get_StartTime() const { return StartMarker.Time; }
        void set_StartTime(__in const TimeStamp Time) { this->StartMarker.Time = Time; }

        __declspec(property(get=get_StartTime, put=set_StartTime)) TimeStamp StartTime;

        TimeStamp get_EndTime() const { return EndMarker.Time; }
        void set_EndTime(__in const TimeStamp Time) { this->EndMarker.Time = Time; }
        __declspec(property(get=get_EndTime, put=set_EndTime)) TimeStamp EndTime;

        //
        // Hierarchical support
        //

        const Interval* ParentInterval;
        SIZE_T ChildrenCount;
        __field_ecount(ChildrenCount) const Interval** Children;

        //
        // Instance specific fields
        //

        LPCWSTR InstanceName;
        ULONG InstanceIndex;

        //
        // Timing & event information
        //

        Marker StartMarker;
        Marker EndMarker;

        ULONG UniqueId;

        //
        // Configuration shared wuth the same intrval types
        //

        const IntervalConfiguration* pIntervalConfiguration;
    };

    typedef strided_adapter<const Interval> StridedIntervals;

    struct MandatoryInterval {
        LPCWSTR Name;
        BOOL Found;
    };

    STDMETHOD (QueryRootActivity)(
        __out const AnalysisSupport::EcoActivity** RootActivity
    ) const = 0;

    STDMETHOD (QueryData) (
        __out StridedIntervals* Intervals,
        __in  const TimeStamp&  QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp&  QueryEndTime   = TimeStamp::Max
    ) const = 0;

    STDMETHOD (QueryRootInterval)(
        __out const Interval** RootInterval
    ) const = 0;
    
    typedef strided_adapter<const Marker> StridedUnmatchedEvents;

    STDMETHOD (QueryUnmatchedEvents) (
        __out StridedUnmatchedEvents* UnmatchedEvents,
        __in  const TimeStamp&        QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp&        QueryEndTime   = TimeStamp::Max
    ) const = 0;
    
    STDMETHOD_(LPCWSTR, GetIntervalAttribute)(
        __in const Interval* Interval,
        __in LPCWSTR AttributeName
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;

    STDMETHOD (ValidateIntervals)(
        __in const Interval* RootInterval,
        __out AnalysisSupport::StridedEcoErrorsAndWarnings* stridedErrorsAndWarnings
    ) const PURE;

    STDMETHOD_(const IIntervalsInfoSource::Interval*, FindIntervalWithName)(
        __in const IIntervalsInfoSource::Interval* RootInterval,
        __in const LPCWSTR TargetName
    ) const PURE;

    STDMETHOD (GetActivityFromInterval)(
        __in const IIntervalsInfoSource::Interval* Interval,
        __out AnalysisSupport::EcoActivity** Activity
    ) const PURE;

    STDMETHOD (GetIntervalFromActivity) (
        __in const AnalysisSupport::EcoActivity* Activity,
        __out IIntervalsInfoSource::Interval** Interval
    ) const PURE;
};

//
// Intervals Controller
//

MIDL_INTERFACE("7826d87a-e28a-44c7-a39b-dd40b6473583")
IIntervalsController : public IUnknown
{
public:
    STDMETHOD(AddManifest)(
        __in LPCWSTR Filename
        ) PURE;

    STDMETHOD(AddDefaultManifest)(
        ) PURE;
};

//
// Intervals-To-Go: Interval processing based on the generic storage infosource
//                  so that intervals can be processed/re-processed after 
//                  the trace session is done processing.
//

MIDL_INTERFACE("7C31D2A8-AD33-4126-92A6-1202AA913D21")
IIntervalsToGoSession : public IUnknown
{
    // Controller functionality

    STDMETHOD(AddManifest)(
        __in LPCWSTR Filename
        ) PURE;

    STDMETHOD(ProcessData)(
        ) PURE;

    // Query functionality

    STDMETHOD (QueryRootActivity)(
        __out const AnalysisSupport::EcoActivity** RootActivity
    ) const PURE;

    STDMETHOD (QueryData) (
        __out IIntervalsInfoSource::StridedIntervals* Intervals,
        __in  const TimeStamp&  QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp&  QueryEndTime   = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryRootInterval)(
        __out const IIntervalsInfoSource::Interval** RootInterval
    ) const PURE;
    
    STDMETHOD (QueryUnmatchedEvents) (
        __out IIntervalsInfoSource::StridedUnmatchedEvents* UnmatchedEvents,
        __in  const TimeStamp&        QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp&        QueryEndTime   = TimeStamp::Max
    ) const PURE;
    
    STDMETHOD_(LPCWSTR, GetIntervalAttribute)(
        __in const IIntervalsInfoSource::Interval* Interval,
        __in LPCWSTR AttributeName
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;

    STDMETHOD (GetActivityFromInterval)(
        __in const IIntervalsInfoSource::Interval* Interval,
        __out AnalysisSupport::EcoActivity** Activity
    ) const PURE;

    STDMETHOD (GetIntervalFromActivity)(
        __in const AnalysisSupport::EcoActivity* Activity,
        __out IIntervalsInfoSource::Interval** Interval
    ) const PURE;
};

MIDL_INTERFACE("8D89CF24-2D5D-43DF-B24D-09ADC29ACE16")
IIntervalsToGoFactory : public IUnknown
{
    template <typename Q>
    HRESULT CreateSession(
        __deref_out Q** ppQ
        ) 
    {
        return CreateSession(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    STDMETHOD(CreateSession)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv
        ) PURE;
};

//
// Helper functions
//

template<class Fn>
static void for_each_child_interval(
    const IIntervalsInfoSource::Interval* Interval,
    Fn function)
{
    std::for_each(
        Interval->Children,
        Interval->Children + Interval->ChildrenCount,
        [&](const IIntervalsInfoSource::Interval* ChildInterval)
    {
        function(ChildInterval);
    });
}

template<class Fn>
void for_each_interval_dfs(
    const IIntervalsInfoSource::Interval* Root,
    Fn function)
{
    std::stack<const IIntervalsInfoSource::Interval*> stack;
    stack.push(Root);
    do
    {
        auto interval = stack.top();
        stack.pop();        
        std::for_each(
            interval->Children,
            interval->Children + interval->ChildrenCount,
            [&](const IIntervalsInfoSource::Interval* child)
        {
            stack.push(child);
        });
        function(interval);
    }
    while (!stack.empty());
}

template<class Fn>
void for_each_interval_bfs(
    const IIntervalsInfoSource::Interval* root,
    Fn function)
{
    std::queue<const IIntervalsInfoSource::Interval*> queue;
    queue.push(root);
    do
    {
        auto interval = queue.front();
        queue.pop();
        function(interval);
        std::for_each(
            interval->Children,
            interval->Children + interval->ChildrenCount,
            [&](const IIntervalsInfoSource::Interval* child)
        {
            queue.push(child);
        });
    }
    while (!queue.empty());
}

template<class Fn>
HRESULT 
for_each_interval_bfs_hr(
    const IIntervalsInfoSource::Interval* root,
    Fn function)
{
    HRESULT hr; 

    std::queue<const IIntervalsInfoSource::Interval*> queue;
    queue.push(root);
    do
    {
        auto interval = queue.front();
        queue.pop();

        hr = function(interval);
        if (FAILED(hr)) {
            return hr;
        }

        std::for_each(
            interval->Children,
            interval->Children + interval->ChildrenCount,
            [&](const IIntervalsInfoSource::Interval* child)
        {
            queue.push(child);
        });
    }
    while (!queue.empty());

    return S_OK;
}

template<class Fn>
void for_each_interval_bfs_if(
    const IIntervalsInfoSource::Interval* root,
    Fn function)
{
    bool processChildren;

    std::queue<const IIntervalsInfoSource::Interval*> queue;
    queue.push(root);
    do
    {
        auto interval = queue.front();
        queue.pop();
        if (interval == NULL)
        {
            continue;
        }
        processChildren = function(interval);
        if (processChildren)
        {
            std::for_each(
                interval->Children,
                interval->Children + interval->ChildrenCount,
                [&](const IIntervalsInfoSource::Interval* child)
            {
                queue.push(child);
            });
        }
    }
    while (!queue.empty());
}

//
// Interval XmlWriter
//

class CIntervalXmlWriter : public XPerfAddIn::XmlActions::CXmlWriter
{
public:
    typedef std::multimap<
        const IIntervalsInfoSource::Interval*,
        const ULONG> IssuesFromIntervalMap;


    CIntervalXmlWriter(
        __in FILE* file,
        __in_opt const IProcessInfoSource* _ProcessInfo = NULL
        )
        : CXmlWriter(XmlActions::CTimeConfig(XmlActions::CTimePresenter(
            XmlActions::TimeUnit_ns,
            XmlActions::TimeUnit_ns)), REPORTING_XML_INDENT, file)
        , m_ProcessInfo(_ProcessInfo)
    {
    }

    CIntervalXmlWriter(
        __in  const XmlActions::CTimeConfig& _TimeConfig,
        __in FILE* file,
        __in_opt const IProcessInfoSource* _ProcessInfo = NULL
        )
        : CXmlWriter( _TimeConfig , REPORTING_XML_INDENT, file)
        , m_ProcessInfo(_ProcessInfo)
    {
    }

    void Transform(
        __in  LPCWSTR szName,
        __in  const IIntervalsInfoSource::Marker& Event
        )
    {
        CStringW GuidStr;
        LPCWSTR ProcessName = L"unknown";

        if (m_ProcessInfo) {
            const IProcessInfoSource::ProcessData* ProcessData = m_ProcessInfo->QueryProcess(Event.Time, Event.ProcessId);

            if (ProcessData != NULL && ProcessData->ImageName != NULL) 
            {
                ProcessName = ProcessData->ImageName;
            }
        }

        Start(L"event");

        Attr(L"type", szName);
        Attr(L"time", Event.Time);
        Attr(L"pid", Event.ProcessId);
        Attr(L"process", ProcessName);
        Attr(L"tid", Event.ThreadId);

        if (Event.ActivityId != GUID_NULL) 
        {
            GuidStr.Format(LGUIDFORMAT, GUIDCOMPONENTS(Event.ActivityId));

            Attr(L"aid", GuidStr.GetString());
        }

        GuidStr.Format(LGUIDFORMAT, GUIDCOMPONENTS(Event.ProviderId));

        Attr(L"provider", GuidStr.GetString());
        Attr(L"value", Event.EventDescriptor.Id);
        Attr(L"version", static_cast<USHORT>(Event.EventDescriptor.Version));

        End();
    }

    void Transform(
        __in  LPCWSTR szName,
        __in  const IIntervalsInfoSource::Interval* Interval
        )
    {
        if (Interval->pIntervalConfiguration) 
        {
            const TimeStamp StartTime(Interval->StartMarker.Time);
            const TimeStamp EndTime(Interval->EndMarker.Time);

            const TimeStampDelta Duration = EndTime - StartTime;

            if (TimeConfig.ShouldBeReported(Duration)) 
            {
                CStringW GuidStr;

                Start(szName);

                GuidStr.Format(LGUIDFORMAT, GUIDCOMPONENTS(Interval->pIntervalConfiguration->Guid));

                Attr(L"guid", GuidStr.GetString());
                Attr(L"name", Interval->pIntervalConfiguration->Name);

                if (Interval->pIntervalConfiguration->FriendlyName) {
                    Attr(L"friendlyname", Interval->pIntervalConfiguration->FriendlyName);
                }

                Attr(L"tags", Interval->pIntervalConfiguration->Tags);
                Attr(L"duration", Duration);

                Transform(L"start", Interval->StartMarker);
                Transform(L"stop", Interval->EndMarker);

                if (Interval->InstanceName) {
                    Start(L"Instance");
                    Text(Interval->InstanceName);
                    End(L"Instance");
                }

                LPCWSTR Description = Interval->pIntervalConfiguration->Description;
                if (Description) {
                    Start(L"Description");
                    Text(Description);
                    End(L"Description");
                }

                for_each_child_interval(Interval, [this](const IIntervalsInfoSource::Interval* Interval)
                {
                    Transform(L"interval", Interval);
                });

                End(szName);
            }
        }
    }
    
    template<typename T>
    void Node(PCWSTR nodeName, const T value)
    {
        Start(nodeName);
        Text(value);
        End(nodeName);
    }

    void NodeIfNotNull(PCWSTR nodeName, PCWSTR value)
    {
        if (value)
        {
            Node(nodeName, value);
        }
    }

    void PrintActivities(
        const IIntervalsInfoSource::Interval* root,
        const IssuesFromIntervalMap& issuesFromInterval)
    {
        Start(L"Activities");
        for_each_interval_bfs(
            root,
            [=](const IIntervalsInfoSource::Interval* interval)
            {
                Start(L"Activity");
                Attr(L"ID", interval->UniqueId);
                if (interval->ParentInterval)
                {
                    Attr(L"parentID", interval->ParentInterval->UniqueId);
                }
                NodeIfNotNull(
                    L"ActivityClass",
                    interval->pIntervalConfiguration->Name);

                CStringW IntervalFriendlyName = interval->pIntervalConfiguration->FriendlyName ? 
                                                    interval->pIntervalConfiguration->FriendlyName :
                                                    interval->pIntervalConfiguration->Name;

                if (interval->InstanceName) {
                    CStringW ActivityTitle(IntervalFriendlyName);
                    ActivityTitle.Append(L": ");
                    ActivityTitle.Append(interval->InstanceName);
                    Node(L"ActivityTitle", ActivityTitle);
                } else {
                    Node(L"ActivityTitle", IntervalFriendlyName);
                }

                Node(L"ActivityStartTime", interval->StartTime.nsec);
                Node(L"ActivityEndTime", interval->EndTime.nsec);
                Node(L"ActivityStartThread", interval->StartMarker.ThreadId);
                Node(L"ActivityEndThread", interval->EndMarker.ThreadId);
                NodeIfNotNull(
                    L"ActivityDescription",
                    interval->pIntervalConfiguration->Description);
                auto itPair = issuesFromInterval.equal_range(interval);
                if (itPair.first != issuesFromInterval.end())
                {
                    Start(L"References");
#ifndef _PREFAST_ // work around Win8 138905
                    auto _this = this;
                    std::for_each(
                        itPair.first,
                        itPair.second,
                        [_this](IssuesFromIntervalMap::value_type vt)
                    {
                        _this->Start(L"IssueReference");
                        _this->Attr(L"IssueID", vt.second);
                        _this->End(L"IssueReference");
                    });
#endif
                    End(L"References");
                }
                End(L"Activity");
            });
        End(L"Activities");
    }

private:
    const IProcessInfoSource* m_ProcessInfo;
    static const UINT32 REPORTING_XML_INDENT = 2;
};

} // namespace XPerfAddIn
