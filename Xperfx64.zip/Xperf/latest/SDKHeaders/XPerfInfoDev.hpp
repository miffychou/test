/*++

Copyright (c) 2004 Microsoft Corporation

Module Name:

    XPerfInfoDev.hpp

Abstract:

    C++ client-side support for XPerfInfo.hpp

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfInfo.hpp>
#include <XPerfCoreDev.hpp>

#include <atlstr.h>

namespace XPerfCore
{

//
// EventDumpers
//

class ATL_NO_VTABLE CEventDumperRootBase : 
    public IEventDumper,
    public CRegistrableImpl<CEventDumperRootBase, IEventDumperRegistry, EventDumperRegistryEntry>
{
protected:
};

__declspec(selectany) REFCATID CATID_IEventDumper = __uuidof(IEventDumper);

#define IMPLEMENTED_CATEGORY_ETW_EVENTDUMPER() \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IEventDumper) \
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()

template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CEventDumperRoot :
    public CSessionServiceRoot<_Derived, ThreadModel>,
    public CEventDumperRootBase
{
public:
    typedef CEventDumperRoot<_Derived, ThreadModel> _EventDumper;

    BEGIN_COM_MAP(_EventDumper)
        COM_INTERFACE_ENTRY(IEventDumper)
        COM_INTERFACE_ENTRY_CHAIN(_SessionService)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_EventDumper)
        IMPLEMENTED_CATEGORY_ETW_EVENTDUMPER()
    END_CATEGORY_MAP()

public:
    STDMETHOD(OnSessionConnect)(__in ISession* pSession)
    {
        return OnSessionConnect_Auto(pSession, &_Derived::_Etw_EventDumper_GetMap);
    }
};

#define BEGIN_ETW_EVENTDUMPER_MAP() \
    static const EventDumperRegistryEntry* _Etw_EventDumper_GetMap(OUT SIZE_T* pcSize) { \
        static const EventDumperRegistryEntry _Map[] = {

#define ETW_EVENTDUMPER_MONITOR_PROVIDER(guid) \
            { &guid },

#define END_ETW_EVENTDUMPER_MAP() }; \
        *pcSize = RTL_NUMBER_OF(_Map); \
        return _Map; \
    };


//
// Actions
//

class ATL_NO_VTABLE CActionRootBase : 
    public IAction
{
protected:
};

__declspec(selectany) REFCATID CATID_IAction = __uuidof(IAction);

#define IMPLEMENTED_CATEGORY_XPERF_ACTION() \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IAction) \
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()

template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CActionRoot :
    public CComObjectRootEx<ThreadModel>,
    public CComCoClass<_Derived, &__uuidof(_Derived)>,
    public CActionRootBase
{
public:
    typedef CActionRoot<_Derived, ThreadModel> _Action;

    DECLARE_NOT_AGGREGATABLE(_Derived)
    DECLARE_NO_REGISTRY()

    BEGIN_COM_MAP(_Action)
        COM_INTERFACE_ENTRY(IAction)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_Action)
        IMPLEMENTED_CATEGORY_XPERF_ACTION()
    END_CATEGORY_MAP()

public:
};

#define DECLARE_CHAINING_COM_MAP_ACTION(x, y) \
    DECLARE_CHAINING_COM_MAP_EX(x, y, IAction)

#ifdef _XPERFCORE_INTERNAL_BUILD

class ATL_NO_VTABLE CMultiSessionActionRootBase
    : public IMultiSessionAction
{
    SIZE_T m_nSessions;
    SIZE_T m_iSession;

protected:

    CMultiSessionActionRootBase()
        : m_nSessions()
        , m_iSession()
    {
    }

    STDMETHOD(PrepareForMultipleSessions)(
        __in  SIZE_T nSessions
        )
    {
        m_nSessions = nSessions;

        return S_OK;
    }

    STDMETHOD(ConnectToSession)(
        __in  ISession* pSession
        )
    {
        UNREFERENCED_PARAMETER(pSession);

        ++m_iSession;

        return S_OK;
    }

    bool IsHostMultiSessionAware() const
    {
        return (m_nSessions != 0);
    }

    SIZE_T GetSessionCount() const
    {
        return (m_nSessions ? m_nSessions : 1);
    }

    SIZE_T GetSessionIndex() const
    {
        return m_iSession;
    }
};

__declspec(selectany) REFCATID CATID_IMultiSessionAction = __uuidof(IMultiSessionAction);

#define IMPLEMENTED_CATEGORY_XPERF_MULTISESSION_ACTION() \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IMultiSessionAction) \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IAction) \
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()

template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CMultiSessionActionRoot :
    public CComObjectRootEx<ThreadModel>,
    public CComCoClass<_Derived, &__uuidof(_Derived)>,
    public CMultiSessionActionRootBase
{
public:
    typedef CMultiSessionActionRoot<_Derived, ThreadModel> _Action;

    DECLARE_NOT_AGGREGATABLE(_Derived)
    DECLARE_NO_REGISTRY()

    BEGIN_COM_MAP(_Action)
        COM_INTERFACE_ENTRY(IAction)
        COM_INTERFACE_ENTRY(IMultiSessionAction)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_Action)
        IMPLEMENTED_CATEGORY_XPERF_MULTISESSION_ACTION()
    END_CATEGORY_MAP()

public:
};

#define DECLARE_CHAINING_COM_MAP_MULTISESSION_ACTION(x, y) \
    DECLARE_CHAINING_COM_MAP_EX(x, y, IMultiSessionAction)

#endif

//
// Replace non-ANSI characters and embedded UNICODE_NULL terminators with '?'
//

inline void ReplaceNonANSICharacters(
    __inout LPWSTR wszText
    )
{
    const SIZE_T TextLen = wcslen(wszText);

    for (SIZE_T iPos = 0; iPos < TextLen; ++iPos)
    {
        const WCHAR wch = wszText[iPos];
        bool  fSkipControl = false;

        if (wch < 0x1F)
        {
            if (wch != 0x09 && wch != 0x0A && wch != 0x0D)
            {
                fSkipControl = true;
            }
        }

        if ((wch > UCHAR_MAX) || (wch == UNICODE_NULL) || fSkipControl)
        {
            wszText[iPos] = L'?';
        }
    }
}

//-----------------------------------------------------------------------------

//
// COutputStreamImpl
//

class ATL_NO_VTABLE COutputStreamImpl : 
    public CComObjectRootEx<CComObjectThreadModel>,
    public CComCoClass<COutputStreamImpl>,
    public IOutputStream
{
    FILE* m_file;
    bool m_bOwnFile;

    CStringW m_sbTextW;

public:
    BEGIN_COM_MAP(COutputStreamImpl)
        COM_INTERFACE_ENTRY(IOutputStream)
    END_COM_MAP()

    COutputStreamImpl()
        : m_bOwnFile(false), m_file(NULL)
    {
    }

    HRESULT Open(__in LPCWSTR wszFilename)
    {
        m_file = _wfopen(wszFilename, L"w");
        m_bOwnFile = true;
        if (m_file) {
            return S_OK;
        } else {
            DWORD dwError = GetLastError();
            return HRESULT_FROM_WIN32(dwError);
        }
    }
    HRESULT Attach(__in FILE* file)
    {
        m_file = file;
        m_bOwnFile = false;
        return m_file ? S_OK : E_INVALIDARG;
    }
    HRESULT Close()
    {
        if (m_bOwnFile) {
            m_bOwnFile = false;
            if (m_file) {
                int iFail = fclose(m_file);
                m_file = NULL;
                if (iFail == EOF) {
                    DWORD dwError = GetLastError();
                    return HRESULT_FROM_WIN32(dwError);
                } else {
                    return S_OK;
                }
            }
        } else {
            m_file = NULL;
        }

        return S_OK;
    }
    ~COutputStreamImpl()
    {
        Close();
    }

    //
    // IOutputStream
    //

    STDMETHOD(Write)(
        __in_bcount(cb) LPCVOID pv,
        __in  SIZE_T cb,
        __out_opt SIZE_T* pcbWritten )
    {
        SIZE_T cbWritten = fwrite(pv, sizeof(CHAR), cb, m_file);
        if (cbWritten < cb) {
            return E_FAIL;
        }
        if (pcbWritten) {
            *pcbWritten = cbWritten;
        }
        return S_OK;
    }

    /* [local] */
    STDMETHOD_(SSIZE_T, PrintV)(
        __in  LPCWSTR wszFormat, 
        __in  va_list argptr )
    {
        try
        {
            m_sbTextW.FormatV(wszFormat, argptr);

            ReplaceNonANSICharacters(m_sbTextW.GetBuffer());
        }
        catch (CAtlException&)
        {
            errno = ENOMEM;
            return -1;
        }

        return fwprintf(m_file, L"%ws", m_sbTextW.GetString());
    }

    /* [local] */
    STDMETHOD_(SSIZE_T, PrintV)(
        __in  LPCSTR szFormat,
        __in  va_list argptr )
    {
        return vfprintf(m_file, szFormat, argptr);
    }

    //
    // Creation support
    //

    static
    HRESULT CreateInstanceRef(__inout CRefCountedPtr<COutputStreamImpl>& rspOutputStream, __in FILE* file)
    {
        return _CreateInstanceRef(rspOutputStream, file);
    }

    static
    HRESULT CreateInstanceRef(__inout CRefCountedPtr<COutputStreamImpl>& rspOutputStream, __in LPCWSTR wszFilename)
    {
        return _CreateInstanceRef(rspOutputStream, wszFilename);
    }

    static
    HRESULT CreateInstance(__in REFIID riid, __deref_out LPVOID* ppv, __in FILE* file)
    {
        return _CreateInstance(riid, ppv, file);
    }

    template <typename Q>
    static
    HRESULT CreateInstance(__deref_out Q** ppQ, __in FILE* file)
    {
        return CreateInstance(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), file);
    }

    static
    HRESULT CreateInstance(__in REFIID riid, __deref_out LPVOID* ppv, __in LPCWSTR wszFilename)
    {
        return _CreateInstance(riid, ppv, wszFilename);
    }

    template <typename Q>
    static
    HRESULT CreateInstance(__deref_out Q** ppQ, __in LPCWSTR wszFilename)
    {
        return CreateInstance(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), wszFilename);
    }

private:
    HRESULT Init(__in FILE* file)
    {
        return Attach(file);
    }

    HRESULT Init(__in LPCWSTR wszFilename)
    {
        return Open(wszFilename);
    }

    static
    HRESULT _CreateInstanceRef(__inout CRefCountedPtr<COutputStreamImpl>& rspOutputStream)
    {
        CComObject<COutputStreamImpl>* pOut = NULL;

        HRESULT hr = CComObject<COutputStreamImpl>::CreateInstance(&pOut);
        
        if (SUCCEEDED(hr)) {
            rspOutputStream = pOut;
        }

        return hr;
    }

    template <typename Arg>
    static
    HRESULT _CreateInstanceRef(__inout CRefCountedPtr<COutputStreamImpl>& rspOutputStream, __in Arg arg)
    {
        CRefCountedPtr<COutputStreamImpl> spOut;

        HRESULT hr = _CreateInstanceRef(spOut);

        if (SUCCEEDED(hr)) {
            // Init
            hr = spOut->Init(arg);

            if (SUCCEEDED(hr)) {
                // Transfer reference
                rspOutputStream.Attach(spOut.Detach());
            }
        }

        return hr;
    }

    template <typename Arg>
    static
    HRESULT _CreateInstance(__in REFIID riid, __deref_out LPVOID* ppv, __in Arg arg)
    {
        CRefCountedPtr<COutputStreamImpl> spOut;

        HRESULT hr = _CreateInstanceRef(spOut, arg);

        if (SUCCEEDED(hr)) {
            // QI
            hr = spOut->QueryInterface(riid, ppv);
        }

        return hr;
    }
};

//
// COutputStreamOnStringImpl
//

class ATL_NO_VTABLE COutputStreamOnStringImpl
    :  public CComObjectRootEx<CComObjectThreadModel>
    , public CComCoClass<COutputStreamOnStringImpl>
    , public IOutputStream
{
    CStringW*   m_psb; // target string buffer [NOT OWNED]
    CStringA    m_sbA; // transient string builder for ANSI operations

public:
    BEGIN_COM_MAP(COutputStreamOnStringImpl)
        COM_INTERFACE_ENTRY(IOutputStream)
    END_COM_MAP()

    COutputStreamOnStringImpl()
        : m_psb(NULL)
    {
    }

    HRESULT Attach(__in CStringW* psb)
    {
        m_psb = psb;
        return m_psb ? S_OK : E_INVALIDARG;
    }
    HRESULT Close()
    {
        m_psb = NULL;
        return S_OK;
    }
    ~COutputStreamOnStringImpl()
    {
        Close();
    }

    //
    // IOutputStream
    //

    STDMETHOD(Write)(
        __in_bcount(cb) LPCVOID pv,
        __in  SIZE_T cb,
        __out_opt SIZE_T* pcbWritten )
    {
        if (!m_psb) {
            return E_FAIL;
        }

        if (cb % sizeof(WCHAR)) {
            return E_INVALIDARG;
        }

        SIZE_T const cch = cb / sizeof(WCHAR);

        if (cch >= INT_MAX) {
            return E_INVALIDARG;
        }

        try {
            m_psb->Append(reinterpret_cast<WCHAR const*>(pv), static_cast<int>(cch));
        } catch (CAtlException& atlExc) {
            return atlExc;
        }

        if (pcbWritten) {
            *pcbWritten = cb;
        }
        return S_OK;
    }

    /* [local] */
    STDMETHOD_(SSIZE_T, PrintV)(
        __in  LPCWSTR wszFormat, 
        __in  va_list argptr )
    {
        if (!m_psb) {
            return E_FAIL;
        }

        try
        {
            int const cchStart = m_psb->GetLength();

            m_psb->AppendFormatV(wszFormat, argptr);

            int const cchEnd = m_psb->GetLength();

            return cchEnd - cchStart;
        }
        catch (CAtlException& atlExc)
        {
            return atlExc;
        }
    }

    /* [local] */
    STDMETHOD_(SSIZE_T, PrintV)(
        __in  LPCSTR szFormat,
        __in  va_list argptr )
    {
        if (!m_psb) {
            return E_FAIL;
        }

        try 
        {
            m_sbA.FormatV(szFormat, argptr);

            int const cchStart = m_psb->GetLength();

            m_psb->AppendFormat(L"%hs", m_sbA.GetString());

            int const cchEnd = m_psb->GetLength();

            return cchEnd - cchStart;
        }
        catch (CAtlException& atlExc)
        {
            return atlExc;
        }
    }

    //
    // Creation support
    //

    static
    HRESULT CreateInstanceRef(__inout CRefCountedPtr<COutputStreamOnStringImpl>& rspOutputStream, __in CStringW* psb)
    {
        return _CreateInstanceRef(rspOutputStream, psb);
    }

    static
    HRESULT CreateInstance(__in REFIID riid, __deref_out LPVOID* ppv, __in CStringW* psb)
    {
        return _CreateInstance(riid, ppv, psb);
    }

    template <typename Q>
    static
    HRESULT CreateInstance(__deref_out Q** ppQ, __in CStringW* psb)
    {
        return CreateInstance(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), psb);
    }

private:
    HRESULT Init(__in CStringW* psb)
    {
        return Attach(psb);
    }

    static
    HRESULT _CreateInstanceRef(__inout CRefCountedPtr<COutputStreamOnStringImpl>& rspOutputStream)
    {
        CComObject<COutputStreamOnStringImpl>* pOut = NULL;

        HRESULT hr = CComObject<COutputStreamOnStringImpl>::CreateInstance(&pOut);
        
        if (SUCCEEDED(hr)) {
            rspOutputStream = pOut;
        }

        return hr;
    }

    template <typename Arg>
    static
    HRESULT _CreateInstanceRef(__inout CRefCountedPtr<COutputStreamOnStringImpl>& rspOutputStream, __in Arg arg)
    {
        CRefCountedPtr<COutputStreamOnStringImpl> spOut;

        HRESULT hr = _CreateInstanceRef(spOut);

        if (SUCCEEDED(hr)) {
            // Init
            hr = spOut->Init(arg);

            if (SUCCEEDED(hr)) {
                // Transfer reference
                rspOutputStream.Attach(spOut.Detach());
            }
        }

        return hr;
    }

    template <typename Arg>
    static
    HRESULT _CreateInstance(__in REFIID riid, __deref_out LPVOID* ppv, __in Arg arg)
    {
        CRefCountedPtr<COutputStreamOnStringImpl> spOut;

        HRESULT hr = _CreateInstanceRef(spOut, arg);

        if (SUCCEEDED(hr)) {
            // QI
            hr = spOut->QueryInterface(riid, ppv);
        }

        return hr;
    }
};

//-----------------------------------------------------------------------------

//
// COutputStreamsImpl
//

template <typename _Derived>
class COutputStreamsImpl
{
protected:
    typedef COutputStreamsImpl<_Derived> _OutputStreams;

public:
    STDMETHOD(GetStdOut)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv )
    {
        if (!m_spStdOut) {
            return E_UNEXPECTED;
        }
        return m_spStdOut->QueryInterface(riid, ppv);
    }

    STDMETHOD(GetStdErr)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv )
    {
        if (!m_spStdErr) {
            return E_UNEXPECTED;
        }
        return m_spStdErr->QueryInterface(riid, ppv);
    }

    STDMETHOD(SetStdOut)( 
        __in_opt LPUNKNOWN pUnk )
    {
        if (!pUnk) {
            return static_cast<_Derived*>(this)->SetStdOutNull();
        }

        CComPtr<IOutputStream> spStdOut;
        HRESULT hr = pUnk->QueryInterface(&spStdOut);
        if (SUCCEEDED(hr)) {
            m_spStdOut = spStdOut;
        }
        return hr;
    }

    STDMETHOD(SetStdErr)(
        __in_opt LPUNKNOWN pUnk )
    {
        if (!pUnk) {
            return static_cast<_Derived*>(this)->SetStdErrNull();
        }

        CComPtr<IOutputStream> spStdErr;
        HRESULT hr = pUnk->QueryInterface(&spStdErr);
        if (SUCCEEDED(hr)) {
            m_spStdErr = spStdErr;
        }
        return hr;
    }

protected:
    HRESULT SetStdOutNull()
    {
        return E_INVALIDARG;
    }

    HRESULT SetStdErrNull()
    {
        return E_INVALIDARG;
    }

    CComPtr<IOutputStream>  m_spStdOut;
    CComPtr<IOutputStream>  m_spStdErr;
};


//
// HostConfig support
//

MIDL_INTERFACE("51370A43-C11F-4D21-8E78-893A753A6131")
IHostConfig_Private: public IUnknown
{
public:
    STDMETHOD(SetTarget)(IHostConfig::Target eTarget) PURE;
};

DECLSPEC_SELECTANY REFCATID CATID_IHostConfig = __uuidof(IHostConfig);

} // namespace XPerfCore

