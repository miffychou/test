/*++

Copyright (c) 2003 Microsoft Corporation

Module Name:

    XPerfAddIn_NTPerf.hpp

Abstract:

    XPerfCore NtPerf AddIn interfaces

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>                // include XPerfCore main header
#include <XPerfAddIn_Core.hpp>          // AddIn_NTPerf references core infosources

#ifdef _XPERFCORE_PERF_NT_COMPONENT_BUILD
#define XPERFCORE_DEPRECATED
#else
#define XPERFCORE_DEPRECATED    __declspec(deprecated)
#endif

namespace XPerfAddIn 
{

//
// Generic
//

MIDL_INTERFACE("9E1BCF24-5099-4577-A7DE-8169320F59B6") 
IGenericInfoSource : public IUnknown
{
    //
    // Crimson ETW Events
    //

    struct GenericEvent
    {
        TimeStamp           Time;
        EVENT_DESCRIPTOR    EventDescriptor;
    };

    typedef strided_adapter<const GenericEvent> StridedGenericEvents;

    STDMETHOD (QueryUnhandledProviderIds) (
        __out_ecount_part_opt(NumEntries, NumEntries) const GUID* ProviderIds[],
        __inout SIZE_T& NumEntries
        ) const PURE;

    STDMETHOD (QueryUnhandledEvents) (
        __out StridedGenericEvents* _StridedGenericEvents,
        __in  REFGUID ProviderId,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    //
    // Classic ETW Events
    //

    struct GenericClassicEvent
    {
        TimeStamp                   Time;
        CLASSIC_EVENT_DESCRIPTOR    EventDescriptor;
    };

    typedef strided_adapter<const GenericClassicEvent> StridedGenericClassicEvents;

    STDMETHOD (QueryUnhandledClassicEventGuids) (
        __out_ecount_part_opt(NumEntries, NumEntries) const GUID* ClassicEventGuids[],
        __inout SIZE_T& NumEntries
        ) const PURE;

    STDMETHOD (QueryUnhandledClassicEvents) (
        __out StridedGenericClassicEvents* _StridedGenericClassicEvents,
        __in  REFGUID EventGuid,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};

MIDL_INTERFACE("2269AD30-BF8B-45FC-B9AD-99CA01B6FFCF") 
IGenericInfoSource2 : public IGenericInfoSource
{
    //
    // Crimson ETW Events
    //

    struct GenericEvent2 : GenericEvent
    {
        ULONG ThreadId;
        ULONG Cpu;
    };

    typedef strided_adapter<const GenericEvent2> StridedGenericEvents2;

    using IGenericInfoSource::QueryUnhandledEvents;

    STDMETHOD (QueryUnhandledEvents) (
        __out StridedGenericEvents2* _StridedGenericEvents,
        __in  REFGUID ProviderId,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    //
    // Classic ETW Events
    //

    struct GenericClassicEvent2 : GenericClassicEvent
    {
        ULONG ThreadId;
        ULONG Cpu;
    };

    typedef strided_adapter<const GenericClassicEvent2> StridedGenericClassicEvents2;

    using IGenericInfoSource::QueryUnhandledClassicEvents;

    STDMETHOD (QueryUnhandledClassicEvents) (
        __out StridedGenericClassicEvents2* _StridedGenericClassicEvents,
        __in  REFGUID EventGuid,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

};


//
// GenericStorageCounts Infosource
//

MIDL_INTERFACE("4DDE1FE2-2E75-4DC9-B137-B35F9F0AB214")
IGenericStorageCountsInfoSource : public IUnknown
{
public:
    STDMETHOD(QueryStatistics)(
        __out ULONGLONG* pcEvents,
        __out ULONGLONG* pcbEventStorage
        ) const PURE;
};


//
// GenericStorage Infosource
//

MIDL_INTERFACE("F72AF72A-1CF0-4056-9A40-2FAD85522C96")
IGenericStorageInfoSource : public IUnknown
{
    STDMETHOD(QueryDirectData) (
        __deref_out_ecount(*pcEvents) TimeStamp const** prgTimeStamps,
        __deref_out_ecount(*pcEvents) EVENT_RECORD const* const** prgpEventRecords,
        __out SIZE_T* pcEvents,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};


//
// Event Name
//

MIDL_INTERFACE("B1E4D35B-F860-4868-895B-8899CDEEBDE8")
IEventNameInfoSource : public IUnknown
{
    STDMETHOD(QueryEventName)(
        __out LPCWSTR* pwszEventName,
        __in  REFGUID ProviderId,
        __in  const EVENT_DESCRIPTOR& EventDescriptor
        ) const PURE;

    STDMETHOD(QueryProviderName)(
        __out LPCWSTR* pwszProviderName,
        __in  REFGUID ProviderId
        ) const PURE;

    STDMETHOD(QueryClassicEventName)(
        __out LPCWSTR* pwszEventName,
        __in  REFGUID ClassicEventGuid,
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor
        ) const PURE;

    STDMETHOD(QueryClassicEventGuidName)(
        __out LPCWSTR* pwszClassicEventGuidName,
        __in  REFGUID ClassicEventGuid
        ) const PURE;
};


//
// Stack Key infosource
//

MIDL_INTERFACE("C07CAE44-3A8B-4056-A8C1-CD48158D0BB3")
IStackKeyInfoSource : public IUnknown
{
    struct StackKey
    {
        TimeStamp           TimeStamp;
        ULONG               ProcessId;
        ULONG               ThreadId;
    };

    STDMETHOD(QueryDirectKeyData)(
        __deref_out_ecount_full(*pcStacks) const StackKey** prgStackKeys,
        __out SIZE_T* pcStacks
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};

MIDL_INTERFACE("EF5CCB59-C928-4A62-81D3-DAFBECE47E52")
IStackKeyInfoSource2 : public IStackKeyInfoSource
{
    using IStackKeyInfoSource::QueryDirectKeyData;

    STDMETHOD(QueryDirectKeyData)(
        __deref_out_ecount_full(*pcStacks) const StackKey** prgStackKeys,
        __deref_out_ecount_full(*pcStacks) const ULONG** prgStackCpus,
        __out SIZE_T* pcStacks
        ) const PURE;
};


//
// Stack Frame infosource
//

MIDL_INTERFACE("162DAF49-6ADA-4156-A81D-DC05E746090F")
IStackFrameInfoSource : public IUnknown
{
    struct VirtualHit
    {
        ULONG64 Address;
    };

    struct StackFrame
    {
        const StackFrame*   Caller;
    };

    struct StackTop
    {
        const StackFrame*   TopStackFrame;
    };

    STDMETHOD(QueryDirectFrameData)(
        __deref_out_ecount_full(*pcStacks) const StackTop** prgStackTops,
        __out SIZE_T* pcStacks,
        __deref_out_ecount_full(*pcStackFrames) const StackFrame** prgStackFrames,
        __deref_out_ecount_full(*pcStackFrames) const VirtualHit** prgVirtualHits,
        __out SIZE_T* pcStackFrames
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};

//
// Stack Query infosource
//

MIDL_INTERFACE("B11EE401-2DD6-414A-AFC3-3FE458CDA3C0")
IStackTopQueryInfoSource : public IUnknown
{
    XPERFCORE_DEPRECATED
    STDMETHOD(QueryStackTopByTimeStamp)(
        __deref_opt_out const IStackFrameInfoSource::StackTop** ppStackTop,
        __in  const TimeStamp timestamp
        ) const PURE;

    STDMETHOD(QueryStackTopByTimeStampThreadId)(
        __deref_opt_out const IStackFrameInfoSource::StackTop** ppStackTop,
        __in  const TimeStamp timestamp,
        __in  const ULONG ThreadId
        ) const PURE;

    __declspec(deprecated)
    _Ret_maybenull_ const IStackFrameInfoSource::StackTop* QueryStackTop(
        __in  const TimeStamp timestamp
        )
    {
        UNREFERENCED_PARAMETER(timestamp);
        return NULL;
    }

    _Ret_maybenull_ const IStackFrameInfoSource::StackTop* QueryStackTop(
        __in  const TimeStamp timestamp,
        __in  const ULONG ThreadId
        )
    {
        const IStackFrameInfoSource::StackTop* pStackTop;
        if (SUCCEEDED(QueryStackTopByTimeStampThreadId(&pStackTop, timestamp, ThreadId))) {
            return pStackTop;
        } else {
            return NULL;
        }
    }

};

//
// Stack Query infosource
//

MIDL_INTERFACE("8A92C3C5-DDF2-4ADB-B4DE-D44475CBE0EE")
IStackTopQueryInfoSource2 : public IStackTopQueryInfoSource
{
    STDMETHOD(QueryStackTopByTimeStampThreadIdCpu)(
        __deref_opt_out const IStackFrameInfoSource::StackTop** ppStackTop,
        __in  const TimeStamp timestamp,
        __in  const ULONG ThreadId,
        __in  const ULONG Cpu
        ) const PURE;

    using IStackTopQueryInfoSource::QueryStackTop;

    _Ret_maybenull_ const IStackFrameInfoSource::StackTop* QueryStackTop(
        __in  const TimeStamp timestamp,
        __in  const ULONG ThreadId,
        __in  const ULONG Cpu
        )
    {
        const IStackFrameInfoSource::StackTop* pStackTop;
        if (SUCCEEDED(QueryStackTopByTimeStampThreadIdCpu(&pStackTop, timestamp, ThreadId, Cpu))) {
            return pStackTop;
        } else {
            return NULL;
        }
    }
};

} // namespace XPerfAddIn

namespace XPerfGUI
{
    class StackTop
    {
    protected:
        typedef const XPerfAddIn::IStackFrameInfoSource::StackTop* _BaseType;
        typedef StackTop    _Myself;
    public:
        StackTop() : m_value(_BaseType()) {}
        StackTop(const _BaseType& value) : m_value(value) {}
        operator _BaseType&() { return m_value; }
        operator const _BaseType&() const { return m_value; }
        _Myself& operator =(const _BaseType& value) { m_value = value; return *this; }
    protected:
        _BaseType m_value;
    };
}

namespace XPerfAddIn
{

//
// Stack mapping infosource
//

MIDL_INTERFACE("AB5DAF5B-95A3-4580-9DD6-7C5FB6E58D43")
IStackMappingInfoSource : public IUnknown
{
    struct Event;
    typedef strided_adapter<const Event> StridedEvents;
    struct EventProvider;
    typedef strided_adapter<const EventProvider> StridedEventProviders;

    struct Event
    {
        EVENT_DESCRIPTOR    EventDescriptor;
        const EventProvider* EventProvider;

    public:
        Event()
            : EventDescriptor()
            , EventProvider()
        {
        }

        CLASSIC_EVENT_DESCRIPTOR GetClassicEventDescriptor() const
        {
            CLASSIC_EVENT_DESCRIPTOR ClassicEventDescriptor;

            ClassicEventDescriptor.Class.Type = EventDescriptor.Opcode;
            ClassicEventDescriptor.Class.Level = EventDescriptor.Level;
            ClassicEventDescriptor.Class.Version = EventDescriptor.Version;

            return ClassicEventDescriptor;
        }
        __declspec(property(get=GetClassicEventDescriptor)) CLASSIC_EVENT_DESCRIPTOR ClassicEventDescriptor;

        const GUID& GetProviderId() const
        {
            return EventProvider->ProviderId;
        }
        __declspec(property(get=GetProviderId)) const GUID& ProviderId;

        BOOLEAN GetIsClassic() const
        {
            return EventProvider->IsClassic;
        }
        __declspec(property(get=GetIsClassic)) BOOLEAN IsClassic;
    };

    struct EventProvider
    {
        GUID                ProviderId;
        StridedEvents       Events;
        BOOLEAN             IsClassic;

    public:
        EventProvider()
            : ProviderId()
            , Events()
            , IsClassic()
        {
        }
    };

    struct StackMapping
    {
        const Event*        Event;
    };

    STDMETHOD(QueryDirectMappingData)(
        __deref_out_ecount_full(*pcStacks) const StackMapping** prgStackMappings,
        __out SIZE_T* pcStacks
        ) const PURE;

    STDMETHOD(QueryStridedEventData)(
        __out StridedEvents* pStridedEvents
        ) const PURE;

    STDMETHOD(QueryStridedEventProvidersData)(
        __out StridedEventProviders* pStridedEventProviders
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};


//
// Stack Analysis InfoSource
//

struct IStackAnalysisFilter;
struct IStackAnalysisResults;

MIDL_INTERFACE("63A58102-6AEF-4F9B-94D6-C5D597AC8CA0")
IStackAnalysis : public IUnknown
{
    struct CExclusiveHitStatistics
    {
        SIZE_T  ExclusiveHits;
        SIZE_T  ExclusiveUniqueHits;

    public:
        CExclusiveHitStatistics()
            : ExclusiveHits()
            , ExclusiveUniqueHits()
        {
        }
    };

    struct CInclusiveHitStatistics
        : public CExclusiveHitStatistics
    {
        SIZE_T  UniInclusiveHits;
        SIZE_T  MultiInclusiveHits;
        SIZE_T  UniInclusiveUniqueHits;
        SIZE_T  MultiInclusiveUniqueHits;

    public:
        CInclusiveHitStatistics()
            : CExclusiveHitStatistics()
            , UniInclusiveHits()
            , MultiInclusiveHits()
            , UniInclusiveUniqueHits()
            , MultiInclusiveUniqueHits()
        {
        }
    };

    struct CSymbol;
    typedef strided_adapter<const CSymbol>          CSymbols;
    struct CSymbolImage;
    typedef strided_adapter<const CSymbolImage>     CSymbolImages;
    typedef sparse_adapter<const CSymbolImage>      CSymbolImages_Sparse;
    struct CSymbolHit;
    typedef strided_adapter<const CSymbolHit>       CSymbolHits;
    typedef sparse_adapter<const CSymbolHit>        CSymbolHits_Sparse;
    struct CVirtualImage;
    typedef strided_adapter<const CVirtualImage>    CVirtualImages;
    typedef sparse_adapter<const CVirtualImage>     CVirtualImages_Sparse;
    struct CVirtualHit;
    typedef strided_adapter<const CVirtualHit>      CVirtualHits;
    typedef sparse_adapter<const CVirtualHit>       CVirtualHits_Sparse;
    struct CStackFrame;
    typedef strided_adapter<const CStackFrame>      CStackFrames;
    typedef sparse_adapter<const CStackFrame>       CStackFrames_Sparse;
    struct CProcess;
    typedef strided_adapter<const CProcess>         CProcesses;
    struct CThread;
    typedef strided_adapter<const CThread>          CThreads;
    struct CEventProvider;
    typedef strided_adapter<const CEventProvider>   CEventProviders;
    struct CEvent;
    typedef strided_adapter<const CEvent>           CEvents;
    struct CClassification;
    typedef strided_adapter<const CClassification>  CCClassifications;
    struct CStack;
    typedef strided_adapter<const CStack>           CStacks;

    struct CSymbolImage
        : public CInclusiveHitStatistics
    {
        const ISymbolInfoSource::SymbolImageData* pImageData;
        CSymbols                Symbols;
        CVirtualImages_Sparse   VirtualImages;

    public:
        CSymbolImage()
            : CInclusiveHitStatistics()
            , pImageData()
            , Symbols()
            , VirtualImages()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pImageData ? FALSE : TRUE;
        }
        __declspec(property(get=GetIsUnknown))  BOOLEAN IsUnknown;

        LPCWSTR GetName() const
        {
            return pImageData ? pImageData->OriginalFileName : NULL;
        }
        __declspec(property(get=GetName))       LPCWSTR Name;

        ULONG32 GetSize() const
        {
            return GetImageSize();
        }
        __declspec(property(get=GetSize))       ULONG32 Size;

        ULONG32 GetImageSize() const
        {
            return pImageData ? pImageData->ImageWeakKey.ImageSize : 0;
        }
        __declspec(property(get=GetImageSize))  ULONG32 ImageSize;

        DWORD GetTimeDateStamp() const
        {
            return pImageData ? pImageData->ImageWeakKey.TimeDateStamp : 0;
        }
        __declspec(property(get=GetTimeDateStamp))  DWORD TimeDateStamp;
    };

    struct CSymbol 
        : public CInclusiveHitStatistics
    {
        ULONG32                 Base;
        ULONG32                 Limit;
        LPCWSTR                 Name;
        const CSymbolImage*     pSymbolImage;
        CSymbolHits             SymbolHits;

    public:
        CSymbol()
            : CInclusiveHitStatistics()
            , Base()
            , Limit()
            , Name()
            , pSymbolImage()
            , SymbolHits()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pSymbolImage ? pSymbolImage->IsUnknown : TRUE;
        }
        __declspec(property(get=GetIsUnknown))  BOOLEAN IsUnknown;

        ULONG32 GetSize() const
        {
            return Limit - Base;
        }
        __declspec(property(get=GetSize))       ULONG32 Size;

        ULONG32 GetTimeDateStamp() const
        {
            return pSymbolImage ? pSymbolImage->TimeDateStamp : NULL;
        }
        __declspec(property(get=GetTimeDateStamp)) ULONG32 TimeDateStamp;

        ULONG32 GetImageSize() const
        {
            return pSymbolImage ? pSymbolImage->ImageSize : NULL;
        }
        __declspec(property(get=GetImageSize))  ULONG32 ImageSize;

        LPCWSTR GetImageName() const
        {
            return pSymbolImage ? pSymbolImage->Name : NULL;
        }
        __declspec(property(get=GetImageName))  LPCWSTR ImageName;

    };

    struct CSymbolHit 
        : public CInclusiveHitStatistics
    {
        const CSymbol*          pSymbol;
        ULONG32                 Address;
        CVirtualHits_Sparse     VirtualHits;

    public:
        CSymbolHit()
            : CInclusiveHitStatistics()
            , pSymbol()
            , Address()
            , VirtualHits()
        {
        }

        LPCWSTR GetName() const
        {
            return pSymbol ? pSymbol->Name : NULL;
        }
        __declspec(property(get=GetName))       LPCWSTR Name;

        ULONG32 GetBase() const
        {
            return pSymbol ? pSymbol->Base : 0;
        }
        __declspec(property(get=GetBase))       ULONG32 Base;

        ULONG32 GetLimit() const
        {
            return pSymbol ? pSymbol->Limit : _UI32_MAX;
        }
        __declspec(property(get=GetLimit))      ULONG32 Limit;

        ULONG32 GetSize() const
        {
            return Limit - Base;
        }
        __declspec(property(get=GetSize))       ULONG32 Size;

        ULONG32 GetTimeDateStamp() const
        {
            return pSymbol ? pSymbol->TimeDateStamp : NULL;
        }
        __declspec(property(get=GetTimeDateStamp)) ULONG32 TimeDateStamp;

        ULONG32 GetImageSize() const
        {
            return pSymbol ? pSymbol->ImageSize : NULL;
        }
        __declspec(property(get=GetImageSize))  ULONG32 ImageSize;

        LPCWSTR GetImageName() const
        {
            return pSymbol ? pSymbol->ImageName : NULL;
        }
        __declspec(property(get=GetImageName))  LPCWSTR ImageName;
    };

    struct CVirtualImage
        : public CInclusiveHitStatistics
    {
        const IProcessInfoSource::ImageData* pImageData;
        const CProcess* pProcess;
        const CSymbolImage* pSymbolImage;
        CVirtualHits VirtualHits;
    
    public:
        CVirtualImage()
            : CInclusiveHitStatistics()
            , pImageData()
            , pProcess()
            , pSymbolImage()
            , VirtualHits()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pImageData ? FALSE : TRUE;
        }
        __declspec(property(get=GetIsUnknown)) BOOLEAN IsUnknown;

        LPCWSTR GetName() const
        {
            return (pImageData && pImageData->ImageName) ? pImageData->ImageName->FileName : NULL;
        }
        __declspec(property(get=GetName))       LPCWSTR Name;

        ULONG64 GetBase() const
        {
            return pImageData ? pImageData->Base : 0;
        }
        __declspec(property(get=GetBase))       ULONG64 Base;

        ULONG64 GetLimit() const
        {
            return pImageData ? pImageData->Limit : _UI64_MAX;
        }
        __declspec(property(get=GetLimit))      ULONG64 Limit;

        ULONG32 GetSize() const
        {
            return pImageData ? (ULONG32)pImageData->Size : 0;
        }
        __declspec(property(get=GetSize))       ULONG32 Size;

        DWORD GetTimeDateStamp() const
        {
            return pImageData ? pImageData->TimeDateStamp : 0;
        }
        __declspec(property(get=GetTimeDateStamp))  DWORD TimeDateStamp;

        DWORD GetChecksum() const
        {
            return pImageData ? pImageData->CheckSum : 0;
        }
        __declspec(property(get=GetChecksum))  DWORD Checksum;
    };

    struct CVirtualHit 
        : public CInclusiveHitStatistics
    {
        ULONG64                 Address;
        const CSymbolHit*       pSymbolHit;
        const CVirtualImage*    pVirtualImage;
        CStackFrames_Sparse     StackFrames;

    public:
        CVirtualHit()
            : CInclusiveHitStatistics()
            , Address()
            , pSymbolHit()
            , pVirtualImage()
            , StackFrames()
        {
        }

        LPCWSTR GetSymbolName() const
        {
            return pSymbolHit ? pSymbolHit->Name : NULL;
        }
        __declspec(property(get=GetSymbolName)) LPCWSTR SymbolName;

        LPCWSTR GetImageName() const
        {
            return pVirtualImage ? pVirtualImage->Name : NULL;
        }
        __declspec(property(get=GetImageName))  LPCWSTR ImageName;

        ULONG64 GetBase() const
        {
            return (pVirtualImage && pSymbolHit) ? (pVirtualImage->Base + pSymbolHit->Base) : 0;
        }
        __declspec(property(get=GetBase))       ULONG64 Base;

        ULONG64 GetLimit() const
        {
            return (pVirtualImage && pSymbolHit) ? (pVirtualImage->Base + pSymbolHit->Limit) : _UI64_MAX;
        }
        __declspec(property(get=GetLimit))      ULONG64 Limit;

        ULONG32 GetSize() const
        {
            return (pVirtualImage && pSymbolHit) ? (pSymbolHit->Limit - pSymbolHit->Base) : 0;
        }
        __declspec(property(get=GetSize))       ULONG32 Size;
    };

    struct CStackFrame 
        : public CInclusiveHitStatistics
    {
        const CVirtualHit*      pVirtualHit;
        const CStackFrame*      pCaller;
        CStackFrames            Callees;

    public:
        CStackFrame()
            : CInclusiveHitStatistics()
            , pVirtualHit()
            , pCaller()
            , Callees()
        {
        }

        LPCWSTR GetSymbolName() const
        {
            return pVirtualHit ? pVirtualHit->SymbolName : NULL;
        }
        __declspec(property(get=GetSymbolName)) LPCWSTR SymbolName;

        LPCWSTR GetImageName() const
        {
            return pVirtualHit ? pVirtualHit->ImageName : NULL;
        }
        __declspec(property(get=GetImageName))  LPCWSTR ImageName;

        ULONG64 GetAddress() const
        {
            return pVirtualHit ? pVirtualHit->Address : 0;
        }
        __declspec(property(get=GetAddress))    ULONG64 Address;

        ULONG64 GetBase() const
        {
            return pVirtualHit ? pVirtualHit->Base : 0;
        }
        __declspec(property(get=GetBase))       ULONG64 Base;

        ULONG64 GetLimit() const
        {
            return pVirtualHit ? pVirtualHit->Limit : _UI64_MAX;
        }
        __declspec(property(get=GetLimit))      ULONG64 Limit;
    };

    struct CProcess
        : public CExclusiveHitStatistics
    {
        const IProcessInfoSource::ProcessData* pProcessData;
        const CStackFrame*      pStackFrameRoot;
        LPCWSTR                 Name;
        CThreads                Threads;
        CVirtualImages          VirtualImages;
        ULONG32                 ProcessId;
        // TODO: Add SubProcessTag and unique pointer

    public:
        CProcess()
            : CExclusiveHitStatistics()
            , pProcessData()
            , pStackFrameRoot()
            , Name()
            , Threads()
            , VirtualImages()
            , ProcessId()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pProcessData ? FALSE : TRUE;
        }
        __declspec(property(get=GetIsUnknown)) BOOLEAN IsUnknown;

        ULONG32 GetParentId() const
        {
            return pProcessData ? pProcessData->ParentId : ULONG_MAX;
        }
        __declspec(property(get=GetParentId))  ULONG32 ParentId;
    };

    struct CThread
        : public CExclusiveHitStatistics
    {
        const IProcessInfoSource::ThreadData* pThreadData;
        const CProcess*         pProcess;
        ULONG32                 ThreadId;

    public:
        CThread()
            : CExclusiveHitStatistics()
            , pThreadData()
            , pProcess()
            , ThreadId()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pThreadData ? FALSE : TRUE;
        }
        __declspec(property(get=GetIsUnknown)) BOOLEAN IsUnknown;

        ULONG32 GetProcessId() const
        {
            return pProcess->ProcessId;
        }
        __declspec(property(get=GetProcessId))  ULONG32 ProcessId;

        const IProcessInfoSource::ProcessData* GetProcessData() const
        {
            return pThreadData ? pThreadData->Process : NULL;
        }
        __declspec(property(get=GetProcessData)) const IProcessInfoSource::ProcessData* pProcessData;

        LPCWSTR GetProcessName() const
        {
            return (pThreadData && pThreadData->Process) ? pThreadData->Process->ImageName : NULL;
        }
        __declspec(property(get=GetProcessName)) LPCWSTR ProcessName;
    };

    struct CEventProvider
        : public CExclusiveHitStatistics
    {
        const IStackMappingInfoSource::EventProvider* pEventProviderData;
        const GUID*             pProviderId;
        LPCWSTR                 ProviderName;
        CEvents                 Events;

    public:
        CEventProvider()
            : CExclusiveHitStatistics()
            , pEventProviderData()
            , pProviderId()
            , ProviderName()
            , Events()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pEventProviderData ? FALSE : TRUE;
        }
        __declspec(property(get=GetIsUnknown)) BOOLEAN IsUnknown;

        BOOLEAN GetIsClassic() const
        {
            return pEventProviderData ? pEventProviderData->IsClassic : FALSE;
        }
        __declspec(property(get=GetIsClassic)) BOOLEAN IsClassic;

    };

    struct CEvent
        : public CExclusiveHitStatistics
    {
        const IStackMappingInfoSource::Event* pEventData;
        const CEventProvider*   pEventProvider;
        LPCWSTR                 EventName;
        EVENT_DESCRIPTOR        EventDescriptor;

    public:
        CEvent()
            : CExclusiveHitStatistics()
            , pEventData()
            , pEventProvider()
            , EventName()
            , EventDescriptor()
        {
        }

        BOOLEAN GetIsUnknown() const
        {
            return pEventData ? FALSE : TRUE;
        }
        __declspec(property(get=GetIsUnknown)) BOOLEAN IsUnknown;

        CLASSIC_EVENT_DESCRIPTOR GetClassicEventDescriptor() const
        {
            CLASSIC_EVENT_DESCRIPTOR ClassicEventDescriptor;

            ClassicEventDescriptor.Class.Type = EventDescriptor.Opcode;
            ClassicEventDescriptor.Class.Level = EventDescriptor.Level;
            ClassicEventDescriptor.Class.Version = EventDescriptor.Version;

            return ClassicEventDescriptor;
        }
        __declspec(property(get=GetClassicEventDescriptor)) CLASSIC_EVENT_DESCRIPTOR ClassicEventDescriptor;

        const GUID* GetpProviderId() const
        {
            return pEventProvider->pProviderId;
        }
        __declspec(property(get=GetpProviderId)) const GUID* pProviderId;

        LPCWSTR GetProviderName() const
        {
            return pEventProvider->ProviderName;
        }
        __declspec(property(get=GetProviderName)) LPCWSTR ProviderName;

        BOOLEAN GetIsClassic() const
        {
            return pEventProvider->IsClassic;
        }
        __declspec(property(get=GetIsClassic)) BOOLEAN IsClassic;
    };

    struct CClassification
        : public CExclusiveHitStatistics
    {
        ULONG_PTR               Classification;

    public:
        CClassification()
            : CExclusiveHitStatistics()
            , Classification()
        {
        }
    };

    struct CStack
    {
        TimeStamp               TimeStamp;
        const CThread*          pThread;
        const CStackFrame*      pTopStackFrame;
        const CEvent*           pEvent;
        const CClassification*  pClassification;

    public:
        CStack()
            : TimeStamp()
            , pThread()
            , pTopStackFrame()
            , pEvent()
            , pClassification()
        {
        }
    };

    struct CResults
    {
        CSymbols            Symbols;
        CSymbolImages       SymbolImages;
        CSymbolHits         SymbolHits;
        CVirtualImages      VirtualImages;
        CVirtualHits        VirtualHits;
        CStackFrames        StackFrames;
        CProcesses          Processes;
        CThreads            Threads;
        CEventProviders     EventProviders;
        CEvents             Events;
        CCClassifications   Classifications;
        CStacks             Stacks;
    };


    STDMETHOD(AnalyzeStacks)(
        __in  REFIID riid,
        __deref_out LPVOID* ppUnk,
        __in  const TimeStamp& StartTime = TimeStamp::Min,
        __in  const TimeStamp& EndTime = TimeStamp::Max,
        __in_opt const IStackMappingInfoSource* pStackMappingInfoSource = NULL,
        __in_opt IStackAnalysisFilter* pStackAnalysisFilter = NULL
        ) const PURE;

    template <typename Q>
    HRESULT AnalyzeStacks(
        __in  Q** ppQ,
        __in  const TimeStamp& StartTime = TimeStamp::Min,
        __in  const TimeStamp& EndTime = TimeStamp::Max,
        __in_opt const IStackMappingInfoSource* pStackMappingInfoSource = NULL,
        __in_opt IStackAnalysisFilter* pStackAnalysisFilter = NULL
        ) const
    {
        return AnalyzeStacks(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), StartTime, EndTime, pStackMappingInfoSource, pStackAnalysisFilter);
    }
};

MIDL_INTERFACE("C4003160-488F-4D32-B03E-6333ED186BD7")
IStackAnalysisFilter : public IUnknown
{
    // EventProvider selection
    STDMETHOD(IsEventProviderSelected)(
        __in  const IStackAnalysis::CEventProvider* pEventProvider
        ) PURE;
    // Event selection
    STDMETHOD(IsEventSelected)(
        __in  const IStackAnalysis::CEvent* pEvent
        ) PURE;
    // Process selection
    STDMETHOD(IsProcessSelected)(
        __in  const IStackAnalysis::CProcess* pProcess
        ) PURE;
    // Thread selection
    STDMETHOD(IsThreadSelected)(
        __in  const IStackAnalysis::CThread* pThread
        ) PURE;
    // Classification & selection
    STDMETHOD(GetStackClassification)(
        __out IStackAnalysis::CClassification* pClassification,
        __in  const IStackAnalysis::CStack* pStack
        ) PURE;
    // Virtual Image selection
    STDMETHOD(IsVirtualImageSelected)(
        __in  const IStackAnalysis::CVirtualImage* pVirtualImage
        ) PURE;
    // Symbol Image selection
    STDMETHOD(IsSymbolImageSelected)(
        __in  const IStackAnalysis::CSymbolImage* pSymbolImage
        ) PURE;
    // Symbol selection
    STDMETHOD(IsSymbolSelected)(
        __in  const IStackAnalysis::CSymbol* pSymbol
        ) PURE;
};

MIDL_INTERFACE("8F26D7CA-C949-4392-8219-C003CCECA335")
IStackAnalysisResults : public IUnknown
{
    STDMETHOD(QueryResults)(
        __out const IStackAnalysis::CResults** ppResults
        ) const PURE;
};


//
// Marks
//

MIDL_INTERFACE("196BB6CA-0615-41d7-B342-4524CBB75D26")
IMarksInfoSource : public IUnknown
{
public:
    enum MarkType 
    {
        Mark            = 0x00000001,
        NumberedMark    = 0x00000002,
        AllMarks        = 0xFFFFFFFF,
    };

    struct MarkData {
        TimeStamp           Time;
        LPCWSTR             Label;
        INT                 MarkType;
    };

    STDMETHOD(QueryMarks)(
        __out_ecount_part_opt(NumEntries, NumEntries) const MarkData** ppMarkDataStart,
        __inout SIZE_T &NumEntries,
        __in  INT MarkTypes,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        __in  INT MarkTypes
        ) const PURE;
};

MIDL_INTERFACE("EC15DD7D-8C80-4759-B966-023E99456F21")
IMarksInfoSource2 : public IMarksInfoSource
{
public:

    struct MarkData2 : public MarkData
    {
        ULONG               ThreadId;
    };

    STDMETHOD(QueryMarks)(
        __out_ecount_part_opt(NumEntries, NumEntries) const MarkData2** ppMarkDataStart,
        __inout SIZE_T &NumEntries,
        __in  INT MarkTypes,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;
};


//
// Relocations Infosource
//

MIDL_INTERFACE("5A8AC9C3-DDD1-44d5-ACFE-10A5DCF69A75")
IRelocationsInfoSource : public IUnknown
{
public:

    struct RelocationData
    {
        TimeStamp Time;
        ULONG64 DefaultBase;
        ULONG64 MappedBase;
        ULONG64 ImageSize;

        const IProcessInfoSource::ImageData* pImageData;

        RelocationData()
            : Time(TimeStamp::Min)
            , DefaultBase(0)
            , MappedBase(0)
            , pImageData(NULL)
        {
        }
    };

    typedef strided_adapter<const RelocationData> StridedRelocationDatas;

    STDMETHOD(QueryStridedData)(
        __out StridedRelocationDatas* RelocationDatas,
        __in const TimeStamp& QueryStart = TimeStamp::Min,
        __in const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};

//
// Sampled Profile Frequency
//

MIDL_INTERFACE("3579A421-351F-4C38-BFA3-0763CE1AB0FB")
ISampledProfileFrequencyInfoSource : public IUnknown
{
    struct ZoneData : public Temporal
    {
        TimeStampDelta Period;
    };

    typedef strided_adapter<ZoneData> StridedZoneDatas;


    STDMETHOD(QueryStridedData)(
        __out StridedZoneDatas* pStridedZoneDatas
        ) PURE;
};

//
// Sampled Profile
//

MIDL_INTERFACE("997CC401-2BD0-4EDE-BB4D-E3DBFF700124")
ISampledProfileInfoSource : public IUnknown
{
    struct SampledData
    {
        TimeStampDelta  Weight;
        TimeStamp       TS;
        ULONG64         IP;
        const IProcessInfoSource::ThreadData *Thread;
        const IProcessInfoSource::ImageData *Image;

    public:
        SampledData()
            : IP()
            , Thread()
            , Image()
        {
        }
    };

    struct CpuUser : public BucketData
    {
        TimeStampDelta  Weight;

    public:
        CpuUser()
            : BucketData()
        {
        }
    };

    struct CpuDetails
    {
        TimeStampDelta  TotalWeight;
        CpuUser        *Details;

    public:
        CpuDetails()
            : Details()
        {
        }
    };

    typedef BOOL (WINAPI *pfnFilter)(__in const SampledData&, __in_opt PVOID Context);

    STDMETHOD (QueryProcesses) (
        __out_ecount_full(NumEntries) const IProcessInfoSource::ProcessData* Buffer[],
        __inout SIZE_T& NumEntries
        ) const PURE;

    STDMETHOD (QueryCpuUsage) (
        __out_ecount_full(NumEntries) FLOAT Utils[],
        __inout SIZE_T& NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
        ) const PURE;

    STDMETHOD (QueryDetailedDataByProcess) (
        __out CpuDetails& Usage,
        __inout SIZE_T& NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) (
        ) const PURE;

    typedef strided_adapter<const SampledData> StridedSampledDatas;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedSampledDatas Data[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD (QueryDetailedDataByThread) (
        __out CpuDetails& Usage,
        __inout SIZE_T& NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;
};

MIDL_INTERFACE("4329239A-7776-4065-AAD8-322B8FED95FF")
ISampledProfileInfoSource2 : public ISampledProfileInfoSource
{
    STDMETHOD (QueryDetailedDataByProcess) (
        __out CpuDetails& Usage,
        __inout SIZE_T& NumEntries,
        __in_opt ISymbolInfoSource* pSymbolInfo,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max        
        ) const PURE;

    STDMETHOD (QueryDetailedDataByThread) (
        __out CpuDetails& Usage,
        __inout SIZE_T& NumEntries,
        __in_opt ISymbolInfoSource* pSymbolInfo,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;
};

MIDL_INTERFACE("9B63848B-0A72-4f8e-ADD3-EA79D7DDD9F0")
ISampledProfileInfoSource3 : public ISampledProfileInfoSource2
{
    #pragma warning(push)
    #pragma warning(disable:4201) // nameless struct/union
    typedef union {
        struct {
            UCHAR ExecutingDpc : 1;
            UCHAR ExecutingIsr : 1;
            UCHAR Reserved : 1;
            UCHAR Priority : 5;
        } DUMMYSTRUCTNAME;
        UCHAR Flags;        
    } SAMPLED_PROFILE_FLAGS;
    #pragma warning(pop)

    struct CpuUser3 : public CpuUser
    {        
        SAMPLED_PROFILE_FLAGS flags;

    public:
        CpuUser3()
            : CpuUser()
            , flags()
        {
        }
    };

    struct CpuDetails3
    {
        TimeStampDelta  TotalWeight;
        CpuUser3        *Details;

    public:
        CpuDetails3()
            : Details()
        {
        }
    };
        
    STDMETHOD (QueryDetailedDataByProcessWithFlags) (
        __out CpuDetails3& Usage,
        __inout SIZE_T& NumEntries,
        __in_opt ISymbolInfoSource* pSymbolInfo,
        __in  const SAMPLED_PROFILE_FLAGS flagMask,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD (QueryDetailedDataByThreadWithFlags) (
        __out CpuDetails3& Usage,
        __inout SIZE_T& NumEntries,
        __in_opt ISymbolInfoSource* pSymbolInfo,
        __in  const SAMPLED_PROFILE_FLAGS flagMask,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    typedef strided_adapter<const SAMPLED_PROFILE_FLAGS> StridedSampledFlags;

    STDMETHOD (QueryStridedDataWithFlags) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedSampledDatas Data[],
        __out_ecount_part_opt(NumProcs, NumProcs) StridedSampledFlags Flags[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsFlagsDataAvailable) (
        __in  const SAMPLED_PROFILE_FLAGS flagMask
        ) const PURE;
};

MIDL_INTERFACE("B062B4A1-C47B-41E0-B236-400B0D398479")
ISampledProfileInfoSource4 : public ISampledProfileInfoSource3
{
    struct SampledData2 : SampledData
    {
        UCHAR Rank;

    public:
        SampledData2()
            : SampledData()
            , Rank()
        {
        }
    };

    typedef strided_adapter<const SampledData2> StridedSampledDatas2;

    STDMETHOD (QueryStridedDataWithFlags) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedSampledDatas2 Data[],
        __out_ecount_part_opt(NumProcs, NumProcs) StridedSampledFlags Flags[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsRankDataAvailable) (
        ) const PURE;
};

//
// IEventDumper
//

MIDL_INTERFACE("E46F9E06-011B-4A3C-BDCA-F746D32C719F")
ICSwitchEventDumperConfig : public IUnknown
{
    STDMETHOD(SetDpcIsrExclusionReport)(__in BOOL fEnable) PURE;
};

//
// IFileIOInfoSource
//

MIDL_INTERFACE("B1381690-65B6-4E35-86A8-07B9F795710A")
IFileIOInfoSource : public IUnknown
{
    typedef enum FileIOType 
    {
        FileIOType_Create,
        FileIOType_Cleanup,
        FileIOType_Close,
        FileIOType_Flush,
        FileIOType_Read,
        FileIOType_Write,
        FileIOType_SetInfo,
        FileIOType_QueryInfo,
        FileIOType_FSCTL,
        FileIOType_Delete,
        FileIOType_Rename,
        FileIOType_DirEnum,
        FileIOType_DirNotify,
        FileIOType_OpEnd,
    };

    struct FileIO : public Temporal 
    {
        struct CreateData
        {
            ULONG   Options;
            ULONG   Attributes;
            ULONG   ShareAccess;
        };

        struct ReadWriteData
        {
            ULONG64 Offset;
            ULONG   Size;
            ULONG   Flags;
            ULONG   ExtraFlags;
        };

        struct InformationData
        {
            ULONG64 ExtraInformation;
            ULONG   InfoClass;
        };

        struct DirEnumData
        {
            ULONG   Length;
            ULONG   InfoClass;
            ULONG   FileIndex;
            LPCWSTR FileName;
        };

        struct EndData
        {
            ULONG64  ExtraInformation;
            NTSTATUS Status;
            LPCWSTR  Result;
        };
        
        union FileIODataStruct
        {
            CreateData CreateData;
            ReadWriteData ReadWriteData;
            InformationData InformationData;
            DirEnumData DirEnumData;
        };

        FileIOType Type;
        ULONG64    Irp;
        ULONG64    FileObject;
        LPCWSTR    Subtype;
        LPCWSTR    Flags;

        const PathNode* FilenamePathNode;

        const IProcessInfoSource::ThreadData *Thread;
        const IProcessInfoSource::ThreadData *LoggingThread;

        FileIODataStruct FileIOData;
        EndData          EndData;

         
    };

    STDMETHOD (QueryData) (
        __out strided_adapter<FileIO>* Data
        ) PURE;

    STDMETHOD_(BOOL, IsCompleteDataAvailable)(
        ) const PURE;
};

MIDL_INTERFACE("13e6ec17-deb8-4907-971e-8d7238c41cf2")
IFileIOStringService : public IUnknown {

    typedef enum StringSet
    {
        StringSet_CreateOptions,      // Passed as the CreateOptions argument to NtCreateFile
        StringSet_Attributes,         // Passed as the FileAttributes argument to NtCreateFile
        StringSet_ShareAccess,        // Passed as the ShareAccess argument to NtCreateFile
        StringSet_RWFlags,            // flags for reading and writing files (details unknown)
        StringSet_InfoClass,          // InfoClass (subtype) for events *other* than FSCTL
        StringSet_FsctlInfoClass,     // InfoClass (subtype) for FSCTL
        StringSet_RWExtraFlags,       // additional flags for reading and writing files
        StringSet_CreateDisposition,  // Create disposition flags (actually they are values)
    };

    // Returns NULL if we don't know the name
    STDMETHOD_(LPCWSTR, QueryString)    (
        StringSet Set, 
        ULONG Code
        ) const PURE; 

    // Format an unrecognized FSCTL infoclass according to its implicit fields (always null-terminates)
    STDMETHOD(FormatFsctlInfoClass) (
        __out_ecount(NumChars) WCHAR *Buffer, 
        UINT NumChars,
        ULONG Code
        ) const PURE;
};


//
// IsBootTrace Infosource
//

MIDL_INTERFACE("D041128E-6FEC-47CD-A665-A5AFF6434305") 
IIsBootTraceInfoSource : public IUnknown
{
    STDMETHOD_(BOOL, IsBootTrace)() const PURE;
};

//
// Pmc Configuration
//

MIDL_INTERFACE("E1AC5D69-3D21-43E1-8DCA-946AB9B0689A")
IPmcConfigInfoSource : public IUnknown
{
    STDMETHOD(QueryProfileSources) (
        __out strided_adapter<const LPCWSTR>* ProfileSources
        ) const PURE;
};

//
// Screenshots
//

MIDL_INTERFACE("84532B2E-070D-4985-9E55-F44C03B369E9")
IScreenshotInfoSource : public IUnknown
{
    struct MonitorData
    {
        LPCWSTR MonitorName;
        RECT rcMonitor;

        LPCWSTR PixelDataContentType;

        __field_bcount(cbPixelData) const BYTE* rgPixelData;
        SIZE_T cbPixelData;

        MonitorData()        
            : MonitorName()
            , rcMonitor()
            , PixelDataContentType()
            , rgPixelData()
            , cbPixelData()
        {}
    };

    typedef strided_adapter<const MonitorData> StridedMonitorDatas;

    struct ScreenshotData : public Temporal
    {
        StridedMonitorDatas Monitors;

        ScreenshotData()
            : Monitors()
        {}
    };

    STDMETHOD(QueryData) (
        __out strided_adapter<const ScreenshotData>* Screenshots
        ) const PURE;
};

MIDL_INTERFACE("CAD42841-6F60-4DC9-A945-AD245E882838")
IShouldYieldProcessorInfoSource : public IUnknown
{
    struct ShouldYieldProcessorData
    {
        TimeStamp EventTime;
        USHORT Cpu;
        USHORT Spare;
        ULONG YieldReason;
        ULONG DpcWatchdogCount;
        ULONG DpcTimeCount;
    };

    typedef strided_adapter<const ShouldYieldProcessorData> StridedShouldYieldProcessorDatas;

    STDMETHOD (QueryStridedData) (
        __out StridedShouldYieldProcessorDatas *Data,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

} // namespace XPerfAddIn;
