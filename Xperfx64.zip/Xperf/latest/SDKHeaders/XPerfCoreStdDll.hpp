/*++

Copyright (c) 2004 Microsoft Corporation

Module Name:

    XPerfCoreStdDll.hpp

Abstract:

    Standard implementation DllMain for XPerfCore AddIns

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

namespace XPerfCore
{

inline 
HRESULT XPerfCoreRegisterClassCategories(
    __in  REFCLSID rclsid, 
    __in_xcount(pEntry->iType != _ATL_CATMAP_ENTRY_END) const _ATL_CATMAP_ENTRY* pEntry, 
    __in  IAddInProxy* pAddInProxy
    )
{
    HRESULT hr = S_OK;

    if (pEntry) {
        while (pEntry->iType != _ATL_CATMAP_ENTRY_END) {

            if (pEntry->iType == _ATL_CATMAP_ENTRY_IMPLEMENTED) {
                hr = pAddInProxy->RegisterClassImplCategories(rclsid, 1, pEntry->pcatid);
                if (FAILED(hr)) {
                    break;
                }
            } else {
                ASSERT( pEntry->iType == _ATL_CATMAP_ENTRY_REQUIRED );
            }

            ++pEntry;
        }
    }
    return hr;
}

inline
HRESULT XPerfCoreRegisterClasses(
    __in  _ATL_COM_MODULE *pComModule, 
    __in  IAddInProxy* pAddInProxy
    )
{
    ASSERT(pComModule);
    if (pComModule == NULL)
        return E_INVALIDARG;

    ASSERT(pAddInProxy);
    if (pAddInProxy == NULL)
        return E_INVALIDARG;

    HRESULT hr = S_OK;

    typedef _ATL_OBJMAP_ENTRY const * PC_ATL_OBJMAP_ENTRY;
    typedef PC_ATL_OBJMAP_ENTRY const * PCPC_ATL_OBJMAP_ENTRY;

    PCPC_ATL_OBJMAP_ENTRY const ppAutoObjMapFirst = _AtlComModule.m_ppAutoObjMapFirst;
    PCPC_ATL_OBJMAP_ENTRY const ppAutoObjMapLast = _AtlComModule.m_ppAutoObjMapLast;

    for(PCPC_ATL_OBJMAP_ENTRY ppEntry = ppAutoObjMapFirst; ppEntry != ppAutoObjMapLast; ++ppEntry) {
        PC_ATL_OBJMAP_ENTRY const pEntry = *ppEntry;

        if (pEntry && pEntry->pclsid && !InlineIsEqualGUID(*pEntry->pclsid, __uuidof(CAddIn)) ) {

            // Register class before registering categories
            hr = pAddInProxy->RegisterClass(*pEntry->pclsid, pEntry->pfnGetObjectDescription());

            if (FAILED(hr) ) {
                break;
            }

            // Register categories
            hr = XPerfCoreRegisterClassCategories(*pEntry->pclsid, pEntry->pfnGetCategoryMap(), pAddInProxy);

            if (FAILED(hr) ) {
                break;
            }
        }
    }
    
    return hr;
}


//
// CAddIn -- stock implementation using ATL maps to automatically integrate with XPerfCore
//

class ATL_NO_VTABLE CAddIn : 
    public CComObjectRoot,
    public CComCoClass<CAddIn, &__uuidof(CAddIn)>,
    public IAddIn
{
public:
    DECLARE_OBJECT_DESCRIPTION("AddIn")

    DECLARE_NO_REGISTRY()
    DECLARE_NOT_AGGREGATABLE(CAddIn)

    BEGIN_COM_MAP(CAddIn)
        COM_INTERFACE_ENTRY(IAddIn)
    END_COM_MAP()

    STDMETHOD(RegisterClasses)(
        __in  IAddInProxy* pAddInProxy
        )
    {
        return XPerfCoreRegisterClasses(&_AtlComModule, pAddInProxy);
    }
};

OBJECT_ENTRY_AUTO(__uuidof(CAddIn), CAddIn);

} // namespace XPerfCore


__if_not_exists (_AtlModule)
{

class CXPerfStdDll : public CAtlDllModuleT<CXPerfStdDll>
{
};

CXPerfStdDll _AtlModule;
}

#ifndef XPERF_NO_STD_DLLMAIN

// DLL Entry Point
__control_entrypoint(DllExport)
EXTERN_C BOOL WINAPI DllMain(
    __in  HINSTANCE hInstance, 
    __in  DWORD dwReason, 
    __in  LPVOID lpReserved
    )
{
    UNREFERENCED_PARAMETER(hInstance);


    switch (dwReason) 
    {
    case DLL_PROCESS_ATTACH:

#ifdef EventRegisterMicrosoft_Windows_XPerfCore
        EventRegisterMicrosoft_Windows_XPerfCore();
#endif
#ifdef XPERF_TRACELOGGING
        {
            // TODO: This should be removed from this header
            // GUID for "XPerfAddIn-PerfNT": {cc0d0409-850f-57b1-83fe-8deb4e1fb60a}
            static const GUID s_perfNtProviderGuid =
            { 0xcc0d0409, 0x850f, 0x57b1, 0x83, 0xfe, 0x8d, 0xeb, 0x4e, 0x1f, 0xb6, 0x0a };

            TraceLoggingRegister(g_hProvider, &s_perfNtProviderGuid);
        }
#endif

        break;

    case DLL_PROCESS_DETACH:

#ifdef XPERF_TRACELOGGING
        TraceLoggingUnregister(g_hProvider);
#endif
#ifdef EventRegisterMicrosoft_Windows_XPerfCore
        EventUnregisterMicrosoft_Windows_XPerfCore();
#endif
        break;
    }

    return _AtlModule.DllMain(dwReason, lpReserved); 
}

#endif

#ifndef XPERF_NO_STD_COMDLL

// Used to determine whether the DLL can be unloaded by OLE
__control_entrypoint(DllExport)
STDAPI DllCanUnloadNow(void)
{
    return _AtlModule.DllCanUnloadNow();
}


// Returns a class factory to create an object of the requested type
__control_entrypoint(DllExport)
STDAPI DllGetClassObject(
    __in  REFCLSID rclsid, 
    __in  REFIID riid, 
    __deref_out LPVOID* ppv
    )
{
    return _AtlModule.DllGetClassObject(rclsid, riid, ppv);
}


// DllRegisterServer - Adds entries to the system registry
__control_entrypoint(DllExport)
STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    HRESULT hr = S_OK; //_AtlModule.DllRegisterServer();
    return hr;
}


// DllUnregisterServer - Removes entries from the system registry
__control_entrypoint(DllExport)
STDAPI DllUnregisterServer(void)
{
    HRESULT hr = S_OK; //_AtlModule.DllUnregisterServer();
    return hr;
}

#endif
