/*++

Copyright (c) 2003 Microsoft Corporation

Module Name:

    XPerfCore.hpp

Abstract:

    XPerfCore core interfaces

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <nt.h>
#include <ntrtl.h>
#include <nturtl.h>
#include <windows.h>
#include <limits.h>

#define INITGUID
#include <wmium.h>
#include <wmiguid.h>
#pragma warning(push)
#pragma warning(disable:4201)  // nonstandard extension used : nameless struct/union
#include <evntcons.h>
#pragma warning(pop)

#include <objbase.h>
#include <comcat.h>
#include <servprov.h>

//
// The default implementation of ASSERT (in ntrtl_x.h) has undesirable
// behavior for WPA: An assertion failure with a debugger attached results in
// the thread running in an infinite loop and repeated output to the debug
// stream. Without a debugger attached, an assertion failure is silent.
// An NT_ASSERT assertion failure with a debugger attached results in an SEH
// exception. If the debugger is VS2012, clicking on Break in SEH Exception
// dialog shows the asserting line. Without a debugger attached, the program
// crashes.
// Both macros do nothing in free builds.
//
#undef ASSERT
#define ASSERT NT_ASSERT


//
// STL-compliant strided adapters and sparse adapters
//

namespace std
{
    struct random_access_iterator_tag;
    template<class _RanIt> class reverse_iterator;
}


namespace XPerfCore
{

//
// Strided adapters and iterators
//

template <typename Type>
class strided_iterator
{
public:

    //
    // iterator compile time interface
    //

    typedef std::random_access_iterator_tag iterator_category;
    typedef Type value_type;
    typedef ptrdiff_t difference_type;
    typedef Type* pointer;
    typedef Type& reference;

public:

    // default constructor
    strided_iterator()
        : m_pCurrent(NULL), m_cbStride(sizeof(Type))
    {
    }

    // constructor
    strided_iterator(__in_opt Type* pCurrent, ptrdiff_t cbStride)
        : m_pCurrent(pCurrent), m_cbStride(cbStride)
    {
    }

    // const-conversion
    operator strided_iterator<Type const>() const
    {
        return strided_iterator<Type const>(m_pCurrent, m_cbStride);
    }

private:

    //
    // internal state
    //

    Type*           m_pCurrent;
    ptrdiff_t       m_cbStride;

    //
    // internal state methods
    //

    Type* _next() const {
        return (Type*)((char*)m_pCurrent + m_cbStride);
    }
    Type* _prev() const {
        return (Type*)((char*)m_pCurrent - m_cbStride);
    }
    Type* _address(difference_type N) const {
        return (Type*)((char*)m_pCurrent + N * m_cbStride);
    }

public:

    //
    // basic operators
    //

    pointer operator->() const { return m_pCurrent; }
    reference operator*() const { return *m_pCurrent; }

    strided_iterator& operator++() 
    {
        m_pCurrent = _next();
        return *this;
    }
    strided_iterator& operator--() 
    {
        m_pCurrent = _prev();
        return *this;
    }
    strided_iterator& operator+=(difference_type N) 
    {
        m_pCurrent = _address(N);
        return *this;
    }
    strided_iterator& operator-=(difference_type N)
    {
        m_pCurrent = _address(-N);
        return *this;
    }
    reference operator[](difference_type N) const 
    {
        return *_address(N);
    }
    difference_type operator-(const strided_iterator other) const 
    {
        return m_cbStride ? ((uintptr_t)m_pCurrent - (uintptr_t)other.m_pCurrent) / m_cbStride : 0;
    }
    

    //
    // derived operators
    //

    strided_iterator operator++(int) 
    {
        strided_iterator result = *this;
        ++(*this); // pre-increment
        return result;
    }
    strided_iterator operator--(int) 
    {
        strided_iterator result = *this;
        --(*this); // pre-decrement
        return result;
    }
    strided_iterator operator+(difference_type N) const 
    {
        strided_iterator result = *this;
        result += N;
        return result;
    }
    strided_iterator operator-(difference_type N) const 
    {
        strided_iterator result = *this;
        result -= N;
        return result;
    }

    //
    // comparison operators
    //

    bool operator ==(const strided_iterator& other) const
    {
        return m_pCurrent == other.m_pCurrent;
    }
    bool operator !=(const strided_iterator& other) const
    {
        return !((*this) == other);
    }
    bool operator <(const strided_iterator& other) const
    {
        return m_pCurrent < other.m_pCurrent;
    }
    bool operator >(const strided_iterator& other) const
    {
        return other < (*this);
    }
    bool operator <=(const strided_iterator& other) const
    {
        return !((*this) > other);
    }
    bool operator >=(const strided_iterator& other) const
    {
        return !((*this) < other);
    }
};


template <typename Type>
class strided_adapter
{
public:
    
    //
    // container compile-time interface
    //

    typedef strided_iterator<Type> iterator;
    typedef std::reverse_iterator<strided_iterator<Type> > reverse_iterator;
    typedef Type& reference;
    typedef Type* pointer;
    typedef Type value_type;
    typedef ptrdiff_t difference_type;
    typedef size_t size_type;

public:

    // default constructor
    strided_adapter()
        : m_pHead(NULL), m_cbStride(sizeof(Type)), m_cSize(0)
    {
    }

    // constructor
    strided_adapter(__in_xcount_opt(cbStride*cSize) Type* pHead, ptrdiff_t cbStride, size_type cSize)
        : m_pHead(pHead), m_cbStride(cbStride), m_cSize(cSize)
    {
    }

    // const-conversion
    operator strided_adapter<Type const>() const
    {
        return strided_adapter<Type const>(m_pHead, m_cbStride, m_cSize);
    }

private:
    
    //
    // internal state
    //
    
    Type*           m_pHead;
    ptrdiff_t       m_cbStride;
    size_type       m_cSize;

public:
    iterator begin() const
    {
        return iterator(m_pHead, m_cbStride);
    }

    iterator end() const
    {
        return begin() + m_cSize;
    }

    reverse_iterator rbegin() const
    {
        return reverse_iterator(end());
    }

    reverse_iterator rend() const
    {
        return reverse_iterator(begin());
    }

    size_type size() const
    {
        return m_cSize;
    }

    bool empty() const
    {
        return m_cSize == 0;
    }

    reference operator[](size_type index) const
    {
        return *(begin() + index);
    }

    reference front() const
    {
        return m_pHead[0];
    }

    reference back() const
    {
        return operator[](m_cSize - 1);
    }

    //
    // state accessors
    //

    Type* head() const
    {
        return m_pHead;
    }
    difference_type stride() const
    {
        return m_cbStride;
    }

    bool valid() const
    {
        return m_pHead != NULL;
    }
};


//
// Sparse adapters and iterators
//

template <typename Type>
class sparse_iterator
{
public:

    //
    // iterator compile time interface
    //

    typedef std::random_access_iterator_tag iterator_category;
    typedef Type value_type;
    typedef ptrdiff_t difference_type;
    typedef Type* pointer;
    typedef Type& reference;

public:

    // constructor
    sparse_iterator(__in_opt Type** ppCurrent)
        : m_ppCurrent(ppCurrent)
    {
    }

    // const-conversion
    operator sparse_iterator<Type const>() const
    {
        return sparse_iterator<Type const>(m_ppCurrent);
    }

private:

    //
    // internal state
    //

    Type**          m_ppCurrent;

    //
    // internal state methods
    //

    Type** _next() const {
        return m_ppCurrent + 1;
    }
    Type** _prev() const {
        return m_ppCurrent - 1;
    }
    Type** _address(difference_type N) const {
        return m_ppCurrent + N;
    }

public:
    
    //
    // basic operators
    //
    
    pointer operator->() const { return *m_ppCurrent; }
    reference operator*() const { return **m_ppCurrent; }

    sparse_iterator& operator++() 
    {
        m_ppCurrent = _next();
        return *this;
    }
    sparse_iterator& operator--() 
    {
        m_ppCurrent = _prev();
        return *this;
    }
    sparse_iterator& operator+=(difference_type N) 
    {
        m_ppCurrent = _address(N);
        return *this;
    }
    sparse_iterator& operator-=(difference_type N)
    {
        m_ppCurrent = _address(-N);
        return *this;
    }
    reference operator[](difference_type N) const 
    {
        return **_address(N);
    }
    difference_type operator-(const sparse_iterator other) const 
    {
        return m_ppCurrent - other.m_ppCurrent;
    }
    

    //
    // derived operators
    //

    sparse_iterator operator++(int)
    {
        sparse_iterator result = *this;
        ++(*this); // pre-increment
        return result;
    }
    sparse_iterator operator--(int)
    {
        sparse_iterator result = *this;
        --(*this); // pre-decrement
        return result;
    }
    
    sparse_iterator operator+(difference_type N) const 
    {
        sparse_iterator result = *this;
        result += N;
        return result;
    }
    sparse_iterator operator-(difference_type N) const 
    {
        sparse_iterator result = *this;
        result -= N;
        return result;
    }

    //
    // comparison operators
    //

    bool operator ==(const sparse_iterator& other) const
    {
        return m_ppCurrent == other.m_ppCurrent;
    }
    bool operator !=(const sparse_iterator& other) const
    {
        return !((*this) == other);
    }
    bool operator <(const sparse_iterator& other) const
    {
        return m_ppCurrent < other.m_ppCurrent;
    }
    bool operator >(const sparse_iterator& other) const
    {
        return other < (*this);
    }
    bool operator <=(const sparse_iterator& other) const
    {
        return !((*this) > other);
    }
    bool operator >=(const sparse_iterator& other) const
    {
        return !((*this) < other);
    }
};


template <typename Type>
class sparse_adapter
{
public:
    
    //
    // container compile-time interface
    //

    typedef sparse_iterator<Type> iterator;
    typedef Type& reference;
    typedef Type* pointer;
    typedef Type value_type;
    typedef ptrdiff_t difference_type;
    typedef size_t size_type;

public:

    // default constructor
    sparse_adapter()
        : m_ppHead(NULL), m_cSize(0)
    {
    }

    // constructor
    sparse_adapter(__in_ecount_opt(cSize) Type** ppHead, size_type cSize)
        : m_ppHead(ppHead), m_cSize(cSize)
    {
    }

    // const-conversion
    operator sparse_adapter<Type const>() const
    {
        return sparse_adapter<Type const>(m_ppHead, m_cSize);
    }

private:
    
    //
    // internal state
    //
    
    Type**          m_ppHead;
    size_type       m_cSize;

public:
    iterator begin() const
    {
        return iterator(m_ppHead);
    }

    iterator end() const
    {
        return begin() + m_cSize;
    }

    size_type size() const
    {
        return m_cSize;
    }

    bool empty() const
    {
        return m_cSize == 0;
    }

    reference operator[](size_type index) const
    {
        return *(begin() + index);
    }

    reference front() const
    {
        return *m_ppHead[0];
    }

    reference back() const
    {
        return operator[](m_cSize - 1);
    }

    //
    // state accessors
    //

    Type** head() const
    {
        return m_ppHead;
    }

    bool valid() const
    {
        return m_ppHead != NULL;
    }
};

} // namespace XPerfCore


namespace XPerfCore
{

//
// AddIn infrastructure
//

struct ISession;

MIDL_INTERFACE("B11D1DF5-67F0-41b8-9701-8C4B1BAF9AB4")
ICollectionGUID : public IUnknown
{
    STDMETHOD(get__NewEnum)(
        __deref_out IUnknown** ppUnk ) PURE;
    STDMETHOD(get_Count)(
        __out long* pcount ) PURE;
    STDMETHOD(get_Item)(
        __in  long Index, 
        __out GUID* pGuid ) PURE;
};

typedef ICollectionGUID ICollectionCLSID;
typedef ICollectionGUID ICollectionCATID;


struct IOutputStream;

enum CreateServiceFlags
{
    XPC_CS_TolerateTimeInversion      = 1,
    XPC_CS_ShowProcessingDependencies = 2,
    XPC_CS_AutoFailOnLostEvents       = 4,
    XPC_CS_TolerateLostEvents         = 8,
    XPC_CS_ShowErrorsOnConsole        = 16,
};

MIDL_INTERFACE("907996Dc-EB88-4806-AEB8-BF161C0D2DE2") 
IAddInManager : public IUnknown
{
public:
    //
    // Load
    //

    STDMETHOD(LoadAddIn)( 
        __in_opt LPCWSTR filename ) PURE;


    //
    // Registration and Instantiation
    //

    STDMETHOD(CoCreateInstance)(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __in  DWORD dwClsContext,
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) PURE;

    template <typename Q>
    HRESULT CoCreateInstance(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __in  DWORD dwClsContext,
        __deref_out Q** ppQ ) 
    {
        return CoCreateInstance(rclsid, pOuterUnk, dwClsContext, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    HRESULT CoCreateInstance(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) 
    {
        return CoCreateInstance(rclsid, pOuterUnk, CLSCTX_INPROC_SERVER, riid, ppv);
    }

    template <typename Q>
    HRESULT CoCreateInstance(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __deref_out Q** ppQ ) 
    {
        return CoCreateInstance(rclsid, pOuterUnk, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    HRESULT CoCreateInstance(
        __in  REFCLSID rclsid, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) 
    {
        return CoCreateInstance(rclsid, NULL, riid, ppv);
    }

    template <typename Q>
    HRESULT CoCreateInstance(
        __in  REFCLSID rclsid, 
        __deref_out Q** ppQ ) 
    {
        return CoCreateInstance(rclsid, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    STDMETHOD(CoGetClassObject)(
        __in  REFCLSID rclsid, 
        __in  DWORD dwClsContext, 
        __in_opt COSERVERINFO* pServerInfo, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) PURE;

    template <typename Q>
    HRESULT CoGetClassObject(
        __in  REFCLSID rclsid, 
        __in  DWORD dwClsContext, 
        __in_opt COSERVERINFO* pServerInfo, 
        __deref_out Q **ppQ)
    {
        return CoGetClassObject(rclsid, dwClsContext, pServerInfo, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    STDMETHOD(GetCategories)(
        __deref_out ICollectionCATID** ppCollCATID ) PURE;

    STDMETHOD(GetClassOfCategories)(
        __in  ULONG cImplCategories,
        __in_ecount(cImplCategories) const CATID rgImplCategories[],
        __out CLSID* pclsid ) PURE;

    STDMETHOD(GetClassesOfCategories)(
        __in  ULONG cImplCategories,
        __in_ecount(cImplCategories) const CATID rgImplCategories[],
        __deref_out ICollectionCLSID** ppCollCLSID ) PURE;

    STDMETHOD(DumpRegistrations)(IOutputStream& out) PURE;

    STDMETHOD(GetClassDescription)(
        __in  REFCLSID rclsid, 
        __deref_out BSTR* pbstrClassDescription ) PURE;

    //
    // Session
    //

    STDMETHOD(CreateSession)(
        __in  SIZE_T nTraces, 
        __in_ecount(nTraces) const LPCWSTR rgwszTraceNames[], 
        __in  DWORD dwFlags,
        __in  REFIID riid,
        __deref_out LPVOID* ppv ) PURE;

    template <typename Q>
    HRESULT CreateSession(
        __in  SIZE_T nTraces, 
        __in_ecount(nTraces) const LPCWSTR rgwszTraceNames[], 
        __in  DWORD dwFlags,
        __deref_out Q** ppQ )
    {
        return CreateSession(nTraces, rgwszTraceNames, dwFlags, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

};


MIDL_INTERFACE("8A8BD9C5-57ED-4AB0-82B9-24D6CDE842FC")
IAddInManager2 : public IAddInManager
{
    typedef strided_adapter<LPCWSTR> StridedAddInFileNames;

    STDMETHOD(GetAddInFileNames)(
        __out StridedAddInFileNames* pStridedAddInFileNames) PURE;

    STDMETHOD(GetClassAddInFileName)(
        __in REFCLSID rclsid,
        __deref_out BSTR* pbstrAddInFileName) PURE;
};


MIDL_INTERFACE("7E23C6AE-6E80-4982-AC8F-5128FE376A19")
IAddInProxy : public IUnknown
{
public:
    STDMETHOD(RegisterClass)( 
        __in  REFCLSID rclsid, 
        __in  LPCWSTR wszObjectDescription ) PURE;

    STDMETHOD(RegisterClassImplCategories)( 
        __in  REFCLSID rclsid, 
        __in  ULONG cCategoriesImpl, 
        __in_ecount(cCategoriesImpl) const CATID pCategoriesImpl[] ) PURE;
};


MIDL_INTERFACE("907996Db-EB88-4806-AEB8-BF161C0D2DE2") 
IAddIn : public IUnknown
{
public:
    STDMETHOD(RegisterClasses)( 
        __in  IAddInProxy* pAddInProxy ) PURE;
};

class DECLSPEC_UUID("EFBBB548-5325-4cd4-BA4E-6AA635AF7528") CAddIn;

STDAPI DllRegisterServer();
STDAPI DllUnregisterServer();
STDAPI DllCanUnloadNow();
STDAPI DllGetClassObject(
    __in  REFCLSID rclsid, 
    __in  REFIID riid, 
    __deref_out LPVOID* ppv );

class DECLSPEC_UUID("FDE49531-0FF3-4167-B9B9-83134EE5D5D2") 
CAddInManager;

inline
HRESULT 
XPerfCoreCreateAddInManager(
    __in  HMODULE hModuleXPerfCore, 
    __in  REFIID riid, 
    __deref_out LPVOID* ppv )
{
    HRESULT hr = S_OK;
    IClassFactory* pClassFactory = NULL;

    if (!hModuleXPerfCore) {
        hr = E_HANDLE;
    }

    if (SUCCEEDED(hr)) {
        typedef HRESULT (STDAPICALLTYPE *FnDllGetClassObject)(REFCLSID, REFIID, LPVOID*);

        FnDllGetClassObject pfnDllGetClassObject = 
            (FnDllGetClassObject) GetProcAddress(hModuleXPerfCore, "DllGetClassObject");

        if (!pfnDllGetClassObject) {
            hr = E_UNEXPECTED;
        }

        if (SUCCEEDED(hr)) {
            hr = pfnDllGetClassObject(__uuidof(CAddInManager), 
                                    IID_IClassFactory, 
                                    reinterpret_cast<LPVOID*>(&pClassFactory));

            if (SUCCEEDED(hr)) {
                ASSERT(pClassFactory);
                hr = pClassFactory->CreateInstance(NULL, riid, ppv);
                pClassFactory->Release();
            }
        }
    }

    return hr;
}

template <typename Q>
HRESULT XPerfCoreCreateAddInManager(
    __in  HMODULE hModuleXPerfCore, 
    __deref_out Q** ppQ )
{
    return XPerfCoreCreateAddInManager(hModuleXPerfCore, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
}

//
// Session infrastructure
//

#define FACILITY_XPERF_CORE 0xEC0

#define XPERF_SESSION_COCREATEINSTANCE_BLOCKED          MAKE_HRESULT(SEVERITY_ERROR, FACILITY_XPERF_CORE, 0x1005)

#define XPERF_TRACE_E_DIFFERENT_NUMBER_OF_PROCESSORS    MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0xFFFF)
#define XPERF_TRACE_E_DIFFERENT_OS_VERSION              MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0xFFFE)
#define XPERF_TRACE_E_DIFFERENT_OS_BUILD_NUMBER         MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0xFFFD)
#define XPERF_TRACE_E_DIFFERENT_CLOCK_TYPE              MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0xFFFC)
#define XPERF_TRACE_E_DIFFERENT_BOOT_TIME               MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0xFFFB)
#define XPERF_TRACE_E_DIFFERENT_EPOCH                   MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 0xFFFA)

class TimeStamp;
class TimeStampDelta;

MIDL_INTERFACE("3916F7A8-4FF4-48B5-82A9-E5FB6412E5AF")
ITraceInfo : public IUnknown
{
    STDMETHOD_(ULONG, GetOSVersion)() const PURE;
    STDMETHOD_(ULONG, GetOSBuildNumber)() const PURE;
    STDMETHOD_(ULONG, GetNumberOfProcessors)() const PURE;
    STDMETHOD_(ULONG, GetCpuSpeedInMHz)() const PURE;

    STDMETHOD_(SIZE_T, GetNumberOfTraces)() const PURE;
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetTraceName)(SIZE_T iTrace) const PURE;
    STDMETHOD_(ULONG, GetNativePointerSize)() const PURE;
    STDMETHOD_(ULONG, GetPointerSize)(SIZE_T iTrace) const PURE;
    STDMETHOD_(ULONG, GetClockType)() const PURE;
    STDMETHOD_(ULONG, GetLogFileMode)(SIZE_T iTrace) const PURE;

    // Use ConvertClockToTimeStamp for Clock data within events.
    STDMETHOD_(TimeStamp, ConvertClockToTimeStamp)(LONGLONG count) const PURE;
    // Use ConvertClockToTimeStampDelta for Clock data within events.
    STDMETHOD_(TimeStampDelta, ConvertClockToTimeStampDelta)(LONGLONG count) const PURE;
    // Use ConvertPerfCounterToTimeStampDelta for PerfCounter data within events.
    STDMETHOD_(TimeStampDelta, ConvertPerfCounterToTimeStampDelta)(LONGLONG count) const PURE;
    // Use ConvertCycleCounterToTimeStampDelta for RDTSC counter data within events.
    STDMETHOD_(TimeStampDelta, ConvertCycleCounterToTimeStampDelta)(LONGLONG count) const PURE;

    STDMETHOD_(TimeStamp, GetFirstEventTimeStamp)() const PURE;
    STDMETHOD_(TimeStamp, GetFirstEventTimeStamp)(SIZE_T iTrace) const PURE;
    STDMETHOD_(TimeStamp, GetLastEventTimeStamp)() const PURE;
    STDMETHOD_(TimeStamp, GetLastEventTimeStamp)(SIZE_T iTrace) const PURE;
    STDMETHOD_(TimeStamp, GetFirstReliableEventTimeStamp)() const PURE;
    STDMETHOD_(TimeStamp, GetFirstReliableEventTimeStamp)(SIZE_T iTrace) const PURE;
    STDMETHOD_(FILETIME, GetStartTime)() const PURE;
    STDMETHOD_(FILETIME, GetStartTime)(SIZE_T iTrace) const PURE;
    STDMETHOD_(FILETIME, GetEndTime)() const PURE;
    STDMETHOD_(FILETIME, GetEndTime)(SIZE_T iTrace) const PURE;

    STDMETHOD_(ULONG, GetTotalNumberOfLostEvents)() const PURE;
    STDMETHOD_(ULONG, GetNumberOfLostEvents)(SIZE_T iTrace) const PURE;
    STDMETHOD_(ULONG, GetTotalNumberOfLostBuffers)() const PURE;
    STDMETHOD_(ULONG, GetNumberOfLostBuffers)(SIZE_T iTrace) const PURE;

    STDMETHOD_(ULONG, GetEtwInternalVersion)() const PURE;

    STDMETHOD_(FILETIME, GetBootTime)() const PURE;

    union OS_VERSION {
        ULONG       Version;            // Logger version
        struct OS_VERSION_DETAIL {
            UCHAR   MajorVersion;
            UCHAR   MinorVersion;
            UCHAR   SubVersion;
            UCHAR   SubMinorVersion;
        } VersionDetail;
    
    public:
        OS_VERSION(ULONG _Version) : Version(_Version) {}
    };

    UCHAR GetOSMajorVersion() const
    {
        return OS_VERSION(GetOSVersion()).VersionDetail.MajorVersion;
    }
    UCHAR GetOSMinorVersion() const
    {
        return OS_VERSION(GetOSVersion()).VersionDetail.MinorVersion;
    }

    __declspec(property(get=GetOSVersion))          ULONG       OSVersion;
    __declspec(property(get=GetOSMajorVersion))     UCHAR       OSMajorVersion;
    __declspec(property(get=GetOSMinorVersion))     UCHAR       OSMinorVersion;
    __declspec(property(get=GetOSBuildNumber))      ULONG       OSBuildNumber;
    __declspec(property(get=GetEtwInternalVersion)) ULONG       EtwInternalVersion;
    __declspec(property(get=GetNumberOfProcessors)) ULONG       NumberOfProcessors;
    __declspec(property(get=GetCpuSpeedInMHz))      ULONG       CpuSpeedInMHz;

    __declspec(property(get=GetNumberOfTraces))     SIZE_T      NumberOfTraces;
    __declspec(property(get=GetTraceName))          LPCWSTR     TraceNames[];
    __declspec(property(get=GetNativePointerSize))  ULONG       NativePointerSize;
    __declspec(property(get=GetPointerSize))        ULONG       PointerSizes[];
    __declspec(property(get=GetClockType))          ULONG       ClockType;
    __declspec(property(get=GetLogFileMode))        ULONG       LogFileModes[];

    __declspec(property(get=GetFirstEventTimeStamp))TimeStamp   FirstEventTimeStamp;
    __declspec(property(get=GetFirstEventTimeStamp))TimeStamp   FirstEventTimeStamps[];
    __declspec(property(get=GetLastEventTimeStamp)) TimeStamp   LastEventTimeStamp;
    __declspec(property(get=GetLastEventTimeStamp)) TimeStamp   LastEventTimeStamps[];
    __declspec(property(get=GetFirstReliableEventTimeStamp))TimeStamp   FirstReliableEventTimeStamp;
    __declspec(property(get=GetFirstReliableEventTimeStamp))TimeStamp   FirstReliableEventTimeStamps[];
    __declspec(property(get=GetStartTime))          FILETIME    StartTime;
    __declspec(property(get=GetStartTime))          FILETIME    StartTimes[];
    __declspec(property(get=GetEndTime))            FILETIME    EndTime;
    __declspec(property(get=GetEndTime))            FILETIME    EndTimes[];

    __declspec(property(get=GetTotalNumberOfLostEvents)) ULONG      TotalNumberOfLostEvents;
    __declspec(property(get=GetNumberOfLostEvents))      ULONG      NumberOfLostEvents[];
    __declspec(property(get=GetTotalNumberOfLostBuffers))ULONG      TotalNumberOfLostBuffers;
    __declspec(property(get=GetNumberOfLostBuffers))     ULONG      NumberOfLostBuffers[];

    __declspec(property(get=GetBootTime))           FILETIME    BootTime;
};


// Provides certain methods of ITraceInfo in a way that managed code can interop with.
// The managed marshaler gets very crashy in x86 with return value types like TimeStamp.
MIDL_INTERFACE("D6AF7771-5F08-4EEE-B442-27BDC8D31DD9")
ITraceInfo2 : public ITraceInfo
{
    // Use ConvertClockToTimeStamp for Clock data within events.
    STDMETHOD(ConvertClockToTimeStamp)(LONGLONG count, __out TimeStamp* pTimeStamp) const PURE;

    // Use ConvertClockToTimeStampDelta for Clock data within events.
    STDMETHOD(ConvertClockToTimeStampDelta)(LONGLONG count, __out TimeStampDelta* pTimeStampDelta) const PURE;

    // Use ConvertPerfCounterToTimeStampDelta for PerfCounter data within events.
    STDMETHOD(ConvertPerfCounterToTimeStampDelta)(LONGLONG count, __out TimeStampDelta* pTimeStampDelta) const PURE;

    // Use ConvertCycleCounterToTimeStampDelta for RDTSC counter data within events.
    STDMETHOD(ConvertCycleCounterToTimeStampDelta)(LONGLONG count, __out TimeStampDelta* pTimeStampDelta) const PURE;

    // These methods have 1 and 2 suffixes in order to ensure they are placed in the correct 
    // order (or at least an ordering that matches this definition, which is important e.g. when
    // doing COM interop definitions in C#). Otherwise they get compiled with the opposite ordering.
    STDMETHOD(GetFirstEventTimeStamp1)(__out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetFirstEventTimeStamp2)(SIZE_T iTrace, __out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetLastEventTimeStamp1)(__out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetLastEventTimeStamp2)(SIZE_T iTrace, __out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetFirstReliableEventTimeStamp1)(__out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetFirstReliableEventTimeStamp2)(SIZE_T iTrace, __out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetFirstGraphableEventTimeStamp1)(__out TimeStamp* pTimeStamp) const PURE;
    STDMETHOD(GetFirstGraphableEventTimeStamp2)(SIZE_T iTrace, __out TimeStamp* pTimeStamp) const PURE;

    STDMETHOD(GetStartTime1)(__out FILETIME* pTime) const PURE;
    STDMETHOD(GetStartTime2)(SIZE_T iTrace, __out FILETIME* pTime) const PURE;
    STDMETHOD(GetEndTime1)(__out FILETIME *pTime) const PURE;
    STDMETHOD(GetEndTime2)(SIZE_T iTrace, __out FILETIME* pTime) const PURE;

    STDMETHOD(GetBootTime)(__out FILETIME *pTime) const PURE;
    STDMETHOD(GetLocalStartTime)(SIZE_T iTrace, __out FILETIME* pTime) const PURE;
    STDMETHOD(GetLocalEndTime)(SIZE_T iTrace, __out FILETIME* pTime) const PURE;
};

// Provides certain methods of ITraceInfo in a way that managed code can interop with.
MIDL_INTERFACE("36F832CA-BBED-4203-802D-31365C3EFBDD")
ITraceInfo3 : public ITraceInfo2
{
    STDMETHOD(GetLocalStartTime)(__out FILETIME* pTime) const PURE;
    STDMETHOD(GetLocalEndTime)(__out FILETIME* pTime) const PURE;
};


MIDL_INTERFACE("9A553A84-12EA-4c25-A9AA-F47BAE469F05") 
IProgressCallback : public IUnknown 
{
public:
    STDMETHOD(OnScheduleBegin)(
        __in  ULONG nStages ) PURE;
    STDMETHOD(OnBegin)(
        __in  ULONGLONG maxVal ) PURE;
    STDMETHOD(OnUpdate)(
        __in  ULONGLONG curVal ) PURE;
    STDMETHOD(OnEnd)() PURE;
    STDMETHOD_(VOID, OnScheduleEnd)(
        __in  HRESULT hrStatus) PURE;
};


enum QueryServiceFlags
{
    XPC_QS_PreExisting          = 1,
    XPC_QS_PostEventSinkDep     = 2,
    XPC_QS_ForceInductive       = 4,
    XPC_QS_Context              = 8,
};

MIDL_INTERFACE("{907996D6-EB88-4806-AEB8-BF161C0D2DE2}") 
ISession : public IUnknown
{
    STDMETHOD(QueryServiceByClassID)(
        __in  REFCLSID clsidService, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppv, 
        __in  DWORD dwFlags = 0 ) PURE;

    template <typename Q>
    HRESULT QueryServiceByClassID(
        __in  REFCLSID clsidService, 
        __deref_out Q** ppQ, 
        __in  DWORD dwFlags = 0 )
    {
        return QueryServiceByClassID(clsidService, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), dwFlags);
    }

    STDMETHOD(QueryService)(
        __in  REFGUID guidService,
        __in  REFIID riid, 
        __deref_out LPVOID* ppv, 
        __in  DWORD dwFlags = 0 ) PURE;

    template <typename Q>
    HRESULT QueryService(
        __in  REFGUID guidService, 
        __deref_out Q** ppQ, 
        __in  DWORD dwFlags = 0 )
    {
        return QueryService(guidService, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), dwFlags);
    }

    template <typename Q>
    HRESULT QueryService(
        __deref_out Q** ppQ, 
        __in  DWORD dwFlags = 0 )
    {
        return QueryService(__uuidof(Q), ppQ, dwFlags);
    }

    STDMETHOD(GetClassesOfCategories)(
        __in  ULONG cImplCategories, 
        __in  const CATID rgImplCategories[], 
        __deref_out ICollectionCLSID** ppCollCLSID ) PURE;

    //
    // Scheduler
    //

    STDMETHOD(ProcessEvents)( 
        __in_opt IProgressCallback* pProgressCallback = NULL ) PURE;

};


MIDL_INTERFACE("82F4D094-3F75-4c13-A7E4-493C9409CEF7") 
ISession2 : public IUnknown
{
    STDMETHOD(GetClassDescription)(
        __in  REFCLSID rclsid, 
        __deref_out BSTR* pbstrClassDescription ) PURE;

    STDMETHOD(PrototypeCoCreateInstance)(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __in  DWORD dwClsContext,
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) PURE;

    template <typename Q>
    HRESULT PrototypeCoCreateInstance(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __in  DWORD dwClsContext,
        __deref_out Q** ppQ ) 
    {
        return PrototypeCoCreateInstance(rclsid, pOuterUnk, dwClsContext, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    HRESULT PrototypeCoCreateInstance(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) 
    {
        return PrototypeCoCreateInstance(rclsid, pOuterUnk, CLSCTX_INPROC_SERVER, riid, ppv);
    }

    template <typename Q>
    HRESULT PrototypeCoCreateInstance(
        __in  REFCLSID rclsid, 
        __in_opt LPUNKNOWN pOuterUnk, 
        __deref_out Q** ppQ ) 
    {
        return PrototypeCoCreateInstance(rclsid, pOuterUnk, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

    HRESULT PrototypeCoCreateInstance(
        __in  REFCLSID rclsid, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppv ) 
    {
        return PrototypeCoCreateInstance(rclsid, NULL, riid, ppv);
    }

    template <typename Q>
    HRESULT PrototypeCoCreateInstance(
        __in  REFCLSID rclsid, 
        __deref_out Q** ppQ ) 
    {
        return PrototypeCoCreateInstance(rclsid, __uuidof(Q), reinterpret_cast<LPVOID*>(ppQ));
    }

};


MIDL_INTERFACE("A5F9278C-EC1C-4247-8735-2D7607203F67")
ISessionListener : public IUnknown
{
    STDMETHOD(OnQueryServiceByClassID)(
        __in REFCLSID clsidService,
        __in REFIID riid,
        __in DWORD dwFlags = 0 ) PURE;

    STDMETHOD(OnQueryService)(
        __in REFGUID guidService,
        __in REFIID riid,
        __in DWORD dwFlags = 0 ) PURE;

    // If this returns a failure HRESULT, it will effectively block the CoCreateInstance() call (and thus
    // the QueryService() or QueryServiceByClassID() call).
    // The HRESULT that you should employ if this is intentional is XPERF_SESSION_COCREATEINSTANCE_BLOCKED
    STDMETHOD(OnCoCreateInstance)(__in REFGUID clsidService) PURE;
};


MIDL_INTERFACE("EB8A6E40-F561-493C-ABBA-4D606E3F891E")
ISession3 : public IUnknown
{
    STDMETHOD(SetSessionListener)(__in_opt ISessionListener* pSessionListener) PURE;
};


MIDL_INTERFACE("3F5E0885-0F62-4049-8A03-B25D43B31ED5") 
IOutputStream : public IUnknown
{
    STDMETHOD(Write)(
        __in_bcount(cb) LPCVOID pv,
        __in  SIZE_T cb,
        __out_opt SIZE_T* pcbWritten ) PURE;

    /* [local] */
    STDMETHOD_(SSIZE_T, PrintV)(
        __in __format_string LPCWSTR wszFormat,
        __in  va_list argptr ) PURE;

    /* [local] */
    SSIZE_T PrintF(
        __in __format_string LPCWSTR wszFormat,
        ... )
    {
        va_list argptr;
        va_start(argptr, wszFormat);

        return PrintV(wszFormat, argptr);
    }

    /* [local] */
    STDMETHOD_(SSIZE_T, PrintV)(
        __in __format_string LPCSTR szFormat,
        __in  va_list argptr ) PURE;

    /* [local] */
    SSIZE_T PrintF(
        __in __format_string LPCSTR szFormat,
        ... )
    {
        va_list argptr;
        va_start(argptr, szFormat);

        return PrintV(szFormat, argptr);
    }
};


MIDL_INTERFACE("DEA6A2D4-A000-4B7D-96D9-1DA5BF8EDA70") 
ISessionService : public IUnknown
{
public:
    STDMETHOD(OnSessionConnect)(
        __in  ISession* pSession ) PURE;

    STDMETHOD(OnSessionProcessEvents)(
        __in  ISession* pSession ) PURE;

    STDMETHOD(OnSessionReady)() PURE;
};

// Widely used error codes

#define XPERF_E_BUFFER_TOO_SMALL            HRESULT_FROM_NT(STATUS_BUFFER_TOO_SMALL)
#define XPERF_E_DATA_ERROR                  HRESULT_FROM_NT(STATUS_DATA_ERROR)
#define XPERF_E_NOT_FOUND                   HRESULT_FROM_WIN32(ERROR_NOT_FOUND)
#define XPERF_E_ARITHMETIC_OVERFLOW         HRESULT_FROM_WIN32(ERROR_ARITHMETIC_OVERFLOW)
#define XPERF_E_TIME_INVERSION              HRESULT_FROM_WIN32(ERROR_TIME_SKEW)

//
// Success Codes for Event Sinks (besides S_OK)
//

#define XPERF_EVSINK_S_UNHANDLED_EVENT      MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x100)
#define XPERF_EVSINK_S_UNKNOWN_VERSION      MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x101)
#define XPERF_EVSINK_S_UNKNOWN_LEVEL        MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x102)
#define XPERF_EVSINK_S_INVALID_DATA         MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x103)


//
// Event Sinks
//

struct ICursor;

enum CEventSinkType
{
    EventSinkType_NonInductive  = 0,
    EventSinkType_Inductive     = 1,
    EventSinkType_Context       = 2,
};


MIDL_INTERFACE("7A3932DF-1947-4A0A-B4CE-B3870682B9CF") 
IEventSink : public IUnknown
{
public:
    STDMETHOD(OnEvent)( 
        __in  const ICursor& cursor, 
        __in  REFGUID ProviderId,
        __in  const EVENT_RECORD* pEventRecord ) PURE;

    STDMETHOD(OnDataComplete)() PURE;

    STDMETHOD_(INT, GetEventSinkType)() PURE;

    DECLSPEC_DEPRECATED
    BOOL IsInductive()
    {
        return (GetEventSinkType() == EventSinkType_Inductive) ? TRUE : FALSE;
    }
};

MIDL_INTERFACE("09B248D4-F609-4E7E-8655-2908F73E733E") 
IEventSink2 : public IEventSink
{
public:
    STDMETHOD(OnStageComplete)() PURE;
};

struct EventSinkRegistryEntry
{
    const GUID* pProviderId;
};

#define XPERF_EVSINK_pProviderId_ANY       reinterpret_cast<const GUID*>(0)
#define XPERF_EVSINK_pProviderId_FALLBACK  reinterpret_cast<const GUID*>(1)

MIDL_INTERFACE("6B14C5AF-CEBC-4543-B29C-8761B87D568C") 
IEventSinkRegistry : public IUnknown
{
public:
    STDMETHOD(Register)( 
        __in  LPUNKNOWN pEventSinkUnk, 
        __in  SIZE_T cbEntrySize, 
        __in  SIZE_T cEntries, 
        __in_xcount(cbEntrySize*cEntries) const EventSinkRegistryEntry *rgEntries ) PURE;
};


//
// IEventNameRegistry
//

struct EventNameRegistryEntry
{
    enum Resolution {
        EventGuid,
        Type,
        TypeVersion,
    };

    const GUID* pEventGuid;
    LPCWSTR     wszEventName;
    UCHAR       ucResolution;
    UCHAR       ucType;
    USHORT      usVersion;
};


MIDL_INTERFACE("4DD694B1-F5EA-47E8-BB66-92CC67A0C928")
IEventNameRegistry : public IUnknown
{
public:
    STDMETHOD(Register)( 
        __in  LPUNKNOWN pEventNameUnk,
        __in  SIZE_T cbEntrySize, 
        __in  SIZE_T cEntries,
        __in_xcount(cbEntrySize*cEntries) const EventNameRegistryEntry *rgEntries ) PURE;
};

MIDL_INTERFACE("38DE5EE7-BB40-469f-8067-D255D575C57D")
IEventNameDatabase : public IUnknown
{
};



//
// Cursor
//

MIDL_INTERFACE("2707828C-ADD6-4868-B0C6-8993ABCDC13C")
ICursor : public IUnknown
{
public:
    // Use ConvertClockToTimeStamp for trace Clock (raw) timestamps within events.
    STDMETHOD_(TimeStamp,       ConvertClockToTimeStamp)(LONGLONG time) const PURE;
    // Use ConvertClockToTimeStampDelta for trace Clock (raw) durations within events.
    STDMETHOD_(TimeStampDelta,  ConvertClockToTimeStampDelta)(LONGLONG count) const PURE;
    // Use ConvertPerfCounterToTimeStampDelta for PerfCounter durations within events.
    STDMETHOD_(TimeStampDelta,  ConvertPerfCounterToTimeStampDelta)(LONGLONG count) const PURE;
    // Use ConvertCycleCounterToTimeStampDelta for RDTSC counter durations within events.
    STDMETHOD_(TimeStampDelta,  ConvertCycleCounterToTimeStampDelta)(LONGLONG count) const PURE;


    STDMETHOD_(ULONG,           GetCurrentCpu)() const PURE;
    STDMETHOD_(ULONGLONG,       GetCurrentEventNumber)() const PURE;
    STDMETHOD_(TimeStamp,       GetCurrentTimeStamp)() const PURE;
    STDMETHOD_(ULONG,           GetCurrentPointerSize)() const PURE;
    STDMETHOD_(LPCWSTR,         GetCurrentTraceName)() const PURE;
    STDMETHOD_(SIZE_T,          GetCurrentTraceNumber)() const PURE;
    STDMETHOD_(ULONGLONG,       GetCurrentEventNumberWithinTrace)() const PURE;


    // Syntactic sugar
    __declspec(property(get=GetCurrentCpu))         ULONG       CurrentCpu;
    __declspec(property(get=GetCurrentEventNumber)) ULONGLONG   CurrentEventNumber;
    __declspec(property(get=GetCurrentPointerSize)) ULONG       CurrentPointerSize;

    __declspec(property(get=GetCurrentTraceName))   LPCWSTR     CurrentTraceName;
    __declspec(property(get=GetCurrentTraceNumber)) SIZE_T      CurrentTraceNumber;
    __declspec(property(get=GetCurrentEventNumberWithinTrace)) ULONGLONG   CurrentEventNumberWithinTrace;

    operator const TimeStamp() const;

    TimeStamp operator+(const TimeStampDelta& dT) const;
    TimeStamp operator-(const TimeStampDelta& dT) const;
    TimeStampDelta operator-(const TimeStamp& TS) const;

    LONGLONG get_nsec() const;
    __declspec(property(get=get_nsec)) LONGLONG nsec;

    LONGLONG get_usec() const;
    __declspec(property(get=get_usec)) LONGLONG usec;

    LONGLONG get_msec() const;
    __declspec(property(get=get_msec)) LONGLONG msec;

    LONGLONG get_sec() const;
    __declspec(property(get=get_sec)) LONGLONG sec;
};

//-----------------------------------------------------------------------------

//
// Light-weight data structures (fixed)
//

class TimeStamp;

class TimeStampDelta
{
public:
    explicit TimeStampDelta(LONGLONG _nsec = 0i64) : m_dTS(_nsec) {}

    // Constants

    static const TimeStampDelta  Zero;
    static const TimeStampDelta  Max;

    // Accessors

    LONGLONG get_nsec() const { return m_dTS; }
    void put_nsec( const LONGLONG _nsec ) { m_dTS = _nsec; }
    __declspec(property(get=get_nsec, put=put_nsec)) LONGLONG nsec;

    LONGLONG get_usec() const { return (m_dTS + 500) / 1000; }
    void put_usec( const LONGLONG _usec ) { m_dTS = _usec * 1000; }
    __declspec(property(get=get_usec, put=put_usec)) LONGLONG usec;

    LONGLONG get_msec() const { return (m_dTS + 500000) / 1000000; }
    void put_msec( const LONGLONG _msec ) { m_dTS = _msec * 1000000; }
    __declspec(property(get=get_msec, put=put_msec)) LONGLONG msec;

    LONGLONG get_sec() const { return (m_dTS + 500000000) / 1000000000; }
    void put_sec( const LONGLONG _sec ) { m_dTS = _sec * 1000000000; }
    __declspec(property(get=get_sec, put=put_sec)) LONGLONG sec;

    //
    // Operators
    //

    TimeStampDelta operator-() const
    {
        return TimeStampDelta( -m_dTS );
    }
    TimeStampDelta operator+( const TimeStampDelta& dT ) const
    {
        return TimeStampDelta( m_dTS + dT.m_dTS );
    }
    TimeStampDelta operator-( const TimeStampDelta& dT ) const
    {
        return TimeStampDelta( m_dTS - dT.m_dTS );
    }

    double DivideFP(const TimeStampDelta& Den) const
    {
        return (double)m_dTS / (double)Den.m_dTS;
    }
    LONGLONG DivideRoundUp(const TimeStampDelta& Den) const
    {
        return (m_dTS + Den.m_dTS - 1) / Den.m_dTS;
    }
    LONGLONG DivideRoundDown(const TimeStampDelta& Den) const
    {
        return m_dTS / Den.m_dTS;
    }
    LONGLONG operator/( const TimeStampDelta& Den ) const
    {
        return m_dTS / Den.m_dTS;
    }
    TimeStampDelta operator%( const TimeStampDelta& Den ) const
    {
        return TimeStampDelta( m_dTS % Den.m_dTS );
    }
    TimeStampDelta operator/( const LONGLONG Den ) const
    {
        return TimeStampDelta(m_dTS / Den);
    }
    TimeStampDelta operator*(LONGLONG scale) const
    {
        return TimeStampDelta(m_dTS * scale);
    }

    void operator+=( const TimeStampDelta& dT )
    {
        m_dTS += dT.m_dTS;
    }

    void operator-=( const TimeStampDelta& dT )
    {
        m_dTS -= dT.m_dTS;
    }

    bool operator< ( const TimeStampDelta& comp ) const
    {
        return m_dTS < comp.m_dTS;
    }
    bool operator<=( const TimeStampDelta& comp ) const
    {
        return m_dTS <= comp.m_dTS;
    }
    bool operator==( const TimeStampDelta& comp ) const
    {
        return m_dTS == comp.m_dTS;
    }
    bool operator>=( const TimeStampDelta& comp ) const
    {
        return m_dTS >= comp.m_dTS;
    }
    bool operator> ( const TimeStampDelta& comp ) const
    {
        return m_dTS > comp.m_dTS;
    }
    bool operator!=( const TimeStampDelta& comp ) const
    {
        return m_dTS != comp.m_dTS;
    }

protected:
    friend class TimeStamp;

    LONGLONG    m_dTS;
};

inline
TimeStampDelta operator*(LONGLONG scale, const TimeStampDelta& dT)
{
    return dT * scale;
}

__declspec(selectany) const TimeStampDelta TimeStampDelta::Zero( 0i64 );
__declspec(selectany) const TimeStampDelta TimeStampDelta::Max( _I64_MAX );

class TimeStamp
{
public:
    explicit TimeStamp(LONGLONG _nsec = 0i64) : m_TS(_nsec) {}

    // Constants

    static const TimeStamp  Min;
    static const TimeStamp  Max;
    static const TimeStamp  End;

    //
    // Accessors
    //

    LONGLONG get_nsec() const { return m_TS; }
    void put_nsec( const LONGLONG _nsec ) { m_TS = _nsec; }
    __declspec(property(get=get_nsec, put=put_nsec)) LONGLONG nsec;

    LONGLONG get_usec() const { return (m_TS + 500) / 1000; }
    void put_usec( const LONGLONG _usec ) { m_TS = _usec * 1000; }
    __declspec(property(get=get_usec, put=put_usec)) LONGLONG usec;

    LONGLONG get_msec() const { return (m_TS + 500000) / 1000000; }
    void put_msec( const LONGLONG _msec ) { m_TS = _msec * 1000000; }
    __declspec(property(get=get_msec, put=put_msec)) LONGLONG msec;

    LONGLONG get_sec() const { return (m_TS + 500000000) / 1000000000; }
    void put_sec( const LONGLONG _sec ) { m_TS = _sec * 1000000000; }
    __declspec(property(get=get_sec, put=put_sec)) LONGLONG sec;

    //
    // Operators
    //

    TimeStamp operator-() const
    {
        return TimeStamp( -m_TS );
    }
    TimeStamp operator+( const TimeStampDelta& dT ) const
    {
        return TimeStamp( m_TS + dT.m_dTS );
    }
    TimeStamp operator-( const TimeStampDelta& dT ) const
    {
        return TimeStamp( m_TS - dT.m_dTS );
    }
    TimeStampDelta operator-( const TimeStamp& T2 ) const
    {
        return TimeStampDelta( m_TS - T2.m_TS );
    }
    
    TimeStampDelta operator%( const TimeStampDelta& Den ) const
    {
        return TimeStampDelta( m_TS % Den.m_dTS );
    }

    void operator+=( const TimeStampDelta& dT )
    {
        m_TS += dT.m_dTS;
    }
    void operator-=( const TimeStampDelta& dT )
    {
        m_TS -= dT.m_dTS;
    }

    bool operator< ( const TimeStamp& comp ) const
    {
        return m_TS < comp.m_TS;
    }
    bool operator<=( const TimeStamp& comp ) const
    {
        return m_TS <= comp.m_TS;
    }
    bool operator==( const TimeStamp& comp ) const
    {
        return m_TS == comp.m_TS;
    }
    bool operator>=( const TimeStamp& comp ) const
    {
        return m_TS >= comp.m_TS;
    }
    bool operator> ( const TimeStamp& comp ) const
    {
        return m_TS > comp.m_TS;
    }
    bool operator!=( const TimeStamp& comp ) const
    {
        return m_TS != comp.m_TS;
    }

protected:
    LONGLONG    m_TS;
};

__declspec(selectany) const TimeStamp TimeStamp::Min( 0i64 );
__declspec(selectany) const TimeStamp TimeStamp::Max( _I64_MAX );
__declspec(selectany) const TimeStamp TimeStamp::End( _I64_MAX-1 );


//
// Syntactic sugar on ICursor
//

inline
ICursor::operator const TimeStamp() const { return GetCurrentTimeStamp(); }
inline
TimeStamp ICursor::operator+(const TimeStampDelta& dT) const { return GetCurrentTimeStamp() + dT; }
inline
TimeStamp ICursor::operator-(const TimeStampDelta& dT) const { return GetCurrentTimeStamp() - dT; }
inline
TimeStampDelta ICursor::operator-(const TimeStamp& TS) const { return GetCurrentTimeStamp() - TS; }
inline
LONGLONG ICursor::get_nsec() const { return GetCurrentTimeStamp().get_nsec(); }
inline
LONGLONG ICursor::get_usec() const { return GetCurrentTimeStamp().get_usec(); }
inline
LONGLONG ICursor::get_msec() const { return GetCurrentTimeStamp().get_msec(); }
inline
LONGLONG ICursor::get_sec()  const { return GetCurrentTimeStamp().get_sec(); }


//
// ReferenceTime -- facilitates conversion of timestamps across 
//                  traces with compatible clock times.
//

MIDL_INTERFACE("1E8423A4-726F-4857-9C50-D51697D88EEE") 
IReferenceTimeInfoSource : public IUnknown
{
    struct ReferenceTime
    {
        TimeStamp   TimeStamp;
        LONGLONG    ClockTime;
    };

    STDMETHOD(QueryReferenceTime)(
        __out ReferenceTime* pReferenceTime
        ) const PURE;

    STDMETHOD_(TimeStampDelta, GetTimeStampBiasFromReference)(
        __in  const ReferenceTime& ReferenceTime
        ) const PURE;
};



//
// Hierarchical Naming System: PathNode/IPathRegistry
//

struct PathNode
{
    LPCWSTR             FileName;
    const PathNode*     Parent;
};

MIDL_INTERFACE("23118026-0A24-4A84-9573-01F5A125FCAF")
IPathRegistry : public IUnknown
{
    static const WCHAR Separator = L'\\';
    static const WCHAR Unknown[];

    STDMETHOD_(const PathNode*, Create)(
        __in  LPCWSTR Path, 
        __in  SIZE_T Len) PURE;
    
    STDMETHOD(Destroy)(
        __in_opt const PathNode* Node) PURE;
    
    STDMETHOD_(const PathNode*, Insert)(
        __in_opt const PathNode* RelativeTo, 
        __in  LPCWSTR Path, 
        __in  SIZE_T MaxLength = ULONG_MAX) PURE;
    
    STDMETHOD(GetName)(
        __in  const PathNode* Node, 
        __out_ecount_part_opt(Cch, Cch) LPWSTR Buffer, 
        __inout SIZE_T& Cch, 
        __in_opt const PathNode* RelativeTo = NULL) CONST PURE;
};

__declspec(selectany) const WCHAR IPathRegistry::Unknown[] = L"\"Unknown\"";

#define AnyPathNode     ((const PathNode*)1)


MIDL_INTERFACE("18667DF4-869D-4B62-96CC-BD91BCFB1566")
IPathRegistryFactory : public IUnknown
{
    template <typename Q>
    HRESULT CreateInstance(
        __in_opt LPUNKNOWN pUnkOuter, 
        __deref_out Q** ppObj
        )
    {
        return CreateInstance(pUnkOuter, __uuidof(Q), reinterpret_cast<LPVOID*>(ppObj));
    }

	// IClassFactory
	STDMETHOD(CreateInstance)(
        __in_opt LPUNKNOWN pUnkOuter, 
        __in  REFIID riid, 
        __deref_out LPVOID* ppvObj
        );
};

} // namespace XPerfCore


// Declare parent namespace for addin contributions
namespace XPerfAddIn
{
    using namespace XPerfCore;
}


namespace XPerfCore
{

//
// See /base/perf/common/AtlGlobalPtr.hpp for more documentation for CAtlGlobalPtr.
//

template <typename T>
class CAtlGlobalPtr
{
public:
    CAtlGlobalPtr()
        : m_p()
    {
        try {
            m_p = new T();
        } catch (...) {
            CAtlBaseModule::m_bInitFailed = true;
        }
    }

    ~CAtlGlobalPtr()
    {
        delete m_p;
    }

    T& operator*() const
    {
        return *m_p;
    }

    T* operator->() const
    {
        return m_p;
    }

    T* m_p;
};

} // namespace XPerfCore

namespace XPerfCore
{
    const ULONG g_cSupportedProcessors = 4096;

} // namespace XPerfCore
