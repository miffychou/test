/*++

Copyright (c) 2004 Microsoft Corporation

Module Name:

    XPerfCoreDev.hpp

Abstract:

    C++ client-side support for XPerfCore.hpp

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>

// Debugging: Uncomment next line to enable ATL QI thunking
//#define _ATL_DEBUG_INTERFACES

// Invariants
#ifdef _XPC_ENFORCE_INVARIANTS
#define XPC_INVARIANT(exp) \
 ((!(exp)) ? \
        (RtlAssert( #exp, __FILE__, __LINE__, NULL ),FALSE) : \
        TRUE)
#define XPC_INVARIANT_ASSERT(exp) XPC_INVARIANT(exp)
#else
#define XPC_INVARIANT(exp) __noop(exp)
#define XPC_INVARIANT_ASSERT(exp) ASSERT(exp)
#endif

// ATL configuration
#if defined(ATLASSERT)
#undef ATLASSERT
#endif
#define ATLASSERT(x) ASSERT(x)

#include <coguid.h>
#include <stdio.h>
#include <stdarg.h>

#pragma warning(push)
#define _ATL_ALL_WARNINGS

#pragma warning(disable:4245) //'conversion' : conversion from 'type1' to 'type2', signed/unsigned mismatch
#include <atlbase.h>
#include <atlcom.h>
#pragma warning(pop)


#pragma warning(disable:4512) // 'class' : assignment operator could not be generated
#pragma warning(disable:4505) // 'function' : unreferenced local function has been removed

// Safe string APIs
#include <strsafe.h>

#include <vector>

//
// XPerfCore Interface Metadata
//

#ifndef XPERFCORE_INTERFACE_ENTRY_PRAGMA

#if defined(_M_IX86)
#define XPERFCORE_INTERFACE_ENTRY_PRAGMA(itf) __pragma(comment(linker, "/include:___xperfcore_itfMap_" #itf));
#else
#define XPERFCORE_INTERFACE_ENTRY_PRAGMA(itf) __pragma(comment(linker, "/include:__xperfcore_itfMap_" #itf));
#endif

#endif	//XPERFCORE_INTERFACE_ENTRY_PRAGMA

#define XPERFCORE_INTERFACE_ENTRY_AUTO2(iid, itf) \
	extern "C" __declspec(selectany) GUID const __xperfcore_itfMap_##itf = iid; \
	XPERFCORE_INTERFACE_ENTRY_PRAGMA(itf)

#define XPERFCORE_INTERFACE_ENTRY_AUTO(itf) \
    XPERFCORE_INTERFACE_ENTRY_AUTO2(__uuidof(itf), itf)


//
// XPerfCore
//

namespace XPerfCore
{

#define COMGUARD(hr) \
    { \
        HRESULT __hrCOM = hr; \
        if (FAILED(__hrCOM)) { \
            return __hrCOM; \
        } \
    }

#define COMGUARDTHROW(hr) \
    { \
        HRESULT __hrCOM = hr; \
        if (FAILED(__hrCOM)) { \
            AtlThrow(__hrCOM); \
        } \
    }

#define COMGUARD_NOTOK(hr) \
    { \
        HRESULT __hrCOM = hr; \
        if (__hrCOM != S_OK) { \
            return __hrCOM; \
        } \
    }

#define COMGUARDTHROW_NOTOK(hr) \
    { \
        HRESULT __hrCOM = hr; \
        if (__hrCOM != S_OK) { \
            AtlThrow(__hrCOM); \
        } \
    }

#define COM(method)\
    if (FAILED (Hr = method)) {\
        XPC_DBGPRINT("%s (line %4d): " #method " failed: [%#x]\n", __FILE__, __LINE__, Hr);\
        goto End;\
    }


//-----------------------------------------------------------------------------

//
// Compile Time Assertion Support
//

template <int i> struct CompileTimeAssert {};
template <> struct CompileTimeAssert<0>;

#define CTASSERT(CTEXPR) sizeof(::XPerfCore::CompileTimeAssert<CTEXPR>)
#define _helper_CTASSERT2(CTEXPR, COUNT) const ::XPerfCore::CompileTimeAssert<CTEXPR> __CTASSERT__ ## COUNT
#define _helper_CTASSERT1(CTEXPR, COUNT) _helper_CTASSERT2(CTEXPR, COUNT)
#define _CTASSERT(CTEXPR) _helper_CTASSERT1(CTEXPR, __COUNTER__)

//-----------------------------------------------------------------------------

//
// Safe Cast
//

template <typename R, typename T>
inline
bool is_static_cast_safe(T val)
{
    return (val == static_cast<T>(static_cast<R>(val)));
}


//-----------------------------------------------------------------------------

//
// Safer CreateInstance (refCount will be 1 instead of 0)
//

template <typename T>
inline
HRESULT CreateInstanceRefCount1(__deref_out CComObject<T>** ppObject)
{
    if (!ppObject || *ppObject)
    {
        return E_POINTER;
    }

    HRESULT hr = CComObject<T>::CreateInstance(ppObject);
    if (SUCCEEDED(hr))
    {
        (*ppObject)->AddRef();
    }

    return hr;
}

//-----------------------------------------------------------------------------

//
// Debug printing and tracing support
//

#if (defined(_XPERFCORE_INTERNAL_BUILD) || DBG)
#if defined(_XPERFCORE_OUTPUT_DEBUG_STRINGS_TO_STDERR) || defined(_XPERFCORE_OUTPUT_DEBUG_STRINGS_TO_DEBUGGER)
#define _XPERFCORE_OUTPUT_DEBUG_STRINGS
#endif
#endif

#if defined(_XPERFCORE_OUTPUT_DEBUG_STRINGS_TO_STDERR)

inline
void vdbgPrint(
    __in __format_string LPCSTR szFormat,
    __in va_list argptr
    )
{
    vfprintf(stderr, szFormat, argptr);
}

#elif defined(_XPERFCORE_OUTPUT_DEBUG_STRINGS_TO_DEBUGGER)

inline
void vdbgPrint(
    __in __format_string LPCSTR szFormat,
    __in va_list argptr)
{
    CHAR chBuffer[1024];
    chBuffer[0] = ANSI_NULL;

    _vsnprintf_s(chBuffer, RTL_NUMBER_OF(chBuffer), _TRUNCATE, szFormat, argptr);
    OutputDebugStringA(chBuffer);
}

#else

inline
void vdbgPrint(
    __in __format_string LPCSTR szFormat,
    __in va_list argptr)
{
    UNREFERENCED_PARAMETER(szFormat);
    UNREFERENCED_PARAMETER(&argptr);
}

#endif

inline
void dbgPrint(
    __in __format_string LPCSTR szFormat,
    ...)
{
    va_list argptr;
    va_start(argptr, szFormat);
    vdbgPrint(szFormat, argptr);
    va_end(argptr);
}

class CDbgTrace
{
    const char* m_szFile;
    int         m_nLine;
public:
    CDbgTrace(const char* szFile, int nLine)
        : m_szFile(szFile)
        , m_nLine(nLine)
    {
    }
    void operator()() const
    {
#if defined(_XPERFCORE_INTERNAL_BUILD)
        dbgPrint("%s(%d)\n", m_szFile, m_nLine);
#endif
    }
    void operator()(
        __in __format_string LPCSTR szFormat,
        ...
        ) const
    {
#if defined(_XPERFCORE_INTERNAL_BUILD)
        dbgPrint("%s(%d): ", m_szFile, m_nLine);
#endif
        va_list argptr;
        va_start(argptr, szFormat);
        vdbgPrint(szFormat, argptr);
        va_end(argptr);
    }
};

#define XPC_SHIP_DBGPRINT ::XPerfCore::dbgPrint
#define XPC_SHIP_TRACE ::XPerfCore::CDbgTrace(__FILE__, __LINE__)

#if defined(_XPERFCORE_OUTPUT_DEBUG_STRINGS)

#define XPC_DBGPRINT XPC_SHIP_DBGPRINT
#define XPC_TRACE XPC_SHIP_TRACE

#else 

#define XPC_DBGPRINT __noop
#define XPC_TRACE __noop

#endif

//-----------------------------------------------------------------------------

//
// Registry support
//

template <typename _CRegistrable, typename _IRegistry, typename _RegistryEntryV0>
class ATL_NO_VTABLE CRegistrableImpl
{
protected:
    HRESULT Register(
        __in  ISession* pSession, 
        __in  SIZE_T cbEntrySize, 
        __in  SIZE_T cEntries, 
        __in_xcount(cbEntrySize*cEntries) const _RegistryEntryV0* rgEntries
        )
    {
        if (cEntries == 0) {
            return S_OK;
        }
        ASSERT(rgEntries != NULL);
        if (rgEntries == NULL) {
            return E_INVALIDARG;
        }
        CComPtr<_IRegistry> spRegistry;
        HRESULT hr = pSession->QueryService(&spRegistry);
        if (SUCCEEDED(hr)) {
            ASSERT(spRegistry != nullptr);
            hr = spRegistry->Register(static_cast<_CRegistrable*>(this), cbEntrySize, cEntries, rgEntries);
        }
        return hr;
    }

    // OnSessionConnect_Auto - member function overload
    template <typename _Derived, typename _RegistryEntry>
    HRESULT OnSessionConnect_Auto(
        __in  ISession* pSession, 
        __in  _RegistryEntry* (_Derived::*_GetMap)(SIZE_T*)
        )
    {
        SIZE_T cEntries = 0;
        const _RegistryEntry* rgEntries = (static_cast<_Derived*>(this)->*_GetMap)(&cEntries);
        return Register(pSession, sizeof(_RegistryEntry), cEntries, rgEntries);
    }
    // OnSessionConnect_Auto - static member function overload
    template <typename _RegistryEntry>
    HRESULT OnSessionConnect_Auto(
        __in  ISession* pSession, 
        __in  _RegistryEntry* (*_GetMap)(SIZE_T*)
        )
    {
        SIZE_T cEntries = 0;
        const _RegistryEntry* rgEntries = (*_GetMap)(&cEntries);
        return Register(pSession, sizeof(_RegistryEntry), cEntries, rgEntries);
    }
};


inline
HRESULT XPerfCoreLoadServices(
    __in ISession* pSession, 
    __in REFIID riid
    )
{
    CComPtr<ICollectionCLSID> spCollCLSID;
    HRESULT hr = pSession->GetClassesOfCategories(1, &riid, &spCollCLSID);
    if (FAILED(hr)) {
        return hr;
    }

    if (hr == S_OK) {
        LONG cServices = 0;

        hr = spCollCLSID->get_Count(&cServices);
        if (FAILED(hr)) {
            return hr;
        }

        for (LONG i = 1; i <= cServices; ++i) {
            CLSID clsid;
            hr = spCollCLSID->get_Item(i, &clsid);
            if (FAILED(hr)) {
                return hr;
            }
            CComPtr<IUnknown> spUnk;
            hr = pSession->QueryServiceByClassID(clsid, riid, reinterpret_cast<LPVOID*>(&spUnk));
            if (FAILED(hr)) {
                return hr;
            }
        }
    }
    
    return S_OK;
}

//-----------------------------------------------------------------------------

MIDL_INTERFACE("108BD2A5-002F-4571-B3B0-52E68416DF83") 
ISessionServiceInternal : public IUnknown
{
    STDMETHOD(StoreSession)(ISession* pSession) PURE;
};

//
// SessionServices
//

class ATL_NO_VTABLE CSessionServiceRootBase : 
    public ISessionService,
    public ISessionServiceInternal
{
public:
    DECLARE_NO_REGISTRY()
    
    STDMETHOD(OnSessionConnect)(
        __in  ISession* pSession
        )
    {
        UNREFERENCED_PARAMETER(pSession);
        return S_OK;
    }

    STDMETHOD(OnSessionProcessEvents)(
        __in  ISession* pSession
        )
    {
        UNREFERENCED_PARAMETER(pSession);
        return S_OK;
    }

    STDMETHOD(OnSessionReady)()
    {
        return S_OK;
    }

public:
    //
    // ISessionServiceInternal
    //

    STDMETHOD(StoreSession)(ISession* pSession)
    {
        m_spSession = pSession;
        return S_OK;
    }

private:
    CComPtr<ISession>  m_spSession;
};

__declspec(selectany) REFCATID CATID_ISessionService = __uuidof(ISessionService);

#define IMPLEMENTED_CATEGORY_SESSIONSERVICE() \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_ISessionService)

template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CSessionServiceRoot :
    public CComObjectRootEx<ThreadModel>,
    public CComCoClass<_Derived, &__uuidof(_Derived)>,
    public CSessionServiceRootBase    
{
public:
    typedef CSessionServiceRoot<_Derived, ThreadModel> _SessionService;

    DECLARE_NOT_AGGREGATABLE(_Derived)

    BEGIN_COM_MAP(_SessionService)
        COM_INTERFACE_ENTRY(ISessionService)
        COM_INTERFACE_ENTRY(ISessionServiceInternal)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_SessionService)
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()
    END_CATEGORY_MAP()    
};


#ifdef _ATL_DEBUG

#define DECLARE_CHAINING_COM_MAP_EX(x, y, base) \
    BEGIN_COM_MAP(x) \
        COM_INTERFACE_ENTRY(base) \
        COM_INTERFACE_ENTRY_CHAIN(y) \
    END_COM_MAP()

#else // _ATL_DEBUG

#define DECLARE_CHAINING_COM_MAP_EX(x, y, base)

#endif // _ATL_DEBUG

#define DECLARE_CHAINING_COM_MAP(x, y) \
    DECLARE_CHAINING_COM_MAP_EX(x, y, ISessionService)

//
// EventSinks
//

class ATL_NO_VTABLE CEventSinkRootBase : 
    public IEventSink2,
    public CRegistrableImpl<CEventSinkRootBase, IEventSinkRegistry, EventSinkRegistryEntry>
{
public:
    STDMETHOD(OnDataComplete)()
    {
        return S_OK;
    }
    STDMETHOD(OnStageComplete)()
    {
        return S_OK;
    }
};

__declspec(selectany) REFCATID CATID_IEventSink = __uuidof(IEventSink);
__declspec(selectany) REFCATID CATID_IEventSink2 = __uuidof(IEventSink2);

#define IMPLEMENTED_CATEGORY_ETW_EVENTSINK() \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IEventSink) \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IEventSink2) \
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()

template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CEventSinkRoot :
    public CSessionServiceRoot<_Derived, ThreadModel>,
    public CEventSinkRootBase
{
public:
    typedef CEventSinkRoot<_Derived, ThreadModel> _EventSink;

    BEGIN_COM_MAP(_EventSink)
        COM_INTERFACE_ENTRY(IEventSink)
        COM_INTERFACE_ENTRY(IEventSink2)
        COM_INTERFACE_ENTRY_CHAIN(_SessionService)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_EventSink)
        IMPLEMENTED_CATEGORY_ETW_EVENTSINK()
    END_CATEGORY_MAP()

public:
    STDMETHOD(OnSessionConnect)(
        __in ISession* pSession
        )
    {
        return OnSessionConnect_Auto(pSession, &_Derived::_Etw_EventSink_GetMap);
    }
};


template <INT iEventSinkType, typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CEventSinkRootEx :
    public CEventSinkRoot<_Derived, ThreadModel>
{
    STDMETHOD_(INT, GetEventSinkType)()
    {
        return iEventSinkType;
    }
};


template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CNonInductiveEventSinkRoot :
    public CEventSinkRootEx<EventSinkType_NonInductive, _Derived, ThreadModel>
{
};


template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CInductiveEventSinkRoot :
    public CEventSinkRootEx<EventSinkType_Inductive, _Derived, ThreadModel>
{
};


template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CContextEventSinkRoot :
    public CEventSinkRootEx<EventSinkType_Context, _Derived, ThreadModel>
{
};


#define BEGIN_ETW_EVENTSINK_MAP() \
    static const EventSinkRegistryEntry* _Etw_EventSink_GetMap(__out SIZE_T* pcSize) { \
        static const EventSinkRegistryEntry _Map[] = {

#define ETW_EVENTSINK_MONITOR_ALL_EVENTS()          XPERF_EVSINK_pProviderId_ANY,
#define ETW_EVENTSINK_MONITOR_UNHANDLED_EVENTS()    XPERF_EVSINK_pProviderId_FALLBACK,
#define ETW_EVENTSINK_MONITOR_PROVIDER(ProviderId)  &ProviderId,

#define END_ETW_EVENTSINK_MAP() }; \
        *pcSize = RTL_NUMBER_OF(_Map); \
        return _Map; \
    };


//
// Event Name Databases
//

class ATL_NO_VTABLE CEventNameDatabaseRootBase : 
    public CRegistrableImpl<CEventNameDatabaseRootBase, IEventNameRegistry, EventNameRegistryEntry>,
    public IEventNameDatabase
{
protected:
};

__declspec(selectany) REFCATID CATID_IEventNameDatabase = __uuidof(IEventNameDatabase);

#define IMPLEMENTED_CATEGORY_ETW_EVENTNAMEDATABASE() \
        IMPLEMENTED_CATEGORY(XPerfCore::CATID_IEventNameDatabase) \
        IMPLEMENTED_CATEGORY_SESSIONSERVICE()

template <typename _Derived, typename ThreadModel = CComObjectThreadModel>
class ATL_NO_VTABLE CEventNameDatabaseRoot :
    public CSessionServiceRoot<_Derived, ThreadModel>,
    public CEventNameDatabaseRootBase
{
public:
    typedef CEventNameDatabaseRoot<_Derived, ThreadModel> _EventNameDatabase;

    BEGIN_COM_MAP(_EventNameDatabase)
        COM_INTERFACE_ENTRY(IEventNameDatabase)
        COM_INTERFACE_ENTRY_CHAIN(_SessionService)
    END_COM_MAP()

    BEGIN_CATEGORY_MAP(_EventNameDatabase)
        IMPLEMENTED_CATEGORY_ETW_EVENTNAMEDATABASE()
    END_CATEGORY_MAP()

public:
    STDMETHOD(OnSessionConnect)(__in ISession* pSession)
    {
        return OnSessionConnect_Auto(pSession, &_Derived::_Etw_EventName_GetMap);
    }
};

#define BEGIN_ETW_EVENTNAME_MAP(_Class) \
    static const EventNameRegistryEntry* _Etw_EventName_GetMap(__out SIZE_T* pcSize) { \
        static const EventNameRegistryEntry _Map[] = {

#define ETW_EVENTNAME_GUID(_GUID, name) \
            { &_GUID, L##name, XPerfCore::EventNameRegistryEntry::EventGuid },

#define ETW_EVENTNAME_GUID_TYPE(_GUID, _TYPE, name) \
            { &_GUID, L##name, XPerfCore::EventNameRegistryEntry::Type, _TYPE },

#define ETW_EVENTNAME_GUID_TYPE_VERSION(_GUID, _TYPE, _VERSION, name) \
            { &_GUID, L##name, XPerfCore::EventNameRegistryEntry::TypeVersion, _TYPE, _VERSION },

#define ETW_EVENTNAME_GUID_AUTO(name) \
    ETW_EVENTNAME_GUID(name##Guid, #name)

#define END_ETW_EVENTNAME_MAP() }; \
        *pcSize = RTL_NUMBER_OF(_Map); \
        return _Map; \
    };


//-----------------------------------------------------------------------------

//
// Virtual resorting of STL collections
//

template <typename _Coll>
class sparse_adapter_on : public sparse_adapter<const typename _Coll::value_type>
{
    typedef sparse_adapter<const typename _Coll::value_type> _base;
public:
    typedef typename _base::value_type value_type;

    sparse_adapter_on(const _Coll& value)
        : m_rgp(new value_type*[value.size()])
    {
        std::transform(value.begin(), value.end(), m_rgp, ref_to_ptr);
        static_cast<_base&>(*this) = _base(m_rgp, value.size());
    }
    ~sparse_adapter_on()
    {
        delete[] m_rgp;
    }

    template <typename Traits>
    void sort(Traits _Comp)
    {
        std::sort(m_rgp, m_rgp + size(), _Comp);
    }

private:
    value_type**    m_rgp;

    static value_type* ref_to_ptr(const value_type& value)
    {
        return &value;
    }
};

//-----------------------------------------------------------------------------

//
// Helper function for creating strided adapters
//

template<typename InterfaceT, typename ImplementationT> 
strided_adapter<const InterfaceT> adapter_from_vector(__in const std::vector<ImplementationT> & Vector)
{
    if (Vector.size() == 0) {
        return strided_adapter<const InterfaceT>(NULL, sizeof(ImplementationT), 0);
    }
    return strided_adapter<const InterfaceT>(&*Vector.begin(), sizeof(ImplementationT), Vector.size());
}

//-----------------------------------------------------------------------------

//
// CRefCountedObjectRootBase
//
// Base class of reference counted objects. Defines reference count.
//
// [Adapted from atlcomcli.h: class CComObjectRootBase.]
//

class CRefCountedObjectRootBase
{
public:
    CRefCountedObjectRootBase()
    {
        m_dwRef = 0L;
    }

    long m_dwRef;
};

//
// CRefCountedObjectRootEx<T>
//
// Provides the standard AddRef/Release methods for reference counting
// protocol, though, as opposed to COM, methods are not required to 
// be virtual.
//
// [Adapted from atlcomcli.h: class CComObjectRootEx.]
//

template <class ThreadModel>
class ATL_NO_VTABLE CRefCountedObjectRootEx : public CRefCountedObjectRootBase
{
public:
    typedef ThreadModel _ThreadModel;
    typedef typename _ThreadModel::AutoCriticalSection _CritSec;
    typedef CComObjectLockT<_ThreadModel> ObjectLock;

    STDMETHODIMP_(ULONG) AddRef()
    {
        ATLASSERT(m_dwRef != -1L);
        return _ThreadModel::Increment(&m_dwRef);
    }
    STDMETHODIMP_(ULONG) Release()
    {
#ifdef _DEBUG
        LONG nRef = _ThreadModel::Decrement(&m_dwRef);
        if (nRef < -(LONG_MAX / 2))
        {
            ASSERT(0 && _T("Release called on a pointer that has already been released"));
        }
        return nRef;
#else
        return _ThreadModel::Decrement(&m_dwRef);
#endif
    }

    void Lock() {m_critsec.Lock();}
    void Unlock() {m_critsec.Unlock();}
private:
    _CritSec m_critsec;
};

//
// CRefCountedObjectRootEx<CComSingleThreadModel> 
//
// Specialization for single threading.
//
// [Adapted from atlcomcli.h: class CComObjectRootEx.]
//

template <>
class ATL_NO_VTABLE CRefCountedObjectRootEx<CComSingleThreadModel> : public CRefCountedObjectRootBase
{
public:
    typedef CComSingleThreadModel _ThreadModel;
    typedef _ThreadModel::AutoCriticalSection _CritSec;
    typedef CComObjectLockT<_ThreadModel> ObjectLock;

    STDMETHODIMP_(ULONG) AddRef()
    {
        ATLASSERT(m_dwRef != -1L);
        return _ThreadModel::Increment(&m_dwRef);
    }
    STDMETHODIMP_(ULONG) Release()
    {
#ifdef _DEBUG
        long nRef = _ThreadModel::Decrement(&m_dwRef);
        if (nRef < -(LONG_MAX / 2))
        {
            ASSERT(0 && _T("Release called on a pointer that has already been released"));
        }
        return nRef;
#else
        return _ThreadModel::Decrement(&m_dwRef);
#endif    
    }

    void Lock() {}
    void Unlock() {}
};

typedef CRefCountedObjectRootEx<CComObjectThreadModel> CRefCountedObjectRoot;


//
// _NoAddRefReleaseOnCRefCountedPtr <T>
//
// This class masks the reference counting protocol AddRef/Release 
// methods, to provide a logical view to the user without plumbing.
//
// [Adapted from atlcomcli.h: class _NoAddRefReleaseOnCComPtr.]
//

#pragma warning(push)
#pragma warning(disable: 4510) // 'XPerfCore::_NoAddRefReleaseOnCRefCountedPtr<T>' : default constructor could not be generated
#pragma warning(disable: 4610) // 'XPerfCore::_NoAddRefReleaseOnCRefCountedPtr<T>' can never be instantiated - user defined constructor required

template <class T>
class _NoAddRefReleaseOnCRefCountedPtr : public T
{
private:
    STDMETHODIMP_(ULONG) AddRef();
    STDMETHODIMP_(ULONG) Release();
};

#pragma warning(pop)


//
// CRefCountedPtr<T>
//
// Manages reference counted objects through the COM AddRef/Release 
// protocol, though, as opposed to COM, methods are not required to 
// be virtual.
//
// [Adapted from atlcomcli.h: class CComPtrBase.]
//

template <typename T>
class CRefCountedPtr
{
public:
    CRefCountedPtr(__in_opt T* lp = NULL) throw()
    {
        p = lp;
        if (p != NULL) 
        {
            p->AddRef();
        }
    }
    CRefCountedPtr(const CRefCountedPtr<T>& other) throw()
    {
        p = other.p;
        if (p != NULL) 
        {
            p->AddRef();
        }
    }
    ~CRefCountedPtr() throw()
    {
        if (p) 
        {
            p->Release();
        }
    }
    operator T*() const throw()
    {
        return p;
    }
    T& operator*() const throw()
    {
        ATLASSERT(p!=NULL);
        return *p;
    }
    //The assert on operator& usually indicates a bug.  If this is really
    //what is needed, however, take the address of the p member explicitly.
    T** operator&() throw()
    {
        ATLASSERT(p==NULL);
        return &p;
    }
    _NoAddRefReleaseOnCRefCountedPtr<T>* operator->() const throw()
    {
        ATLASSERT(p!=NULL);
        return reinterpret_cast<_NoAddRefReleaseOnCRefCountedPtr<T>*>(p);
    }
    bool operator!() const throw()
    {
        return (p == NULL);
    }
    bool operator<(T* pT) const throw()
    {
        return p < pT;
    }
    bool operator==(__in_opt T* pT) const throw()
    {
        return p == pT;
    }
    bool operator!=(__in_opt T* pT) const throw()
    {
        return p != pT;
    }

    // Release the interface and set to NULL
    void Release() throw()
    {
        T* pTemp = p;
        if (pTemp)
        {
            p = NULL;
            pTemp->Release();
        }
    }
    // Attach to an existing interface (does not AddRef)
    void Attach(__in_opt T* p2) throw()
    {
        if (p)
            p->Release();
        p = p2;
    }
    // Detach the interface (does not Release)
    T* Detach() throw()
    {
        T* pt = p;
        p = NULL;
        return pt;
    }
    _Check_return_ HRESULT CopyTo(__deref_out T** ppT) throw()
    {
        ATLASSERT(ppT != NULL);
        if (ppT == NULL)
            return E_POINTER;
        *ppT = p;
        if (p) 
        {
            p->AddRef();
        }
        return S_OK;
    }

    // [Adapted from atlcomcli.h: AtlComPtrAssign().]
    T* operator=(__in_opt T* pT)
    {
        if (pT != NULL)
        {
            pT->AddRef();
        }
        if (p) 
        {
            p->Release();
        }
        p = pT;
        return pT;
    }

    T* operator=(__in const CRefCountedPtr<T>& other)
    {
        return this->operator =(static_cast<T*>(other));
    }

    T* p;
};

//-----------------------------------------------------------------------------

//
// String Parser to C++ LPWSTR
//
class CWStrParser : public CAutoVectorPtr<WCHAR>
{

public:
    CWStrParser(
        __in LPCWSTR wszSrc
        )
    {
        // Calculate string length
        size_t cbSrcLen = wcslen(wszSrc) * sizeof(WCHAR);

        _AllocCopy(wszSrc, cbSrcLen);
    }

    CWStrParser(
        __in LPCSTR szSrc
        )
    {
        // Calculate string length
        size_t cbSrcLen = strlen(szSrc) * sizeof(CHAR);

        _AllocCopy(szSrc, cbSrcLen);
    }

    CWStrParser(
        __in_bcount(cbMax) LPCWSTR wszSrc, 
        __in  SIZE_T cbMax, 
        __in  bool fReqNullTerminator = true, 
        __out_opt LPCWSTR* pwszSrcEnd = NULL
        )
    {
        if (fReqNullTerminator && cbMax < sizeof(WCHAR)) {
            // Invalid data
            AtlThrow(XPERF_EVSINK_S_INVALID_DATA);
        }

        size_t cbSrcLen;
        bool fSrcNullTerminated = true;

        if (cbMax > 0)
        {
            HRESULT hr = StringCbLengthW(wszSrc, cbMax, &cbSrcLen);
            if (FAILED(hr)) {
                if (!fReqNullTerminator && (hr == STRSAFE_E_INVALID_PARAMETER)) {
                    // string does not have NULL terminator; it will be implicitly bound by the buffer end
                    cbSrcLen = cbMax - (cbMax % sizeof(WCHAR));
                    fSrcNullTerminated = false;
                } else {
                    // Any other error is caused by invalid data
                    AtlThrow(XPERF_EVSINK_S_INVALID_DATA);
                }
            }
        }
        else
        {
            // Create an empty (NULL-terminated) string
            cbSrcLen = 0;
            fSrcNullTerminated = false;
        }

        _AllocCopy(wszSrc, cbSrcLen, pwszSrcEnd, fSrcNullTerminated);
    }

    CWStrParser(
        __in_bcount(cbMax) LPCSTR szSrc, 
        __in  SIZE_T cbMax, 
        __in  bool fReqNullTerminator = true, 
        __out_opt LPCSTR* pszSrcEnd = NULL)
    {
        if (fReqNullTerminator && cbMax < sizeof(CHAR)) {
            // Invalid data
            AtlThrow(XPERF_EVSINK_S_INVALID_DATA);
        }

        size_t cbSrcLen;
        bool fSrcNullTerminated = true;

        if (cbMax > 0)
        {
            HRESULT hr = StringCbLengthA(szSrc, cbMax, &cbSrcLen);
            if (FAILED(hr)) {
                if (!fReqNullTerminator && (hr == STRSAFE_E_INVALID_PARAMETER)) {
                    // string does not have NULL terminator; it will be implicitly bound by the buffer end
                    cbSrcLen = cbMax;
                    fSrcNullTerminated = false;
                } else {
                    // Any other error is caused by invalid data
                    AtlThrow(XPERF_EVSINK_S_INVALID_DATA);
                }
            }
        }
        else
        {
            // Create an empty (NULL-terminated) string
            cbSrcLen = 0;
            fSrcNullTerminated = false;
        }

        _AllocCopy(szSrc, cbSrcLen, pszSrcEnd, fSrcNullTerminated);
    }

private:
    void _AllocCopy(
        __in_bcount(cbSrcLen) LPCWSTR wszSrc, 
        __in  SIZE_T cbSrcLen, 
        __out_opt LPCWSTR* pwszSrcEnd = NULL, 
        __in  bool fSrcNullTerminated = true
        )
    {
        ASSERT(wszSrc);
        ASSERT((cbSrcLen % sizeof(WCHAR)) == 0);

        // Account for zero terminator
        size_t cbDest = cbSrcLen + sizeof(WCHAR);

        if (cbSrcLen > cbDest) {
            AtlThrow(E_OUTOFMEMORY);
        }

        if (!Allocate(cbDest / sizeof(WCHAR))) {
            AtlThrow(E_OUTOFMEMORY);
        }

        HRESULT hr = StringCbCopyNW(m_p, cbDest, wszSrc, cbSrcLen);
        if (FAILED(hr)) {
            ASSERT(hr != STRSAFE_E_INVALID_PARAMETER);
            ASSERT(hr != STRSAFE_E_INSUFFICIENT_BUFFER);

            // No error is expected, forward
            AtlThrow(hr);
        }

        if (pwszSrcEnd) {
            *pwszSrcEnd = (LPCWSTR)((PBYTE)wszSrc + cbSrcLen + (fSrcNullTerminated ? sizeof(WCHAR) : 0));
        }
    }

    void _AllocCopy(
        __in_bcount(cbSrcLen) LPCSTR szSrc, 
        __in  SIZE_T cbSrcLen, 
        __out_opt LPCSTR* pszSrcEnd = NULL, 
        __in  bool fSrcNullTerminated = true
        )
    {
        ASSERT(szSrc);

        // Allocate as many wide characters as ASCII characters in the original string

        // Account for zero terminator
        size_t cchDest = cbSrcLen + 1;

        if (cbSrcLen >= cchDest) {
            AtlThrow(E_OUTOFMEMORY);
        }

        if (!Allocate(cchDest)) {
            AtlThrow(E_OUTOFMEMORY);
        }
        
        if (cbSrcLen > 0) {
            ASSERT (cbSrcLen < INT_MAX);    // grace to ETW buffersize limitations 
            ASSERT (cchDest < INT_MAX);     // grace to ETW buffersize limitations 

            // Convert
            SIZE_T cch = MultiByteToWideChar(CP_ACP, 0, szSrc, static_cast<int>(cbSrcLen), m_p, static_cast<int>(cbSrcLen)); // do not add NULL teminator
            ASSERT (cch <= cbSrcLen);

            if (cch == 0) {
                if (GetLastError() == ERROR_NO_UNICODE_TRANSLATION) {
                    AtlThrow(XPERF_EVSINK_S_INVALID_DATA);
                } else {
                    // Any other error is unexpected, forward
                    AtlThrow(XPERF_EVSINK_S_INVALID_DATA);
                }
            }

            // Add NULL terminator
            m_p[cch] = UNICODE_NULL;
        } else {
            // cbSrcLen == 0
            m_p[0] = UNICODE_NULL;
        }

        if (pszSrcEnd) {
            *pszSrcEnd = (LPCSTR)((PBYTE)szSrc + cbSrcLen + (fSrcNullTerminated ? sizeof(CHAR) : 0));
        }
    }

    // block copy construction and assignment
    CWStrParser(const CWStrParser&);
    CWStrParser& operator=(const CWStrParser&);
};

//
// Case sensitive wide character string comparison function object
//

struct lessLPCWSTR
{
    typedef LPCWSTR first_argument_type;
    typedef LPCWSTR second_argument_type;
    typedef bool result_type;

    bool operator() (__in LPCWSTR left, __in LPCWSTR right) const
    {
        return wcscmp(left, right) < 0;
    }
};

struct lessLPCWSTR_ci
{
    typedef LPCWSTR first_argument_type;
    typedef LPCWSTR second_argument_type;
    typedef bool result_type;

    bool operator() (__in LPCWSTR left, __in LPCWSTR right) const
    {
        return _wcsicmp(left, right) < 0;
    }
};

//-----------------------------------------------------------------------------

inline 
void 
ConvertEventRecordToEventTrace(
    __out EVENT_TRACE* pEventTrace, 
    __in  const EVENT_RECORD* pEventRecord
    )
{
    pEventTrace->Header.Size          = pEventRecord->EventHeader.Size;
    pEventTrace->Header.Guid          = pEventRecord->EventHeader.ProviderId;
    pEventTrace->Header.TimeStamp     = pEventRecord->EventHeader.TimeStamp;
    pEventTrace->Header.Class.Type    = pEventRecord->EventHeader.EventDescriptor.Opcode;
    pEventTrace->Header.Class.Version = pEventRecord->EventHeader.EventDescriptor.Version;
    pEventTrace->Header.Class.Level   = pEventRecord->EventHeader.EventDescriptor.Level;
    pEventTrace->Header.ThreadId      = pEventRecord->EventHeader.ThreadId;
    pEventTrace->Header.ProcessId     = pEventRecord->EventHeader.ProcessId;
    pEventTrace->Header.KernelTime    = pEventRecord->EventHeader.KernelTime;
    pEventTrace->Header.UserTime      = pEventRecord->EventHeader.UserTime;
    pEventTrace->MofData              = pEventRecord->UserData;
    pEventTrace->MofLength            = pEventRecord->UserDataLength;
    pEventTrace->BufferContext        = pEventRecord->BufferContext;
}

#define XPerfCore_EtwPortingPrefix_EventRecordToEventTrace(pEventRecord, pEventTrace) \
    if ((pEventRecord->EventHeader.Flags & EVENT_HEADER_FLAG_CLASSIC_HEADER) == 0) { \
        return XPERF_EVSINK_S_UNHANDLED_EVENT; \
    } \
    EVENT_TRACE _XPerfCore_EtwPortingPrefix_EventTrace_ ## pEventTrace = {0}; \
    ConvertEventRecordToEventTrace(&_XPerfCore_EtwPortingPrefix_EventTrace_ ## pEventTrace, pEventRecord); \
    const EVENT_TRACE* pEventTrace = &_XPerfCore_EtwPortingPrefix_EventTrace_ ## pEventTrace; \


//-----------------------------------------------------------------------------

//
// Filter Object support
//

template <typename _Derived, typename TValue, typename TResult = bool>
class CFilterObjectImpl
{
public:
    typedef TValue CValue;
    typedef TResult CResult;

    static CResult WINAPI Callback(const CValue& value, PVOID pvContext)
    {
        ASSERT(pvContext);
        return (*reinterpret_cast<_Derived*>(pvContext))(value);
    }
    static PVOID Context(_Derived* pDerived)
    {
        return reinterpret_cast<PVOID>(pDerived);
    }
};

#define XPERFCORE_FILTER_OBJECT(OBJ) (OBJ).Callback, (OBJ).Context(&(OBJ))


} // namespace XPerfCore

//-----------------------------------------------------------------------------

namespace XPerfCore
{

//
// CBitSetAdapter
//

class CBitSetAdapter
{     
public:

    CBitSetAdapter(__in_bcount_opt((cBits + 7) / 8) LPCVOID pvBits, __in ULONG cBits)
        : m_pbBits(reinterpret_cast<const CCell*>(pvBits))
        , m_cBits(cBits)
    {     
    }      

    bool operator[](ULONG iBit) const
    {
        if (m_pbBits == NULL)
        {
            return true;
        }       

        if (iBit >= m_cBits)
        {
            return false;
        }       

        ULONG const iCell = iBit / s_cBitsPerCell;
        DWORD const dwCellMask = 1 << (iBit % s_cBitsPerCell);

        return (m_pbBits[iCell] & dwCellMask) ? true : false;
    }

    LPCVOID GetBitArray() const
    {
        return m_pbBits;
    }

    ULONG GetMaxBitCount() const
    {
        return m_pbBits ? m_cBits : ULONG_MAX;
    }

protected:

    typedef ULONG CCell;
    static const ULONG s_cBitsPerByte = 8;
    static const ULONG s_cBitsPerCell = sizeof(CCell) * s_cBitsPerByte;

    __field_bcount((m_cBits + 7) / 8) CCell const* const m_pbBits;
    ULONG const m_cBits;
};


//
// CBitSet<nBits>
//
// nBits = g_cSupportedProcessors by default because that is the maximum 
//         number of processors supported by tools.
//

template <ULONG nBits = g_cSupportedProcessors>
class CBitSet : public CBitSetAdapter
{  
public:        

    CBitSet() 
        : CBitSetAdapter(m_rgCells, s_nBits)
    {
        Clear();
    }      
    
    void Clear()
    {
        ZeroMemory(m_rgCells, sizeof(m_rgCells));
    }

    void SetBit(ULONG iBit, bool fValue = true)
    {       
        ASSERT(m_pbBits);

        if (iBit >= nBits)
        {
            ASSERT(iBit < nBits);
            return;
        }

        ULONG const iCell = iBit / s_cBitsPerCell;
        DWORD const dwCellMask = 1 << (iBit % s_cBitsPerCell);

        if (fValue)
        {
            m_rgCells[iCell] |= dwCellMask;
        }
        else
        {
            m_rgCells[iCell] &= ~dwCellMask;
        }
    }

private:

    static const ULONG s_nBits = nBits;
    CCell m_rgCells[s_nBits/s_cBitsPerCell];
};

} // namespace XPerfCore

//-----------------------------------------------------------------------------

namespace XPerfCore
{

//
// Adjustors for arrays of pointers
//

/*

class CxxxInfoSource
{
    STDMETHOD(QD)(__out_ecount_part_opt(count, count) I** rgpI, __inout SIZE_T& count)
    {
        HRESULT hr = ...::QD(AdjustArrayTo<C>(rgpI), count);
        if (SUCCEEDED(hr)) {
            AdjustPtrArrayFrom<C>(rgpI, count);
        }
        return hr;
    }
};

*/

template <typename C, typename I>
_Ret_writes_maybenull_(count) C** AdjustArrayTo(__in_ecount_opt(count) I** rgpI, __in  SIZE_T count)
{
    UNREFERENCED_PARAMETER(count);

    return reinterpret_cast<C**>(rgpI);
}
 
template <typename C, typename I>
_Ret_writes_(count) C** AdjustNonNullArrayTo(__in_ecount(count) I** rgpI, __in  SIZE_T count)
{
    UNREFERENCED_PARAMETER(count);

    return reinterpret_cast<C**>(rgpI);
}
 
template <typename C, typename I>
void AdjustPtrArrayFrom(__inout_ecount_opt(count) I** rgpI, __in  SIZE_T count)
{
    if (static_cast<I*>(reinterpret_cast<C*>(NULL)) && rgpI) {
        // Adjust array of pointers
        for (SIZE_T i = 0; i < count; ++i) {
            rgpI[i] = static_cast<I*>(reinterpret_cast<C*>(rgpI[i]));
        }
    }
}

//
// Adjustors for arrays of strided adapters
//

/*

class CxxxInfoSource
{
    STDMETHOD(QSD)(__out_ecount_part_opt(count, count) strided_adapter<I>* rgsaI, __inout SIZE_T& count)
    {
        HRESULT hr = ...::QSD(AdjustArrayTo<C>(rgsaI), count);
        if (SUCCEEDED(hr)) {
            AdjustStridedAdapterArrayFrom<C>(rgsaI, count);
        }
        return hr;
    }
};

*/

template <typename C, typename I>
_Ret_writes_maybenull_(count) XPerfCore::strided_adapter<C>* AdjustArrayTo(__in_ecount_opt(count) XPerfCore::strided_adapter<I>* rgsaI, __in  SIZE_T count)
{
    UNREFERENCED_PARAMETER(count);

    return reinterpret_cast<XPerfCore::strided_adapter<C>*>(rgsaI);
}
 
template <typename C, typename I>
_Ret_writes_(count) XPerfCore::strided_adapter<C>* AdjustNonNullArrayTo(__in_ecount(count) XPerfCore::strided_adapter<I>* rgsaI, __in  SIZE_T count)
{
    UNREFERENCED_PARAMETER(count);

    return reinterpret_cast<XPerfCore::strided_adapter<C>*>(rgsaI);
}
 
template <typename C, typename I>
void AdjustStridedAdapterArrayFrom(__inout_ecount_opt(count) XPerfCore::strided_adapter<I>* rgsaI, __in  SIZE_T count)
{
    if (static_cast<I*>(reinterpret_cast<C*>(NULL)) && rgsaI) {
        // Adjust array of strided adapters
        for (SIZE_T i = 0; i < count; ++i) {
            rgsaI[i] = XPerfCore::strided_adapter<I>(static_cast<I*>(reinterpret_cast<C*>(rgsaI[i].head())), rgsaI[i].stride(), rgsaI[i].size());
        }
    }
}

} // namespace XPerfCore
