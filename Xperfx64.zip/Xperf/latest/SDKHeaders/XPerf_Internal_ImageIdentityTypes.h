/*++

Copyright (c) 2013 Microsoft Corporation

Module Name:
    ImageIdentityTypes.h

Author:

    Kyle Sabo (kysabo)

Revision History:

--*/

#pragma once

#include <wtypes.h>

struct ImageWeakKey
{
    ImageWeakKey()
        : TimeDateStamp(0)
        , ImageSize(0)
    {
    }

    DWORD TimeDateStamp;
    DWORD ImageSize;
};

struct RsdsKey
{
	RsdsKey()
		: Rsds()
		, Age(0)
	{
	}
	
	GUID Rsds;
	DWORD Age;
};


//
// CV Data
//

enum {
    NB_PATH_SIZE = 260,    // max. length of full pathname (_MAX_PATH)
};

enum {
    CV_SIGNATURE_RSDS = (DWORD)'SDSR',
    CV_SIGNATURE_NB10 = (DWORD)'01BN',
    CV_SIGNATURE__ILRSDS = 3,
    CV_SIGNATURE__DBG = 2,
    CV_SIGNATURE__BIN = 1,
    CV_SIGNATURE_NONE = 0,
};

typedef struct _RSDS {             // RSDS debug info
    DWORD   dwSig;                 // "RSDS"
    GUID    guidSig;
    DWORD   age;
    CHAR    szPdb[NB_PATH_SIZE * 3];
} RSDS;

enum {
    RSDS_cbHeader = RTL_SIZEOF_THROUGH_FIELD(RSDS, age),
    RSDS_cbMaxPdb = RTL_FIELD_SIZE(RSDS, szPdb),
};

typedef struct _NB10 {             // NB10 debug info
    DWORD   dwSig;                 // "NB10"
    DWORD   dwOffset;              // offset, always 0
    ULONG   sig;
    ULONG   age;
    CHAR    szPdb[NB_PATH_SIZE];
} NB10;

enum {
    NB10_cbHeader = RTL_SIZEOF_THROUGH_FIELD(NB10, age),
    NB10_cbMaxPdb = RTL_FIELD_SIZE(NB10, szPdb),
};

typedef struct _NOCV {             // 'NOCV' debug info
    DWORD   dwSig;                 // _DBG, _BIN
    DWORD   dwChecksum;
    DWORD   dwTimeDateStamp;
    DWORD   dwImageSize;
    WCHAR   wszOriginalFileName[NB_PATH_SIZE * 3];
} NOCV;

enum {
    NOCV_cbHeader = RTL_SIZEOF_THROUGH_FIELD(NOCV, dwImageSize),
    NOCV_cbMaxOriginalFileName = RTL_FIELD_SIZE(NOCV, wszOriginalFileName),
};

typedef union _CVDD {
    DWORD   dwSig;
    RSDS    rsds;
    NB10    nb10;
    NOCV    nocv;
} CVDD;