/*++

Copyright (c) 2003 Microsoft Corporation

Module Name:

    XPerfInfo.hpp

Abstract:

    XPerfCore Command Line Extensibility

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>
#include <math.h>   // HUGE_VAL, used in actions

namespace XPerfAddIn
{
    struct ITraceStatsInfoSource;
}

namespace XPerfCore 
{

MIDL_INTERFACE("9225F1BD-1468-47C3-915B-6460F84EC9FB") 
IHostConfig : public IUnknown
{
    enum Target
    {
        Target_Human,
        Target_Machine,
    };

    STDMETHOD_(Target, GetTarget)() PURE; 
};

//
// Success Codes for EventDumpers (besides S_OK)
//

#define XPERF_EVDUMP_S_UNHANDLED_EVENT      MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x100)
#define XPERF_EVDUMP_S_UNKNOWN_VERSION      MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x101)
#define XPERF_EVDUMP_S_UNKNOWN_LEVEL        MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x102)
#define XPERF_EVDUMP_S_INVALID_DATA         MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_ITF, 0x103)


//
// Event Dumpers
//

MIDL_INTERFACE("45F32B23-041D-453C-AC29-EE6A3AF1A339") 
IEventDumper : public IUnknown
{
public:
    STDMETHOD(DumpHeaders)(
        __in  IOutputStream& out,
        __in  XPerfAddIn::ITraceStatsInfoSource* pTraceStats ) PURE;

    STDMETHOD(DumpEvent)(
        __in  IOutputStream& out,
        __in  const ICursor& cursor, 
        __in  REFGUID ProviderId, 
        __in  const EVENT_RECORD *pEventRecord ) PURE;
};

struct EventDumperRegistryEntry
{
    const GUID* pProviderId;
};

MIDL_INTERFACE("2AEBB4E8-30C6-4F0E-BBF6-7067E6C54CDC") 
IEventDumperRegistry : public IUnknown
{
public:
    STDMETHOD(Register)( 
        __in  LPUNKNOWN pEventDumperUnk,
        __in  SIZE_T cbEntrySize, 
        __in  SIZE_T cEntries,
        __in_xcount(cbEntrySize*cEntries) const EventDumperRegistryEntry *rgEntries ) PURE;
};


//
// Event Presentation
//

MIDL_INTERFACE("A47273EA-2743-4C9D-8A5A-3C4178BA8EAF")
IEventPresenter : public IUnknown
{
    //
    // Output Data Protocol
    //
    // <field0>\0<space><field1>\0<space><field2>...\0\0
    //

    STDMETHOD(DumpHeader)(
        __inout IOutputStream& out,
        __in  REFGUID ProviderId,
        __in  EVENT_DESCRIPTOR const& EventDescriptor,
        __in  IHostConfig::Target target
        ) PURE;

    STDMETHOD(DumpEvent)(
        __inout IOutputStream& out,
        __in  TimeStamp const& time,
        __in  EVENT_RECORD const* pEventRecord,
        __in  IHostConfig::Target target
        ) PURE;
};


//
// Session Services
//

MIDL_INTERFACE("AA8D7AAC-C698-4094-A33A-418EF86D0868")
ITraceDumper : public IUnknown
{
    STDMETHOD(put_TraceDumpFilename)(
        __in  LPCWSTR wszTraceDumpFilename ) PURE;

    STDMETHOD(put_Range)(
        __in  TimeStamp StartTime, 
        __in  TimeStamp EndTime) PURE;
    
};

MIDL_INTERFACE("65167ED1-9CE8-4B16-897D-F75B5C359FF2")
ITraceDumper2 : public ITraceDumper
{
    STDMETHOD(put_ProvidersFilteredIn)(
        __in  ULONG cProviderIds,   
        __in_ecount(cProviderIds) const GUID rgProviderIds[] ) PURE;
};

MIDL_INTERFACE("91999B2E-D4C3-4B96-8973-C1BA1D0462BF")
ITraceDumperConfig : public IUnknown
{
    enum TraceDumperFlags
    {
        StackTimeShifting = 1,
        AddRawData        = 2,
        AddPgoData        = 4,
        AddInline         = 8,
    };

    STDMETHOD(put_Flags)(
        __in  DWORD dwFlags
        ) PURE;
};

MIDL_INTERFACE("B24A8817-3093-4F88-833D-D694E4CC7355")
ITraceDumperConfig2 : public ITraceDumperConfig
{
    STDMETHOD_(DWORD, get_Flags)(
        ) const PURE;
};
    

MIDL_INTERFACE("D67CFCEA-A0D0-43C6-82AA-89261CBD532D")
IXmlEventDumper : public IUnknown
{
    STDMETHOD(LoadManifest)(
        __in  LPCWSTR wszManifestFilename) PURE;
};


MIDL_INTERFACE("C19E2879-F661-4B84-B205-4BEDF3D86BE8")
ICmdLine : public IUnknown
{
    /*++

    Description:

        XPerfCore actions will be passed an ICmdLine interface before the trace
        file is processed. Actions should call GetOpts to retrieve command line
        options.  On input, Opts and NumOpts defines the name and number of
        arguments that each option expects.  GetOpt will try to match
        user-suplied options with one of the expected options, and returns:

        1)  an index into the Opts array that corresponds to the matched option
            if a match is found, and the number of parameters of the option is
            within the specified range.
        2)  NumOpts if either the user-suplied options is unexpected, in which
            case *Argc is also set to zero, or the number of parameters is out
            of the specified range
        3)  END if all options have been processed.

        The option itself and any arguments to the option are returned in the
        arguments Argc and Argv.

    Arguments:

        Opts:   An array of struct Option that defines expected options.
                See below for detail.

        NumOpts: Number of elements in array Opts.

        Argc:   On return, receives the number of arguments of the option.
                It is set to 0 if the option is unexpected.

        Argv:   On return, receives a pointer to an array of const IArgument*.
                The Length of the array is Argc.  This is similar to argc and
                argv arguments of the main().

                Argument value can be retrieved through the methods of
                IArgument, which return error if the user-suplied string can
                not be parsed to the specified value type.  Optionally if a
                range is supplied via the Min and Max values, the parsed values
                are further validated against the range.  If GetOpt returns
                error, it also print error messages properly.

        Flags:  See comments in enum OptionFlag for difinition.

    Returned Value:

        If one of the options defined in Opts presents, returns the
        index into Opts that corresponds to the option.

        If an unexpected option presents, returns NumOpts.

        If no more options, returns END.

    --*/

    enum OptionFlag
    {
        OPT_CASE_SENSITIVE  = 0x1,   // option name is case sensitive
        OPT_UNKNOWN_OK      = 0x2,   // don't print error message on unknown options
        OPT_NO_VALIDATION   = 0x4
    };

    enum ReturnedError
    {
        END = -1,       // options have been exhausted
        INVALID = -2    // option has wrong number of args
    };

    struct Option
    {
        WCHAR      *Name;       // name of the option
        SIZE_T      MinCount;   // minimum and maximum number of arguments
        SIZE_T      MaxCount;   // expected by this option
    };

    MIDL_INTERFACE("3608A32C-FCF5-4872-9E61-B7AC1F99300B")
    IArgument : public IUnknown
    {
        STDMETHOD (GetLong) (
            __out LONG &Value,
            __in  LONG Min = LONG_MIN,
            __in  LONG Max = LONG_MAX
            ) const = 0;
        STDMETHOD (GetUlong) (
            __out ULONG &Value,
            __in  ULONG Min = 0,
            __in  ULONG Max = ULONG_MAX
            ) const = 0;
        STDMETHOD (GetLong64) (
            __out LONG64 &Value,
            __in  LONG64 Min = _I64_MIN,
            __in  LONG64 Max = _I64_MAX
            ) const = 0;
        STDMETHOD (GetUlong64) (
            __out ULONG64 &Value,
            __in  ULONG64 Min = 0ui64,
            __in  ULONG64 Max = _UI64_MAX
            ) const = 0;
        STDMETHOD (GetDouble) (
            __out DOUBLE &Value,
            __in  DOUBLE Min = -HUGE_VAL,
            __in  DOUBLE Max = HUGE_VAL
            ) const = 0;
        STDMETHOD (GetTimeStamp) (
            __out TimeStamp &Value,
            __in  const TimeStamp &Min = TimeStamp::Min,
            __in  const TimeStamp &Max = TimeStamp::Max
            ) const = 0;
        STDMETHOD (GetTimeStampDelta) (
            __out TimeStampDelta &Value,
            __in  const TimeStampDelta &Min = TimeStampDelta::Zero,
            __in  const TimeStampDelta &Max = TimeStampDelta::Max
            ) const = 0;
        STDMETHOD_(BOOL, Compare) (
            __in  const WCHAR *String,
            __in  BOOL CaseSensitive = FALSE
            ) const = 0;
        STDMETHOD_(const WCHAR *const, GetString) () const = 0;
    };

    STDMETHOD_(SSIZE_T, GetOpt) (
        __in  const Option Opts[],
        __in  SIZE_T  NumOpts,
        __out SIZE_T *Argc,
        __deref_out_ecount(*Argc) const IArgument *const **Argv,
        __in  ULONG_PTR Flags = 0
    ) = 0;
};

//
// Actions
//

MIDL_INTERFACE("58023428-7349-4efa-9f0e-524a538739d5") 
IAction : public IUnknown
{
    /*++

    Descriptions:

        Called before session is available. Action implementation uses this
        chance to parse options.

    Arguments:

        pCmdLine    The command line options. Action implementation calls
                    the GetOpts() method to parse and validate the options.

    Return value:

        S_OK        Options are fine. Action can be executed after
                    ConnectToSession() call.

        S_FALSE     Options are unexpected, illegal, or contain help.  Action
                    will not be executed, instead, a help message will be
                    printed out by the caller

        E_*         Un-recoverable error. Caller should error out asap.

    --*/
    STDMETHOD (Prepare) (
        __in  ICmdLine* pCmdLine
    ) = 0;

    // called after a session is available. Action implementation initializes.
    STDMETHOD (ConnectToSession) (
        __in  ISession* pSession
    ) = 0;

    // called to execute
    STDMETHOD (Execute) () = 0;
};

#ifdef _XPERFCORE_INTERNAL_BUILD

//
// Multi-Session Actions
//

MIDL_INTERFACE("6FFD92DF-D712-4BF1-9E3D-E15D834EE0EE") 
IMultiSessionAction : public IAction
{
    // Called before IAction::Prepare to inform the action about how many sessions it will connect to.
    STDMETHOD (PrepareForMultipleSessions) (
        __in  SIZE_T nSessions
    ) PURE;
};

#endif

} // namespace XPerfCore;

