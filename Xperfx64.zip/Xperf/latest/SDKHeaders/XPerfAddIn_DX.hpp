/*++

  Copyright (c) 2007 Microsoft Corporation

  Module Name:
  XPerfAddIn_dx.hpp

  Author:

  Daniel Speyer

  Revision History:

  Naming conventions:

    Key: any large value with no intrinsic meaning which maps to an object
    Id: a value counting from 1 or 0 that is unique in its enclosing space
    GlobalId: a value counting from 1 or 0 that is unique in the session, used as an array index where applicable
    FullId: a list of Ids that constitute a path to have the same effect as a GlobalId

  --*/

#pragma once

#include <XPerfCore.hpp>                // include XPerfCore main header

#include <XPerfAddIn_Core.hpp>          // AddIn_alloc references core infosources

struct StackTopInfo;

namespace XPerfAddIn
{
namespace DX
{


//
// Warnings are issued by all three infosources to indicate where the trace events are apparently inconsistent,
// such as the completion of a never-submitted DMA buffer.
// They do NOT indicate bad performance by the original media application.
//

struct Warning{
    TimeStamp Time;
    const WCHAR* Msg;
};
typedef strided_adapter<const Warning> StridedWarnings;

typedef ULONGLONG CAdapterKey;
typedef BYTE CAdapterId;
typedef BYTE CSegmentId;
typedef BYTE CSegmentGlobalId;

typedef ULONG64 GlobalAllocationHandle;
typedef ULONG64 LocalAllocationHandle;
typedef strided_adapter<const LocalAllocationHandle> StridedLocalHandles;

typedef DWORD ColorSpace;


MIDL_INTERFACE("cd839e6e-a5c0-4b87-bafa-1bcc0ce2ee39")
ISegmentInfoSource : public IUnknown
{
    struct Segment
    {
        ULONGLONG Size;

        enum 
        {
            Flag_Aperture                  = 1  ,
            Flag_Agp                       = 2  ,
            Flag_CpuVisible                = 4  ,
            Flag_UseBanking                = 8  ,
            Flag_CacheCoherent             = 16 ,
            Flag_PitchAlignment            = 32 ,
            Flag_PopulatedFromSystemMemory = 64 ,
        };
        DWORD Flags;

        CAdapterId AdapterId;
        CSegmentId Id;             // unique within adapter or aperture
        CSegmentGlobalId GlobalId; // unique within trace session -- index into QuerySegments
        BYTE Reserved;
    };
    typedef sparse_adapter<const Segment> SparseSegments;

    STDMETHOD(QuerySegments)(
        __out SparseSegments* Segments
        ) const PURE;

    STDMETHOD_(CAdapterId, QueryAdapterIdByAdapterKey)(
        __in CAdapterKey AdapterKey // As contained in raw events such as DXGKETW_CREATEALLOCATIONEVENT
        ) const PURE;

    STDMETHOD_(const Segment*, QuerySegmentByFullId)(
        __in CAdapterId AdapterId, 
        __in CSegmentId SegmentId
        ) const PURE;

    STDMETHOD(QueryWarnings)(
        __out StridedWarnings* Warnings
        ) const PURE;
};

MIDL_INTERFACE("63A9B303-3CE5-49b4-93F8-C3D03DF119B8")
ISegmentInfoSource2 : public ISegmentInfoSource
{
    struct AdapterInfo
    {
        CAdapterKey Key;
        TimeStamp CreationTime;

        AdapterInfo::AdapterInfo(CAdapterKey _Key, TimeStamp _CreationTime) :
            Key(_Key),
            CreationTime(_CreationTime)
        {
        }
        
        AdapterInfo::AdapterInfo() :
            Key(0),
            CreationTime(TimeStamp(0))
        {
        }
    };
    
    STDMETHOD_(AdapterInfo, QueryAdapterInfoById)(
        __in CAdapterId AdapterId
        ) const PURE;

    STDMETHOD_(UINT, QueryAdapterCount)(
        ) const PURE;
};

MIDL_INTERFACE("45180910-5AE0-46B1-BF47-26D92205C8B2")
IAllocationInfoSource : public IUnknown
{
    struct SegmentPlacement // this represents arrival in a segment
    {
        TimeStamp Time;
        TimeStamp EndTime;
        ULONGLONG NewOffset;
        const ISegmentInfoSource::Segment* NewSegment;
    };
    typedef strided_adapter<const SegmentPlacement> StridedSegmentPlacements;

    struct SegmentPreference 
    {
        const ISegmentInfoSource::Segment* Segment; // NULL means no preference

        enum ScanFrom 
        {
            ScanFrom_Low = 0,
            ScanFrom_High = 1
        } Direction;
    };
    typedef strided_adapter<const SegmentPreference> StridedSegmentPreferences;

    struct Allocation : public Temporal
    {
        GlobalAllocationHandle GlobalHandle;

        ULONGLONG Size;
        const IProcessInfoSource::ProcessData *Creator;

        StridedSegmentPreferences SegmentPreferences;
        StridedSegmentPlacements  Placements; // Pointers and iterators to inside this structure will be invalidated during the pass;
                                              // they should only be kept around after the pass is complete.
        ColorSpace Format;
        UINT Width;
        UINT Height;

        enum {
            Flag_CpuVisible             = 0x00000001,
            Flag_PermanentSysMem        = 0x00000002,
            Flag_Cached                 = 0x00000004,
            Flag_Protected              = 0x00000008,
            Flag_ExistingSysMem         = 0x00000010,
            Flag_ExistingKernelSysMem   = 0x00000020,
            Flag_FromEndOfSegment       = 0x00000040,
            Flag_Swizzled               = 0x00000080, 
            Flag_Overlay                = 0x00000100,
            Flag_Capture                = 0x00000200,
            Flag_UseAlternateVA         = 0x00000400,
            Flag_SynchronousPaging      = 0x00000800,
            Flag_LinkMirrored           = 0x00001000,
            Flag_LinkInstanced          = 0x00002000,
            Flag_PinnedBackingStore     = 0x08000000,
            Flag_PagingBuffer           = 0x10000000,  // Driver should never set these fields
            Flag_Shareable              = 0x20000000,
            Flag_Primary                = 0x40000000,
            Flag_ManagedPrimary         = 0x80000000
        };
        ULONG Flags;

        enum {
            UsageFlag_PrivateFormat = 1,
            UsageFlag_Swizzled      = 2, // Hopefully this and Flag_Swizzled mean the same thing, but they're reported seperately
            UsageFlag_MipMap        = 4,
            UsageFlag_Cube          = 8,
            UsageFlag_Volume        = 16,
            UsageFlag_Vertex        = 32,
            UsageFlag_Index         = 64
        };
        ULONG UsageFlags;
        const WCHAR *AdapterFriendlyName;

        CAdapterId AdapterId;

        BYTE Reserved[3];
        
        ULONGLONG SectionObject;
    };
    typedef strided_adapter<const Allocation> StridedAllocations;

    // Memory backing process private gpu memory allocations.
    struct ProcessAllocation : public Temporal 
    {
        union {
            ULONGLONG BaseAddress;
            ULONGLONG SectionObject;
        };
        ULONGLONG Size;
        const IProcessInfoSource::ProcessData* Process;
#pragma warning(push)
#pragma warning(disable:4201)  // nonstandard extension used : nameless struct/union
        union {
            struct {
                UCHAR Section : 1;
                UCHAR HeapBlock : 1;
                UCHAR Spare : 6;
            };
            UCHAR Flags;
        };
#pragma warning(pop)
    };
    typedef strided_adapter<const ProcessAllocation> StridedProcessAllocations;

    struct DeviceAllocation : public Temporal 
    {
        LocalAllocationHandle LocalHandle;
        ULONGLONG BaseAddress;
        const IProcessInfoSource::ProcessData* Process;
        Allocation *Allocation;
        ProcessAllocation *ProcessAllocation;

        ULONGLONG GetSectionObject() const
        {
            bool Shareable = (Allocation->Flags & Allocation::Flag_Shareable) == Allocation->Flag_Shareable;
            if (Shareable)
            {
                ASSERT(Allocation->SectionObject);
                return Allocation->SectionObject;
            }
            else if (ProcessAllocation && ProcessAllocation->Section)
            {
                ASSERT(ProcessAllocation->SectionObject);
                return ProcessAllocation->SectionObject;
            }
            else
            {
                return 0;
            }
        }
    };
    typedef strided_adapter<const DeviceAllocation> StridedDeviceAllocations;

    STDMETHOD(QueryAllocations)(
        __out StridedAllocations* Allocations
        ) const PURE;

    STDMETHOD(QueryDeviceAllocations)(
        __out StridedDeviceAllocations* Allocations
        ) const PURE;

    STDMETHOD_(const Allocation*, QueryAllocationByLocalHandle)(
        __in LocalAllocationHandle LocalHandle,
        __in ULONG ProccessId,
        __in TimeStamp Time = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(const Allocation*, QueryAllocationByGlobalHandle)(
        __in GlobalAllocationHandle GlobalHandle,
        __in TimeStamp Time = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(HRESULT, QueryUsage)(
        __out_ecount(nSegments*nIntervals) ULONGLONG * Usage, // data in each segment -- in bytes
        __in SIZE_T nSegments,
        __in SIZE_T nIntervals,
        __in TimeStamp StartTime,
        __in TimeStamp EndTime,
        __in TimeStampDelta Resolution
        ) const PURE;

    STDMETHOD_(bool, BigHandlesExist)(
        ) const PURE;

    STDMETHOD_(const SegmentPlacement*, Allocation_PlacementAt)(
        __in const Allocation *Self, 
        __in TimeStamp Time
        ) const PURE;

    STDMETHOD_(const ISegmentInfoSource::Segment*, Allocation_SegmentAt)(
        __in const Allocation *Self, 
        __in TimeStamp Time
        ) const PURE;

    STDMETHOD_(LONGLONG, Allocation_OffsetAt)(
        __in const Allocation *Self,
        __in TimeStamp Time
        ) const PURE;

    // Fills in FiveCharacterBuffer including a null-terminator, then returns it for convinience
    STDMETHOD_(WCHAR *, ColorSpace_ToString)(
        __in ColorSpace cs,
        __out_ecount(cchFiveCharacterBuffer) WCHAR *FiveCharacterBuffer, 
        __in SIZE_T cchFiveCharacterBuffer = 5
        ) const PURE;
    
    STDMETHOD(QueryWarnings)(
        __out StridedWarnings* out
        ) const PURE;

    STDMETHOD_(bool, IsDataAvailable)(
        ) const PURE;

    STDMETHOD(QueryProcessAllocations)(
        __out StridedProcessAllocations* Allocations
        ) const PURE;
};

MIDL_INTERFACE("D3F58F70-E24F-4BC8-A3CA-CE025613F90E")
IMemCounterInfoSource : public IUnknown
{
    enum EPurpose
    {
        Purpose_Application,
        Purpose_ApplicationRenamed,

        Purpose_DriverPadding,
        Purpose_DriverPacking,
        Purpose_DriverUnknown,
        Purpose_DriverDmaBuffer,
        Purpose_DriverStaging,
        Purpose_DriverContextSave,
        Purpose_DriverLevel9,
        Purpose_DriverDeferredFree,

        Purpose_VidmmDeferredFree,
        Purpose_VidmmDmaBuffer,

        Purpose_CddSharedPrimarySurface,
        Purpose_CddShadowSurface,
        Purpose_CddStagingSurface,
        Purpose_CddGdiSurface,

        //Debugging purposes, do not remove
        Purpose_MappingTotal = 1000,
        Purpose_DeviceAllocationTotal = 1001,
    };

    struct CounterD3DInfo
    {
        UINT32 Width;
        UINT32 Height;
        UINT32 Depth;
        UINT32 Format;
        UINT32 MipLevels;
        UINT32 UsageFlags;
        const WCHAR *Name;
        ULONGLONG D3DHandle;
    };

    struct CounterVidMmInfo
    {
        ULONGLONG GlobalAllocHandle;
        ULONG AllocationFlags;
    };

    struct StackTopInfo
    {
        ULONGLONG TimeNSec;
        ULONG ThreadId;
    };

    struct CounterStackInfo
    {
        //Resoure Create
        StackTopInfo ResourceCreate;
        StackTopInfo ResourceDestroy;
        StackTopInfo VidMmCreate;
        StackTopInfo VidMmDestroy;
        StackTopInfo MapCreate;
        StackTopInfo MapDestroy;
    };

    struct Counter : public Temporal
    {
        ULONGLONG AllocSize;
        const WCHAR *ProcessName;
        ULONG ProcessId;
        EPurpose Purpose;

        CounterD3DInfo D3DInfo;
        CounterVidMmInfo VidMmInfo;
        CounterStackInfo StackInfo;
    };
    typedef strided_adapter<const Counter> StridedCounters;

    STDMETHOD(QueryCounters)(
        __out StridedCounters* Allocs
        ) const PURE;

    STDMETHOD_(bool, IsDataAvailable)(
        ) const PURE;
};

MIDL_INTERFACE("0D8BFFCA-3736-4266-B6C2-AF652E9A5B81")
IReferencedMemoryInfoSource : public IUnknown
{
    enum EReferenceCounterType
    {
        ReferenceCounterType_Integral,
        ReferenceCounterType_Differential,
    };

    struct ReferenceCounter : public Temporal
    {
        EReferenceCounterType Type;
        ULONGLONG VidMmGlobalAlloc;
        ULONGLONG Size;
        ULONG ProcessId;
    };

    typedef strided_adapter<const ReferenceCounter> StridedCounters;

    STDMETHOD(QueryReferencedCountersFrame)(
        __out StridedCounters* Allocs
        ) const PURE;

    STDMETHOD(QueryReferencedCountersSecond)(
        __out StridedCounters* Allocs
        ) const PURE;

    STDMETHOD(QueryReferencedCountersAll)(
        __out StridedCounters* Allocs
        ) const PURE;

    STDMETHOD_(bool, IsDataAvailable)(
        ) const PURE;
};

MIDL_INTERFACE("081f55c6-0447-42ed-ab2e-5371d70b0689")
IDMABufferInfoSource : public IUnknown
{
    typedef enum 
    {
        DmaBufferType_Render,
        DmaBufferType_BLT,
        DmaBufferType_MemoryTransfer,
        DmaBufferType_FLIP,
        DmaBufferType_RenderKM,
        DmaBufferType_Unknown,
    } DmaBufferType;

#pragma warning(push)
#pragma warning(disable:4201)  // nonstandard extension used : nameless struct/union
    union FullEngineId
    {
        struct
        {
            BYTE EngineId;
            BYTE NodeId;
            BYTE AdapterId;
            BYTE Reserved;
        };
        DWORD AsDWORD;
    };
#pragma warning(pop)
    typedef strided_adapter<const FullEngineId> StridedEngines;

    typedef sparse_adapter<const IAllocationInfoSource::Allocation> SparseAllocations;

    struct DMABuffer
    {
        TimeStamp Initialized;
        TimeStamp SubmittedToHW;
        TimeStamp StartExecution;
        TimeStamp Finished;

        ULONGLONG FenceID;
        ULONGLONG PDMA; // Physical address of the buffer at submittal time

        const IProcessInfoSource::ThreadData *Scheduler; // This is NULL for MemoryTransfers and occasionally other things

        DmaBufferType Type;
        FullEngineId Engine; 

        // The local handle arrays are in the same order as the Allocation* arrays
        SparseAllocations Reads;
        SparseAllocations Writes;
        StridedLocalHandles ReadHandles;
        StridedLocalHandles WriteHandles;

        // This element is only meaningful for MemoryTransfer events.
        // It gives the times at which allocations to transfer were added to the DMA buffer
        strided_adapter<const TimeStamp> TransferTimes;

        bool Preempted;
    };
    typedef strided_adapter<const DMABuffer> StridedDMABuffers;

    struct LockUnLock : public Temporal
    {
        const IAllocationInfoSource::Allocation* Allocation;
        const IProcessInfoSource::ThreadData*    Thread;
    };
    typedef strided_adapter<const LockUnLock> StridedLockUnLocks;

    struct Flip
    {
        TimeStamp Scheduled;
        TimeStamp Ready;
        TimeStamp Target;
        TimeStamp Consummated;
        const IAllocationInfoSource::Allocation* Allocation;
        const IProcessInfoSource::ThreadData *Thread;
        BYTE AdapterId;
        BYTE MonitorId;
        BYTE MMIOFlip;
        BYTE Reserved[5];
    };
    typedef strided_adapter<const Flip> StridedFlips;

    struct VSync
    {
        TimeStamp Time;
        BYTE AdapterId;
        BYTE MonitorId;
        BYTE Reserved[6];
    };
    typedef strided_adapter<const VSync> StridedVSyncs;

    STDMETHOD_(LPCWSTR, DmaBufferTypeName)(
        __in DmaBufferType Type
        ) const PURE;
    STDMETHOD_(int, DmaBufferType__Count)() const PURE;

    // These three query functions return the smallest interval containing everything that overlaps the time interval specified
    // It will probably contain items which are only partially in the interval (such as DMA buffers initialized in the interval
    // but submitted to hardware later) and it may contain items which are not in the interval at all.
    // We guarantee only completeness (everything you want will be there) and efficiency (logarithmic time).
    // For exactly what you want, filter the data while you loop through it.  You'll probably need to anyway.
    STDMETHOD(QueryDMABuffers)(
        __out StridedDMABuffers* Out,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
       ) const PURE;
    STDMETHOD(QueryLockUnLocks)(
        __out StridedLockUnLocks* Out,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
        ) const PURE;
    STDMETHOD(QueryFlips)(
        __out StridedFlips* Out,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryVSyncs)(
        __out StridedVSyncs* Out,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryEngines)(
        __out StridedEngines* out
        ) const PURE;

    STDMETHOD(QueryUsage)(
        __out_ecount(nEngines*nIntervals) double* Usage, // between 0 and 1 -- portion of engine used during interval
        __in SIZE_T nEngines,
        __in SIZE_T nIntervals,
        __in TimeStamp StartTime,
        __in TimeStamp EndTime,
        __in TimeStampDelta Resolution
        ) const PURE;

    STDMETHOD(QueryWarnings)(
        __out StridedWarnings* out
        ) const PURE;

    STDMETHOD_(bool, IsDataAvailable) () const PURE;
};


MIDL_INTERFACE("20A1A283-5580-4cfa-BF88-2A5BD8F258F0")
IDMABufferInfoSource2 : public IDMABufferInfoSource
{    
    struct QueuePacket
    {
        TimeStamp SubmissionTime;
        TimeStamp CompletionTime;
        ULONG SubmissionSequence;
        const IProcessInfoSource::ThreadData *SubmissionThread;
        bool IsPresent;
    };
    
    typedef strided_adapter<const QueuePacket> StridedQueuePackets;
    
    STDMETHOD(QueryQueuePackets)(
        __out StridedQueuePackets* QueuePackets,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
       ) const PURE;
};

MIDL_INTERFACE("B0EAE393-AA13-4f79-8DE5-28C08F7CD4F0")
IDDIInfoSource : public IUnknown
{
    typedef enum _DXGKETW_PROFILER_TYPE
    {
    //
    // Dxgkrnl Cdd interface.
    //
    ETW_PROFILER_DxgkCddCreate = 3000,
    ETW_PROFILER_DxgkCddDestroy = 3001,
    ETW_PROFILER_DxgkCddEnable = 3002,
    ETW_PROFILER_DxgkCddDisable = 3003,
    ETW_PROFILER_DxgkCddGetDisplayModeList = 3004,
    ETW_PROFILER_DxgkCddGetDriverCaps = 3005,
    ETW_PROFILER_DxgkCddLock = 3006,
    ETW_PROFILER_DxgkCddUnlock = 3007,
    ETW_PROFILER_DxgkCddPresent = 3008,
    ETW_PROFILER_DxgkCddSetGammaRamp = 3009,
    ETW_PROFILER_DxgkCddSetPalette = 3010,
    ETW_PROFILER_DxgkCddSetPointerPosition = 3011,
    ETW_PROFILER_DxgkCddSetPointerShape = 3012,
    ETW_PROFILER_DxgkCddTerminateThread = 3013,
    ETW_PROFILER_DxgkCddSetOrigin = 3014,
    ETW_PROFILER_DxgkCddWaitForVerticalBlankEvent = 3015,

    ETW_PROFILER_DxgkCddSyncGPUAccess       = 3016,
    ETW_PROFILER_DxgkCddCreateAllocation    = 3017,
    ETW_PROFILER_DxgkCddDestroyAllocation   = 3018,
    ETW_PROFILER_DxgkCddBltToPrimary        = 3019,
    ETW_PROFILER_DxgkCddGdiCommand          = 3020,

    ETW_PROFILER_DxgkCddDrvBitBlt           = 3021,
    ETW_PROFILER_DxgkCddDrvColorFill        = 3022,
    ETW_PROFILER_DxgkCddDrvStrokePath       = 3023,
    ETW_PROFILER_DxgkCddDrvAlphaBlend       = 3024,
    ETW_PROFILER_DxgkCddDrvLineTo           = 3025,
    ETW_PROFILER_DxgkCddDrvFillPath         = 3026,     
    ETW_PROFILER_DxgkCddDrvStrokeAndFillPath = 3027,
    ETW_PROFILER_DxgkCddDrvStretchBltROP    = 3028,
    ETW_PROFILER_DxgkCddDrvPlgBlt           = 3029,
    ETW_PROFILER_DxgkCddDrvStretchBlt       = 3030,
    ETW_PROFILER_DxgkCddDrvTextOut          = 3031,
    ETW_PROFILER_DxgkCddDrvGradientFill     = 3032,
    ETW_PROFILER_DxgkCddDrvTransparentBlt   = 3033,

    ETW_PROFILER_DxgkCddOpenResource        = 3034,
    ETW_PROFILER_DxgkCddQueryResourceInfo   = 3035,
    ETW_PROFILER_DxgkCddSubmitPresentHistory= 3036,
    ETW_PROFILER_DxgkCddCreateDeviceBitmap  = 3037,
    ETW_PROFILER_DxgkCddUpdateGdiMem        = 3038,
    }DXGKETW_PROFILER_TYPE;



    typedef enum _DXGKETW_GDIOP
    {
        DXGK_COLORFILL = 1,
        DXGK_BITBLT = 2,
        DXGK_STRETCHBLT = 3,
        DXGK_ALPHABLEND = 4,
        DXGK_TRANSPARENTBLT = 5,
        DXGK_CLEARTYPEBLEND = 6
    }DXGKETW_GDIOP;


    struct CRenderInfo
    {
        TimeStampDelta CpuTime;
        TimeStampDelta WaitTime;
        UINT NumReadBacks;
        UINT NumFlushes;
        UINT NumPresents;      
        TimeStampDelta FlushTime;
        TimeStampDelta PresentTime;      
        CRenderInfo()
        {
           NumReadBacks = 0 ;
           NumFlushes = 0;
           NumPresents = 0; 
        }
    };

    struct CDDI
    {
        const IProcessInfoSource::ProcessData* PData;
        ULONG ThreadId;
        DXGKETW_PROFILER_TYPE Type;
        TimeStamp StartTime;
        TimeStamp EndTime;    
        UINT SrcWidth;
        UINT SrcHeight;
        UINT DstWidth;
        UINT DstHeight;
        LPCWSTR SrcType;
        LPCWSTR DstType;
        TimeStamp StartWaitTime;
        TimeStamp StartFlushTime;
        TimeStamp StartFlushAfterTime;
        TimeStamp StartPresentTime;
        UINT Accelerated; 
        UINT SolidColor;
        UINT Reserved[3];
        bool FlushAfter;
        TimeStampDelta FlushAfterTime;
        CRenderInfo RenderInfo;
    };

    struct CDDI_Command
    {
        const IProcessInfoSource::ProcessData* PData;
        DXGKETW_GDIOP Type;
        LPCWSTR TypeName;
        TimeStamp Time;
        const CDDI *Ddi;
    };

  

    STDMETHOD_(LPCWSTR, DDITypeName)(
        __in DXGKETW_PROFILER_TYPE ddi
        ) const PURE;
    
    typedef strided_adapter<const CDDI> StridedDDIs;

    typedef strided_adapter<const CDDI_Command> StridedCommands;


    STDMETHOD(QueryDDIs)(
        __out StridedDDIs* Out,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
       ) const PURE;
   
      STDMETHOD(QueryCommands)(
        __out StridedCommands* Out,
        __in const TimeStamp& StartTime = TimeStamp::Min,
        __in const TimeStamp&   EndTime = TimeStamp::Max
       ) const PURE;

  

    STDMETHOD_(bool, IsDataAvailable) () const PURE;
};

MIDL_INTERFACE("50E80EDF-12FE-4696-8A42-2227B72D362C")
IGpuPowerInfoSource : public IUnknown
{
public:

    //
    // 2. Declare data structures returned to infosource clients.
    //
    // We recommend that these data structures are C-structs describing 
    // information inside data structures owned by the infosource; access will 
    // be provided by pointer.
    //

    struct TestData 
    {
        TimeStamp           Time;
        UINT32              Value;
        WCHAR*              Label;
    };

    struct VSyncDPCData64
    {
        LARGE_INTEGER pDxgAdapter;
        UINT32 VidPnTargetId;
        LARGE_INTEGER ScannedPhysicalAddress;
        UINT32 VidPnSourceId;
        UINT32 FrameNumber;
        INT64 FrameQPCTime;
        UINT64 hFlipDevice;
        UINT32 FlipType;
        UINT64 FlipFenceId;
    };

    struct VSyncDPCData32
    {
        LARGE_INTEGER pDxgAdapter;
        UINT32 VidPnTargetId;
        LARGE_INTEGER ScannedPhysicalAddress;
        UINT32 VidPnSourceId;
        UINT32 FrameNumber;
        INT64 FrameQPCTime;
        UINT32 hFlipDevice;
        UINT32 FlipType;
        UINT64 FlipFenceId;
    };

    struct VSyncDpcData
    {
        TimeStamp tsEventTime;
        UINT64 ullAdapterHandle;
        UINT32 uiVidPnTargetId;
        UINT32 uiVidPnSourceId;
    };

    struct VSyncHwInterruptData
    {
        TimeStamp tsEventTime;
        UINT64 ullAdapterHandle;
        UINT32 uiVidPnTargetId;
    };

    #define DXGK_POWERCOMPONENT_NAME_SIZE 40

    typedef struct _DXGK_POWERCOMPONENT_DESC64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 ComponentType;
        UINT32 ComponentId;
        UINT32 NumberOfIdleStates;
        GUID   ControlGuid;
        WCHAR  Name[DXGK_POWERCOMPONENT_NAME_SIZE];
    } DXGK_POWERCOMPONENT_DESC64;

    typedef struct _DXGK_POWERCOMPONENT_DESC32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 ComponentType;
        UINT32 ComponentId;
        UINT32 NumberOfIdleStates;
        GUID   ControlGuid;
        WCHAR  Name[DXGK_POWERCOMPONENT_NAME_SIZE];
    } DXGK_POWERCOMPONENT_DESC32;

    typedef struct _DXGK_POWERCOMPONENT_DESC
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 ComponentType;
        UINT32 ComponentId;
        UINT32 NumberOfIdleStates;
        WCHAR  *Name;
        INT32  NameSize;
    } DXGK_POWERCOMPONENT_DESC;

    typedef struct _DXGK_PSTATECOMPONENT_DESC64
    {
        UINT64 Adapter;
        UINT32 ComponentIndex;
        UINT32 NodeIndex;
        UINT32 NumberOfPStates;
        UINT32 CurrentfPState;
    } DXGK_PSTATECOMPONENT_DESC64;

    typedef struct _DXGK_PSTATECOMPONENT_DESC32
    {
        UINT32 Adapter;
        UINT32 ComponentIndex;
        UINT32 NodeIndex;
        UINT32 NumberOfPStates;
        UINT32 CurrentfPState;
    } DXGK_PSTATECOMPONENT_DESC32;

    typedef struct _DXGK_POWERCOMPONENT_IDLESTATE_DESC64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 FState;
        UINT32 NominalPower;
        UINT64 TransitionLatency;
        UINT64 ResidencyRequirement;
    } DXGK_POWERCOMPONENT_IDLESTATE_DESC64;

    typedef struct _DXGK_POWERCOMPONENT_IDLESTATE_DESC32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 FState;
        UINT32 NominalPower;
        UINT64 TransitionLatency;
        UINT64 ResidencyRequirement;
    } DXGK_POWERCOMPONENT_IDLESTATE_DESC32;

    typedef struct _DXGK_POWERPSTATE_DESC64
    {
        UINT64 Adapter;
        UINT32 NodeIndex;
        UINT32 PState;
        UINT32 OperatingFrequency;
    } DXGK_POWERPSTATE_DESC64;

    typedef struct _DXGK_POWERPSTATE_DESC32
    {
        UINT32 Adapter;
        UINT32 NodeIndex;
        UINT32 PState;
        UINT32 OperatingFrequency;
    } DXGK_POWERPSTATE_DESC32;

    struct ComponentsPStateData
    {
        UINT64 Adapter;
        UINT32 ComponentIndex;
        UINT32 NodeIndex;
        std::vector<UINT32> OperatingFrequency;
    };

    struct ComponentPowerCharacteristics
    {
        UINT32 NominalPower;
        UINT64 TransitionLatency;
        UINT64 ResidencyRequirement;
    };

    struct ComponentsPowerData
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        std::vector<ComponentPowerCharacteristics> PowerCharacteristics;
        WCHAR *Name;
    };

    struct PowerActivationRequestEvent64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 Active;
    };

    struct PowerActivationRequestEvent32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 Active;
    };

    class PowerActivationRequest
    {
    public:
        BOOL Valid;
        BOOL Completed;
        TimeStamp Time;
        UINT32 Active;
        UINT32 PreviousFState;

        PowerActivationRequest()
        {
            Valid = FALSE;
        }
    };

    struct PowerActivationCompletionEvent64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 Active;        
    };

    struct PowerActivationCompletionEvent32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 Active;        
    };

    class LastSetPowerFState
    {
    public:
        BOOL Valid;
        TimeStamp Time;
        UINT32 FState;

        LastSetPowerFState()
        {
            Valid = FALSE;
        }
    };

    struct PowerComponentFStateInterval
    {
        TimeStamp ActivationTime;
        TimeStamp FStateRequestTime;
        TimeStamp StartTime;
        TimeStamp EndTime;
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 Active;
        UINT32 FState;
        UINT32 PreviousFState;
    };

    struct PowerComponentStateSetStart64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 State;
    };

    struct PowerComponentStateSetEnd64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
    };

    struct PowerComponentStateSetStart32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 State;
    };

    struct PowerComponentStateSetEnd32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
    };

    struct SetPowerPState64
    {
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 PreviousState;
        UINT32 State;
    };

    struct SetPowerPState32
    {
        UINT32 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 PreviousState;
        UINT32 State;
    };

    struct SetPowerPState
    {
        TimeStamp Time;
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 PreviousState;
        UINT32 State;
    };

    struct PowerComponentStateSetStart
    {
        TimeStamp Time;
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
        UINT32 State;
    };

    struct PowerComponentStateSetEnd
    {
        TimeStamp Time;
        UINT64 AdapterHandle;
        UINT32 ComponentIndex;
    };

    struct SetDisplayModeData32
    {
        UINT32 AdapterHandle;
        UINT32 VidPnSourceId;
        UINT32 Width;
        UINT32 Height;
        UINT32 Format;
        UINT32 RefreshRate_Numerator;
        UINT32 RefreshRate_Denominator;
        UINT32 ScanLineOrdering;
        UINT32 Orientation;
        UINT32 DisplayFixedOutput;
        UINT32 Flags;
        UINT32 NumSamples;
        UINT32 NumQualityLevels;
    };

    struct SetDisplayModeData64
    {
        UINT64 AdapterHandle;
        UINT32 VidPnSourceId;
        UINT32 Width;
        UINT32 Height;
        UINT32 Format;
        UINT32 RefreshRate_Numerator;
        UINT32 RefreshRate_Denominator;
        UINT32 ScanLineOrdering;
        UINT32 Orientation;
        UINT32 DisplayFixedOutput;
        UINT32 Flags;
        UINT32 NumSamples;
        UINT32 NumQualityLevels;
    };

    struct SetDisplayModeData
    {
        TimeStamp Time;
        UINT64 AdapterHandle;
        UINT32 VidPnSourceId;
        UINT32 Width;
        UINT32 Height;
        UINT32 Format;
        UINT32 RefreshRate_Numerator;
        UINT32 RefreshRate_Denominator;
        UINT32 ScanLineOrdering;
        UINT32 Orientation;
        UINT32 DisplayFixedOutput;
        UINT32 Flags;
        UINT32 NumSamples;
        UINT32 NumQualityLevels;
    };

public:
    
    //
    // 3. Declare infosource methods.
    //
    // Methods should be STDMETHOD(name); this allows failure mode modeling 
    // through the error code.
    //
    // If returned data is contiguous with respect to infosource internal data 
    // structures, the recommended protocol for passing data out is T*+stride; 
    // if returned data is sparse, the recommended protocol is T*[]. (see 
    // Sample 2 for an example of T*[].)
    //
    // Compliance to these protocols allows easy handling of previous versions 
    // of infosource interfaces using the same internal data structures.
    //

    // Define strided type for ease of use
    typedef strided_adapter<const TestData> StridedTestData;
    typedef strided_adapter<const VSyncDpcData> StridedVsyncData;
    typedef strided_adapter<const VSyncHwInterruptData> StridedVsyncHwData;
    typedef strided_adapter<const SetDisplayModeData> StridedSetDisplayModeData;
    typedef strided_adapter<const ComponentsPowerData> StridedComponentsPowerData;
    typedef strided_adapter<const PowerComponentStateSetStart> StridedPowerComponentStateSetStart;
    typedef strided_adapter<const PowerComponentStateSetEnd> StridedPowerComponentStateSetEnd;
    typedef strided_adapter<const PowerComponentFStateInterval> StridedPowerComponentFStateInterval;
    typedef strided_adapter<const ComponentsPStateData> StridedComponentsPStateData;
    typedef strided_adapter<const SetPowerPState> StridedPowerSetPStateStart;
    typedef strided_adapter<const SetPowerPState> StridedPowerSetPStateEnd;

    STDMETHOD(QueryStridedVSyncData)(

        // T* + stride
        __out StridedTestData* pStridedTestData, 
        __out StridedVsyncData* pStridedVsyncTimes, 
        __out StridedVsyncHwData* pStridedVsyncHwTimes, 
        __out StridedSetDisplayModeData* pStridedSetDisplayModeData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryStridedFStateData)(

        // T* + stride
        __out StridedTestData* pStridedTestData, 
        __out StridedComponentsPowerData* pStridedComponentsPowerData, 
        __out StridedPowerComponentStateSetStart* pStridedPowerComponentStateSetStart, 
        __out StridedPowerComponentStateSetEnd* pStridedPowerComponentStateSetEnd, 
        __out bool *powerManagementEnabled,
        __out bool *powerManagementFStateEnabled,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryStridedFStateIntervalData)(
        // T* + stride
        __out StridedPowerComponentFStateInterval* pStridedPowerComponentFStateInterval, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryStridedPStateData)(

        // T* + stride
        __out StridedTestData* pStridedTestData, 
        __out StridedComponentsPStateData* pStridedComponentsPStateData, 
        __out StridedPowerSetPStateStart* pStridedPowerSetPStateStart, 
        __out StridedPowerSetPStateEnd* pStridedPowerSetPStateEnd, 
        __out bool *powerManagementEnabled,
        __out bool *powerManagementPStateEnabled,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryGpuCpuUsage)(
        __out LONGLONG *scenarioTime, 
        __out_ecount(numEntries) LONGLONG gpuTime[], 
        __out_ecount(numEntries) LONGLONG cpuTime[], 
        __out_ecount(numEntries) double gpuUsage[], 
        __out_ecount(numEntries) double cpuUsage[], 
        __in  SIZE_T numEntries,

        __in LPCWSTR processName,
        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryGlitchCount)(
        __out int *dwmGlitchCount,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    //
    // New methods
    //

    STDMETHOD(QueryCount)(
        // T**
        __out_ecount_part_opt(nEntries, nEntries) ULONG rgCounts[],
        __inout SIZE_T& nEntries,

        // resolution
        __in  const TimeStampDelta& Resolution,

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,

        __in_opt PVOID pvContext = NULL
        ) const PURE;

    STDMETHOD_(bool, IsFStateDataAvailable) () const PURE;
    STDMETHOD_(bool, IsPStateDataAvailable) () const PURE;
};


MIDL_INTERFACE("145A81FF-689C-4BA0-90E4-DC5054DF5FFF")
ITestMarksInfoSource : public IUnknown
{
public:

    //
    // The test LogMarker info is considered complete if there is both a start and 
    // stop time in the requested range. 

    struct LogMarkerInfo
    {
        ULONG     ulMarker;
        ULONG     ulProcessId;
        TimeStamp tsLogMarkerStart;
        TimeStamp tsLogMarkerStop;
    };

public:
    
    // Define strided type for ease of use
    typedef strided_adapter<const LogMarkerInfo> StridedLogMarkerInfoData;

    // This method returns a pointer to the StridedLogMarkerInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedLogMarkerInfoData* pStridedLogMarkerInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

};

MIDL_INTERFACE("145AA1FF-6A9C-4BF0-90E4-DC5054DF5FFF")
ICountersInfoSource : public IUnknown
{
public:
    // Time,AdapterHandle,VidPnTargetId,ScannedPhysicalAddress
    struct VSyncHWInterruptInfo
    {
        TimeStamp tsEventTime;
        ULONGLONG ullAdapterHandle;
        UINT      uiVidPnTargetId;
        LARGE_INTEGER liScannedPhysicalAddress;
    };

    // Time,AdapterHandle,VidPnTargetId,ScannedPhysicalAddress,
    // VidPnSourceId,FrameNumber,FrameQPCTime,hFlipDevice,FlipType,FlipFenceId
    struct VSyncDPCInfo
    {
        TimeStamp tsEventTime;
        ULONGLONG ullAdapterHandle;
        UINT      uiVidPnTargetId;
        LARGE_INTEGER liScannedPhysicalAddress;
        UINT      uiVidPnSourceId;
        UINT      uiFrameNumber;
        ULONGLONG ullFrameQPCTime;
        ULONGLONG ullhFlipDevice;
        ULONG     ulFlipType;
        ULARGE_INTEGER uliFlipFenceId;
    };

    struct VTransitionInfo
    {
        TimeStamp tsEventTime;
        ULONG     ulEntering; // boolean
        ULONGLONG ullCompositionSurface;
        ULONG     ulVidPnSourceId;
        ULONG     ulPlane;
        ULONG     ulApprovedPresentDuration;
        ULONG     ulPendingIndependentFlip; // boolean
        ULONGLONG ullBindId;
        ULONG     ulRequestedByDwm; // boolean
    };

    // We simply want to know if DWM logged a glitch event.
    struct VDWMGlitchInfo
    {
        TimeStamp tsEventTime;
    };

    struct VProfilerInfo
    {
        TimeStamp tsEventTime;
        ULONG     ulFuncId;
        ULONG     ulProcessorNum;
        ULONG     ulProcessId;
        ULONG     ulThreadId;
        bool      bStart;  // true=start, false=end
    };

    enum eEventType
    {
        eDxgKrnl,
        eDWM,
        eW32k,
        eDXGI,
        eD3D11,
    };

    // Used for counting misc events.
    struct VEventInfo
    {
        TimeStamp tsEventTime;
        EVENT_DESCRIPTOR ed;
        ULONG ulProcessId;
        ULONG ulThreadId;
    };
public:
    
    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_

    // Define strided type for ease of use
    typedef strided_adapter<const VSyncHWInterruptInfo> StridedVSyncHWInterruptInfoData;

    // This method returns a pointer to the StridedVSyncHWInterruptInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedVSyncHWInterruptInfoData* pStridedVSyncHWInterruptInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_

    // Define strided type for ease of use
    typedef strided_adapter<const VSyncDPCInfo> StridedVSyncDPCInfoData;

    // This method returns a pointer to the StridedVSyncDPCInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedVSyncDPCInfoData* pStridedVSyncDPCInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_

    // Define strided type for ease of use
    typedef strided_adapter<const VTransitionInfo> StridedTransitionInfoData;

    // This method returns a pointer to the StridedTransitionInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedTransitionInfoData* pStridedTransitionInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_

    // Define strided type for ease of use
    typedef strided_adapter<const VDWMGlitchInfo> StridedDWMGlitchInfoData;

    // This method returns a pointer to the StridedDWMGlitchInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedDWMGlitchInfoData* pStridedDWMGlitchInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max) const PURE; 
    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_

    // Define strided type for ease of use
    typedef strided_adapter<const VProfilerInfo> StridedProfilerInfoData;

    // This method returns a pointer to the StridedProfilerInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedProfilerInfoData* pStridedProfilerInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max) const PURE; 
    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_

    // Define strided type for ease of use
    typedef strided_adapter<const VEventInfo> StridedEventInfoData;

    // This method returns a pointer to the StridedProfilerInfoData that corrisponds
    // to the given range.  T* + stride
    STDMETHOD(QueryStridedData)(

        // T* + stride
        __out StridedEventInfoData* pStridedEventInfoData, 

        // temporal selection
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in eEventType _eType = eDxgKrnl) const PURE; 
    //+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_++_+_+_+_+_+_+_
};

MIDL_INTERFACE("0EF668BD-EBE2-440C-86D6-97EE958B8D38")
ITimingDataInfoSource : public IUnknown
{
public:

    struct Context
    {
        UINT64 pID3D11Device;
        UINT64 pID3D11DeviceContext;
        UINT32 ContextType;
        UINT32 ContextFlags;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct MarkerInt
    {
        UINT64 pID3D11DeviceContext;
        UINT64 APISequenceNumber;
        WCHAR *Label;
        INT32 Data;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct RuntimeMarkerData
    {
        UINT64 CPUFrequency;
        UINT64 FirstAPISequenceNumber;
        UINT64 pID3D11DeviceContext;
        UINT32 CPUTimeHigh;
        BYTE ThreadIDs;
        UINT32 *ThreadID;
        UINT32 DataSize;
        BYTE *Data;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct RuntimeDroppedCall
    {
        UINT64 pID3D11DeviceContext;
        UINT32 Type;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct CommandBufferSubmission
    {
        UINT64 pIDXGIDevice;
        UINT32 hContext;
        BYTE BroadcastContexts;
        UINT32 *hBroadcastContexts;
        UINT32 MarkerLogType;
        UINT32 RenderCBSequenceNumber;
        UINT32 FirstAPISequenceNumberHigh;
        UINT32 CompletedAPISequenceNumberLow0Size;
        UINT32 CompletedAPISequenceNumberLow1Size;
        UINT32 BegunAPISequenceNumberLow0Size;
        UINT32 BegunAPISequenceNumberLow1Size;
        UINT32 *CompletedAPISequenceNumberLow0;
        UINT32 *CompletedAPISequenceNumberLow1;
        UINT32 *BegunAPISequenceNumberLow0;
        UINT32 *BegunAPISequenceNumberLow1;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct CommandList
    {
        UINT64 pID3D11DeviceContext;
        UINT64 pID3D11CommandList;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct CustomDriverStringTable
    {
        UINT64 pID3D11Device;
        INT32 StringIndex;
        WCHAR *Description;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct CustomDriverMarker
    {
        UINT64 InsertionAPISequenceNumber;
        UINT64 pID3D11DeviceContext;
        UINT32 hContext;
        INT32 Index;
        INT32 StringIndex;
        WCHAR *MarkerDescription;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct CalibrateGpuClock
    {
        UINT64 hAdapter;
        UINT32 NodeOrdinal;
        UINT32 EngineOrdinal;
        UINT64 GpuFrequency;
        UINT64 GpuClock;
        UINT64 CpuClock;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

    struct HistoryBuffer
    {
        UINT64 hContext;
        UINT32 RenderCbSequence;
        UINT32 DmaSubmissionSequence;
        UINT32 Precision;
        UINT32 HistoryBufferSize;
        BYTE *pHistoryBuffer;
        ULONG ProcessId;
        TimeStamp EventTime;
    };

public:
    typedef std::vector<Context> ContextVector;

    STDMETHOD(GetContextData)(
        __out ContextVector* pContextData 
        ) PURE;

    typedef std::vector<MarkerInt> MarkerIntVector;

    STDMETHOD(GetMarkerIntData)(
        __out MarkerIntVector* pMarkerIntData 
        ) PURE;

    typedef std::vector<RuntimeMarkerData> RuntimeMarkerVector;

    STDMETHOD(GetRuntimeMarkerData)(
        __out RuntimeMarkerVector* pRuntimeMarkerData 
        ) PURE;

    typedef std::vector<RuntimeDroppedCall> RuntimeDroppedCallVector;

    STDMETHOD(GetRuntimeDroppedCallData)(
        __out RuntimeDroppedCallVector* pRuntimeDroppedCallData 
        ) PURE;

    typedef std::vector<CommandBufferSubmission> CommandBufferSubmissionVector;

    STDMETHOD(GetCommandBufferSubmissionData)(
        __out CommandBufferSubmissionVector* pCommandBufferSubmissionData 
        ) PURE;

    typedef std::vector<CommandList> CommandListVector;

    STDMETHOD(GetCommandListData)(
        __out CommandListVector* pCommandListData 
        ) PURE;

    typedef std::vector<CustomDriverStringTable> CustomDriverStringTableVector;

    STDMETHOD(GetCustomDriverStringTableData)(
        __out CustomDriverStringTableVector* pCustomDriverStringTableData 
        ) PURE;

    typedef std::vector<CustomDriverMarker> CustomDriverMarkerVector;

    STDMETHOD(GetCustomDriverMarkerData)(
        __out CustomDriverMarkerVector* pCustomDriverMarkerData 
        ) PURE;

    typedef std::vector<CalibrateGpuClock> CalibrateGpuClockVector;

    STDMETHOD(GetCalibrateGpuClockData)(
        __out CalibrateGpuClockVector* pCalibrateGpuClockData 
        ) PURE;   

    typedef std::vector<HistoryBuffer> HistoryBufferVector;

    STDMETHOD(GetHistoryBufferData)(
        __out HistoryBufferVector* pHistoryBufferData 
        ) PURE;   
};

//
// While DX/DWM events are recorded in per-CPU circular buffer, there is chance
// buffer is used up and in some period of start of the trace some CPU buffer has events
// but some doesn't, which looks some events are lost and causes DX/DWM plugin confused.
//
// This inforsource aims to provide time period when all CPU buffers have events therefore
// metrics reported by plugin is reliable.
//
MIDL_INTERFACE("014E7D8C-90D4-40C8-B00C-C6DA4E16DAED")
IDXEventAvailabilityInfoSource : public IUnknown
{
public:

    // The earliest time when all CPU has DX events
    STDMETHOD (GetFirstValidTime) (
        __out TimeStamp& Time
        ) const PURE;

    // The latest time when all CPU has DX events
    STDMETHOD (GetLastValidTime) (
        __out TimeStamp& Time
        ) const PURE;

    STDMETHOD_(bool, IsDataAvailable)(
        ) const PURE;
};

MIDL_INTERFACE("9F427CB4-1990-4FBE-B1BD-661C337D7D00")
IRecycleHeapInfoSource : public IUnknown
{
public:
    STDMETHOD_(bool, IsDataAvailable)(
    ) const PURE;

    struct RecycleAllocationStateLifetime
    {
        ULONG64 Range;
        ULONG64 Block;
        ULONG64 Section;
        ULONG64 Heap;
        ULONG64 EProcess;

        TimeStamp StartTime;
        TimeStamp EndTime;

        ULONG64 StartAddress;
        ULONG64 EndAddress;

        ULONG MemoryState;
        ULONG HeapType;

        ULONG64 GlobalAlloc;

        ULONG ProcessID;
        std::wstring ProcessName;
    };

    //
    // Event definitions
    //
#pragma pack(push)
#pragma pack(1)
    struct CreateRange32
    {
        ULONG32 EProcess;
        ULONG32 Range;
        ULONG32 Block;
        ULONG32 Section;
        ULONG32 Heap;
        ULONG32 StartAddress;
        ULONG32 EndAddress;

        ULONG32 HeapType;
        ULONG32 CreationState;
    };

    struct CreateRange64
    {
        ULONG64 EProcess;
        ULONG64 Range;
        ULONG64 Block;
        ULONG64 Section;
        ULONG64 Heap;
        ULONG64 StartAddress;
        ULONG64 EndAddress;

        ULONG32 HeapType;
        ULONG32 CreationState;
    };

    struct TransitionRange32
    {
        ULONG32 Range;

        ULONG32 PreviousState;
        ULONG32 NextState;
    };

    struct TransitionRange64
    {
        ULONG64 Range;

        ULONG32 PreviousState;
        ULONG32 NextState;
    };

    struct DestroyRange32
    {
        ULONG32 Range;
    };

    struct DestroyRange64
    {
        ULONG64 Range;
    };
#pragma pack(pop)

    typedef std::vector<RecycleAllocationStateLifetime> RecycleLifetimes;

    STDMETHOD(QueryStateLifetimes)(
        _Out_ RecycleLifetimes* StateLifetimes) const PURE;
};

} // namespace DX
} // namespace XPerfAddIn


