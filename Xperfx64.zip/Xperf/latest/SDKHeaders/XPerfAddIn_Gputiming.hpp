/*++

  Copyright (c) 2014 Microsoft Corporation

  Module Name:
  XPerfAddIn_GpuTiming.hpp

  Author:

  Dean Wills (deanwi)

  Revision History:

  --*/

#pragma once

#include <XPerfCore.hpp>                // include XPerfCore main header
#include <XPerfAddIn_Core.hpp>          // AddIn_alloc references core infosources

namespace XPerfAddIn
{

MIDL_INTERFACE("0EF668BD-EBE2-440C-86D6-97EE958B8D39")
IGPUTimingInfoSource : public IUnknown
{
    //
    // Diagnostics
    //
    struct Diagnostics
    {
        UINT64 EventsEnabled;
        UINT64 CountHistoryBuffer;
        UINT64 CountMarker;
        UINT64 CountRuntimeMarker;
        UINT64 CountCommandBufferSubmission;
        UINT64 CountOutOfOrder;
        UINT64 ActualGpuFrequency;
        UINT64 ReportedGpuFrequency;
        UINT64 TotalEventSize;
        UINT64 ApiCount;
        UINT64 BytesPerApi;
    };

    enum EventTracking
    {
        Dxgk_NodeMetadata,
        Dxgk_DpiReportAdapter,
        Dxgk_VSyncInterrupt,
        Dxgk_DmaPacket,
        Dxgk_DmaDpcComplete,
        Dxgk_DmaIsrComplete,
        Dxgk_HistoryBuffer,
        Dxgk_CalibrateGpuClockTask,
        Dxgk_SelectContext,
        Dxgk_EventCreateDevice,
        Dxgk_EventReportDevice,
        Dxgk_EventDestroyDevice,
        Dxgk_EventCreateContext,
        Dxgk_EventDestroyContext,
        Dxgk_EventReportContext,
        D3D11_Device,
        D3D11_Context,
        D3D11_Marker,
        D3D11_RuntimeMarkerData,
        D3D11_CommandBufferSubmission,
        D3D11_CommandList,
        EventTrace_Guid_22,
        EventTrace_Guid_15,
        EventTracking_COUNT
    };

    //
    // Command Buffer Submissions
    //
    struct Dma
    {
        UINT32 RenderCBSequenceNumber;              //The packet we're keying on.
        INT64 *pCpuTimes;                           //First, Count, Last, times in ns, adjusted to Cpu clock
        UINT32 Count;                               //ones that were explicitly completed with this packet. 
        INT64 *pApiNumber;                          //the Count Api numbers
        UINT32 iCBSEx;                              //extra internal info, using during processing.
        UINT64 uliSubmissionId;                     //Corresponding DMA packet 
        UINT32 ulQueueSubmitSequence;               //Corresponding DMA packet 
        INT64 EventTime;                            //Event time when the Command Buffer Submission was seen
        UINT64 First;                               //First Gputimestamp
        UINT64 *pTimes;                             //Gputimestamp for completed items
        UINT64 Last;                                //Last Gputimestamp
        UINT32 ImplicitCount;                       //Apis that were implicitly completed with this packet
        INT64 *pImplicit;                           //the implicit Api Numbers
        UINT32 BegunCount;                          //ones that had some progress on them
        INT64 *pBegun;                              //
        UINT32 fSeen:1;                             //
        UINT32 fFeaturelevel : 4;                   //version number of DMA data. Deprecated
        UINT32 fPresent:1;                          //
        UINT32 ProcessIndex;                        //
        UINT32 DeviceIndex;                         //
        UINT64 ContextHandle;                       //from 41/21 : internal
        UINT64 CpuFrequency;                        //cpu frequency
        INT32 Previous;                             //back linked list : internal
    };

    //
    // Adapter Description
    //
    struct EventPnp
    {
        UINT32 UpperFiltersCount;
        UINT32 LowerFiltersCount;
        UINT32 DevStatus;
        UINT32 DevProblem;
        WCHAR DeviceID[128];
        WCHAR DeviceDescription[128];
        WCHAR FriendlyName[128];
        WCHAR PdoName[128];
        WCHAR ServiceName[128];
    };

    struct EventDpiReportAdapt
    {
        UINT64 pDxgAdapter;
        UINT32 ConfigSpaceSize;
        UINT32 ChainUid;
        UINT32 NumberOfLinksInChain;
        UINT32 LeadLink;
        UINT32 BusType;
        UINT32 VendorID;
        UINT32 DeviceID;
        UINT32 SubVendorID;
        UINT32 SubSystemID;
        UINT32 RevisionID;
        WCHAR DeviceIDString[128];
    };
    //
    // For each node in each Adapter
    //
    struct EventNodeReport
    {
        WCHAR FriendlyName[128];
        UINT32 NodeOrdinal;
        UINT32 EngineType;
        //
        UINT32 SubmissionsCount;
        Dma *pSubmissions;                          //array of SubmissionsCount Dma
    };

    struct EventVSyncInt
    {
        UINT64 pDxgAdapter;
        UINT32 VidPNSourceId;                       //0 1 2, output channel
        UINT64 ScannedPhysicalAddress;
        INT64 EventTime;
    };

    struct EventCalibrationEvent
    {
        INT64 EventTime;
        UINT64 CpuTimeStamp;
        UINT64 GpuTimeStamp;
        UINT64 hAdapter;
        UINT32 NodeOrdinal;
        UINT32 EngineOrdinal;
        UINT64 GpuFrequency;
        ULONG ProcessId;
    };

    struct EventTag     //deprecated
    {
        INT64 EventTime;
        UINT64 CpuTimeStamp;
        UINT64 GpuTimeStamp;
        UINT64 pID3D11Device;
        INT64 SequenceNumber;
        UINT8 MarkerAPI;
    };

    struct EventDxgAdapterReport
    {
        EventDpiReportAdapt DpiReportAdapt;
        EventPnp EventPnpInfo;
        UINT64 GpuFrequency;                        //calculated GpuFrequency
        INT64 TimeAdjust;                           //Amount to adjust times based on correlation of DMA packet arrival
        UINT64 pDxgAdapter;
        //
        UINT32 VSyncInterruptCount;
        EventVSyncInt *pVSyncInterrupt;             //array
        //
        UINT32 NodeCount;
        EventNodeReport *pNodes;                    //array
        //
        UINT32 CalibrateEventCount;
        EventCalibrationEvent *pCalibrateEvents;    //array
    };

    //
    // Api Calls
    //
    struct Api
    {
        INT64 SequenceNumber;                       //Api Sequence Number
        INT64 CpuStartNs;                           //cpu Start at the issuance of the Api in ns
        INT64 GpuStartNs;                           //gpu Start in ns
        INT64 GpuEndNs;                             //gpu End in ns
        INT64 ElapsedNs;                            //Elapsed Gpu time in ns 
        UINT32 ThreadID;                            //ThreadID
        WCHAR *Label;                               //label, if any
        UINT16 MarkerAPI;                           //Api function number
        UINT8 ColorHint;                            //Color hint : deprecated
        UINT8 Fill;                                 //stay on 32 bits
        UINT64 pID3D11Device;                       //Device where the call was issued
        union                                       //union used to add DxgAdapterIndex overlay (based on version)
        {                                           //still binary compatible
            UINT64 pDxgAdapter;                     //internal: Adapter where this Api was processed.
            UINT32 DxgAdapterIndex;                 //Index of Adapter in the m_Gputiming array
        };
        INT64  QPC;                                 //cpu QPC timestamp at the issuance of the Api
        UINT64 TimeStart;                           //gpu start timestamp
        UINT64 TimeEnd;                             //gpu end timestamp
        UINT64 CpuFrequency;                        //cpu frequency when issued
        UINT16 Index;                               //Index within History Buffer / Dma
        UINT8  NodeOrdinal;                         //NodeOrdinal
        UINT8  EngineOrdinal;                       //EngineOrdinal
        UINT32 RenderCBSequenceNumber;              //
        UINT64 hContext;                            //context where this was executed
        UINT64 uliSubmissionId;                     //DMA Submission Id
    };

    struct ProcessReport
    {
        WCHAR ImageName[128];                       //Name
        UINT64 hProcess;
        //
        UINT32 ApiCount;
        Api *pApi;                                  //array
        //
        UINT64 CpuFrequency;                        //CpuFrequency
    };

    struct Filters
    {
        UINT64 Process;                             //Process Match
        UINT64 Device;                              //D3DDevice Match
        INT64 ApiSequence[2];                       //Low -> High: Api Sequence (only valid for a given Device)
        INT64 Time[2];                              //Low -> High: Time 
        UINT32 RenderCBSequence[2];                 //Low -> High: RenderCb
        UINT64 uliSubmissionId[2];                  //Low -> High: Submission Id
    };

    struct DeviceReport
    {
        UINT64 pID3D11Device;
        UINT64 pIDXGIDevice;
        UINT64 Reserved;
    };

    struct ProcessReportDevice
    {
        UINT32 DeviceCount;
        DeviceReport *pDevices;                     //array
    };

    //
    // GetGputiming returns this structure
    //
    struct GputimingReport
    {
        UINT32 DxgAdapterCount;
        EventDxgAdapterReport *pAdapters;           //array
        //
        UINT32 ProcessCount;
        ProcessReport *pProcesses;                  //array(ProcessCount)
        ProcessReportDevice *pProcessDevice;        //array(ProcessCount)
    };
    //
    // GetGputiming is the primary method for reading Infosource Data
    //
    STDMETHOD(GetGputiming) (
        __out GputimingReport **ppGputimingReport,
        __in Filters *pFilter
        ) PURE;

    STDMETHOD(DisplayTestResults) (
        __in ULONG  Parameters
        ) PURE;

    STDMETHOD(RedBlue) (                            //Deprecated
        __in PWCHAR  FileName
        ) PURE;

    STDMETHOD(SetParameters) (
        __in ULONG  Parameters
        ) PURE;

    STDMETHOD(GetDiagnostics) (
        __out Diagnostics *pDiagnostics,
        __in Filters *pFilter
        ) PURE;

};

MIDL_INTERFACE("0EF668BD-EBE2-440C-86D6-97EE958B8D3A")
IGPUTimingInfoSource1 : public IGPUTimingInfoSource
{
    struct EventVSyncDPC
    {
        INT64 EventTime;
        UINT64 pDxgAdapter;
        UINT32 VidPNTargetId;                   //actual display device id
        UINT64 ScannedPhysicalAddress;
        UINT32 VidPNSourceId;                   //0, 1, 2 in Monitor Structure
        UINT32 FrameNumber;
        UINT64 FrameQPCTime;
        UINT64 hFlipDevice;
        UINT32 FlipType;
        UINT32 FlipFenceId;
    };

    struct EventProcessInfo
    {
        UINT64 UniqueProcessKey;
        UINT32 ProcessId;
        UINT32 ParentId;
        UINT32 SessionId;
        UINT32 ExitStatus;
        UINT64 DirectoryTableBase;
        UINT32 Flags;
        UINT64 Spacer1;
        UINT64 Spacer2;
        //
        // SID here
        //
        WCHAR ImageName[128];               //Name
    };

    struct EventProcess
    {
        ULONG ProcessId;
        UINT32 ServiceState;
        UINT32 SubProcessTag;
        WCHAR ServiceName[128];
        WCHAR DisplayName[128];
        WCHAR ProcessName[128];
        WCHAR LoadOrderGroup[128];
        WCHAR SvchostGroup[128];
    };

    struct EventEngineReport
    {
        UINT32 EngineOrdinal;

        UINT64 GpuFrequency;                //calculated GpuFrequency
        UINT64 GpuTimeStamp;                //last GpuTimestamp
        UINT64 CpuTimeStamp;                //last CpuTimestamp

        UINT64 GpuFrequency0;               //first Gpu Frequency
        UINT64 GpuTimeStamp0;               //first GpuTimestamp
        UINT64 CpuTimeStamp0;               //first CpuTimestamp
        INT64 TimeAdjust;                   //Amount to adjust times based on correlation of DMA packet arrival. 

        UINT32 SubmissionsCount;
        Dma *pSubmissions;                  //array of SubmissionsCount Dma

        UINT32 GpuViewSubmissionsCount;     //GpuView compatible Data
        Dma *pGpuViewSubmissions;           //array of SubmissionsCount Dma

        UINT32 CalibrateEventCount;
        EventCalibrationEvent *pCalibrateEvents;    //array
    };

    //
    // For each node in each Adapter
    //
    struct EventNodeReport1
    {
        WCHAR FriendlyName[128];
        UINT32 NodeOrdinal;
        UINT32 EngineType;
        UINT32 EngineCount;
        EventEngineReport *pEngines;
    };

    struct EventScreenShot
    {
        INT64 EventTime;
        UINT64 FrameNumber;
        UINT32 Width;
        UINT32 Height;
        UINT32 Left;
        UINT32 Top;
        UINT32 Pitch;
        UINT8 PixelSize;
        UINT8 Monitor;
        UINT16 DxgiFormat;
        UINT32 BufferSize;
        //
        UINT8 *pBuffer;
    };

    struct EventDxgAdapterReport1
    {
        EventDpiReportAdapt DpiReportAdapt;
        EventPnp EventPnpInfo;
        UINT64 GpuFrequency;                        //calculated GpuFrequency
        INT64 TimeAdjust;                           //Amount to adjust times based on correlation of DMA packet arrival
        UINT64 pDxgAdapter;
        //
        UINT32 VSyncInterruptCount;
        EventVSyncInt *pVSyncInterrupt;             //array
        //
        UINT32 NodeCount;
        EventNodeReport1 *pNodes;                    //array

    };

    struct CoreActivityReport
    {
        INT64 Time;                                 //
        UINT32 ProcessIndex;                        //
        UINT32 DeviceIndex;                         //
        UINT16 MarkerAPI;                           //api call
        UINT32 fApi : 1;
    };

    struct ThreadReport
    {
        UINT32 hThread;
        UINT32 ThreadIndex;                         //TODO: Do we need? Redundant?
        UINT32 ActivityCount;
        CoreActivityReport *pActivity;
    };


    struct DeviceReport1
    {
        UINT64 pID3D11Device;
        UINT64 pIDXGIDevice;
        UINT64 Reserved;
        UINT32 ApiIndexCount;
        UINT32 *pApiIndices;      //Array of indicies into the ProcessReport1 pApi array
    };

    struct ProcessReport1
    {
        WCHAR ImageName[128];                       //Name
        UINT64 hProcess;

        UINT32 ThreadCount;
        ThreadReport *pThreads;
        //
        UINT32 ApiCount;
        Api *pApi;                                  //array
        //
        UINT64 CpuFrequency;                        //CpuFrequency

        UINT32 DeviceCount;
        DeviceReport1 *pDevices;                    //array

        UINT32 ExtraCount;
        void *pExtras;
    };

    struct CoreActivity
    {
        INT64 Time;
        UINT64 hProcess;
        UINT32 hThread;
        UINT64 pID3D11Device;
        UINT16 MarkerAPI;                           //api call
        UINT32 fActive : 1;
        UINT32 fApi : 1;
        INT32 Cpu;
    };

    struct CoreReport
    {
        UINT32 ActivityCount;
        CoreActivityReport *pActivity;
    };

    struct VidPNSource
    {
        UINT32 ScreenShotCount;
        EventScreenShot *pScreenShots;
    };

    struct GputimingReport1
    {
        UINT32 DxgAdapterCount;
        EventDxgAdapterReport1 *pAdapters;           //array
        //
        UINT32 ProcessCount;
        ProcessReport1 *pProcesses;                  //array

        UINT32 CoresExtraCount;                     //includings diagnostic cores
        UINT32 CoresCount;
        CoreReport *pCores;

        //ToDo : Do the VidPNSources go here, or in EventDxgAdapterReport1?
        UINT32 VidPNSourceCount;
        VidPNSource *pVidPNSources;

        UINT32 ExtraCount;
        void *pExtras;
    };

    STDMETHOD(GetGputiming1) (
        __out GputimingReport1 **ppGputimingReport,
        __in Filters *pFilter
        ) PURE;

    STDMETHOD(GetMarkerName) (
        __in UINT32 MarkerOp,
        __out PWCHAR *
        ) PURE;

    enum EMarkerOp : UINT32
    {
        e_MOp_SetMarker = 0, // These values must match up with ETW.
        e_MOp_BeginEvent,
        e_MOp_EndEvent,
        e_MOp_Draw,
        e_MOp_DrawIndexed,
        e_MOp_DrawInstanced,
        e_MOp_DrawIndexedInstanced,
        e_MOp_DrawAuto,
        e_MOp_DrawIndexedInstancedIndirect,
        e_MOp_DrawInstancedIndirect,
        e_MOp_Dispatch,
        e_MOp_DispatchIndirect,
        e_MOp_CopySubresourceRegion,
        e_MOp_CopyResource,
        e_MOp_UpdateSubresource,
        e_MOp_CopyStructureCount,
        e_MOp_GenerateMips,
        e_MOp_ResolveSubresource,
        e_MOp_ClearRenderTargetView,
        e_MOp_ClearUnorderedAccessView,
        e_MOp_ClearDepthStencilView,
        e_MOp_ClearView,
        e_MOp_UpdateTileMappings,
        e_MOp_CopyTileMappings,
        e_MOp_CopyTiles,
        e_MOp_UpdateTiles,
        e_MOp_DecoderExtension,
        e_MOp_SubmitDecoderBuffers,
        e_MOp_VideoProcessorBlt,
        e_MOp_EncryptionBlt,
        e_MOp_DecryptionBlt,
        e_MOp_Present,
        e_MOp_GetDC,
        e_MOp_ReleaseDC,
        e_MOp_GetDisplaySurfaceData,
        e_MOp_ExecuteCommandList,
        e_MOp_Unknown = 0xff,
        //
        e_M12_SetMarker = 0x100,
        e_M12_BeginEvent,
        e_M12_EndEvent,
        e_M12_DrawInstanced,
        e_M12_DrawIndexedInstanced,
        e_M12_DrawAuto,
        e_M12_DrawIndexedInstancedIndirect,
        e_M12_DrawInstancedIndirect,
        e_M12_Dispatch,
        e_M12_DispatchIndirect,
        e_M12_CopySubresourceRegion,
        e_M12_CopyResource,
        e_M12_CopyStructureCount,
        e_M12_CopyTiles,
        e_M12_ResolveSubresource,
        e_M12_ClearRenderTargetView,
        e_M12_ClearUnorderedAccessView,
        e_M12_ClearDepthStencilView,
        e_M12_ClearView,
        e_M12_ResourceBarrier,
        e_M12_ExecuteBundle,
        e_M12_Present,
    };
};

MIDL_INTERFACE("0EF668BD-EBE2-440C-86D6-97EE958B8D3B")
IGPUTimingInfoSource2 : public IGPUTimingInfoSource1
{
    struct Api2
    {
        UINT32 fIHVMessage : 1;
        INT64 SequenceNumber;                       //Api Sequence Number set in GetSequenceNumber or fillOutApiData
        INT64 CpuStartNs;                           //fillOutApiData
        INT64 GpuStartNs;                           //gpu Start in ns
        INT64 GpuEndNs;                             //gpu End in ns
        INT64 ElapsedNs;                            //Elapsed Gpu time in ns 
        UINT32 ThreadID;                            //ThreadID
        WCHAR *Label;                               //label, if any
        UINT16 MarkerAPI;                           //fillOutApiData
        UINT8 ColorHint;                            //Color hint : deprecated
        UINT8 Fill;                                 //stay on 32 bits
        UINT64 pID3DDevice;                       //fillOutApiData
        UINT64 pCommandList;
        UINT64 CommandListSequenceNumber;
        UINT64 pCommandQueue;
        union                                       //union used to add DxgAdapterIndex overlay (based on version)
        {                                           //still binary compatible
            UINT64 pDxgAdapter;                     //internal: Adapter where this Api was processed.
            UINT32 DxgAdapterIndex;                 //Index of Adapter in the m_Gputiming array
        };
        INT64  QPC;                                 //fillOutApiData
        UINT64 TimeStart;                           //gpu start timestamp
        UINT64 TimeEnd;                             //gpu end timestamp
        UINT64 CpuFrequency;                        //fillOutApiData
        UINT16 Index;                               //Index within History Buffer / Dma
        UINT8  NodeOrdinal;                         //NodeOrdinal
        UINT8  EngineOrdinal;                       //EngineOrdinal
        UINT32 RenderCBSequenceNumber;              //
        UINT64 hContext;                            //context where this was executed
        UINT64 uliSubmissionId;                     //DMA Submission Id
        UINT64 hProcess;                            //
        UINT8 CoreReportOrdinal;                    //fillOutApiData
        UINT64 CoreActivityReportOrdinal;           //link to coreActivityReport
    };

    struct EventVSyncDPC
    {
        INT64 EventTime;
        UINT64 pDxgAdapter;
        UINT32 VidPNTargetId;                   //actual display device id
        UINT64 ScannedPhysicalAddress;
        UINT32 VidPNSourceId;                   //0, 1, 2 in Monitor Structure
        UINT32 FrameNumber;
        UINT64 FrameQPCTime;
        UINT64 hFlipDevice;
        UINT32 FlipType;
        UINT32 FlipFenceId;
    };

    struct EventEngineReport2
    {
        UINT32 EngineOrdinal;

        UINT64 GpuFrequency;                //calculated GpuFrequency
        UINT64 GpuTimeStamp;                //last GpuTimestamp
        UINT64 CpuTimeStamp;                //last CpuTimestamp

        UINT64 GpuFrequency0;               //first Gpu Frequency
        UINT64 GpuTimeStamp0;               //first GpuTimestamp
        UINT64 CpuTimeStamp0;               //first CpuTimestamp
        INT64 TimeAdjust;                   //Amount to adjust times based on correlation of DMA packet arrival. 

        UINT32 SubmissionsCount;
        Dma *pSubmissions;                  //array of SubmissionsCount Dma

        UINT32 GpuViewSubmissionsCount;     //GpuView compatible Data
        Dma *pGpuViewSubmissions;           //array of SubmissionsCount Dma

        UINT32 CalibrateEventCount;
        EventCalibrationEvent *pCalibrateEvents;    //array
        
        UINT64 pCommandQueue;               
    };

    //
    // For each node in each Adapter
    //
    struct EventNodeReport2
    {
        WCHAR FriendlyName[128];
        UINT32 NodeOrdinal;
        UINT32 EngineType;
        UINT32 EngineCount;
        EventEngineReport2 *pEngines;
    };

    struct EventDxgAdapterReport2
    {
        EventDpiReportAdapt DpiReportAdapt;
        EventPnp EventPnpInfo;
        UINT64 GpuFrequency;                        //calculated GpuFrequency
        INT64 TimeAdjust;                           //Amount to adjust times based on correlation of DMA packet arrival
        UINT64 pDxgAdapter;
        //
        UINT32 VSyncInterruptCount;
        EventVSyncInt *pVSyncInterrupt;             //array
        //
        UINT32 NodeCount;
        EventNodeReport2 *pNodes;                    //array
    };

    struct CoreActivityReport2
    {
        INT64 Time;                                 //
        UINT32 ProcessIndex;                        //
        UINT32 DeviceIndex;                         //
        UINT32 ThreadIndex;
        INT64 APISequenceNumber;
        UINT16 MarkerAPI;                           //api call
        UINT32 fApi : 1;
    };

    struct CommandListReport
    {
        UINT64 CommandListSequenceNumber;
        UINT32 APICount;
        UINT32 *pApiIndices;
    };

       
    struct CommandQueueReport
    {
        UINT32 CommandListCount;
        CommandListReport *pCommandList;
    };

    struct DeviceReport2
    {
        UINT64 pID3DDevice; // holding onto this for now to maintain functionality TODO: remove later
        UINT64 pIDXGIDevice;
        UINT64 Reserved;
        UINT32 ApiIndexCount;
        UINT32 *pApiIndices;      //Array of indicies into the ProcessReport1 pApi array
        UINT32 fD3D12Device : 1;
        UINT32 CommandQueueCount;
        CommandQueueReport *pCommandQueue;
    };

    struct ProcessReport2
    {
        WCHAR ImageName[128];                       //Name
        UINT64 hProcess;

        UINT32 ThreadCount;
        ThreadReport *pThreads;
        //

        UINT32 ApiCount;
        Api2 *pApi;                                  //array TODO: fix
        //
        UINT64 CpuFrequency;                        //CpuFrequency

        UINT32 DeviceCount;
        DeviceReport2 *pDevices;                    //array

        UINT32 ExtraCount;
        void *pExtras;
    };

    struct CoreReport2
    {
        UINT32 ActivityCount;
        CoreActivityReport2 *pActivity;
    };

    struct GputimingReport2
    {
        UINT32 DxgAdapterCount;
        EventDxgAdapterReport2 *pAdapters;           //array
        //
        UINT32 ProcessCount;
        ProcessReport2 *pProcesses;                  //array

        UINT32 CoresExtraCount;                     //includings diagnostic cores
        UINT32 CoresCount;
        CoreReport2 *pCores;

        //ToDo : Do the VidPNSources go here, or in EventDxgAdapterReport1?
        UINT32 VidPNSourceCount;
        VidPNSource *pVidPNSources;

        UINT32 ExtraCount;
        void *pExtras;
    };

    STDMETHOD(GetGputiming2) (
        __out GputimingReport2 **ppGputimingReport,
        __in Filters *pFilter
        ) PURE;
};

} // namespace XPerfAddIn


