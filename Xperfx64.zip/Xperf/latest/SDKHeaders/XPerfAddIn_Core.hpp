/*++

Copyright (c) 2003 Microsoft Corporation

Module Name:

    XPerfAddIn_Core.hpp

Abstract:

    XPerfCore Core AddIn interfaces

Author:

Revision History:

--*/

#pragma once

#include <XPerfCore.hpp>
#include <XPerf_ImageIdentityTypes.h>
#include <tdh.h>


namespace XPerfAddIn
{

// Common data structures and constants.

#define MINIMUM_RANK 0L
#define MAXIMUM_RANK LONG_MAX

struct Temporal
{
    TimeStamp StartTime;
    TimeStamp EndTime;

public:
    Temporal() : StartTime(TimeStamp::Min), EndTime(TimeStamp::Max) {}

    Temporal(const TimeStamp& _StartTime, const TimeStamp& _EndTime) : StartTime(_StartTime), EndTime(_EndTime) {}

    // virtual members
    TimeStampDelta get_Duration() const { return EndTime - StartTime; }
    __declspec(property(get=get_Duration)) TimeStampDelta Duration;
};

struct TemporalRange : public Temporal
{
    ULONG64         Base;
    ULONG64         Size;

    // virtual members
    ULONG64 get_Limit() const { return Base + Size; }
    __declspec(property(get=get_Limit)) ULONG64 Limit;
};

enum Proximity
{
    Exact,
    Past,
    Future
};


//
// Classic Event Descriptor
//

struct CLASSIC_EVENT_DESCRIPTOR
{
    union {
        ULONG       Version;
        struct {
            UCHAR   Type;
            UCHAR   Level;
            USHORT  Version;
        } Class;
    };
};

inline
bool operator == (const CLASSIC_EVENT_DESCRIPTOR& left, const CLASSIC_EVENT_DESCRIPTOR& right)
{
    return left.Version == right.Version;
}

inline
bool operator != (const CLASSIC_EVENT_DESCRIPTOR& left, const CLASSIC_EVENT_DESCRIPTOR& right)
{
    return !(left == right);
}

struct CClassicEventDescriptor : public CLASSIC_EVENT_DESCRIPTOR
{
    CClassicEventDescriptor(UCHAR _Type, UCHAR _Level, USHORT _Version)
    {
        Class.Type = _Type;
        Class.Level = _Level;
        Class.Version = _Version;
    }

    CClassicEventDescriptor(ULONG _FullVersion)
    {
        Version = _FullVersion;
    }

    CClassicEventDescriptor(const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor)
        : CLASSIC_EVENT_DESCRIPTOR(ClassicEventDescriptor)
    {
    }
};

inline
bool operator == (const EVENT_DESCRIPTOR& left, const EVENT_DESCRIPTOR& right)
{
    return left.Id == right.Id && left.Version == right.Version;
}

inline
bool operator != (const EVENT_DESCRIPTOR& left, const EVENT_DESCRIPTOR& right)
{
    return !(left == right);
}

struct CEventDescriptor : public EVENT_DESCRIPTOR
{
    CEventDescriptor(USHORT _Id, UCHAR _Version, UCHAR _Channel = 0, UCHAR _Level = 0, UCHAR _Opcode = 0, USHORT _Task = 0, ULONGLONG _Keyword = 0)
    {
        Id        = _Id;
        Version   = _Version;
        Channel   = _Channel;
        Level     = _Level;
        Opcode    = _Opcode;
        Task      = _Task;
        Keyword   = _Keyword;
    }

    CEventDescriptor(const EVENT_DESCRIPTOR& EventDescriptor)
        : EVENT_DESCRIPTOR(EventDescriptor)
    {
    }
};

//
// Trace Stats
//

MIDL_INTERFACE("907996ab-EB88-4806-AEB8-BF161C0D2DE2") 
ITraceStatsInfoSource : public IUnknown
{
    //
    // Crimson-style ETW events
    //

    struct EventStats
    {
        EVENT_DESCRIPTOR    EventDescriptor;
        ULONGLONG           TotalSize;
        ULONGLONG           Count;
    };

    typedef strided_adapter<const EventStats> StridedEventStats;

    struct ProviderStats
    {
        GUID                ProviderId;
        StridedEventStats   StridedEventStats;
        ULONGLONG           TotalSize;
        ULONGLONG           TotalCount;
    };

    typedef strided_adapter<const ProviderStats> StridedProviderStats;

    struct EventStatsSeq
    {
        StridedEventStats   StridedEventStats;
        ULONGLONG           TotalSize;
        ULONGLONG           TotalCount;
    };

    STDMETHOD (QueryStridedData) (
        __out StridedProviderStats* _StridedProviderStats,
        __out ULONGLONG& TotalCount,
        __out ULONGLONG& TotalSize
        ) const PURE;

    STDMETHOD (QueryProviderStats) (
        __deref_out const ProviderStats** _ProviderStats,
        __in  REFGUID ProviderId
        ) const PURE;

    STDMETHOD (QueryEventStatsById) (
        __out EventStatsSeq* _EventStatsSeq,
        __in  REFGUID ProviderId,
        __in  USHORT Id
        ) const PURE;

    HRESULT QueryEventStatsById (
        __out EventStatsSeq *_EventsStatsSeq, 
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor
        ) const
    {
        return QueryEventStatsById(_EventsStatsSeq, ProviderId, EventDescriptor.Id);
    }

    STDMETHOD (QueryEventStatsByIdVersion) (
        __out EventStatsSeq* _EventStatsSeq,
        __in  REFGUID ProviderId,
        __in  USHORT Id,
        __in  UCHAR Version
        ) const PURE;

    HRESULT QueryEventStatsByIdVersion (
        __out EventStatsSeq *_EventsStatsSeq, 
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor
        ) const
    {
        return QueryEventStatsByIdVersion(_EventsStatsSeq, ProviderId, EventDescriptor.Id, EventDescriptor.Version);
    }

    ULONGLONG QueryCount (
        __in  REFGUID ProviderId, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        const ProviderStats* pProviderStats;
        if (SUCCEEDED(QueryProviderStats(&pProviderStats, ProviderId))) {
            if (TotalSize) {
                *TotalSize = pProviderStats->TotalSize;
            }
            return pProviderStats->TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryCountById (
        __in  REFGUID ProviderId, 
        __in  USHORT Id, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        EventStatsSeq _EventStatsSeq;
        if (SUCCEEDED(QueryEventStatsById(&_EventStatsSeq, ProviderId, Id))) {
            if (TotalSize) {
                *TotalSize = _EventStatsSeq.TotalSize;
            }
            return _EventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryCountById (
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor,
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        return QueryCountById(ProviderId, EventDescriptor.Id, TotalSize);
    }

    ULONGLONG QueryCountByIdVersion (
        __in  REFGUID ProviderId, 
        __in  USHORT Id, 
        __in  UCHAR Version, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        EventStatsSeq _EventStatsSeq;
        if (SUCCEEDED(QueryEventStatsByIdVersion(&_EventStatsSeq, ProviderId, Id, Version))) {
            if (TotalSize) {
                *TotalSize = _EventStatsSeq.TotalSize;
            }
            return _EventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryCountByIdVersion (
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor,
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        return QueryCountByIdVersion(ProviderId, EventDescriptor.Id, EventDescriptor.Version, TotalSize);
    }

    //
    // Classic ETW events
    //

    struct ClassicEventStats
    {
        CLASSIC_EVENT_DESCRIPTOR    EventDescriptor;
        ULONGLONG                   TotalSize;
        ULONGLONG                   Count;
    };

    typedef strided_adapter<const ClassicEventStats> StridedClassicEventStats;

    struct ClassicEventGuidStats
    {
        GUID                        EventGuid;
        StridedClassicEventStats    StridedEventStats;
        ULONGLONG                   TotalSize;
        ULONGLONG                   TotalCount;
    };

    typedef strided_adapter<const ClassicEventGuidStats> StridedClassicEventGuidStats;

    struct ClassicEventStatsSeq
    {
        StridedClassicEventStats    StridedEventStats;
        ULONGLONG                   TotalSize;
        ULONGLONG                   TotalCount;
    };

    STDMETHOD (QueryStridedClassicData) (
        __out StridedClassicEventGuidStats* _StridedClassicEventGuidStats,
        __out ULONGLONG& TotalCount, 
        __out ULONGLONG& TotalSize
        ) const PURE;

    STDMETHOD (QueryClassicEventGuidStats) (
        __deref_out const ClassicEventGuidStats** _ClassicEventGuidStats,
        __in  REFGUID ClassicEventGuid
        ) const PURE;

    STDMETHOD (QueryClassicEventStatsByType) (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type
        ) const PURE;

    HRESULT QueryClassicEventStatsByType (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor
        ) const
    {
        return QueryClassicEventStatsByType(_ClassicEventsStatsSeq, ClassicEventGuid, ClassicEventDescriptor.Class.Type);
    }

    STDMETHOD (QueryClassicEventStatsByTypeVersion) (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type, 
        __in  USHORT Version
        ) const PURE;

    HRESULT QueryClassicEventStatsByTypeVersion (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor
        ) const
    {
        return QueryClassicEventStatsByTypeVersion(_ClassicEventsStatsSeq, ClassicEventGuid, ClassicEventDescriptor.Class.Type, ClassicEventDescriptor.Class.Version);
    }

    ULONGLONG QueryClassicCount (
        __in  REFGUID ClassicEventGuid, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        const ClassicEventGuidStats* pClassicEventGuidStats;
        if (SUCCEEDED(QueryClassicEventGuidStats(&pClassicEventGuidStats, ClassicEventGuid))) {
            if (TotalSize) {
                *TotalSize = pClassicEventGuidStats->TotalSize;
            }
            return pClassicEventGuidStats->TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryClassicCountByType (
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const 
    {
        ClassicEventStatsSeq _ClassicEventStatsSeq;
        if (SUCCEEDED(QueryClassicEventStatsByType(&_ClassicEventStatsSeq, ClassicEventGuid, Type))) {
            if (TotalSize) {
                *TotalSize = _ClassicEventStatsSeq.TotalSize;
            }
            return _ClassicEventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryClassicCountByType (
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        return QueryClassicCountByType(ClassicEventGuid, ClassicEventDescriptor.Class.Type, TotalSize);
    }

    ULONGLONG QueryClassicCountByTypeVersion (
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type, 
        __in  USHORT Version, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        ClassicEventStatsSeq _ClassicEventStatsSeq;
        if (SUCCEEDED(QueryClassicEventStatsByTypeVersion(&_ClassicEventStatsSeq, ClassicEventGuid, Type, Version))) {
            if (TotalSize) {
                *TotalSize = _ClassicEventStatsSeq.TotalSize;
            }
            return _ClassicEventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryClassicCountByTypeVersion (
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor, 
        __out_opt ULONGLONG *TotalSize = NULL
        ) const
    {
        return QueryClassicCountByTypeVersion(ClassicEventGuid, ClassicEventDescriptor.Class.Type, ClassicEventDescriptor.Class.Version, TotalSize);
    }
};


//
// Trace Stats
//

MIDL_INTERFACE("3FF8CC2E-A899-41DC-A328-35857194746C") 
ITraceStatsInfoSource2 : public ITraceStatsInfoSource
{
    //
    // Crimson-style ETW events
    //

    struct EventStats
    {
        EVENT_DESCRIPTOR    EventDescriptor;
        ULONGLONG           TotalSize;
        ULONGLONG           Count;
        ULONGLONG           TotalStorageSize;
    };

    typedef strided_adapter<const EventStats> StridedEventStats;

    struct ProviderStats
    {
        GUID                ProviderId;
        StridedEventStats   StridedEventStats;
        ULONGLONG           TotalSize;
        ULONGLONG           TotalCount;
        ULONGLONG           TotalStorageSize;
    };

    typedef strided_adapter<const ProviderStats> StridedProviderStats;

    struct EventStatsSeq
    {
        StridedEventStats   StridedEventStats;
        ULONGLONG           TotalSize;
        ULONGLONG           TotalCount;
        ULONGLONG           TotalStorageSize;
    };

    STDMETHOD (QueryStridedData) (
        __out StridedProviderStats* _StridedProviderStats,
        __out ULONGLONG& TotalCount,
        __out ULONGLONG& TotalSize,
        __out ULONGLONG& TotalStorageSize
        ) const PURE;

    STDMETHOD (QueryProviderStats) (
        __deref_out const ProviderStats** _ProviderStats,
        __in  REFGUID ProviderId
        ) const PURE;

    STDMETHOD (QueryEventStatsById) (
        __out EventStatsSeq* _EventStatsSeq,
        __in  REFGUID ProviderId,
        __in  USHORT Id
        ) const PURE;

    HRESULT QueryEventStatsById (
        __out EventStatsSeq *_EventsStatsSeq, 
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor
        ) const
    {
        return QueryEventStatsById(_EventsStatsSeq, ProviderId, EventDescriptor.Id);
    }

    STDMETHOD (QueryEventStatsByIdVersion) (
        __out EventStatsSeq* _EventStatsSeq,
        __in  REFGUID ProviderId,
        __in  USHORT Id,
        __in  UCHAR Version
        ) const PURE;

    HRESULT QueryEventStatsByIdVersion (
        __out EventStatsSeq *_EventsStatsSeq, 
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor
        ) const
    {
        return QueryEventStatsByIdVersion(_EventsStatsSeq, ProviderId, EventDescriptor.Id, EventDescriptor.Version);
    }

    ULONGLONG QueryCount (
        __in  REFGUID ProviderId, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        const ProviderStats* pProviderStats;
        if (SUCCEEDED(QueryProviderStats(&pProviderStats, ProviderId))) {
            if (TotalSize) {
                *TotalSize = pProviderStats->TotalSize;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = pProviderStats->TotalStorageSize;
            }
            return pProviderStats->TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryCountById (
        __in  REFGUID ProviderId, 
        __in  USHORT Id, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        EventStatsSeq _EventStatsSeq;
        if (SUCCEEDED(QueryEventStatsById(&_EventStatsSeq, ProviderId, Id))) {
            if (TotalSize) {
                *TotalSize = _EventStatsSeq.TotalSize;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = _EventStatsSeq.TotalStorageSize;
            }
            return _EventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryCountById (
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor,
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        return QueryCountById(ProviderId, EventDescriptor.Id, TotalSize, TotalStorageSize);
    }

    ULONGLONG QueryCountByIdVersion (
        __in  REFGUID ProviderId, 
        __in  USHORT Id, 
        __in  UCHAR Version, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        EventStatsSeq _EventStatsSeq;
        if (SUCCEEDED(QueryEventStatsByIdVersion(&_EventStatsSeq, ProviderId, Id, Version))) {
            if (TotalSize) {
                *TotalSize = _EventStatsSeq.TotalSize;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = _EventStatsSeq.TotalStorageSize;
            }
            return _EventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryCountByIdVersion (
        __in  REFGUID ProviderId, 
        __in  const EVENT_DESCRIPTOR& EventDescriptor,
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        return QueryCountByIdVersion(ProviderId, EventDescriptor.Id, EventDescriptor.Version, TotalSize, TotalStorageSize);
    }

    //
    // Classic ETW events
    //

    struct ClassicEventStats
    {
        CLASSIC_EVENT_DESCRIPTOR    EventDescriptor;
        ULONGLONG                   TotalSize;
        ULONGLONG                   Count;
        ULONGLONG                   TotalStorageSize;
    };

    typedef strided_adapter<const ClassicEventStats> StridedClassicEventStats;

    struct ClassicEventGuidStats
    {
        GUID                        EventGuid;
        StridedClassicEventStats    StridedEventStats;
        ULONGLONG                   TotalSize;
        ULONGLONG                   TotalCount;
        ULONGLONG                   TotalStorageSize;
    };

    typedef strided_adapter<const ClassicEventGuidStats> StridedClassicEventGuidStats;

    struct ClassicEventStatsSeq
    {
        StridedClassicEventStats    StridedEventStats;
        ULONGLONG                   TotalSize;
        ULONGLONG                   TotalCount;
        ULONGLONG                   TotalStorageSize;
    };

    STDMETHOD (QueryStridedClassicData) (
        __out StridedClassicEventGuidStats* _StridedClassicEventGuidStats,
        __out ULONGLONG& TotalCount, 
        __out ULONGLONG& TotalSize,
        __out ULONGLONG& TotalStorageSize
        ) const PURE;

    STDMETHOD (QueryClassicEventGuidStats) (
        __deref_out const ClassicEventGuidStats** _ClassicEventGuidStats,
        __in  REFGUID ClassicEventGuid
        ) const PURE;

    STDMETHOD (QueryClassicEventStatsByType) (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type
        ) const PURE;

    HRESULT QueryClassicEventStatsByType (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor
        ) const
    {
        return QueryClassicEventStatsByType(_ClassicEventsStatsSeq, ClassicEventGuid, ClassicEventDescriptor.Class.Type);
    }

    STDMETHOD (QueryClassicEventStatsByTypeVersion) (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type, 
        __in  USHORT Version
        ) const PURE;

    HRESULT QueryClassicEventStatsByTypeVersion (
        __out ClassicEventStatsSeq *_ClassicEventsStatsSeq, 
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor
        ) const
    {
        return QueryClassicEventStatsByTypeVersion(_ClassicEventsStatsSeq, ClassicEventGuid, ClassicEventDescriptor.Class.Type, ClassicEventDescriptor.Class.Version);
    }

    ULONGLONG QueryClassicCount (
        __in  REFGUID ClassicEventGuid, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        const ClassicEventGuidStats* pClassicEventGuidStats;
        if (SUCCEEDED(QueryClassicEventGuidStats(&pClassicEventGuidStats, ClassicEventGuid))) {
            if (TotalSize) {
                *TotalSize = pClassicEventGuidStats->TotalSize;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = pClassicEventGuidStats->TotalStorageSize;
            }
            return pClassicEventGuidStats->TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryClassicCountByType (
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const 
    {
        ClassicEventStatsSeq _ClassicEventStatsSeq;
        if (SUCCEEDED(QueryClassicEventStatsByType(&_ClassicEventStatsSeq, ClassicEventGuid, Type))) {
            if (TotalSize) {
                *TotalSize = _ClassicEventStatsSeq.TotalSize;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = _ClassicEventStatsSeq.TotalStorageSize;
            }
            return _ClassicEventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryClassicCountByType (
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        return QueryClassicCountByType(ClassicEventGuid, ClassicEventDescriptor.Class.Type, TotalSize, TotalStorageSize);
    }

    ULONGLONG QueryClassicCountByTypeVersion (
        __in  REFGUID ClassicEventGuid, 
        __in  UCHAR Type, 
        __in  USHORT Version, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        ClassicEventStatsSeq _ClassicEventStatsSeq;
        if (SUCCEEDED(QueryClassicEventStatsByTypeVersion(&_ClassicEventStatsSeq, ClassicEventGuid, Type, Version))) {
            if (TotalSize) {
                *TotalSize = _ClassicEventStatsSeq.TotalSize;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = _ClassicEventStatsSeq.TotalStorageSize;
            }
            return _ClassicEventStatsSeq.TotalCount;
        } else {
            if (TotalSize) {
                *TotalSize = 0ui64;
            }
            if (TotalStorageSize) {
                *TotalStorageSize = 0ui64;
            }
            return 0ui64;
        }
    }

    ULONGLONG QueryClassicCountByTypeVersion (
        __in  REFGUID ClassicEventGuid, 
        __in  const CLASSIC_EVENT_DESCRIPTOR& ClassicEventDescriptor, 
        __out_opt ULONGLONG *TotalSize = NULL, 
        __out_opt ULONGLONG *TotalStorageSize = NULL
        ) const
    {
        return QueryClassicCountByTypeVersion(ClassicEventGuid, ClassicEventDescriptor.Class.Type, ClassicEventDescriptor.Class.Version, TotalSize, TotalStorageSize);
    }
};


//
// EventMetadata Infosource
//

MIDL_INTERFACE("E32C2EBA-9F9D-4CDC-BD8D-DEA86AF431D0")
IEventMetadataInfoSource : public IUnknown
{
    STDMETHOD(GetEventInformation)(
        __in  REFGUID ProviderId,
        __in  EVENT_DESCRIPTOR const& EventDescriptor,
        __deref_out_bcount(*pcbTraceEventInfo) TRACE_EVENT_INFO const** ppTraceEventInfo,
        __out ULONG* pcbTraceEventInfo
        ) PURE;

    STDMETHOD(GetEventMapInformation)(
        __in  REFGUID ProviderId,
        __in  LPCWSTR MapName,
        __deref_out_bcount(*pcbEventMapInfo) EVENT_MAP_INFO const** ppEventMapInfo,
        __out ULONG* pcbEventMapInfo
        ) PURE;
};


//
// Process
//

MIDL_INTERFACE("6074D0BF-587E-4c4f-B4F5-126FF9BFABFA") 
IProcessInfoSource : public IUnknown
{
    //
    // Data structure returned by the query methods:
    //
    struct ProcessData : public Temporal
    {
        ULONG64         UniqueProcessKey;   // unique process id used in MM
        const WCHAR    *ImageName;
        ULONG           ProcessId;
        ULONG           ParentId;
        ULONG           SessionId;
        NTSTATUS        ExitStatus;
        const SID*      UserSid;
    };

    //
    // Constants identify usage purposes of virtual address ranges
    //
    enum MemoryUsageType
    {
        MT_PROCESS_STACK = 1,
        MT_PROCESS_IMAGE,
        MT_PROCESS_VM,
        MT_PROCESS_HEAP,
        MT_PROCESS_RESERVED,
        MT_PROCESS_MAX = MT_PROCESS_RESERVED,
        MT_PROCESS_MAPFILE,
        MT_PROCESS_PFMAPPEDSECTION,
        MT_PROCESS_TEB
    };

    struct ThreadData;

    struct VARange : public TemporalRange
    {
        union {
            const ProcessData *Process;
            const ThreadData *Thread;   // for kernel stack, we put thread info here.
        };
        ULONG           UsageType;
    };

    struct ThreadData : public VARange
    {
        ULONG64         StartAddr;
        ULONG64         StackBase;
        ULONG64         StackLimit;
        ULONG64         TebBase;
        ULONG           ProcessId;
        ULONG           ThreadId;
    };

    struct ImageData : public VARange
    {
        ImageData()
        : DefaultBase(0)
        , ImageName(NULL)
        , ProcessId(0)
        , TimeDateStamp(0)
        , CheckSum(0)
        {
        }

        ULONG64         DefaultBase;
        const PathNode *ImageName;
        ULONG           ProcessId;
        ULONG           TimeDateStamp;
        ULONG           CheckSum;
    };

    struct MapFileData : public VARange
    {
        MapFileData()
        : FileOffset(0)
        , StartingProtoPte(0)
        , FileName(NULL)
        {
        }

        ULONG64 FileOffset;
        union {
            ULONG64 StartingProtoPte;
            ULONG64 FileKey;
        };
        const PathNode *FileName;        
    };

    /*

    Query methods:

    All objects, process, thread, image, and VA range, have life times as
    indicated by the Temporal structure.  StartTime of TimeStamp::Min and EndTime
    of TimeStamp::Max or TimeStamp::End mean respectively that the object exists
    before the start of the trace and after the end of the trace.  If an object
    does not exists exactly at the given time, the optional parameter "option"
    allows query for the object that exists either before or after the given
    time.  The optional parameter is ignored if an exact match is found.

    For query methods that require a buffer to return pointers to multiple
    objects, e.g., QueryProcesses(), a parameter of type SIZE_T& is used to
    pass in the size of the caller-supplied buffer on input, and return the
    required size on output.

    */

    /*

    Description:

        Query for process info by UniqueProcessKey and time.  MM uses this to
        uniquely identify processes in some of its data structures.

    Arguments:

        TS:     Time stamp, query for process with given pross id at this time.
        UniqueProcessKey: UniqueProcessKey.
        option: Optional. See description above.

    Return Value:

        A pointer to the ProcessData structure which contains the information
        about the process.  NULL if no process is found with given pid at the
        given time.
    */

    STDMETHOD_(_Ret_maybenull_ const ProcessData*, QueryProcessByUniqueProcessKey) (
        __in  const TimeStamp& TS,
        __in  const ULONG64 UniqueProcessKey,
        __in  Proximity option = Exact
        ) const PURE;

    /*

    Description:

        Query for process info by Process ID (PID) and time

    Arguments:

        TS:     Time stamp, query for process with given pross id at this time.
        pid:    Process ID of the process.
        option: Optional. See description above.

    Return Value:

        A pointer to the ProcessData structure which contains the information
        about the process.  NULL if no process is found with given pid at the
        given time.
    */
    STDMETHOD_(_Ret_maybenull_ const ProcessData*, QueryProcess) (
        __in  const TimeStamp& TS,
        __in  const ULONG pid,
        __in  Proximity option = Exact
        ) const PURE;

    /*

    Description:

        Query for processes whose life spans overlap with the time interval
        given by the parameters StartTime and EndTime.

    Arguments:

        Buffer:     Caller-supplied buffer to receive query results
        NumEntries: On input, the size of Buffer, on output, the required size
                    for the query results, both in number of entries.
        StartTime:  Start time of the interval
        EndTime:    End time of the interval

    Return Value:

        S_OK:       if either Buffer is NULL or the call is success.
        XPERF_E_BUFFER_TOO_SMALL   Buffer size is too small.
                    required size is returned in NumEntries.
    */
    STDMETHOD (QueryProcesses) (
        __out_ecount_part_opt(NumEntries, NumEntries) const ProcessData *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    /*

    Description:

        Query for thread info by Thread ID (TID) and time

    Arguments:

        TS:     Time stamp, query for the thread with the given thread id at
                this time.
        tid:    Thread ID of the thread.
        option: Optional. See description above.

    Return Value:

        A pointer to the ProcessData structure which contains the information
        about the process.  NULL if no process is found with given pid at the
        given time.
    */
    STDMETHOD_(_Ret_maybenull_ const ThreadData*, QueryThread) (
        __in  const TimeStamp& TS,
        __in  const ULONG tid,
        __in  Proximity option = Exact
        ) const PURE;

    /*

    Description:

        Query for threads whose life spans overlap with the time interval
        given by the parameters StartTime and EndTime.

    Arguments:

        Buffer:     Caller-supplied buffer to receive query results
        NumEntries: On input, the size of Buffer, on output, the required size
                    for the query results, both in number of entries.
        StartTime:  Start time of the interval
        EndTime:    End time of the interval

    Return Value:

        S_OK:       if either Buffer is NULL or the call is success.
        XPERF_E_BUFFER_TOO_SMALL   Buffer size is too small.
                    required size is returned in NumEntries.
    */
    STDMETHOD (QueryThreads) (
        __out_ecount_part_opt(NumEntries, NumEntries) const ThreadData *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    /*

    Description:

        Query for the Image loaded into the address space of the given process
        that contains the given virtual address at the given time.

    Arguments:

        pProcessData: Pointer to a ProcessData structure that identifies the
                process.
        TS:     Time stamp, query for the image that contains the virtual
                address at this time.
        va:     virtual address.
        option: Optional. See description above.

    Return Value:

        Pointer to ImageData structure.  NULL if no image found at the given
        address and time.
    */
    STDMETHOD_(_Ret_maybenull_ const ImageData*, QueryImage) (
        __in  const ProcessData* pProcessData,
        __in  const TimeStamp& TS,
        __in  const ULONG64 va,
        __in  Proximity option = Exact
        ) const PURE;

    /*

    Description:

        Query for virtual address range in the address space of the given process
        that contains the given virtual address at the given time.

    Arguments:

        pProcessData: Pointer to a ProcessData structure that identifies the
                process.
        TS:     Time stamp, query for address range that contains the virtual
                address at this time.
        va:     virtual address.
        option: Optional. See description above.

    Return Value:

        Pointer to ImageData structure.  NULL if no image found at the given
        address and time.
    */
    STDMETHOD_(_Ret_maybenull_ const VARange*, QueryVARange) (
        __in  const ProcessData* pProcessData,
        __in  const TimeStamp& TS,
        __in  const ULONG64 va,
        __in  Proximity option = Exact
        ) const PURE;

    /*

    Description:

        Query for Images loaded into the address space of given process whose life
        spans overlap with the time interval given by the parameters StartTime
        and EndTime.

    Arguments:

        Buffer:     Caller-supplied buffer to receive query results
        NumEntries: On input, the size of Buffer, on output, the required size
                    for the query results, both in number of entries.
        pProcessData: Pointer to a ProcessData structure that identifies the
                    process whose loaded images are queried for.
        StartTime:  Start time of the interval
        EndTime:    End time of the interval

    Return Value:

        S_OK:       if either Buffer is NULL or the call is success.
        XPERF_E_BUFFER_TOO_SMALL   Buffer size is too small.
                    required size is returned in NumEntries.
    */
    STDMETHOD (QueryImages) (
        __out_ecount_part_opt(NumEntries, NumEntries) const ImageData *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const ProcessData* pProcessData,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD (QueryThreadsByProcess) (
        __out_ecount_part_opt(NumEntries, NumEntries) const ThreadData *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const ProcessData* pProcessData,
        __in  const TimeStamp StartTime = TimeStamp::Min,
        __in  const TimeStamp EndTime = TimeStamp::Max
        ) const PURE;

    STDMETHOD (QueryVARanges) (
        __out_ecount_part_opt(NumEntries, NumEntries) const VARange *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const ProcessData* pProcessData,
        __in  const TimeStamp StartTime = TimeStamp::Min,
        __in  const TimeStamp EndTime = TimeStamp::Max
        ) const PURE;

    const ProcessData* QueryProcess(
        __in  const TimeStamp& TS,
        __in  const ULONG64 UniqueProcessKey,
        __in  Proximity option = Exact
        ) const
       {
            return QueryProcessByUniqueProcessKey(TS, UniqueProcessKey, option);
       }

   HRESULT QueryThreads(
        __out_ecount_part_opt(NumEntries, NumEntries) const ThreadData *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const ProcessData* pProcessData,
        __in  const TimeStamp StartTime = TimeStamp::Min,
        __in  const TimeStamp EndTime = TimeStamp::Max
        )
        {
            return QueryThreadsByProcess(Buffer, NumEntries, pProcessData, StartTime, EndTime);
        }

    /*

    Description:

        Returns SystemProcess.  Used for queries for images or VA ranges in
        kernel space

    */
    STDMETHOD_(_Ret_maybenull_ const ProcessData*, SystemProcess) () const PURE;
};


//
// Process Command Line
//

MIDL_INTERFACE("D095651C-D8E5-4746-AAA2-CF4A39139494") 
IProcessCommandLineInfoSource : public IUnknown
{
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, QueryProcessCommandLine)(
        __in  const IProcessInfoSource::ProcessData* pProcess
        ) const PURE;
};

//
// Modern Application Information
//

MIDL_INTERFACE("2A4C6D49-077B-48C8-9126-418B5961D766") 
IModernApplicationInfoSource : public IUnknown
{
    struct ModernApplicationData
    {
        LPCWSTR PackageFullName; // e.g. microsoft.test.sudoku_1.0.0.0_neutral_neutral_8wekyb3d8bbwe 
        LPCWSTR PackageRelativeApplicationId; // an identifier for this application that is relative to its package name, e.g. Microsoft.Test.Sudoku 
        LPCWSTR FriendlyName;

        ModernApplicationData()
            : PackageFullName()
            , PackageRelativeApplicationId()
            , FriendlyName()
        {}
    };

    STDMETHOD_(_Ret_maybenull_ const ModernApplicationData*, QueryModernApplicationData)(
        __in  const IProcessInfoSource::ProcessData* pProcess
        ) const PURE;
};

//
// Process, Thread and Image Event Anchors
//

MIDL_INTERFACE("11E0DCA4-FF5D-4054-B938-3C0DE9EE0C4A") 
IAnchorInfoSource : public IUnknown
{
    struct AnchorData 
    {
        TimeStamp StartAnchorTime;
        TimeStamp EndAnchorTime;
        ULONG     StartAnchorThreadId;
        ULONG     EndAnchorThreadId;

        AnchorData() 
            : StartAnchorTime(TimeStamp::Min)
            , EndAnchorTime(TimeStamp::Max) 
            , StartAnchorThreadId(0)
            , EndAnchorThreadId(0)
        {}

    };

    STDMETHOD_(_Ret_maybenull_ const AnchorData*, QueryAnchorDataForProcess)(
        __in  const IProcessInfoSource::ProcessData* pProcessData
        ) const PURE;

    STDMETHOD_(_Ret_maybenull_ const AnchorData*, QueryAnchorDataForThread)(
        __in  const IProcessInfoSource::ThreadData* pThreadData
        ) const PURE;

    STDMETHOD_(_Ret_maybenull_ const AnchorData*, QueryAnchorDataForImage)(
        __in  const IProcessInfoSource::ImageData* pImageData
        ) const PURE;

    _Ret_maybenull_ const AnchorData* QueryAnchorData(
        __in  const IProcessInfoSource::ProcessData* pProcessData
        ) const
        {
            return QueryAnchorDataForProcess(pProcessData);
        }

    _Ret_maybenull_ const AnchorData* QueryAnchorData(
        __in  const IProcessInfoSource::ThreadData* pThreadData
        ) const
        {
            return QueryAnchorDataForThread(pThreadData);
        }

    _Ret_maybenull_ const AnchorData* QueryAnchorData(
        __in  const IProcessInfoSource::ImageData* pImageData
        ) const
        {
            return QueryAnchorDataForImage(pImageData);
        }
};

MIDL_INTERFACE("0EE95EA3-7BAD-4257-A06A-0754EBDF196E")
IImageLoadDependenceInfoSource : public IUnknown
{
    struct ImageLoadDependenceData
    {
        IProcessInfoSource::ImageData* DependentImage;
        ULONG                          LoadReason;

        ImageLoadDependenceData()
            : DependentImage(NULL)
            , LoadReason(ULONG_MAX)
        {}
    };

    STDMETHOD_(_Ret_maybenull_ const ImageLoadDependenceData*, QueryImageLoadDependenceData)(
        __in  const IProcessInfoSource::ImageData* pImageData
        ) const PURE;

    STDMETHOD_(_Ret_notnull_ LPCWSTR, QueryImageLoadDependenceReasonString)(
        __in  const ULONG LoadReason
        ) const PURE;
};

MIDL_INTERFACE("6B7C2E97-2B6D-4cf2-A7D9-9C7A23F955D9")
IImageSigningInformationInfoSource : public IUnknown
{
    enum ImageSignatureType: UCHAR
    {
        ImageSignatureType_None = 0,
        ImageSignatureType_Embedded,
        ImageSignatureType_Cache,
        ImageSignatureType_CatalogCached,
        ImageSignatureType_CatalogNotCached,
        ImageSignatureType_CatalogHint,
        ImageSignatureType_Count
    };

    struct ImageSigningInformationData
    {
        ImageSignatureType SignatureType;
        UCHAR SignatureLevel;

        ImageSigningInformationData()
            : SignatureType(ImageSignatureType_None)
            , SignatureLevel(0)
        {}
    };

    static
    LPCWSTR
    GetSignatureTypeName (
        ImageSignatureType SignatureType
        )
    {
        static LPCWSTR const SignatureTypeNames[] = 
        {
            L"None",
            L"Embedded",
            L"Cache",
            L"CatalogCached",
            L"CatalogNotCached",
            L"CatalogHint"
        };

        if (SignatureType < ARRAYSIZE(SignatureTypeNames)) 
        {
            return SignatureTypeNames[SignatureType];
        } 
        else 
        {
            return L"Unknown";
        }
    }

    static
    LPCWSTR
    GetSignatureLevelName (
        UCHAR SignatureLevel
        )
    {
        static LPCWSTR const SignatureLevelNames[] = 
        {
            L"Unchecked", 
            L"Unsigned",
            L"Custom_0",
            L"Custom_1",
            L"Authenticode",
            L"Custom_2",
            L"Store",
            L"AntiMalware",
            L"Microsoft",
            L"Custom_4",
            L"Custom_5",
            L"DynamicCodegen",
            L"Windows",
            L"Custom_7",
            L"WindowsTCB",
            L"Custom_6",
        };

        if (SignatureLevel < ARRAYSIZE(SignatureLevelNames)) 
        {
            return SignatureLevelNames[SignatureLevel];
        } 
        else 
        {
            return L"Unknown";
        }
    }


    STDMETHOD_(_Ret_maybenull_ const ImageSigningInformationData*, QueryImageSigningInformationData)(
        __in  const IProcessInfoSource::ImageData* pImageData
        ) const PURE;
};

MIDL_INTERFACE("2210C4ED-58E9-4F2C-A3AF-FD33BB2E31D2") 
IJITInfoSource : public IUnknown
{
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetFullMethodName)(
        __in  const IProcessInfoSource::ImageData* pProcessImageData,
        __in  ULONG64 Address
        ) const PURE;

    STDMETHOD_(BOOL, HasJITImages)(
        ) const PURE;

    STDMETHOD(GetManagedPdbInfo)(
        __out GUID& pdbSignature,
        __out UINT32& pdbAge,
        __in const IProcessInfoSource::ImageData* pProcessImageData
        ) const PURE;

    STDMETHOD(GetManagedToken)(
        __out UINT32& token,
        __in const IProcessInfoSource::ImageData* pProcessImageData
        ) const PURE;

    STDMETHOD(GetILOffset)(
        __out UINT32& ilOffset,
        __in UINT32 nativeOffset,
        __in const IProcessInfoSource::ImageData* pProcessImageData
        ) const PURE;
};

MIDL_INTERFACE("8978F986-E8B0-440E-B201-8F0254BFF8C3")
IDynamicSourceInfoSource : public IUnknown
{
    STDMETHOD(GetLineNumber)(
    __out UINT32& lineNumber,
    __in const IProcessInfoSource::ImageData* pProcessImageData
    ) const PURE;

    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetSourceFileName)(
        __in  const IProcessInfoSource::ImageData* pProcessImageData
        ) const PURE;

};

//
// Hierarchy: All Processes / Process / Thread
//

MIDL_INTERFACE("89254C81-B177-416C-BC49-89095B5D8307")
IProcessThreadHierarchy : public IUnknown
{
    STDMETHOD(GetProcessNode)(
        __deref_out const PathNode** ppPathNode,
        __in_opt const IProcessInfoSource::ProcessData* pProcess
        ) PURE;

    STDMETHOD(GetThreadNode)(
        __deref_out const PathNode** ppPathNode,
        __in_opt const IProcessInfoSource::ThreadData* pThread
        ) PURE;
};


//
// Hierarchy: All Processes / Process Name / Process / Thread
//

MIDL_INTERFACE("6693C860-CE34-46CF-858C-C9382D9117C1")
IProcessNameProcessThreadHierarchy : public IProcessThreadHierarchy
{
};


//
// Filename
//

MIDL_INTERFACE("329E58BE-7CAD-42EA-8C39-F2388FD46D1D") 
IFilenameInfoSource : public IUnknown
{
    struct FileNameData : public Temporal
    {
        ULONG64         m_FileObject;
        const PathNode *m_PathNode;
    };

    STDMETHOD (QueryFileNames) (
        __out_ecount_part_opt(NumEntries, NumEntries) const FileNameData *Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(_Ret_maybenull_ const PathNode *, QueryFileName) (
        __in  const TimeStamp& Time,
        __in  ULONG64 FileObject,
        __in  Proximity Option = Exact
    ) = 0;
};


//
// IDiskIOCountsInfoSource
//

MIDL_INTERFACE("CF679CF5-05E4-46FE-8E5C-019B5481BD41")
IDiskIOCountsInfoSource : public IUnknown
{
    struct DiskIOCountsData
    {
        ULONGLONG   Reads;
        ULONGLONG   Writes;
        ULONGLONG   Flushes;

        ULONGLONG   GetTotal() const 
        {
            return Reads + Writes + Flushes;
        }
        __declspec(property(get=GetTotal)) ULONGLONG Total;
    };

    typedef strided_adapter<DiskIOCountsData> StridedDiskIOCountsDatas;
    
    struct DiskIOInitCountsData
    {
        ULONGLONG   ReadInits;
        ULONGLONG   WriteInits;
        ULONGLONG   FlushInits;

        ULONGLONG   GetTotalInits() const 
        {
            return ReadInits + WriteInits + FlushInits;
        }
        __declspec(property(get=GetTotalInits)) ULONGLONG TotalInits;
    };

    STDMETHOD(QueryStridedData)(
        __out StridedDiskIOCountsDatas* pStridedDiskIOCountsDatas
        ) PURE;

    STDMETHOD(QueryInitData)(
        __out DiskIOInitCountsData* pDiskIOInitCountsData
        ) PURE;
};


//
// IDiskIOInitInfoSource
//

MIDL_INTERFACE("C540729B-58F5-4060-8D26-33824446736F")
IDiskIOInitInfoSource : public IUnknown
{
    struct DiskIOInitData
    {
        TimeStamp InitTime;
    };

    typedef strided_adapter<const DiskIOInitData> StridedDiskIOInitDatas;
    
    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(NumDisks, NumDisks) StridedDiskIOInitDatas* pStridedDiskIOInitDatas,
        __inout SIZE_T& NumDisks,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};


//
// IDiskIOInitInfoSource2
//

MIDL_INTERFACE("6FF21031-81F0-4d47-B139-43AB343C932F")
IDiskIOInitInfoSource2 : public IDiskIOInitInfoSource
{
    struct DiskIOInitData2 : DiskIOInitData
    {
        ULONG     ThreadId; // CurrentThreadId
        
    public:

        DiskIOInitData2()
            : DiskIOInitData()
            , ThreadId(ULONG_MAX)
        {
        }
    };

    typedef strided_adapter<const DiskIOInitData2> StridedDiskIOInitDatas2;
    
    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(NumDisks, NumDisks) StridedDiskIOInitDatas2* pStridedDiskIOInitDatas,
        __inout SIZE_T& NumDisks,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;
};


//
// IDiskIOInitInfoSource3
//

MIDL_INTERFACE("766DFDFD-511A-47E3-A7B9-56EDDFAAD0AE")
IDiskIOInitInfoSource3 : public IDiskIOInitInfoSource2
{
    struct DiskIOInitData3 : DiskIOInitData2
    {
        ULONG     Processor;

    public:

        DiskIOInitData3()
            : DiskIOInitData2()
            , Processor()
        {
        }
    };

    typedef strided_adapter<const DiskIOInitData3> StridedDiskIOInitDatas3;
    
    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(NumDisks, NumDisks) StridedDiskIOInitDatas3* pStridedDiskIOInitDatas,
        __inout SIZE_T& NumDisks,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) CONST PURE;
};


//
// Disk I/O
//

MIDL_INTERFACE("3E8322A6-431E-4827-8C69-02F24415BEF8")
IDiskIOInfoSource : public IUnknown
{
    enum IOType
    {
        DISKIO_TYPE_READ        = 0,
        DISKIO_TYPE_WRITE       = 1,
        DISKIO_TYPE_FLUSH       = 2,
        DISKIO_TYPE_MAX
    };

    enum SourceFlags
    {
        DISKIO_SOURCE_ORIGINAL  = 1,
        DISKIO_SOURCE_VOLSNAP   = 2,
        DISKIO_SOURCE_ECACHE    = 4,
        DISKIO_SOURCE_WRITELOG  = 8,
    };

    enum IOPriority
    {
        DISKIO_PRIORITY_NOTSET      = 0,
        DISKIO_PRIORITY_VERYLOW     = 1,
        DISKIO_PRIORITY_LOW         = 2,
        DISKIO_PRIORITY_NORMAL      = 3,
        DISKIO_PRIORITY_HIGH        = 4,
        DISKIO_PRIORITY_CRITICAL    = 5,
        DISKIO_PRIORITY_RESERVED0   = 6,
        DISKIO_PRIORITY_RESERVED1   = 7,
        DISKIO_PRIORITY_MAX
    };

    struct DiskIOData
    {
        TimeStamp       InitTime;
        TimeStamp       CompleteTime;
        TimeStampDelta  DiskServiceTime;
        ULONGLONG       ByteOffset;
        ULONG64         FileObject;
        ULONG64         Irp;
        const IProcessInfoSource::ThreadData *Thread; // IssuingThread
        const PathNode *FilePath;
        ULONG           Size;
        UCHAR           IOType;
        UCHAR           SourceFlags;
        USHORT          Reserved0;
        ULONG           CompletionProcessor;
        ULONG           DiskNumber;
        ULONG           IrpFlags;
        ULONG           NumOutstandingIOs;
        ULONG           NumIOsStartedBeforeEndedBefore;
        ULONG           NumIOsStartedAfterEndedBefore;
        ULONG           NumOutstandingIOsAtCompletionTime;
        
        // GetIssuingThreadId
        ULONG GetThreadId() const
        {
            return Thread ? Thread->ThreadId : ULONG_MAX;
        }
        __declspec(property(get=GetThreadId)) ULONG ThreadId; // IssuingThreadId

        ULONG GetNumIOsStartedBeforeEndedAfter() const
        {
            return NumOutstandingIOs - NumIOsStartedBeforeEndedBefore;
        }
        __declspec(property(get=GetNumIOsStartedBeforeEndedAfter)) ULONG NumIOsStartedBeforeEndedAfter;

        UCHAR GetIOPriority() const
        {
            return (UCHAR)((IrpFlags >> 17) & 0x7);
        }
        __declspec(property(get=GetIOPriority)) UCHAR IOPriority;

        TimeStampDelta GetElapsedTime() const
        {
            return CompleteTime - InitTime;
        }
        __declspec(property(get=GetElapsedTime)) TimeStampDelta ElapsedTime;
    
    public:
        DiskIOData()
            : InitTime()
            , CompleteTime()
            , DiskServiceTime()
            , ByteOffset()
            , FileObject()
            , Irp()
            , Thread()
            , FilePath()
            , Size()
            , IOType()
            , SourceFlags()
            , CompletionProcessor()
            , Reserved0()
            , DiskNumber()
            , IrpFlags()
            , NumOutstandingIOs()
            , NumIOsStartedBeforeEndedBefore()
            , NumIOsStartedAfterEndedBefore()
            , NumOutstandingIOsAtCompletionTime()
        {
        }
    };

    typedef BOOL (WINAPI *pfnFilter)(__in const DiskIOData&, __in_opt PVOID Context);

    struct PerDiskData
    {
        TimeStampDelta  IOTime;
        ULONG           IOCounts;
        ULONG           IOSize;
        TimeStampDelta  DiskServiceTime;
        ULONG           ReadCounts;
        ULONG           ReadSize;
        TimeStampDelta  ReadServiceTime;
        ULONG           WriteCounts;
        ULONG           WriteSize;
        TimeStampDelta  WriteServiceTime;
        ULONG           FlushCounts;
        ULONG           FlushSize;
        TimeStampDelta  FlushServiceTime;
        ULONG           DiskNumber;

        PerDiskData()
            : IOTime()
            , IOCounts()
            , IOSize()
            , DiskServiceTime()
            , ReadCounts()
            , ReadServiceTime()
            , WriteCounts()
            , WriteSize()
            , WriteServiceTime()
            , FlushCounts()
            , FlushSize()
            , FlushServiceTime()
            , DiskNumber()
        {
        }
    };

    struct PerFileData
    {
        TimeStampDelta  IOTime;
        ULONG           IOCounts;
        ULONG           IOSize;
        TimeStampDelta  DiskServiceTime;
        ULONG           ReadCounts;
        ULONG           ReadSize;
        TimeStampDelta  ReadServiceTime;
        ULONG           WriteCounts;
        ULONG           WriteSize;
        TimeStampDelta  WriteServiceTime;
        const PathNode *FilePath;

        PerFileData()
            : IOTime()
            , IOCounts()
            , IOSize()
            , DiskServiceTime()
            , ReadCounts()
            , ReadSize()
            , ReadServiceTime()
            , WriteCounts()
            , WriteSize()
            , WriteServiceTime()
            , FilePath()
        {
        }
    };

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;

    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const DiskIOData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    typedef strided_adapter<const DiskIOData> StridedDiskIODatas;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumDisks, NumDisks) StridedDiskIODatas Data[],
        __inout SIZE_T& NumDisks,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    /*

    returns counts of disk IO in intervals with length given by Resolution.
    NumEntries returns the required number of entries.  For best performance,
    make NumEntries = NumDisks * DISKIO_TYPE_MAX * NumIntervals,
    where NumIntervals = ceil ((QueryEnd - QueryStart) / Resolution)

    */
    STDMETHOD (QueryCount) (
        __out_ecount_part_opt(NumEntries, NumEntries) ULONG Counts[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    /*

    returns disk utilization in intervals with length given by Resolution.
    NumEntries returns the required number of entries.  For best performance,
    make NumEntries = NumDisks * NumIntervals, where
    NumIntervals = ceil ((QueryEnd - QueryStart) / Resolution)

    */
    STDMETHOD (QueryUtilization) (
        __out_ecount_part_opt(NumEntries, NumEntries) FLOAT Utils[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd
    ) const PURE;

    /*

    returns counts of disk IO for each priority in intervals with length given by Resolution.
    NumEntries returns the required number of entries.  For best performance,
    make NumEntries = NumDisks * DISKIO_TYPE_MAX * NumIntervals,
    where NumIntervals = DISKIO_PRIORITY_MAX * ceil ((QueryEnd - QueryStart) / Resolution)

    */
    STDMETHOD (QueryCountByPriority) (
        __out_ecount_part_opt(NumEntries, NumEntries) ULONG Counts[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    /*

    returns disk utilization for each priority in intervals with length given by Resolution.
    NumEntries returns the required number of entries.  For best performance,
    make NumEntries = NumDisks * NumIntervals, where
    NumIntervals = DISKIO_PRIORITY_MAX * ceil ((QueryEnd - QueryStart) / Resolution)

    */
    STDMETHOD (QueryUtilizationByPriority) (
        __out_ecount_part_opt(NumEntries, NumEntries) FLOAT Utils[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd
    ) const PURE;

    STDMETHOD_(SIZE_T, NumPhysicalDisks) () const PURE;

    /*

    returns disk IO summary data for each disk.  NumEntries returns the
    required number of entries in data.  For best performance, call
    NumPhysicalDisks() to get the maximum number of entries that need to be
    allocated.

    */
    STDMETHOD (QueryDiskSummary) (
        __out_ecount_part_opt(NumEntries, NumEntries) PerDiskData buffer[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStartTime,
        __in  const TimeStamp& QueryEndTime
    ) const PURE;

    STDMETHOD_(SIZE_T, NumUniqueFiles) () const PURE;

    /*

    returns disk IO summary data for each file.  NumEntries returns the
    required number of entries in data.  For best performance, call
    NumUniqueFiles() to get the maximum number of entries that need to be
    allocated.

    */
    STDMETHOD (QueryFileSummary) (
        __out_ecount_part_opt(NumEntries, NumEntries) PerFileData buffer[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStartTime,
        __in  const TimeStamp& QueryEndTime
    ) const PURE;

};


MIDL_INTERFACE("7A6FC533-CDCC-4616-ACC0-FCFC41ACF2F4")
IDiskIOInfoSource2 : public IDiskIOInfoSource
{
    enum CCapabilityFlags
    {
        CapabilityFlag_CompletionProcessor = 1,
        CapabilityFlag_ReliableIssuingThread = 2,
    };

    STDMETHOD_(DWORD, GetCapabilities)() const PURE;
};

MIDL_INTERFACE("4A964B02-B4B9-46E8-B071-351C6BCB2F66")
IDiskIOInfoSource3 : public IDiskIOInfoSource2
{
    /*

    returns disk utilization for each priority in intervals with length given by Resolution.
    NumEntries returns the required number of entries.  For best performance,
    make NumEntries = NumDisks * NumIntervals, where
    NumIntervals = DISKIO_PRIORITY_MAX * ceil ((QueryEnd - QueryStart) / Resolution)
    Applies Filter to each disk I/O, passing it the optional Context.

    */
    STDMETHOD (QueryUtilizationByPriority) (
        __out_ecount_part_opt(NumEntries, NumEntries) FLOAT Utils[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in pfnFilter Filter,
        __in_opt PVOID Context = NULL
    ) const PURE;
};

MIDL_INTERFACE("C06D0D15-9978-4454-9136-C8B814EA16A8")
IClassPnPInfoSource : public IUnknown
{
    STDMETHOD_(BOOL, IsIdleDiskIOBoosted) (
        __in const IDiskIOInfoSource::DiskIOData&
    ) const PURE;
};

//
// HardFault
//

MIDL_INTERFACE("fc9ca9a8-3543-49aa-8f89-e3a2de4d1ae1")
IHardFaultInfoSource : public IUnknown
{
    struct HardFaultData
    {
        TimeStamp       TS;
        TimeStampDelta  IoTime;
        ULONG64         ReadOffset;
        ULONG64         VirtualAddress;
        ULONG64         FileObject;
        const PathNode *File;
        const IProcessInfoSource::ThreadData *Thread;
        SIZE_T          ByteCount;
    };

    struct HardFaultStats
    {
        const IProcessInfoSource::ProcessData *Process;
        const PathNode *File;
        SIZE_T          NumFaults;
        SIZE_T          TotalBytes;
    };

    typedef BOOL (WINAPI *pfnFilter)(__in const HardFaultData&, __in_opt PVOID Context);

    STDMETHOD (QueryCount) (
        __out_ecount_part_opt(NumEntries, NumEntries) ULONG Counts[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const HardFaultData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    typedef strided_adapter<const HardFaultData> StridedHardFaultDatas;

    STDMETHOD (QueryStridedData) (
        __out StridedHardFaultDatas *Datas,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryStats) (
        __out_ecount_part_opt(NumEntries, NumEntries) HardFaultStats Stats[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};


//
// IDpcIsrCountsInfoSource
//

MIDL_INTERFACE("8182DBAA-C900-4787-AA06-8286C5F16E57")
IDpcIsrCountsInfoSource : public IUnknown
{
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgDpcIsrCounts,
        __out SIZE_T& nCpus
        ) PURE;
};


//
// DPC/ISR
//

MIDL_INTERFACE("4E668976-7956-45DE-AF18-05D46F2C435B")
IDpcIsrInfoSource : public IUnknown
{
    enum DataType {
        Interrupt,
        Dpc
    };

    enum DpcType {
        TimerDpc,
        RegularDpc
    };

    struct DpcIsrData
    {
        TimeStamp       EnterTime;
        TimeStamp       ExitTime;
        ULONG64         Routine;
        const IProcessInfoSource::ImageData *Module;
        ULONG           CPUNumber;
        UCHAR           Overlap;
        UCHAR           Type;
        union {
            UCHAR       DpcType;
            UCHAR       IsrReturnValue;
        };
        UCHAR           Reserved;
    };

    struct TimeByModule
    {
        TimeByModule()
        {
            Time = TimeStampDelta::Zero;
            Module = NULL;
            NumCalls = 0;
        }

        TimeStampDelta  Time;
        const IProcessInfoSource::ImageData* Module;
        SIZE_T          NumCalls;
    };

    typedef BOOL (WINAPI *pfnFilter)(__in const DpcIsrData&, __in_opt PVOID Context);

    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const DpcIsrData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in  ULONG64 CPUMask = (ULONG64)-1i64,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryModules) (
        __out_ecount_part_opt(NumEntries, NumEntries) const IProcessInfoSource::ImageData *Modules[],
        __inout SIZE_T &NumEntries,
        __in  const DataType Type,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeStampDelta Usage[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in  ULONG64 CPUMask = (ULONG64)-1i64,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryModuleUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeByModule Times[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in  ULONG64 CPUMask = (ULONG64)-1i64
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) (DataType Type) const PURE;
};

MIDL_INTERFACE("F608CACD-DC15-4126-AB41-1D220EF1C728")
IDpcIsrInfoSource2 : public IDpcIsrInfoSource
{
    struct TimeByDpcIsr
    {
        TimeStampDelta  Time;
        const IDpcIsrInfoSource::DpcIsrData* DpcIsr;
    };

    typedef strided_adapter<const DpcIsrData> StridedDpcIsrDatas;

    STDMETHOD (QueryDpcIsrUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeByDpcIsr Times[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& MinThreshold,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in  ULONG64 CPUMask = (ULONG64)-1i64,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedDpcIsrDatas Data[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;
};

MIDL_INTERFACE("298FA8F8-38E1-4a82-A125-981698B9E39A")
IDpcIsrInfoSource3 : public IDpcIsrInfoSource2
{
    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const DpcIsrData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

     STDMETHOD (QueryUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeStampDelta Usage[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryDpcIsrUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeByDpcIsr Times[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& MinThreshold,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryModuleUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeByModule Times[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0
    ) const PURE;
};

MIDL_INTERFACE("9B311764-CF22-40BF-B711-D26A9956D79C")
IDpcIsrInfoSource4 : public IDpcIsrInfoSource3
{
    struct DpcIsrData4 : public IDpcIsrInfoSource::DpcIsrData
    {
        ULONG Vector;
        ULONG MessageIndex;
    };

    typedef strided_adapter<const DpcIsrData4> StridedDpcIsrDatas4;

    struct TimeByDpcIsr4
    {
        TimeStampDelta  Time;
        const IDpcIsrInfoSource4::DpcIsrData4* DpcIsr;
    };

    typedef BOOL (WINAPI *pfnFilter4)(__in const DpcIsrData4&, __in_opt PVOID Context);

    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const DpcIsrData4 *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0,
        __in_opt pfnFilter4 Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

     STDMETHOD (QueryUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeStampDelta Usage[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0,
        __in_opt pfnFilter4 Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedDpcIsrDatas4 Data[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryDpcIsrUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) TimeByDpcIsr4 Times[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& MinThreshold,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_bcount_opt((cMaskCpus + 7) / 8) const LPCVOID pvMaskCpus = NULL,
        __in  const ULONG cMaskCpus = 0,
        __in_opt pfnFilter4 Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;
};

//
// CurrentThread Context
//

MIDL_INTERFACE("2383472B-84B9-43BD-8DD9-8D19FD372FBA")
ICurrentThreadCtxInfoSource : public IUnknown
{
    STDMETHOD(GetCurrentThreadIds)(
        __out ULONG* pnCpus,
        __deref_out_ecount(*pnCpus) const ULONG** ppThreadIds
        ) const PURE;
};


//
// RunningThread
//

MIDL_INTERFACE("E60EA693-15A3-4427-81AC-1779A13B0FE8")
IRunningThreadInfoSource : public IUnknown
{
    STDMETHOD_(const IProcessInfoSource::ThreadData*, GetRunningThread)(
        __in  TimeStamp Time,
        __in  ULONG iCpu
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) const PURE;
};


//
// Per-CPU CSwitch counts
//

MIDL_INTERFACE("3C8FCB51-A51B-44F0-88FF-F24573226E17")
ICSwitchCountsInfoSource : public IUnknown
{
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgCSwitchCounts,
        __out SIZE_T& nCpus
        ) PURE;

    STDMETHOD(GetFirstReliableCSwitchEventTimeStamp)(
        __out TimeStamp& timestamp
        ) PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        ) PURE;
};


//
// ReadyThreadCounts Infosource
//

MIDL_INTERFACE("97A964F0-73F3-47b8-B938-837296364314")
IReadyThreadCountsInfoSource : public IUnknown
{
public:
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgReadyThreadCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};


//
// ReadyThread Infosource
//

MIDL_INTERFACE("F5636664-82A7-42A8-BA75-01E8D655A591")
IReadyThreadInfoSource : public IUnknown
{
    struct ReadyThreadData
    {
        TimeStamp   Time;
        const IProcessInfoSource::ThreadData* Thread;
        ULONG       Processor;
        UCHAR       AdjustReason;
        SCHAR       AdjustIncrement;
        BOOLEAN     ExecutingDpc;
        BOOLEAN     KernelStackNotResident : 1;
        BOOLEAN     ProcessOutOfMemory : 1;
        BOOLEAN     DirectSwitchAttempt : 1;
        bool        _Padding1 : 5;
    };

    typedef strided_adapter<const ReadyThreadData> StridedReadyThreadDatas;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedReadyThreadDatas Data[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;
};

//
// Context Switch
//

MIDL_INTERFACE("D54B3A96-2B7E-4FA6-9353-C74299657BCC")
ICSwitchInfoSource : public IUnknown
{
    struct CSwitchData
    {
        TimeStamp   SwitchOutTime;
        const IProcessInfoSource::ThreadData *Thread;
        CHAR        Priority;
        CHAR        Quantum;
        UCHAR       WaitReason;
        CHAR        WaitMode;
        UCHAR       State;
        CHAR        NewThreadPriority;
        CHAR        NewThreadQuantum;
        UCHAR       Reserved;
        ULONG       IdealProcessor;
        ULONG       Processor;
        USHORT      NewThreadWaitTime;
        USHORT      Reserved1;
    };

    struct CpuUsageProcessEntry
    {
        TimeStampDelta Time;
        
        union {
            const IProcessInfoSource::ProcessData  *Process;
            const IProcessInfoSource::ThreadData   *Thread;
            const void                             *value;
        } ProcessOrThreadData;
    };

    struct CpuUsageByPriorityEntry
    {
        TimeStampDelta Time[MAXIMUM_PRIORITY];
        TimeStampDelta CombinedTime;
        
        union {
            const IProcessInfoSource::ProcessData  *Process;
            const IProcessInfoSource::ThreadData   *Thread;
            const void                             *value;
        } ProcessOrThreadData;
    };

    typedef strided_adapter<const CSwitchData> StridedCSwitchDatas;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedCSwitchDatas Data[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    //
    // Routine added on 11/22/02 by coryw
    // QueryCpuUsageByProcess just sums up cpu time for each process in the
    // range and returns that for each cpu.  The buffer contains an entry for
    // each process on each cpu.  Thus if there are c CPUs, then
    // the entry buffer[p * c_0 + c] gives the time of process p on cpu c.

    STDMETHOD (QueryCpuUsageByProcess) (
        __out_ecount_part_opt(NumEntries, NumEntries) CpuUsageProcessEntry *buffer,
        __inout SIZE_T &NumEntries,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryCpuUsageByPriorityByProcess) (
        __out_ecount_part_opt(NumEntries, NumEntries) CpuUsageByPriorityEntry *buffer,
        __inout SIZE_T &NumEntries,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    //
    // Routine added on 02/06/03 by coryw
    // same as QueryCpuUsageByProcess, but groups by thread instead of process

    STDMETHOD (QueryCpuUsageByThread) (
        __out_ecount_part_opt(NumEntries, NumEntries) CpuUsageProcessEntry *buffer,
        __inout SIZE_T &NumEntries,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryCpuUsageByPriorityByThread) (
        __out_ecount_part_opt(NumEntries, NumEntries) CpuUsageByPriorityEntry *buffer,
        __inout SIZE_T &NumEntries,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryCpuUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) FLOAT Utils[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_range(LOW_PRIORITY, MAXIMUM_PRIORITY) LONG MinPriority = LOW_PRIORITY,
        __in_range(LOW_PRIORITY, MAXIMUM_PRIORITY) LONG MaxPriority = HIGH_PRIORITY
    ) const PURE;

    STDMETHOD (GetFirstValidTime) (
        __out TimeStamp& Time
        ) const PURE;

    STDMETHOD (GetLastValidTime) (
        __out TimeStamp& Time
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

MIDL_INTERFACE("333278EC-78C2-443B-8454-72CB9E56BBEB")
ICSwitchInfoSource2 : public ICSwitchInfoSource
{
    struct CSwitchData2 : CSwitchData
    {
        LONG _OldThreadRemainingQuantum_Internal;

        inline
        LONGLONG GetOldThreadRemainingQuantum () const
        {
            return static_cast<LONGLONG>(_OldThreadRemainingQuantum_Internal) * 1024;
        }

        __declspec(property(get=GetOldThreadRemainingQuantum)) LONGLONG OldThreadRemainingQuantum;

    public:

        CSwitchData2()
            : CSwitchData()
            , _OldThreadRemainingQuantum_Internal(0)
        {
        }
    };

    STDMETHOD (QueryCpuUsageByPriorityByThread) (
        __out_ecount_part_opt(NumEntries, NumEntries) CpuUsageByPriorityEntry *buffer,
        __inout SIZE_T &NumEntries,
        __in  ULONG64 CPUMask,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    typedef strided_adapter<const CSwitchData2> StridedCSwitchDatas2;

    STDMETHOD (QueryStridedData) (
        __out_ecount_part_opt(NumProcs, NumProcs) StridedCSwitchDatas2 Data[],
        __inout SIZE_T& NumProcs,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;
};

MIDL_INTERFACE("56B543A6-515B-4FF3-8531-ADD8963C5A6A")
ICSwitchInfoSource3 : public ICSwitchInfoSource2
{
    STDMETHOD (QueryCpuUsage) (
        __out_ecount_part_opt(NumEntries, NumEntries) FLOAT Utils[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in_opt IDpcIsrInfoSource *DpcIsrInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_range(LOW_PRIORITY, MAXIMUM_PRIORITY) LONG MinPriority = LOW_PRIORITY,
        __in_range(LOW_PRIORITY, MAXIMUM_PRIORITY) LONG MaxPriority = HIGH_PRIORITY,
        __in_range(MINIMUM_RANK, MAXIMUM_RANK) LONG MinPriority_Rank = MINIMUM_RANK,
        __in_range(MINIMUM_RANK, MAXIMUM_RANK) LONG MaxPriority_Rank = MAXIMUM_RANK
    ) const PURE;
};

//
// CSwitch Ext
//

MIDL_INTERFACE("9EB0A0AB-B346-4F40-9047-4AB31AA77A3E")
ICSwitchExtInfoSource : public IUnknown
{
    struct CSwitchExt
    {
        const ICSwitchInfoSource2::CSwitchData2* pPreviousCSwitchOut;
        const IReadyThreadInfoSource::ReadyThreadData* pReadyingReadyThread;
    };

    typedef strided_adapter<const CSwitchExt> StridedCSwitchExts;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedCSwitchExts rgStridedCSwitchExts[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;
};


//
// ReadyThread Ext
//

MIDL_INTERFACE("5AAF8781-67D9-4170-B973-0A70F7CCF8C4")
IReadyThreadExtInfoSource : public IUnknown
{
    struct ReadyThreadExt
    {
        const ICSwitchInfoSource2::CSwitchData2* pCSwitchIn;
    };

    typedef strided_adapter<const ReadyThreadExt> StridedReadyThreadExts;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedReadyThreadExts rgStridedReadyThreadExts[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;
};


MIDL_INTERFACE("9BC03C58-FAD9-47E5-8BF3-9AF24AA81E9F")
IReadyThreadExtInfoSource2 : public IReadyThreadExtInfoSource
{
    struct ReadyThreadExt2 : public ReadyThreadExt
    {
        const IReadyThreadInfoSource::ReadyThreadData* pPreviousPendingReadyThread;
    };

    typedef strided_adapter<const ReadyThreadExt2> StridedReadyThreadExts2;

    using IReadyThreadExtInfoSource::QueryStridedData;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedReadyThreadExts2 rgStridedReadyThreadExts[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;
};


//
// Readythread forward link (supplies the switch-in for a given readythread
// record).
//

MIDL_INTERFACE("EC467295-EC8B-4BE5-8DEA-30EF925D7A19")
IReadyThreadForwardLinkInfoSource : public IUnknown
{
    struct ReadyThreadForwardLink
    {
        const ICSwitchInfoSource2::CSwitchData2* pCSwitchIn;
    };

    typedef strided_adapter<const ReadyThreadForwardLink> StridedReadyThreadFLinks;

    __control_entrypoint(COM)
    __override
    STDMETHOD(QueryStridedData) (
        __out_ecount_part_opt(nCpus, nCpus) StridedReadyThreadFLinks rgStridedFLinks[],
        __inout SIZE_T& nCpus,
        __in const TimeStamp& QueryStart = TimeStamp::Min,
        __in const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;

};

//
// IDiskIOCSwitchInfoSource
//

MIDL_INTERFACE("8E884C73-9E09-40C6-924D-91869D93F6BE")
IDiskIOCSwitchInfoSource: public IUnknown
{
    STDMETHOD(GetCSwtichByDiskIO)(
        __out_opt const ICSwitchInfoSource::CSwitchData** ppCSwitchIn,
        __out_opt  const IReadyThreadInfoSource::ReadyThreadData** ppReadyThread,
        __in_opt  const IDiskIOInfoSource::DiskIOData* const pDiskIOData
        ) const PURE;

    STDMETHOD(GetCSwitchByDiskIOAndBitLockerInfo)(
        __out_opt const ICSwitchInfoSource::CSwitchData** ppCSwitchIn,
        __out_opt  const IReadyThreadInfoSource::ReadyThreadData** ppReadyThread,
        __in_opt  const IDiskIOInfoSource::DiskIOData* const pDiskIOData,
        __in bool fCheckBitLockerDetour
        ) const PURE;

    STDMETHOD(GetDiskIOByCSwitchIn)(
        __out const IDiskIOInfoSource::DiskIOData*& pDiskIOData,
        __in  const ICSwitchInfoSource::CSwitchData* const pCSwitchIn
        ) const PURE;

    STDMETHOD(GetDiskIOByReadyThread)(
        __out const IDiskIOInfoSource::DiskIOData*& pDiskIOData,
        __in  const IReadyThreadInfoSource::ReadyThreadData* const pReadyThread
        ) const PURE;
    
    STDMETHOD(GetDiskIOsByCSwitchIn)(
        __out_ecount_part_opt(NumEntries, NumEntries) const IDiskIOInfoSource::DiskIOData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const ICSwitchInfoSource::CSwitchData* const pCSwitchIn
        ) const PURE;

    STDMETHOD(GetDiskIOsByReadyThread)(
        __out_ecount_part_opt(NumEntries, NumEntries) const IDiskIOInfoSource::DiskIOData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const IReadyThreadInfoSource::ReadyThreadData* const pReadyThread
        ) const PURE;
};

//
// Work Items
//

MIDL_INTERFACE("D48A7605-43CA-48C7-AC70-ECEED4C0E549")
IWorkItemInfoSource : public IUnknown
{
    enum CFlags
    {
        Flag_Empty                 = 0x00,
        Flag_ShouldFollowByDefault = 0x01,
        Flag_ShouldBindForward     = 0x02,
        Flag_ShouldBindBack        = 0x04,
        Flag_RemoveBind            = 0x08,
    };

    struct CWorkItemDescription
    {
        LPCWSTR        Layer;
        LPCWSTR        Operation;
        LPCWSTR        Message;
    };

    struct CWorkItemData
    {    
        TimeStamp      Timestamp;
        ULONGLONG      Id;
        const ICSwitchInfoSource2::CSwitchData2* pCSwitchOut;  // the next context switch out of the thread running at the time of the workitem        
        const CWorkItemDescription* Description;
        const CWorkItemData* OtherData;
        union
        {
            USHORT         FlagsAsUShort;
            CFlags         Flags : 16;
        };       
        USHORT        Reserved;        
        ULONG         Cpu;

        inline
        const IProcessInfoSource::ThreadData *GetThread() const { return pCSwitchOut ? pCSwitchOut->Thread : NULL; }
        __declspec(property(get=GetThread)) const IProcessInfoSource::ThreadData *Thread;        

        inline
        bool HasFlag(CFlags flagsToCompare) const
        {
            return (FlagsAsUShort & (USHORT)flagsToCompare) ? true : false;
        }               
    };

    typedef strided_adapter<const CWorkItemData> StridedWorkItemDatas;

    STDMETHOD(QueryStridedData)(
        __out StridedWorkItemDatas* pStridedWorkItemDatas,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        );
};


//
// Wait Analysis
//

MIDL_INTERFACE("9BAF28AD-99AB-469B-A660-81B5CBE0F3B3")
IWaitAnalysisInfoSource : public IUnknown
{
    enum CFlags
    {
        Flag_Recursive      = 0x40000000, // Recursive Wait Analysis
        Flag_OutsideBounds  = 0x20000000, // Add Outside Bounds Markers
    };

    template <typename Q>
    HRESULT AnalyzeThread(
        __deref_out Q** ppQ,
        __in  const TimeStamp& StartTime,
        __in  const TimeStamp& EndTime,
        __in  const IProcessInfoSource::ThreadData* pThread,
        __in  DWORD dwFlags = 0
        ) 
    {
        return AnalyzeThread(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), StartTime, EndTime, pThread, dwFlags);
    }

    STDMETHOD(AnalyzeThread)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  const TimeStamp StartTime,
        __in  const TimeStamp EndTime,
        __in  const IProcessInfoSource::ThreadData* pThread,
        __in  DWORD dwFlags = 0
        ) PURE;

    template <typename Q>
    HRESULT AnalyzeCSwitchIn(
        __deref_out Q** ppQ,
        __in  const TimeStamp& StartTime,
        __in  const TimeStamp& EndTime,
        __in  const ICSwitchInfoSource2::CSwitchData2* pCSwitchIn,
        __in  DWORD dwFlags = 0
        ) 
    {
        return AnalyzeCSwitchIn(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), StartTime, EndTime, pCSwitchIn, dwFlags);
    }

    STDMETHOD(AnalyzeCSwitchIn)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  const TimeStamp StartTime,
        __in  const TimeStamp EndTime,
        __in  const ICSwitchInfoSource2::CSwitchData2* pCSwitchIn,
        __in  DWORD dwFlags = 0
        ) PURE;

    template <typename Q>
    HRESULT AnalyzeReadyThread(
        __deref_out Q** ppQ,
        __in  const TimeStamp& StartTime,
        __in  const TimeStamp& EndTime,
        __in  const IReadyThreadInfoSource::ReadyThreadData* pReadyThread,
        __in  DWORD dwFlags = 0
        ) 
    {
        return AnalyzeReadyThread(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), StartTime, EndTime, pReadyThread, dwFlags);
    }

    STDMETHOD(AnalyzeReadyThread)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  const TimeStamp StartTime,
        __in  const TimeStamp EndTime,
        __in  const IReadyThreadInfoSource::ReadyThreadData* pReadyThread,
        __in  DWORD dwFlags = 0
        ) PURE;

    STDMETHOD(IsSymbolDecodingEnabled)(
        ) const PURE;
};

MIDL_INTERFACE("06B1B811-527B-411E-84FD-4E4ECBE7F9EC") ISignatureMissingSymbolsList;

MIDL_INTERFACE("F4BCE512-0B01-47C9-AAEC-4BD855B42241")
IWaitAnalysisInfoSource2 : public IWaitAnalysisInfoSource
{
    template <typename Q>
    HRESULT AnalyzeThread(
        __deref_out Q** ppQ,
        __in  const TimeStamp& StartTime,
        __in  const TimeStamp& EndTime,
        __in  const IProcessInfoSource::ThreadData* pThread,
        __in  ISignatureMissingSymbolsList* pMissingSymbolsList,
        __in  DWORD dwFlags = 0
        ) 
    {
        return AnalyzeThread(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), StartTime, EndTime, pThread, pMissingSymbolsList, dwFlags);
    }

    STDMETHOD(AnalyzeThread)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  const TimeStamp StartTime,
        __in  const TimeStamp EndTime,
        __in  const IProcessInfoSource::ThreadData* pThread,
        __in  ISignatureMissingSymbolsList* pMissingSymbolsList,
        __in  DWORD dwFlags = 0
        ) PURE;
};


MIDL_INTERFACE("D76DFAB7-4F11-4C55-AE59-DBAF89896385")
IWaitAnalysisResults : public IUnknown
{
    enum CCause
    {
        Cause_Meta      = 0, // Meta information        
        Cause_Preempted = 1, // CPU contention: Ready after Preemption or quantum expiration
        Cause_PostWait  = 2, // CPU contention: Ready after ReadyThread
        Cause_Wait      = 3, // Wait
        Cause_DPC       = 4, // DPC that readies a thread
        Cause_CpuUsage  = 5, // CPU usage: Running
        Cause_PostWorkItemReady = 6,     // Work Item Scheduling:  The time period where the work item was ready to run,  but wasn't running.  
        Cause_WorkItem = 7,              // Work Item Migration.  
        Cause_DPC_SchedulesWorkItem = 8, // DPC that schedules a work item
        Cause_MetaWorkItem = 9,  // Meta information        
        Cause__count
    };

    enum CCategory
    {
        Category_Unclassified = 0,
        Category_CpuUsage     = 1,
        Category_Starvation   = 2,
        Category_DPC_Network  = 3,
        Category_DPC_Disk     = 4,
        Category_DPC_Timer    = 5,
        Category_DPC_Other    = 6,
        Category_Other        = 7,
        Category_Count
    };

    enum CType
    {
        // Generic Types
        Type_Default                    = 0,
        

        // Wait
        Type_Wait_WaitQueue             = 1,
        Type_Wait_ThreadCreation        = 2,
        Type_Wait_Readying              = 3,

        // Meta
        Type_Meta_Outside               = 1,
        Type_Meta_TimeInversion         = 2,
        Type_Meta_BrokenCausality       = 3,
        Type_Meta_MissingReadyThread    = 4,
        Type_Meta_MissingWaitCause      = 5,
        Type_Meta_UnaccountedTime       = 6,      // Used when there is a time period we just can't analyze - e.g. due to brokencausality.          

        // Cause_MetaWorkItem
        Type_MetaWorkItem_UnableToFollowWorkItem = 1,

        // DPC
        Type_DPC_Network                = 1,
        Type_DPC_Disk                   = 2,
        Type_DPC_Timer                  = 3,
        Type_DPC_Other                  = 4,
    };

    enum CWaitType
    {
        WaitType_Unclassified           = 0,

        WaitType_Lock_CriticalSection   = 1,
        WaitType_Lock_EResource         = 2,
        WaitType_Lock_FastMutex         = 3,
        WaitType_Lock_GuardedMutex      = 4,
        WaitType_Lock_KeyedEvent        = 5,
        WaitType_Lock_PushLock          = 6,
        
        WaitType_Inherit_LpcReply       = 16,
        WaitType_Inherit_FltMessage     = 17,
        WaitType_Inherit_WorkQueue      = 18,

        WaitType_Lock__mask             = 0xF,
        WaitType_Inherit__mask          = 0xF0,
    };

    enum CFlags
    {
        //
        // Generic Flags
        //

        Flag_Level_Descend          = 0x80, // Recursive Analysis Level Marker: Descend

        //
        // Specific Flags
        //

        // Wait
        Flag_Wait_CascadedLock      = 0x01,        
        Flag_Migration              = 0x02,
    };

    struct Result
        : public Temporal
    {
    public:
        LPCWSTR     LockId;
        UCHAR       Cause;
        UCHAR       Type;
        UCHAR       Flags;
        UCHAR       Ascend;
        UCHAR       WaitType;
        UCHAR       InheritPriority;
        UCHAR       Category;

        struct CCSwitchIn
        {
            const ICSwitchInfoSource2::CSwitchData2* pCSwitchIn;
        };

        struct CCSwitchOut
        {
            const ICSwitchInfoSource2::CSwitchData2* pCSwitchOut;
        };

        struct CReadyThread
        {
            const IReadyThreadInfoSource::ReadyThreadData* pReadyThread;
        };

        struct CWorkItem
        {
            const IWorkItemInfoSource::CWorkItemData* pWorkItemData;
        };

        union CResultExt
        {
            CCSwitchIn      Meta;
            CWorkItem       MetaWorkItem;
            CCSwitchIn      Preempted;
            CCSwitchIn      PostWait;
            CReadyThread    Wait;
            CReadyThread    DPC;
            CWorkItem       DPCWorkItem;
            CCSwitchOut     CpuUsage;
            CWorkItem       WorkItem;
        };

        CResultExt  Ext;
    };

    typedef strided_adapter<Result> StridedResults;

    STDMETHOD(QueryStridedData)(
        __out StridedResults* pStridedResults
        ) PURE;

    STDMETHOD_(UCHAR, QueryWaitCategoryByRowIndex)(
        __in  UINT pRowIndex
        ) PURE;
};

//
// Wait Classification
//

MIDL_INTERFACE("8E117BD8-A5FF-dace-812A-8AE2021DF5C4")
IWaitClassificationInfoSource : public IUnknown
{
    STDMETHOD(CreateWaitClassificationContext)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  LPCWSTR wszWatchFunctionsFileName
        ) const PURE;

    template <typename Q>
    HRESULT CreateWaitClassificationContext(
        __deref_out Q** ppQ,
        __in  LPCWSTR wszWatchFunctionsFileName
        ) 
    {
        return CreateWaitClassificationContext(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), wszWatchFunctionsFileName);
    }

    STDMETHOD(IsSymbolDecodingEnabled)(
        ) const PURE;
};

MIDL_INTERFACE("2740B043-FF55-43cd-871E-53A285F024A0")
IWaitClassificationInfoSource2 : public IWaitClassificationInfoSource
{
    STDMETHOD(CreateWaitClassificationContext2)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  LPCWSTR wszWatchFunctionsFileName,
        __in  LPCWSTR wszWatchLocksFileName
        ) const PURE;

    template <typename Q>
    HRESULT CreateWaitClassificationContext2(
        __deref_out Q** ppQ,
        __in  LPCWSTR wszWatchFunctionsFileName,
        __in  LPCWSTR wszWatchLocksFileName
        ) 
    {
        return CreateWaitClassificationContext2(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), wszWatchFunctionsFileName, wszWatchLocksFileName);
    }
};

MIDL_INTERFACE("B7137E3B-7B54-46d4-A096-2F72A4EFDB6B")
IWaitClassificationContext : public IUnknown
{
    STDMETHOD(ClassifyWaits)(
        __in  REFIID riid,
        __deref_out LPVOID* ppv,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;

    template <typename Q>
    HRESULT ClassifyWaits(
        __deref_out Q** ppQ,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) 
    {
        return ClassifyWaits(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), QueryStart, QueryEnd);
    }
};


MIDL_INTERFACE("3A1C8FDF-151D-40cf-921F-2BBD3FE4D18C")
IWaitClassificationResults : public IUnknown
{
    STDMETHOD(QueryDirectData) (
        __deref_out_ecount(nWaits) const ICSwitchInfoSource::CSwitchData*** prgpWaits,
        __out SIZE_T& nWaits,
        __out SIZE_T& Stride
        ) PURE;
};

MIDL_INTERFACE("AC42C393-2C7F-4a02-A990-08437B0725F6")
IWaitClassificationResults2 : public IWaitClassificationResults
{
    struct LockResult
    {
        //
        // WARNING: Symbol name is interned by the Symbol InfoSource
        // and doesn't survive ISymbolController::FlushCache().
        //
        LPCWSTR     LockId;
        const ICSwitchInfoSource::CSwitchData* pCSwitchIn;
    };

    STDMETHOD(QueryDirectData2) (
        __deref_out_ecount(nWaits) const ICSwitchInfoSource::CSwitchData*** prgpWaits,
        __out SIZE_T& nWaits,
        __out SIZE_T& Stride,
        __deref_out_ecount(nLocks) LockResult** prgpLocks,
        __out SIZE_T& nLocks
        ) PURE;
};

MIDL_INTERFACE("4FA95E96-0543-4b18-827E-1AD7AA917876")
IThreadClassificationInfoSource : public IUnknown
{
    STDMETHOD(ClassifyThreads)(
        __in REFIID riid,
        __deref_out LPVOID* ppv,
        __in LPCWSTR wszThreadClassificationFileName,
        __in  const TimeStamp QueryStart,
        __in  const TimeStamp QueryEnd
        ) const PURE;

    template <typename Q>
    HRESULT ClassifyThreads(
        __deref_out Q** ppQ,
        __in LPCWSTR wszThreadClassificationFileName,
        __in  const TimeStamp QueryStart = TimeStamp::Min,
        __in  const TimeStamp QueryEnd = TimeStamp::Max
        ) const 
    {
        return ClassifyThreads(__uuidof(Q), reinterpret_cast<LPVOID*>(ppQ), wszThreadClassificationFileName, QueryStart, QueryEnd);
    }
};


MIDL_INTERFACE("B0D4AA1D-3486-428c-90DF-8C30C5C46ADD")
IThreadClassificationResults : public IUnknown
{
    STDMETHOD(QueryDirectData) (
        __deref_out_ecount(nThreads) const IProcessInfoSource::ThreadData*** prgpThreads,
        __out SIZE_T& nThreads
        ) PURE;
};

//
// Scheduler analysis.
//

enum ESchedEventType {
    SchedEventUnknown,
    SchedEventReadyIdleSameCpu,
    SchedEventReadyIdleCrossCpu,
    SchedEventReadyQueued,
    SchedEventReadyPreempt,
    SchedEventReadyMax,
    SchedEventSwitchIn,
    SchedEventSwitchToIdle,
    SchedEventMax
};

MIDL_INTERFACE("81DA32EC-0DAC-4F7C-9E66-0AB7B7F1D8E2")
ISchedulerAnalysisInfoSource : public IUnknown
{
    
    //
    // N.B. The scheduler data in the event corresponds to
    //      the period immediately after the corresponding CSwitch or
    //      ready thread.
    //

    struct SchedulerAnalysisEvent {
        UCHAR EventType;
        UCHAR MinNRunnablePriorityIncl;
        UCHAR MinNRunnablePriorityExcl;
        UCHAR MinRunningPriority;

        //
        // -1 indicates that no threads are currently ready.
        //

        SCHAR MaxReadyPriority;
        BOOLEAN ImbalanceOnReady;
        BOOLEAN CSwitchDelay;
        BOOLEAN DpcIsrDelay;
  
        //
        // N.B. If EventType <= SchedEventReadyMax, the ReadyThread
        //      field is valid.  Otherwise the CSwitchIn field is valid.
        //

        union {
            const IReadyThreadInfoSource::ReadyThreadData *ReadyThread;
            const ICSwitchInfoSource::CSwitchData *CSwitchIn;
        };

        TimeStamp GetEventTime() const
        {
            ASSERT(EventType >  SchedEventUnknown &&  EventType <  SchedEventMax);
            return (EventType <= SchedEventReadyMax) ? ReadyThread->Time : CSwitchIn->SwitchOutTime;
        }
        __declspec(property(get=GetEventTime)) TimeStamp EventTime;
       
        ULONG GetProcessor() const
        {
            ASSERT(EventType >  SchedEventUnknown &&  EventType <  SchedEventMax);
            return (EventType <= SchedEventReadyMax) ? ReadyThread->Processor : CSwitchIn->Processor;
        }
        __declspec(property(get=GetProcessor)) ULONG Processor;
    };
        

    typedef strided_adapter<const SchedulerAnalysisEvent> StridedSchedulerAnalysisEvents;

    STDMETHOD(QueryStridedData)(
        __out StridedSchedulerAnalysisEvents *SchedAnalysisEvents,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) PURE;
};

//
// Registry
//

MIDL_INTERFACE("fac9a283-b244-47a0-876a-6d8afcd42318")
IRegistryInfoSource : public IUnknown
{
    enum RegAccessType
    {
        REG_TYPE_CREATE,
        REG_TYPE_OPEN,
        REG_TYPE_DELETE,
        REG_TYPE_QUERY,
        REG_TYPE_SETVALUE,
        REG_TYPE_DELETEVALUE,
        REG_TYPE_QUERYVALUE,
        REG_TYPE_ENUMERATEKEY,
        REG_TYPE_ENUMERATEVALUEKEY,
        REG_TYPE_QUERYMULTIPLEVALUE,
        REG_TYPE_SETINFORMATION,
        REG_TYPE_FLUSH,
        REG_TYPE_KCBCREATE,
        REG_TYPE_KCBDELETE,
        REG_TYPE_KCBRUNDOWNBEGIN,
        REG_TYPE_KCBRUNDOWNEND,
        REG_TYPE_REGVIRTUALIZE,
        REG_TYPE_REGCLOSE,
    };

    struct RegAccessData
    {
        TimeStamp       AccessTime;
        TimeStampDelta  ElapsedTime;
        const PathNode *BaseKey;
        const PathNode *Key;
        RegAccessType   AccessType;
        ULONG           Status;
        ULONG           ThreadId;
        union {
            ULONG       Index;
            ULONG       InfoClass;
        };
    };

    __success(return != 0)
    STDMETHOD_(SIZE_T, GetRegAccessTypeNames) (
        __deref_out_ecount_full(return) const LPCWSTR **RegistryAccessTypeNames
    ) const PURE;

    STDMETHOD_(LPCWSTR, GetRegAccessTypeName) (
        __in  SIZE_T RegistryAccessType
    ) const PURE;

    typedef BOOL (WINAPI *pfnFilter)(__in const RegAccessData&, __in_opt PVOID Context);

    STDMETHOD (QueryCount) (
        __out_ecount_part_opt(NumEntries, NumEntries) ULONG Counts[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const RegAccessData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    typedef strided_adapter<const RegAccessData> StridedRegAccessDatas;

    STDMETHOD (QueryStridedData) (
        __out StridedRegAccessDatas* Datas,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};


// base class for data bucketed by Process/Thread-Module-Function
struct BucketData
{
    union {
        const IProcessInfoSource::ProcessData* Process;
        const IProcessInfoSource::ThreadData*  Thread;
    };
    const PathNode *Module;
    const WCHAR    *FunctionName;
};

//
// Symbol
//

MIDL_INTERFACE("8B66A7F3-4CE5-4155-9B17-E53EDEB83C53")
IImageIdentityInfoSource : public IUnknown
{
public:
    struct ImageIdentityData
    {
        IProcessInfoSource::ImageData const* pProcessImageData;

        LPCWSTR OriginalFileName; // The name the binary was compiled with

        CVDD CvDD;

        ImageWeakKey ImageWeakKey;
            // DWORD TimeDateStamp;
            // DWORD ImageSize;

        ImageIdentityData()
            : pProcessImageData()
            , OriginalFileName()
            , CvDD()
            , ImageWeakKey()
        {
        }
    };

    STDMETHOD_(_Ret_maybenull_ const ImageIdentityData*, QueryImageIdentityData)(
        _In_ IProcessInfoSource::ImageData const* pProcessImageData
        ) const PURE;


    STDMETHOD(QueryData)(
        _Out_writes_all_(cData) ImageIdentityData const* rgpData[],
        _Inout_ SIZE_T &cData
        ) const PURE;
};

MIDL_INTERFACE("F8A96E37-63C9-4E11-9174-108B48470D32")
ISymbolControllerProgressCallback : public IUnknown
{
public:
    STDMETHOD(OnUpdate)(
        _In_ ULONGLONG cImagesProcessed,
        _In_ ULONGLONG cImagesLoaded,
        _In_ ULONGLONG cImagesTotal) PURE;
    STDMETHOD(OnBegin)() PURE;
    STDMETHOD(OnEnd)() PURE;
    STDMETHOD(OnError)(
        _In_ LPCWSTR errorMessage) PURE;
};

MIDL_INTERFACE("F8B75090-500E-4E89-A62A-FC9D444EF523")
ISymbolInfoSource : public IUnknown
{
public:

    //
    // This is a sub-set of elements in IMAGE_SECTION_HEADER in NtImage.w and retrieved from PDB
    //

    struct SectionInfo 
    {
        ULONG   VirtualSize;
        ULONG   VirtualAddress;
        ULONG   SizeOfRawData;
        ULONG   PointerToRawData;
        ULONG   Characteristics;
        LPCWSTR wszName;
    };

    struct SymbolImageData
    {
        SymbolImageData()
            : OriginalFileName()
            , PdbPath()
            , SymCachePath()
            , pSection() 
            , cSection() 
            , RsdsKey()
            , ImageWeakKey()
        {
        }

        LPCWSTR OriginalFileName; // The name the binary was compiled with, which will be the name of the PDB
        LPCWSTR PdbPath; // Path to PDB - can be empty if a SymCache file was loaded directly
        LPCWSTR SymCachePath; // Path to loaded SymCache file - if symbols were found this will be non-null

        SectionInfo* pSection;
        UINT32 cSection;

        RsdsKey RsdsKey;
            // GUID Rsds;
            // DWORD Age;

        ImageWeakKey ImageWeakKey;
            // DWORD TimeDateStamp;
            // DWORD ImageSize;
    };

    struct SymbolData
    {
        UINT64 Base;
        UINT64 Limit;
        UINT64 PgoDynamicInstructionCount;
        const IProcessInfoSource::ImageData* pProcessImageData;
        const SymbolImageData* pSymbolImageData;
        LPCWSTR SymbolName;
        LPCWSTR PgoPhaseName;
        LPCWSTR SourceFileName;
        strided_adapter<const LPCWSTR> InlineSymbolNames;
        UINT32 SourceLineNumber;
        bool IsFunctionPgo : 1;
        bool IsOptimizedForSpeed : 1;
        bool HasValidPgoCounts : 1;
        bool IsModulePgo : 1;
        bool IsCodeSeparated : 1;
        bool IsAssemblyCode : 1;
        bool _Padding1 : 2;

        UINT64 GetSize() { return Limit - Base; }
        __declspec(property(get = GetSize)) ULONG64 Size;
    };

    struct SymbolLoadingConfiguration
    {
        LPCWSTR NtSymbolPath;
        LPCWSTR NtSymCachePath;
        bool SymbolLoadingEnabled; // If false no symbols will be returned for queries and the prefetcher will pause
    };

    STDMETHOD(QuerySymbol)(
        _Out_ SymbolData& symbolData,
        _In_  const IProcessInfoSource::ImageData* pProcessImageData,
        _In_  const ULONG64 rva
        ) PURE; // Not found == S_FALSE

    STDMETHOD(QuerySymbolEx)(
        _Out_ SymbolData& symbolData,
        _In_  const IProcessInfoSource::ImageData* pProcessImageData,
        _In_  const ULONG64 rva
        ) PURE;

    HRESULT QueryImage(
        _Out_ const SymbolImageData** ppSymbolImageData,
        _In_ const IProcessInfoSource::ImageData* pProcessImageData
        )
    {
        if (!ppSymbolImageData)
        {
            return E_POINTER;
        }

        SymbolData symbolData;
        {
            HRESULT hr = QuerySymbol(symbolData, pProcessImageData, 0);

            if (FAILED(hr))
            {
                return hr;
            }
        }

        *ppSymbolImageData = symbolData.pSymbolImageData;

        return (symbolData.pSymbolImageData) ? S_OK : S_FALSE;
    }

    STDMETHOD_(BOOL, IsEnabled)() const PURE;

    STDMETHOD_(BOOL, IsSymbolLoadingAvailable)() const PURE; // Has the trace been properly merged or are there any JIT symbols

    STDMETHOD(GetSymbolLoadingConfiguration)(
        _Out_ SymbolLoadingConfiguration& symbolLoadingConfiguration
        ) PURE;

    STDMETHOD(SetSymbolLoadingConfiguration)(
        _In_ const SymbolLoadingConfiguration& symbolLoadingConfiguration
        ) PURE;

    STDMETHOD(StartSymCachePrefetcher)(
        _In_opt_ ISymbolControllerProgressCallback* pProgressCallback
        ) PURE;

    STDMETHOD(StopSymCachePrefetcher)() PURE;

    //STDMETHOD (QuerySymbolStatusData) ( // TODO: This will be implemented later
    //    _Writable_elements_(NumEntries) SymbolImageData SymbolImageDatas[],
    //    _Inout_ SIZE_T& NumEntries
    //    ) const PURE;

    STDMETHOD(EnableVerboseOutput)() PURE; // TEMPORARY (10/2013) workaround to let people see that "something is happening" while the symbol status function is still left todo. REMOVE THIS WHEN QuerySymbolStatusData IS IMPLEMENTED

    STDMETHOD(GetDefaultSymbolDirPath)(
        _Out_ LPCWSTR& wszDefaultSymbolDirPath
        ) PURE;

    STDMETHOD(GetDefaultSymCacheDirPath)(
        _Out_ LPCWSTR& wszDefaultSymCacheDirPath
        ) PURE;

    STDMETHOD(GetBnsSymbolPath)(
        _Out_ LPCWSTR& wszBnsSymbolPath
        ) PURE;

    STDMETHOD(SetIncludedProcesses)(
        _In_reads_opt_(processNameCount) wchar_t const * pProcessNames[],
        _In_ UINT32 processNameCount
        );

    STDMETHOD(SetExcludedImages)(
        _In_reads_opt_(imageNameCount) wchar_t const * pImageNames[],
        _In_ UINT32 imageNameCount
        );

    STDMETHOD(GetUsedSymPaths)(
        _Inout_ LPCWSTR*& paths,
        _Inout_ UINT32* cPath
        );
};

//
// Page Fault
//

MIDL_INTERFACE("3153e2b7-f92b-492b-9a9f-30bb9dde7a51")
IPageFaultInfoSource : public IUnknown
{
    struct PageFaultData
    {
        TimeStamp   TS;
        ULONG64     IP;             // Instruction Pointer
        ULONG64     VA;             // Faulting Virtual Address
        const IProcessInfoSource::ThreadData *Thread;
        const IProcessInfoSource::ImageData *Image;

        bool get_IsCodeFault() const { return IP == VA; }
        __declspec(property(get=get_IsCodeFault)) bool IsCodeFault;
    };

    struct PageFaultProcess
    {
        const IProcessInfoSource::ProcessData *Process;
        SIZE_T      FaultCount;     // Fault count occurred by this process
    };

    struct PageFaultSummary : public BucketData
    {
        ULONG       FaultCount;            // Fault count occurred in these pages
        ULONG       CodeFaultCount;        // Code fault count (IP == Address)
        ULONG       DataFaultCount;        // Data fault count (IP != Address)
        ULONG       CodeFaultPages;        // Code fault pages (IP == Address)
        ULONG       DataFaultPages;        // Data fault pages (IP != Address)
        ULONG       CodePagesCount;        // Total code pages which generate fault
    };

    typedef BOOL (WINAPI *pfnFilter)(__in const PageFaultData&, __in_opt PVOID Context);

    STDMETHOD (QueryCount) (
        __out_ecount_part_opt(NumEntries, NumEntries) ULONG Counts[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryData) (
        __out_ecount_part_opt(NumEntries, NumEntries) const PageFaultData *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_opt pfnFilter Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    typedef strided_adapter<const PageFaultData> StridedPageFaultDatas;

    STDMETHOD (QueryStridedData) (
        __out StridedPageFaultDatas* Datas,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryProcesses) (
        __out_ecount_part_opt(NumEntries, NumEntries) const IProcessInfoSource::ProcessData *Buffer[],
        __inout SIZE_T &NumEntries
    ) const PURE;

    STDMETHOD (QueryPageFaultStatByProcess) (
        __out_ecount_part_opt(NumEntries, NumEntries) PageFaultProcess Buffer[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryPageFaultStat) (
        __out_ecount_part_opt(NumEntries, NumEntries) PageFaultSummary Buffer[],
        __inout SIZE_T &NumEntries,
        __in_opt ISymbolInfoSource* SymbolInfo = NULL,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};


MIDL_INTERFACE("C6CAA0BE-2418-49EF-A87E-EC16AA092930")
IPageFaultInfoSource2 : public IPageFaultInfoSource
{
    enum CPageFaultType
    {
        Transition,
        DemandZero,
        CopyOnWrite,
        GuardPage,
        HardPageFault,
    };

    struct PageFaultData2 : PageFaultData
    {
        ULONG  Cpu;
        UCHAR  Type;
        UCHAR  Reserved0;
        USHORT Reserved1;

    public:
        PageFaultData2()
            : PageFaultData()
            , Type()
            , Cpu()
            , Reserved0()
            , Reserved1()
        {
        }
    };

    typedef BOOL (WINAPI *pfnFilter2)(__in const PageFaultData2&, __in_opt PVOID Context);

    STDMETHOD (QueryCount2) (
        __out_ecount_part_opt(NumEntries, NumEntries) ULONG Counts[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart,
        __in  const TimeStamp& QueryEnd,
        __in_opt pfnFilter2 Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    STDMETHOD (QueryData2) (
        __out_ecount_part_opt(NumEntries, NumEntries) const PageFaultData2 *Data[],
        __inout SIZE_T &NumEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in_opt pfnFilter2 Filter = NULL,
        __in_opt PVOID Context = NULL
    ) const PURE;

    typedef strided_adapter<const PageFaultData2> StridedPageFaultData2s;

    STDMETHOD (QueryStridedData2) (
        __out StridedPageFaultData2s* Datas,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;
};


//
// Driver Delay
//

MIDL_INTERFACE("853ed463-9e4a-4ab0-b981-c4662b9f53a6")
IDriverDelayInfoSource : public IUnknown
{
    // This structure describes one function call done to a driver.
    struct DriverDelayData
    {
        TimeStamp   CallTS;
        TimeStamp   ReturnTS;
        ULONG64     RoutineAddr;
        ULONG64     Irp;
        const IProcessInfoSource::ThreadData *Thread;
        const PathNode *ModuleName;
        const PathNode *Filename;
        ULONG       MajorFunction;
        ULONG       MinorFunction;
    };

    // QueryDelay is the method to be used by consummers of the
    // information produced by this class.
    //
    // QueryDelay will produce a list of Driver Delays that match the
    // given criteria.  These criteria are:
    //     1. The time range of the driver call falls at least partly in
    //        the time range described by queryStartTime and queryEndTime.
    //     2. The name of the module containing the function called matches
    //        moduleName.  If moduleName is NULL, then the delay entry will
    //        be returned regardless of module name.
    //     3. The time spent inside the function (delay) must be equal to
    //        or greater than minDelay
    //
    // If this method is called with buffer set to NULL, then upon return it
    // sets NumEntries to an exact count of the number of entries that would be
    // needed for the given criteria.  Otherwise the numEntries should be
    // the number of entries in the buffer array.
    //
    // Please note that buffer is an array of pointers to the data structures
    // maintained by this class, and thus the const modifier should not be
    // ignored.
    //

    STDMETHOD (QueryDelay) (
        __out_ecount_part_opt(NumEntries, NumEntries) const DriverDelayData *buffer[],
        __inout SIZE_T& NumEntries,
        __in_opt LPCWSTR ModuleName,
        __in  const TimeStampDelta &MinDelay,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// MiniFilter Delay
//

MIDL_INTERFACE("BC5B5CF6-F7B2-4B7E-B881-4A227B03CBD7")
IMiniFilterDelayInfoSource : public IUnknown
{
    // This is the main strucute to hold mini filter calls.
    struct MiniFilterDelayData
    {
        TimeStamp   CallTS;
        TimeStamp   ReturnTS;
        ULONG64     RoutineAddr;
        ULONG64     Irp;
        ULONG64     FileContext;
        ULONG64     FileObject;
        ULONG64     CallbackData;
        const IProcessInfoSource::ThreadData *Thread;   // Thread information, Thread->Process has process information.
                                                        // If completion event - this will be from the mathcing init data
        const PathNode *ModuleName;                     // FilterDriver name
        const PathNode *FileName;                       // name of the file that was accessed
        LPCWSTR      MajorFunctionName;
        LPCWSTR        EventType;
        UINT32      MajorFunction;
        NTSTATUS Status;
        UCHAR       InitProcessor;                      // Again, matched from the init data

    public:
        LPCWSTR GetFileName() const { return FileName ? FileName->FileName : L"Unknown"; };
        LPCWSTR GetFilterName() const { return ModuleName ? ModuleName->FileName : L"Unknown"; };
        LPCWSTR GetProcessName() const { return Thread && Thread->Process ? Thread->Process->ImageName : L"Unknown"; };
    };

    // This structure holds aggregated minifilter delays
    struct MiniFilterDelayPerFilter
    {
        LPCWSTR Filter;
        ULONGLONG Delay;
    };

    // This structure holds aggregated minifilter delays per process
    struct MiniFilterDelayPerProcess
    {
        LPCWSTR Process;
        LPCWSTR Filter;
        ULONGLONG Delay;
    };

    typedef strided_adapter<const MiniFilterDelayData> StridedMiniFilterDelayData;

    // Use this version if you don't need to query by start, end, or min delay
    STDMETHOD (QueryDelay) (
        __out StridedMiniFilterDelayData* datas
    ) const PURE;

    // QueryDelay is the method to be used by consummers of the
    // information produced by this class.
    //
    // QueryDelay will produce a list of MiniFilter Delays that match the
    // given criteria.  These criteria are:
    //     1. The time range of the mini filter call falls at least partly in
    //        the time range described by queryStartTime and queryEndTime.
    //     2. The name of the module containing the function called matches
    //        moduleName.  If moduleName is NULL, then the delay entry will
    //        be returned regardless of module name.
    //     3. The time spent inside the function (delay) must be equal to
    //        or greater than minDelay
    //
    // If this method is called with buffer set to NULL, then upon return it
    // sets NumEntries to an exact count of the number of entries that would be
    // needed for the given criteria.  Otherwise the numEntries should be
    // the number of entries in the buffer array.
    //
    // Please note that buffer is an array of pointers to the data structures
    // maintained by this class, and thus the const modifier should not be
    // ignored.
    //

    STDMETHOD (QueryDelay) (
        __out_ecount_part_opt(NumEntries, NumEntries) const MiniFilterDelayData *buffer[],
        __inout SIZE_T& NumEntries,
        __in_opt LPCWSTR ModuleName,
        __in  const TimeStampDelta &MinDelay,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    // QueryAggregateDelay is the method to be used by consummers of the
    // information produced by this class.
    //
    // QueryAggregateDelay will produce a list of MiniFilters and how much total delay
    // they caused based on the given criteria.  These criteria are:
    //     1. The time range of the mini filter call falls at least partly in
    //        the time range described by queryStartTime and queryEndTime.  Only the time in
    //        this interval will be counted toward aggregate
    //     2. Will only aggregate times that are equal to or greater than minDelay
    //
    //
    // Please note that buffer is an array of pointers to the data structures
    // that are NOT maintained by this class.  The array of data structures
    // need to be deleted, in addition to the buffer of pointers that you provide.
    //
    // First version provides delays per filter over time interval
    // Second version providers delays per filter per process over time interval

    STDMETHOD (QueryAggregateDelayPerFilter) (
        __out_ecount_part_opt(NumEntries, NumEntries) MiniFilterDelayPerFilter *buffer[],
        __inout SIZE_T& NumEntries,
        __in  const TimeStampDelta &MinDelay,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;

    STDMETHOD (QueryAggregateDelayPerProcess) (
        __out_ecount_part_opt(NumEntries, NumEntries)  MiniFilterDelayPerProcess *buffer[],
        __inout SIZE_T& NumEntries,
        __in  const TimeStampDelta &MinDelay,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
    ) const PURE;
    

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};


//
// Services
//

MIDL_INTERFACE("AF8346BD-5F24-41DA-85CA-FCA2D79D037F")
IServicesInfoSource : public IUnknown
{
public:
    struct Service; // forward

    struct AutostartGroup : public Temporal {
        LPCWSTR                                Name;
        DWORD                                  TID;
    };

    struct ServiceStateChangeEvent {
        TimeStamp                              Time;
        const Service                         *Service;
        DWORD                                  State;            // SERVICE_[RUNNING,START_PENDING,etc.]
        DWORD                                  ExecutionPhase;   // TODO [VIENNA]: enum to be declared in winsvcs.h
        LPCWSTR                                ImageName;
        DWORD                                  PID;
        DWORD                                  TID;
    };

    enum ServiceTransitionType { StartTransition, StopTransition };

    struct ServiceTransition {
        ServiceTransitionType                  TransitionType;
        const Service                         *Service;

        const ServiceStateChangeEvent         *StartEvent;
        const ServiceStateChangeEvent         *EndEvent;

        const ServiceStateChangeEvent * const *Checkpoints;
        SIZE_T                                 NumCheckpoints;
    };
    
    struct Service {
        LPCWSTR                                Name;
        const AutostartGroup                  *Group;
        DWORD                                  StartType;
        
        const ServiceStateChangeEvent * const *Events;
        SIZE_T                                 NumEvents;

        const ServiceTransition * const       *Transitions;
        SIZE_T                                 NumTransitions;
    };

    STDMETHOD(QueryAutostartInformation)(
        __out TimeStamp &AutostartStartTime,
        __out TimeStamp &AutostartEndTime
    ) const PURE;

    typedef strided_adapter<const AutostartGroup> StridedAutostartGroups;

    STDMETHOD(QueryGroups)(
        __out StridedAutostartGroups* Groups,
        __in  const TimeStamp                &QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp                &QueryEndTime   = TimeStamp::Max
    ) const PURE;

    typedef strided_adapter<const Service> StridedServices;

    STDMETHOD(QueryServices)(
        __out StridedServices* Services
    ) const PURE;    

    STDMETHOD(QueryServices)(
        __out_ecount_part_opt(NumEntries, NumEntries) const Service **Services,
        __inout SIZE_T                       &NumEntries,
        __in  const TimeStamp                &QueryStartTime  = TimeStamp::Min,
        __in  const TimeStamp                &QueryEndTime    = TimeStamp::Max
    ) const PURE;    

    typedef strided_adapter<const ServiceStateChangeEvent> StridedServiceStateChangeEvents;

    STDMETHOD(QueryStateChangeEvents)(
        __out StridedServiceStateChangeEvents* ServiceStateChangeEvents,
        __in  const TimeStamp                &QueryStartTime  = TimeStamp::Min,
        __in  const TimeStamp                &QueryEndTime    = TimeStamp::Max
    ) const PURE; 

    STDMETHOD(QueryServiceTransitions)(
        __in  const Service                  *Service,
        __deref_out_ecount_part_opt(NumTransitions, NumTransitions) const ServiceTransition * const ** const Transitions,
        __out SIZE_T                         &NumTransitions,
        __in  const TimeStamp                QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp                QueryEndTime   = TimeStamp::Max
    ) const PURE;    

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};

MIDL_INTERFACE("5BD1DAF4-AE44-4EC2-B96E-9831609BBB27")
IServicesInfoSource2 : public IServicesInfoSource
{
    STDMETHOD(QueryAutostartInformationWithThread)(
        __out TimeStamp& AutostartStartTime,
        __out TimeStamp& AutostartEndTime,
        __out DWORD&     AutostartEndTID
    ) const PURE;
};

//
// SysConfig
//

MIDL_INTERFACE("35366777-AEAE-4387-98A5-EECA121E89AA") 
ISysConfigInfoSource  : public IUnknown
{
public:
    struct VideoAdapter
    {
        ULONG           MemorySize;
        ULONG           HorizontalRes;
        ULONG           VerticalRes;
        ULONG           BitsPerPixel;
        ULONG           VerticalRefreshRate;
        ULONG           DeviceType;
        LPCWSTR         ChipType;
        LPCWSTR         DACType;
        LPCWSTR         AdapterString;
        LPCWSTR         BiosString;
        LPCWSTR         DeviceId;
    };

    struct ServiceData
    {
        ULONG           ProcessId;
        LPCWSTR         ServiceName;
        LPCWSTR         DisplayName;
        LPCWSTR         ProcessName;
    };

    struct PowerConfig
    {
        CHAR            S1_IsAvailable : 1;
        CHAR            S2_IsAvailable : 1;
        CHAR            S3_IsAvailable : 1;
        CHAR            S4_IsAvailable : 1;
        CHAR            S5_IsAvailable : 1;
    };

    struct NICAdapter
    {
        LPCWSTR         PhysicalAddress;
        LPCWSTR         DeviceId;
        ULONG           Ipv4Index;
        ULONG           Ipv6Index;
        ULONG           NumberOfIpAddresses;
        ULONG           NumberOfDnsServers;
        const LPCWSTR*  IpAddresses;
        const LPCWSTR*  DnsServers;
    };

    struct IRQRecord
    {
        ULONG64         IRQAffinity;
        ULONG           IRQNum;
        LPCWSTR         DeviceDescription;
    };

    struct PnPRecord
    {
        LPCWSTR         DeviceId;
        LPCWSTR         DeviceDescription;
        LPCWSTR         DeviceFriendlyName;
    };

    enum PartitionType {
        PartitionType_Partition   = 1,
        PartitionType_Volume      = 2,
    };

    struct ExtentInfo {
        ULONGLONG       StartOffset;
        ULONGLONG       ExtentLength;
        ULONG           DiskNumber;
    };

    struct PartitionInfo {
        ULONGLONG       StartOffset;
        ULONGLONG       EndOffset;
        ULONGLONG       Capacity;
        LONGLONG        NumFreeClusters;
        LONGLONG        NumClusters;
        LPCWSTR         FileSystemType;
        const ExtentInfo *Extents;
        ULONG           SectorsPerCluster;
        ULONG           BytesPerSector;
        ULONG           ExtentsCount;
        WCHAR           DriveLetter;
        PartitionType   PartitionType;
        BOOLEAN         Valid;
    };

    struct DiskInfo
    {
        ULONGLONG       StartOffset;
        ULONGLONG       EndOffset;
        ULONGLONG       Capacity;
        ULONGLONG       Cylinders;
        ULONG           BytesPerSector;
        ULONG           SectorsPerTrack;
        ULONG           TracksPerCylinder;
        ULONG           SCSIPortNumber;
        ULONG           SCSIPathId;
        ULONG           SCSITargetId;
        ULONG           SCSILun;
        ULONG           PartitionCount;
        LPCWSTR         Manufacturer;
        const PartitionInfo *Partitions;
        BOOLEAN         WriteCacheEnabled;
        BOOLEAN         Valid;
    };

    enum IDEDeviceType {
        IDEDeviceType_Unknown,
        IDEDeviceType_ATA,
        IDEDeviceType_ATAPI,
    };

    enum IDETimingModeClass {
        IDETimingModeClass_Unknown,
        IDETimingModeClass_PIO,
        IDETimingModeClass_SWDMA,
        IDETimingModeClass_MWDMA,
        IDETimingModeClass_UDMA,
    };

    static const ULONG IDETimingModeType_Unknown = ULONG_MAX;

    struct IDEChannelInfo {
        LPCWSTR LocationInformation;
        IDEDeviceType Type;
        IDETimingModeClass TimingModeClass;
        ULONG TimingModeType;
        ULONG TargetId;
    };

    typedef strided_adapter<const DiskInfo> StridedDiskInfos;

    STDMETHOD (QueryDisks) (
        __out StridedDiskInfos* pStridedDiskInfos
        ) const PURE;

    STDMETHOD_(LONG, DriveLetterToDiskNumber) (
        const WCHAR DriveLetter
        ) const PURE;

    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetFileSystem) (
        const WCHAR DriveLetter
        ) const PURE;

    STDMETHOD_(WCHAR, GetBootDriveLetter)() const PURE;

    typedef strided_adapter<const ServiceData> StridedServiceDatas;

    STDMETHOD (QueryServices) (
        __out StridedServiceDatas* pStridedServicesDatas
        ) const PURE;

    typedef strided_adapter<const VideoAdapter> StridedVideoAdapters;

    STDMETHOD (QueryVideoAdapters) (
        __out StridedVideoAdapters* pStridedVideoAdapters
        ) const PURE;

    typedef strided_adapter<const NICAdapter> StridedNICAdapters;

    STDMETHOD (QueryNICAdapters) (
        __out StridedNICAdapters* pStridedNICAdapters
        ) const PURE;

    STDMETHOD (QueryPowerConfig) (
        __deref_out const PowerConfig** ppPowerConfig
        ) const PURE;

    typedef strided_adapter<const IRQRecord> StridedIRQRecords;

    STDMETHOD (QueryIRQRecords) (
        __out StridedIRQRecords* pStridedIRQRecords
        ) const PURE;

    typedef strided_adapter<const PnPRecord> StridedPnPRecords;

    STDMETHOD (QueryPnPRecords) (
        __out StridedPnPRecords* pStridedPnPRecords
        ) const PURE;

    typedef strided_adapter<const IDEChannelInfo> StridedIDEChannelInfos;

    STDMETHOD (QueryIDEChannelInfos) (
        __out StridedIDEChannelInfos* pStridedIDEChannelInfos
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryIDEDeviceTypeName) (
        const IDEDeviceType Type
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryIDETimingModeClassName) (
        const IDETimingModeClass ModeClass
        ) const PURE;

    struct GroupMaskInfo
    {
        TimeStamp Time;
        ULONG Masks[8];
    };
    
    STDMETHOD (QueryGroupMasks) (
        __deref_out_ecount(NumGroupMaskInfos) const GroupMaskInfo** ppGroupMaskInfos,
        __out SIZE_T& NumGroupMaskInfos
        ) const PURE;

    STDMETHOD_(SIZE_T, GetNumberOfProcessors) () const PURE;
    STDMETHOD_(SIZE_T, GetMemorySize) () const PURE;
    STDMETHOD_(SIZE_T, GetAllocationGranularity) () const PURE;
    STDMETHOD_(ULONG, GetCpuSpeedInMHz) () const PURE;
    STDMETHOD_(SIZE_T, GetPageSize) () const PURE;
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetComputerName) () const PURE;
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetDomainName) () const PURE;
    STDMETHOD_(ULONG64, GetSystemStartAddress) () const PURE;
    STDMETHOD_(BOOL, IsRetailTrace) () const PURE;
    STDMETHOD_(ULONG64, GetHyperThreadingFlag) () const PURE;
    STDMETHOD_(BOOLEAN, IsHyperThreadingFlagAvailable) () const PURE;
    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};


MIDL_INTERFACE("A4E1692C-598F-4876-957E-A442391D8FDF") 
ISysConfigInfoSource2 : public ISysConfigInfoSource
{
    struct ServiceData2 : public ISysConfigInfoSource::ServiceData
    {
        ULONG State;
        ULONG SubProcessTag;

    public:
        ServiceData2()
            : ISysConfigInfoSource::ServiceData()
            , State()
            , SubProcessTag()
        {
        }
    };

    typedef strided_adapter<const ServiceData2> StridedServiceData2s;

    STDMETHOD (QueryServices2) (
        __out StridedServiceData2s* pStridedServicesData2s
        ) const PURE;

    struct BuildInfo
    {
        FILETIME    InstallTime;
        LPCWSTR     BuildLab;
        LPCWSTR     ProductName;
    };

    STDMETHOD (QueryBuildInfo) (
        __deref_opt_out const BuildInfo** ppBuildInfo
        ) const PURE;
};

MIDL_INTERFACE("A07F2436-A611-48fd-B537-772D3774A0CA") 
ISysConfigInfoSource3 : public ISysConfigInfoSource2
{
    struct ServiceData3 : public ISysConfigInfoSource2::ServiceData2
    {
        LPCWSTR LoadOrderGroupName;

    public:
        ServiceData3()
            : ISysConfigInfoSource2::ServiceData2()
            , LoadOrderGroupName()
        {
        }
    };

    typedef strided_adapter<const ServiceData3> StridedServiceData3s;

    STDMETHOD (QueryServices3) (
        __out StridedServiceData3s* pStridedServicesData3s
        ) const PURE;
};

MIDL_INTERFACE("845D9038-6C3F-4B8A-BE6D-89B08D068FC0") 
ISysConfigInfoSource4 : public ISysConfigInfoSource3
{
    struct GroupAffinity
    {
        ULONG64 Mask;
        USHORT  Group;
    };

    typedef strided_adapter<const GroupAffinity>    StridedGroupAffinityDatas;
    typedef strided_adapter<const GroupAffinity>    StridedProcessorGroupDatas;
    typedef strided_adapter<const PROCESSOR_NUMBER> StridedProcessorNumberDatas;

    STDMETHOD (QueryGroupAffinity) (
        __out StridedGroupAffinityDatas* pStridedGroupAffinityDatas
        ) const PURE;

    STDMETHOD (QueryProcessorGroup) (
        __out StridedProcessorGroupDatas* pStridedProcessorGroupDatas
        ) const PURE;

    STDMETHOD (QueryProcessorNumber) (
        __out StridedProcessorNumberDatas* pStridedProcessorNumberDatas
        ) const PURE;
};

MIDL_INTERFACE("A69E10AD-D175-4b85-9283-C77E772A49F4") 
ISysConfigInfoSource5 : public ISysConfigInfoSource4
{
    enum OpticalDiscStatus 
    {
        OpticalDiscStatus_Empty,
        OpticalDiscStatus_Incomplete,
        OpticalDiscStatus_Complete,
        OpticalDiscStatus_Other
    };

    enum OpticalSessionStatus 
    {
        OpticalSessionStatus_Empty,
        OpticalSessionStatus_Incomplete,
        OpticalSessionStatus_Reserved,
        OpticalSessionStatus_Complete,
        OpticalSessionStatus_Unknown
    };
    
    enum OpticalProfile 
    {
        OpticalProfile_Invalid = 0x0,
        OpticalProfile_NonRemovableDisk,
        OpticalProfile_RemovableDisk,
        OpticalProfile_MOErasable,
        OpticalProfile_MOWriteOnce,
        OpticalProfile_AS_MO,
        OpticalProfile_CD_ROM = 0x8,
        OpticalProfile_CD_R,
        OpticalProfile_CD_RW,
        OpticalProfile_DVD_ROM = 0x10,
        OpticalProfile_DVD_DASH_R_SR,
        OpticalProfile_DVD_RAM,
        OpticalProfile_DVD_DASH_RW_RO,
        OpticalProfile_DVD_DASH_RW_SR,
        OpticalProfile_DVD_DASH_R_DL_SR,
        OpticalProfile_DVD_DASH_R_DL_LJ,
        OpticalProfile_DVD_DASH_RW_DL,
        OpticalProfile_DVD_DDR,
        OpticalProfile_DVD_PLUS_RW = 0x1A,
        OpticalProfile_DVD_PLUS_R,
        OpticalProfile_DDCD_ROM = 0x20,
        OpticalProfile_DDCD_R,
        OpticalProfile_DDCD_RW,
        OpticalProfile_DVD_PLUS_RW_DL,
        OpticalProfile_DVD_PLUS_R_DL,
        OpticalProfile_BD_ROM = 0x40,
        OpticalProfile_BD_DASH_R_SRM,
        OpticalProfile_BD_DASH_R_RRM,
        OpticalProfile_BD_DASH_RE,
        OpticalProfile_HD_DVD_ROM = 0x50,
        OpticalProfile_HD_DVD_DASH_R,
        OpticalProfile_HD_DVD_RAM,
        OpticalProfile_HD_DVD_DASH_RW,
        OpticalProfile_HD_DVD_DASH_R_DL = 0x58,
        OpticalProfile_HD_DVD_DASH_RW_DL = 0x5A,
        OpticalProfile_NonStandard = 0xFFFF
    };

    enum OpticalBusType 
    {
        OpticalBusType_Unknown = 0x0,
        OpticalBusType_Scsi,
        OpticalBusType_Atapi,
        OpticalBusType_Ata,
        OpticalBusType_1394,
        OpticalBusType_Ssa,
        OpticalBusType_Fibre,
        OpticalBusType_Usb,
        OpticalBusType_RAID,
        OpticalBusType_iScsi,
        OpticalBusType_Sas,
        OpticalBusType_Sata,
        OpticalBusType_Sd,
        OpticalBusType_Mmc,
        OpticalBusType_Virtual,
        OpticalBusType_FileBackedVirtual
    };

    enum OpticalDeviceType 
    {
        OpticalDeviceType_Disk = 0x0,
        OpticalDeviceType_Sequential,
        OpticalDeviceType_Printer,
        OpticalDeviceType_Processor,
        OpticalDeviceType_Worm,
        OpticalDeviceType_Cdrom,
        OpticalDeviceType_Scanner,
        OpticalDeviceType_Optical,
        OpticalDeviceType_Changer,
        OpticalDeviceType_Net,
        OpticalDeviceType_ASCIT8_1,
        OpticalDeviceType_ASCIT8_2,
        OpticalDeviceType_Array,
        OpticalDeviceType_Enclosure,
        OpticalDeviceType_CardReader,
        OpticalDeviceType_Bridge,
        OpticalDeviceType_Unknown
    };
    
    struct OpticalDriveInfo
    {
        USHORT      DiskNumber;
        USHORT      BusType;
        USHORT      DeviceType;
        USHORT      MediaType;
        ULONGLONG   StartOffset;
        ULONGLONG   EndOffset;
        ULONGLONG   Capacity;
        ULONGLONG   NumberOfFreeBlocks;
        ULONGLONG   TotalNumberOfBlocks;
        ULONGLONG   NextWritableAddress;
        ULONG       NumberOfSessions;
        ULONG       NumberOfTracks;
        ULONG       BytesPerSector;
        USHORT      DiscStatus;
        USHORT      LastSessionStatus;
        LPCWSTR     DriveLetter;
        LPCWSTR     FileSystemName;
        LPCWSTR     DeviceName;
        LPCWSTR     ManufacturerName;
        BOOLEAN     Valid;
        UCHAR       Reserved0;
        USHORT      Reserved1;
        ULONG       Reserved2;
    };

    typedef strided_adapter<const OpticalDriveInfo> StridedOpticalDriveInfos;

    STDMETHOD (QueryOpticalDrives) (
        __out StridedOpticalDriveInfos* pStridedOpticalDriveInfos
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryOpticalBusTypeName) (
        const USHORT Type
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryOpticalDeviceTypeName) (
        const USHORT Type
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryOpticalProfileName) (
        const USHORT Type
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryOpticalDiscStatusName) (
        const USHORT Type
        ) const PURE;

    STDMETHOD_(LPCWSTR, QueryOpticalSessionStatusName) (
        const USHORT Type
        ) const PURE;
};

// This interface contains methods that are the same as those in ISysConfigInfoSource1-5,
// but which don't cause problems with .NET's COM interop (it doesn't like methods that
// return >=64-bit integers, although SIZE_T seems to be fine)
MIDL_INTERFACE("B9833BD9-C308-4CC6-AF0D-3EA7D91EAD73")
ISysConfigInfoSource6 : public ISysConfigInfoSource5
{
    STDMETHOD (GetSystemStartAddress2) (
        __out ULONG64* pqwAddress
        ) const PURE;

    STDMETHOD (GetHyperThreadingFlag2) (
        __out ULONG64* pqwFlag
        ) const PURE;
};

MIDL_INTERFACE("4E45ADF1-6520-4F11-84AE-0E589CE183E5")
ISysConfigInfoSource7 : public ISysConfigInfoSource6
{
    struct PnPRecord2 : public ISysConfigInfoSource::PnPRecord
    {
        GUID ClassGuid;

        LPCWSTR ServiceName;
        LPCWSTR PdoName;

        ULONG UpperFiltersCount;
        ULONG LowerFiltersCount;

        __field_ecount(UpperFiltersCount) LPCWSTR *UpperFilters;
        __field_ecount(LowerFiltersCount) LPCWSTR *LowerFilters;

    public:
        PnPRecord2()
            : ISysConfigInfoSource::PnPRecord()
            , ClassGuid()
            , ServiceName()
            , PdoName()
            , UpperFiltersCount()
            , LowerFiltersCount()
            , UpperFilters()
            , LowerFilters()
        {
        }
    };

    typedef strided_adapter<const PnPRecord2> StridedPnPRecord2s;

    STDMETHOD (QueryPnPRecords2) (
        __out StridedPnPRecord2s* pStridedPnPRecord2s
        ) const PURE;
};

MIDL_INTERFACE("C19E393C-5029-47c0-AF19-9163BEA2DF1D")
ISysConfigInfoSource8 : public ISysConfigInfoSource7
{

    enum ClockInfo
    {
        DTT_DATA_INVALID,
        DTT_NOT_SUPPORTED,
        DTT_SUPPORTED_BY_HARDWARE_DISABLED_BY_BCD,
        DTT_SUPPORTED_BY_HARDWARE_DISABLED_BY_OVERIDE,
        DTT_IS_SUPPORTED_IS_ENABLED
    };

    STDMETHOD (QueryClockInfo) ( __out ClockInfo& SystemClockInfo ) const;
};

MIDL_INTERFACE("3F1BAA8E-7CCE-4BE2-B829-FEC923F7EE67")
ISysConfigInfoSource9 : public ISysConfigInfoSource8
{
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetSystemManufacturer) () const PURE;
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetSystemProductName) () const PURE;
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetBiosDate) () const PURE;
    STDMETHOD_(_Ret_maybenull_ LPCWSTR, GetBiosVersion) () const PURE;

    struct PowerSettingData
    {
        const WCHAR *SettingName;
        const WCHAR *SettingValue;
    };

    typedef strided_adapter<const PowerSettingData> StridedPowerSettingData;

    STDMETHOD (QueryPowerSettings) (
        __out StridedPowerSettingData *pStridedData
        ) const PURE;
};


//
// WinSAT (WinEI)
// Additional helper functions are in XPerfAddIn_WinSAT.hpp
//

MIDL_INTERFACE("9BAF28AD-99AB-469B-A660-91B5CBE0F3C5")
IWinSATInfoSource : public IUnknown
{
    enum WinSATXML
    {
        WinSATXML_SPR,
        WinSATXML_Metrics,
        WinSATXML_SysConfig,
        WinSATXML__count
    };

    STDMETHOD(GetXml)(
        WinSATXML xml,
        __deref_out_bcount_opt(*pcbBuffer) const WCHAR** ppBuffer,
        __out ULONG* pcbBuffer) CONST PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() CONST PURE;
};

MIDL_INTERFACE("af7a9c04-00ea-426f-b7f3-57d16b5e4ce8")
IPerfCounters : public IUnknown
{
    struct ProcessPerfCounters {

        ULONG  PageFaultCount;
        ULONG  HandleCount;

        ULONGLONG PeakVirtualSize;
        ULONGLONG PeakWorkingSetSize;
        ULONGLONG PeakPagefileUsage;
        ULONGLONG QuotaPeakPagedPoolUsage;
        ULONGLONG QuotaPeakNonPagedPoolUsage;

        ULONGLONG VirtualSize;
        ULONGLONG WorkingSetSize;
        ULONGLONG PagefileUsage;
        ULONGLONG QuotaPagedPoolUsage;
        ULONGLONG QuotaNonPagedPoolUsage;
        ULONGLONG PrivatePageCount;
    };

    STDMETHOD_(const ProcessPerfCounters *, QueryProcessPerfCtrs) (
        __in const IProcessInfoSource::ProcessData *Process
    ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

MIDL_INTERFACE("DC7DFC74-BDDB-4a19-9BDA-3BDC2C708B23") 
IFocusChangeInfoSource : public IUnknown
{
    struct FocusChangeData : public Temporal
    {
        // start/end times in base class provide focus loose/gain times
        const IProcessInfoSource::ThreadData *ThreadData;
        ULONG                                 ThreadId;
    };

    STDMETHOD (QueryFocusChange) (
        __out_ecount_part_opt(NumEntries, NumEntries) const FocusChangeData* Data[],
        __inout SIZE_T& NumEntries,
        __in_opt const TimeStamp QueryStart = TimeStamp::Min,
        __in_opt const TimeStamp QueryEnd   = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(_Ret_maybenull_ const FocusChangeData*, QueryFocusChange) (
        __in ULONG ThreadId,
        __in const TimeStamp& Time
        ) const PURE;

    STDMETHOD(QueryData)(
        __out_ecount_part_opt(NumEntries, NumEntries) const IFocusChangeInfoSource::FocusChangeData* Data[],
        __inout SIZE_T& NumEntries
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;

};

//
// Volume Mapping Infosource
//

MIDL_INTERFACE("8FD853FC-BAC1-4d8b-9279-0A122E3F2029") 
IVolumeMappingInfoSource : public IUnknown
{
    //
    // Convert an NT path to a DOS path.
    //
    // Return Values:
    //    S_OK:     The NT path was successfully converted to a DOS 
    //              path.
    //    S_FALSE:  The NT path could not be converted to a DOS path.
    //              The NT path is returned instead.
    //    XPERF_E_INSUFFICIENT_BUFFER: The provided buffer is too small 
    //              for the result path.  The required buffer size is 
    //              returned in cchDosFileName.
    //    E_OUTOFMEMORY: An out-of-memory condition has been encountered
    //              while processing the request.
    //

    STDMETHOD(GetFileName)(
        __in LPCWSTR wszNtPathName,
        __out_ecount_part_opt(cchDosPathName, cchDosPathName) LPWSTR wszDosPathName, 
        __inout SIZE_T& cchDosPathName
        ) PURE;
        
    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};

//
// P-State Counts Infosource
//

MIDL_INTERFACE("EEFEDCF4-35D7-48DF-BBE0-BA1DBC684483")
IPStateCountsInfoSource : public IUnknown
{
public:
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgStateCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};

//
// P-State Infosource
//

MIDL_INTERFACE("B2B0C3FF-A437-4FE0-8E00-E91B2710EA29") 
IPStateInfoSource : public IUnknown
{
    struct PStateData : public Temporal
    {
        ULONG       State;
        ULONG       Type;
    };

    typedef strided_adapter<const PStateData> StridedStateDatas;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedStateDatas rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryUsage)(
        __out_ecount_part_opt(nEntries, nEntries) FLOAT Utils[],
        __inout SIZE_T& nEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    struct CpuStateStats
    {
        ULONG           Processor;
        ULONG           State;
        TimeStampDelta  Duration;
        ULONGLONG       Count;
    };

    STDMETHOD(QueryStatsByCpuAndState)(
        __out_ecount_part_opt(nEntries, nEntries) CpuStateStats rgStats[],
        __inout SIZE_T& nEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// P-IdleState Counts Infosource
//

MIDL_INTERFACE("723515EC-EEAE-4B2D-8BDE-CC9D8D25E3B5")
IPIdleStateCountsInfoSource : public IUnknown
{
public:
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgStateCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};

//
// P-IdleState Infosource
//

MIDL_INTERFACE("96FD9AD3-882D-4B1D-BD76-A428F9B9B15C") 
IPIdleStateInfoSource : public IUnknown
{
    struct PIdleStateData : public Temporal
    {
        ULONG       State;
        ULONG       Reserved;
    };

    typedef strided_adapter<const PIdleStateData> StridedStateDatas;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedStateDatas rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryUsage)(
        __out_ecount_part_opt(nEntries, nEntries) FLOAT Utils[],
        __inout SIZE_T& nEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    struct CpuStateStats
    {
        ULONG           Processor;
        ULONG           State;
        TimeStampDelta  Duration;
        ULONGLONG       Count;
    };

    STDMETHOD(QueryStatsByCpuAndState)(
        __out_ecount_part_opt(nEntries, nEntries) CpuStateStats rgStats[],
        __inout SIZE_T& nEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// C-State Counts Infosource
//

MIDL_INTERFACE("CF994FBD-5CA9-427F-83F6-729DE8FBB05A")
ICStateCountsInfoSource : public IUnknown
{
public:
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgStateCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};

//
// C-State Infosource
//

MIDL_INTERFACE("44F4D2A2-7D5F-46A5-85A2-E281D4450563") 
ICStateInfoSource : public IUnknown
{
    struct CStateData : public Temporal
    {
        ULONG       State;
        ULONG       Reserved;
    };

    typedef strided_adapter<const CStateData> StridedStateDatas;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedStateDatas rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD(QueryUsage)(
        __out_ecount_part_opt(nEntries, nEntries) FLOAT Utils[],
        __inout SIZE_T& nEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    struct CpuStateStats
    {
        ULONG           Processor;
        ULONG           State;
        TimeStampDelta  Duration;
        ULONGLONG       Count;
    };

    STDMETHOD(QueryStatsByCpuAndState)(
        __out_ecount_part_opt(nEntries, nEntries) CpuStateStats rgStats[],
        __inout SIZE_T& nEntries,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// C-State Infosource2 with the Idle duration hint data
//

MIDL_INTERFACE("6d691ed6-be29-4ab8-bd55-5543a3f6f1aa")
ICStateInfoSource2 : public ICStateInfoSource
{
    struct CStateData2 : public CStateData
    {
        TimeStampDelta ExpectedDuration;
        ULONG          Flags;
    };

    typedef strided_adapter<const CStateData2> StridedStateDatas2;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedStateDatas2 rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;
};

//
// Clock Interrupt Counts Infosource
//

MIDL_INTERFACE("E95C544B-4CFD-4284-8FBA-71CD57A47365")
IClockInterruptCountsInfoSource : public IUnknown
{
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgInterruptCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};

//
// Clock Interrupt Infosource
//

MIDL_INTERFACE("ADE9D984-4239-49A3-97D6-2602B92C36BF") 
IClockInterruptInfoSource : public IUnknown
{
    struct ClockInterruptData : public Temporal
    {
        ULONGLONG   InterruptTime;
        ULONG       Reserved;
        ULONG       Processor;
        bool        fSpurious;
        bool        fClockOwner;
    };

    typedef strided_adapter<const ClockInterruptData> StridedClockInterruptDatas;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedClockInterruptDatas rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// Ipi Counts Infosource
//

MIDL_INTERFACE("8A3AF35F-5BEF-4D92-8AF3-26C4777F1F8C")
IIpiCountsInfoSource : public IUnknown
{
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgInterruptCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};

//
// Ipi Infosource
//

MIDL_INTERFACE("071D9A23-98E2-49B3-8C07-9872A92344CC") 
IIpiInfoSource : public IUnknown
{
    struct IpiData : public Temporal
    {
        ULONG Reserved;
        ULONG Processor;
        bool fApcRequested;
        bool fDpcRequested;
    };

    typedef strided_adapter<const IpiData> StridedIpiDatas;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedIpiDatas rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// Timer Expiration Counts Infosource
//

MIDL_INTERFACE("982E31B9-1D47-4100-81D1-C90B5F5026EF")
ITimerExpirationCountsInfoSource : public IUnknown
{
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nCpus) const ULONGLONG** prgExpirationCounts,
        __out SIZE_T& nCpus
        ) const PURE;
};

//
// Timer Expiration Infosource
//

MIDL_INTERFACE("C0058692-0B92-4C2C-9E9C-DCD7DAAED140") 
ITimerExpirationInfoSource : public IUnknown
{

    struct TimerOwnerData
    {
        const IProcessInfoSource::ProcessData* Process;
        TimeStamp SetTime;
        ULONG ThreadId;
        ULONG Processor;
        const IProcessInfoSource::ImageData *DpcModule;
        ULONG64 DpcRoutine;
        bool fThreadTimer;
        UCHAR Reserved;
        USHORT Reserved1;
    };

    struct TimerExpirationData : public Temporal
    {
        TimerOwnerData  OwnerData;
        ULONG Processor;
    };

    typedef strided_adapter<const TimerExpirationData> StridedTimerExpirationDatas;

    STDMETHOD(QueryStridedData)(
        __out_ecount_part_opt(nCpus, nCpus) StridedTimerExpirationDatas rgData[],
        __inout SIZE_T& nCpus,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// HwPower Counts Infosource
//

MIDL_INTERFACE("4ED46756-4886-43C0-9806-46A86108610F")
IHwPowerCountsInfoSource : public IUnknown
{
public:
    STDMETHOD(QueryDirectData)(
        __deref_out_ecount(nChannels) const ULONGLONG** prgHwPowerCounts,
        __out SIZE_T& nChannels
        ) const PURE;
};

//
// HwPower Infosource
//

MIDL_INTERFACE("F18765EC-2B25-4039-900D-96C0AF98A18D") 
IHwPowerInfoSource : public IUnknown
{
    struct ChannelData
    {
        TimeStamp       StartTime;
        TimeStamp       EndTime;
        double          SamplingPeriod;
        ULONG           ChannelId;
        const LONG*     rgValues;
        SIZE_T          nValues;
        ULONG           Unit;
        ULONG           UnitMultiplier;
        LPCWSTR         Name;

        TimeStamp GetValueTime(SIZE_T iValue) const
        {
            return TimeStamp(StartTime.nsec + static_cast<LONGLONG>(iValue * SamplingPeriod + 0.5));
        }

        TimeStamp GetPreviousValueTime(SIZE_T iValue) const
        {
            return TimeStamp(StartTime.nsec + static_cast<LONGLONG>((static_cast<double>(iValue) - 1.0) * SamplingPeriod + 0.5));
        }
    };

    enum QueryMode 
    {
        Sum,
        Average,
        Floor
    };

    STDMETHOD (QueryDirectData)(
        __out_ecount_part_opt(nChannels, nChannels) ChannelData rgData[],
        __inout SIZE_T& nChannels,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD (QueryUsage)(
        __out_ecount_part_opt(nEntries, nEntries) FLOAT Utils[],
        __inout SIZE_T& nEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max,
        __in  const DWORD dwUnit = UINT_MAX,
        __in  const QueryMode Mode = QueryMode::Average
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)(
        __in  const DWORD dwUnit = UINT_MAX
        ) const PURE;
};

//
// FileVersion Infosource
//

MIDL_INTERFACE("7550F17B-24B0-4AD9-A869-AC12A94379B0") 
IFileVersionInfoSource : public IUnknown
{
    struct ImageData
    {
        DWORD   TimeDateStamp;
        DWORD   ImageSize;
        LPCWSTR wszOriginalFileName;
        LPCVOID Reserved;
    };

    struct FileVersionData
    {
        DWORD   TimeDateStamp;
        DWORD   ImageSize;
        LPCWSTR wszOriginalFileName;
        LPCWSTR wszFileDescription;
        LPCWSTR wszFileVersion;
        LPCWSTR wszBinFileVersion;
        LPCWSTR wszVerLanguage;
        LPCWSTR wszProductName;
        LPCWSTR wszCompanyName;
        LPCWSTR wszProductVersion;
        LPCWSTR wszFileId;
        LPCWSTR wszProgramId;
    };

    STDMETHOD (QueryDirectData)(
        __out_ecount_part_opt(nDatas, nDatas) FileVersionData rgData[],
        __inout SIZE_T& nDatas
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;

    STDMETHOD(QueryImage)(
        __out ImageData& VersionImageData,
        __in  const IProcessInfoSource::ImageData* pImageData
        ) const PURE;

    STDMETHOD (QueryFileVersionData)(
        __out FileVersionData& VersionData,
        __in  const IProcessInfoSource::ImageData* pImageData
        ) const PURE;
};

//
// System Sleep Infosource
//

MIDL_INTERFACE("E23DE514-4540-4667-B45A-E4143E1D4936") 
ISystemSleepInfoSource : public IUnknown
{
    struct SleepTransition
    {
        SYSTEM_POWER_STATE   State;
        ULONG       Reason;
        TimeStamp   TransitionStart;
        TimeStamp   SleepTime;
        TimeStamp   RawWakeTime;
        TimeStamp   TrustedWakeTime;
        TimeStamp   TransitionEnd;
    };

    typedef strided_adapter<const SleepTransition> StridedSleepTransitions;

    STDMETHOD(QueryStridedData)(
        __out StridedSleepTransitions* StridedData,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};

MIDL_INTERFACE("416CEFDA-52DA-4894-9199-1D0397D8241C") 
ISystemSleepInfoSource2 : public ISystemSleepInfoSource
{
    // Average of system "awakeness" per interval with values from 0 (asleep) to 1 (awake)
    // based on SleepTransition::[SleepTime,TrustedWakeTime].
    STDMETHOD(QueryUsage)(
        __out_ecount_part_opt(nEntries, nEntries) FLOAT Utils[],
        __inout SIZE_T& nEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;
};

//
// System Power Infosource
//

MIDL_INTERFACE("23B7FF70-1956-46EF-910F-2AD5C34C8113") 
ISystemPowerSourceInfoSource : public IUnknown
{
    enum CSystemPowerSource
    {
        SystemPowerSource_AC = 0,
        SystemPowerSource_DC = 1,
        SystemPowerSource__count
    };

    struct SystemPowerSourceData : public Temporal
    {
        CSystemPowerSource PowerSource;
    };

    typedef strided_adapter<const SystemPowerSourceData> StridedSystemPowerSourceDatas;

    STDMETHOD(QueryStridedData)(
        __out StridedSystemPowerSourceDatas* StridedData,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    // Average of power source per interval with values equivalent to CSystemPowerSource
    STDMETHOD(QueryUsage)(
        __out_ecount_part_opt(nEntries, nEntries) FLOAT Utils[],
        __inout SIZE_T& nEntries,
        __in  const TimeStampDelta& Resolution,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable) () const PURE;
};

//
// Windows Store Application states
//

MIDL_INTERFACE("c383763e-51e4-4fbc-9354-c18ba7f86051")
IMetroAppInfoSource : public IUnknown
{
public:
    enum CAppStateType {
        StateActive,
        StateBrokered,
        StateSandboxed,
        StateQuiescing,
        StateHalted,
        StateTerminated,
        StateOverQuota,
        MaximumAppState
    };

    enum CAppPriorityType {
        PriorityNormal,
        PriorityLow,
        MaximumPriority
    };

    struct AppData : public Temporal {
        ULONG64 ApplicationId;
        LPCWSTR PackageFullName;
        ULONG SessionId;
        BOOLEAN LockScreen;
    };

    struct AppState : public Temporal {
        const AppData *Application;
        CAppStateType State;
        ULONG64 CycleTime;
        ULONG64 NetworkTokens;
    };

    static
    LPCWSTR
    GetStateName (
        CAppStateType State
        )
    {
        static LPCWSTR StateNames[] = 
        {
            L"Active",
            L"Brokered",
            L"Sandboxed",
            L"Quiescing",
            L"Halted",
            L"Terminated",
            L"OverQuota"
        };

        if (State < MaximumAppState) {
            return StateNames[State];
        } else {
            return L"Invalid";
        }
    }

    static
    LPCWSTR
    GetPriorityName (
        CAppPriorityType Priority
        )
    {
        static LPCWSTR PriorityNames[] = 
        {
            L"Normal",
            L"Low"
        };

        if (Priority < MaximumPriority) {
            return PriorityNames[Priority];
        } else {
            return L"Invalid";
        }
    }

    typedef strided_adapter<const AppState> StridedAppStateDatas;

    STDMETHOD(QueryStridedAppStateData)(
        __out StridedAppStateDatas* Data,
        __in  const TimeStamp &QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp &QueryEndTime = TimeStamp::Max
    ) const PURE;

    STDMETHOD_(BOOL, IsAppStateDataAvailable)() const PURE;

    struct BackgroundTask : public Temporal {
        const AppData *Application;
        LPCWSTR EntryPoint;
        LPCWSTR TaskName;
        GUID TaskInstanceId;
        GUID TaskId;
        GUID BrokerId;
        GUID TriggerEventId;
        ULONG TriggerEventType;
        ULONG ActivationType;
        ULONG ErrorCode;
        USHORT CpuThrottleCount;
        USHORT NetThrottleCount;
        BOOLEAN IsCritical;
        BOOLEAN TaskExecuted;
    };

    typedef strided_adapter<const BackgroundTask> StridedBackgroundTaskDatas;

    STDMETHOD(QueryStridedBackgroundTaskData)(
        __out StridedBackgroundTaskDatas* Data,
        __in  const TimeStamp &QueryStartTime = TimeStamp::Min,
        __in  const TimeStamp &QueryEndTime = TimeStamp::Max
    ) const PURE;

    STDMETHOD_(BOOL, IsBackgroundTaskDataAvailable)() const PURE;
};

MIDL_INTERFACE("EB93768C-283F-4917-8BE6-C88E92A038D7")
IHandleInfoSource : public IUnknown
{
public:
    enum CreationMethod
    {
        Create,
        Duplicate,
        Rundown,
        MaximumCreationMethod
    };

    struct HandleData : public Temporal
    {
        ULONG64 Object;
        LPCWSTR ObjectName;
        const IProcessInfoSource::ProcessData* Process;
        const IProcessInfoSource::ThreadData* CreateThread;
        const IProcessInfoSource::ThreadData* CloseThread;
        ULONG   Handle;
        ULONG   SourceHandle;
        CreationMethod  CreationMethod;
        USHORT  ObjectType;
        USHORT  Reserved;

        HandleData()
            : Temporal(),
              Object(),
              ObjectName(UNICODE_NULL),
              Process(NULL),
              CreateThread(NULL),
              CloseThread(NULL),
              Handle(),
              SourceHandle(),
              CreationMethod(MaximumCreationMethod),
              ObjectType(),
              Reserved()
        {
        }
    };

    STDMETHOD(QueryStridedData)(
        __out strided_adapter<const IHandleInfoSource::HandleData> *Datas,
        __in  const TimeStamp& QueryStart = TimeStamp::Min,
        __in  const TimeStamp& QueryEnd = TimeStamp::Max
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};

MIDL_INTERFACE("D2E0AEF2-0E17-423D-B4F7-3792E48A6CAE")
IObjectManagerInfoSource : public IUnknown
{
public:
    _Post_satisfies_(ObjectTypeName != NULL)
    STDMETHOD(QueryObjectTypeById)(
        __in  USHORT   ObjectType,
        __out LPCWSTR& ObjectTypeName
        ) const PURE;

    STDMETHOD_(BOOL, IsDataAvailable)() const PURE;
};

} // namespace XPerfAddIn
