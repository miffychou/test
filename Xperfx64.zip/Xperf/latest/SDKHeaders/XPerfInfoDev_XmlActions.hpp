/*++

Copyright (c) 2005 Microsoft Corporation

Module Name:

    XPerfInfoDev_XmlActions.hpp

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#ifndef __XPERFINFODEV_XMLACTIONS_HPP__
#define __XPERFINFODEV_XMLACTIONS_HPP__

#pragma warning(push)
#pragma warning(disable:4127) // conditional expression is constant
#pragma warning(disable:4995) // ' function ': name was marked as #pragma deprecated
#pragma warning(disable:4996) // ' function ': was declared deprecated
#include <atlstr.h>
#include <atlenc.h>
#pragma warning(pop)
#include <stdexcept>

namespace XPerfAddIn
{
    namespace XmlActions
    {
        //
        // TimeUnit support
        //

        enum TimeUnit
        {
            TimeUnit_ns,
            TimeUnit_us,
            TimeUnit_ms,
            TimeUnit_s,
            TimeUnit__count
        };

        static const double _g_dblTimeUnitScale[] = {
            1.0,
            1000.0,
            1000000.0,
            1000000000.0,
        };
        _CTASSERT(RTL_NUMBER_OF(_g_dblTimeUnitScale) == TimeUnit__count);

        static const LPCWSTR _g_wszTimeUnitName[] = {
            L"ns",
            L"us",
            L"ms",
            L"s",
        };
        _CTASSERT(RTL_NUMBER_OF(_g_wszTimeUnitName) == TimeUnit__count);

        inline
        HRESULT
        ParseTimeUnit(
            __out TimeUnit& timeunit, 
            __in  LPCWSTR wsz
            )
        {
            if (!wcscmp(wsz, L"ns")) {
                timeunit = TimeUnit_ns;
            } else if (!wcscmp(wsz, L"us")) {
                timeunit = TimeUnit_us;
            } else if (!wcscmp(wsz, L"ms")) {
                timeunit = TimeUnit_ms;
            } else if (!wcscmp(wsz, L"s")) {
                timeunit = TimeUnit_s;
            } else {
                return E_INVALIDARG;
            }

            return S_OK;
        }

        inline
        LPCWSTR 
        GetTimeUnitName(
            __in  TimeUnit timeunit
            )
        {
            return (timeunit >= 0 && timeunit < TimeUnit__count) ? _g_wszTimeUnitName[timeunit] : L"unknown-time-unit";
        }

        class CTimePresenter
        {
        public:
            CTimePresenter(__in TimeUnit Unit = TimeUnit__count, __in TimeUnit Precision = TimeUnit__count)
            {
                m_Unit = (Unit < TimeUnit__count) ? Unit : TimeUnit_us;
                m_Precision = (Precision < TimeUnit__count) ? Precision : (Unit < TimeUnit__count) ? Unit : TimeUnit_us;
            }

        public:
            void Print(__in TimeStampDelta delta) const
            {
                Print(stdout, delta);                
            }

            void Print(__in FILE* pFile, __in TimeStampDelta delta) const
            {
                fprintf(pFile,
                    "%.*f",
                    (m_Unit > m_Precision) ? (m_Unit - m_Precision) * 3 : 0, 
                    (delta.nsec / _g_dblTimeUnitScale[m_Unit])
                    );
            }

            void PrintAttr(__in LPCWSTR szAttr, __in TimeStampDelta delta) const
            {
                PrintAttr(stdout, szAttr, delta);
            }

            void PrintAttr(__in FILE* pFile, __in LPCWSTR szAttr, __in TimeStampDelta delta) const
            {
                fprintf(pFile,
                    " %ws=\"%.*f\"",
                    szAttr,
                    (m_Unit > m_Precision) ? (m_Unit - m_Precision) * 3 : 0, 
                    (delta.nsec / _g_dblTimeUnitScale[m_Unit])
                    );
            }

            TimeUnit GetUnit() const
            {
                return m_Unit;
            }
            TimeUnit GetPrecision() const
            {
                return m_Precision;
            }

            __declspec(property(get=GetUnit))       TimeUnit Unit;
            __declspec(property(get=GetPrecision))  TimeUnit Precision;
        private:
            TimeUnit    m_Unit;
            TimeUnit    m_Precision;
        };

        struct CTimeConfig
        {
            CTimePresenter  TimePresenter;
            TimeStampDelta  dtMinToReport;

        public:
            CTimeConfig(
                __in  const CTimePresenter& _TimePresenter = CTimePresenter(),
                __in  const TimeStampDelta _dtMinToReport = TimeStampDelta::Zero
                )
                : TimePresenter(_TimePresenter)
                , dtMinToReport(_dtMinToReport)
            {
            }

            bool ShouldBeReported(__in TimeStampDelta delta) const
            {
                return (delta >= dtMinToReport) || (delta <= -dtMinToReport);
            }
        };


        //
        // XML encoding
        //

        inline
        void 
        EscapeXml(
            __inout CStringW& sText,
            __in_opt LPCWSTR wszText,
            __in  DWORD dwFlags = ATL_ESC_FLAG_NONE
            )
        {
            const int cchText = static_cast<int>(wszText ? wcslen(wszText) : 0);
            if (cchText) {
                const int cchBuffer = EscapeXML(wszText, cchText, NULL, 0, dwFlags);
                const LPWSTR wszBuffer = sText.GetBufferSetLength(cchBuffer);
                const int cnt = EscapeXML(wszText, cchText, wszBuffer, cchBuffer + 1, dwFlags);
                sText.ReleaseBufferSetLength(cnt);
                if (!cnt) {
                    AtlThrow(E_OUTOFMEMORY);
                }
            } else {
                sText.SetString(L"");
            }
        }


        //
        // XML Presentation
        //

        class CXmlWriter
        {
        public:
            struct out_of_order {};
            struct missing_element_name {};

            CXmlWriter(
                __in const CTimeConfig& _TimeConfig, 
                __in_opt UINT32 cIndent = 0,
                __in_opt FILE* pFile = NULL
                )
                : TimeConfig(_TimeConfig)
                , m_cIndent(cIndent)
                , m_fAttr(false)
                , m_fInline(false)
                , m_pFile(pFile ? pFile : stdout)
            {
            }
            
            void Start(__in LPCWSTR szName)
            {
                if (m_fInline) {
                    throw out_of_order();
                }
                if (m_fAttr) {
                    fprintf(m_pFile, ">\n");
                }
                fprintf(m_pFile, "%*s<%ws", m_cIndent, "", szName);
                m_cIndent += 2;
                m_fAttr = true;
            }

            void End(__in_opt LPCWSTR szName = NULL)
            {
                m_cIndent -= 2;
                if (!m_fAttr) {
                    if (szName) {
                        if (m_fInline) {
                            fprintf(m_pFile, "</%ws>\n", szName);
                            m_fInline = false;
                        } else {
                            fprintf(m_pFile, "%*s</%ws>\n", m_cIndent, "", szName);
                        }
                    } else {
                        throw std::invalid_argument("szName");
                    }
                } else {
                    fprintf(m_pFile, " />\n");
                }
                m_fAttr = false;
            }


            void CData(__in LPCWSTR swzCData)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "<![CDATA[%ws]]>", swzCData);
            }


            void CData(__in LPCSTR szCData)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "<![CDATA[\n%s\n]]>", szCData);
            }

            void CData(__in_ecount(cchCData) CHAR const* rgCData, ULONG cchCData)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "<![CDATA[\n%.*s\n]]>", cchCData, rgCData);
            }

            void Text(__in LPCWSTR szValue)
            {
                _CloseAttrOpenInline();
                EscapeXml(m_sCachedValue, szValue, ATL_ESC_FLAG_ATTR);
                fprintf(m_pFile, "%ws", m_sCachedValue.GetString());
            }

            void Text(__in TimeStampDelta dt)
            {
                _CloseAttrOpenInline();
                TimeConfig.TimePresenter.Print(m_pFile, dt);
            }

            void Text(__in TimeStamp ts)
            {
                Text(TimeStampDelta(ts.nsec));
            }

            void Text(__in signed char decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%d", static_cast<LONG>(decimal));
            }

            void Text(__in SHORT decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%d", static_cast<LONG>(decimal));
            }

            void Text(__in INT decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%d", decimal);
            }

            void Text(__in LONG decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%d", decimal);
            }

            void Text(__in LONGLONG decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%I64d", decimal);
            }

            void Text(__in BYTE decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%u", static_cast<ULONG>(decimal));
            }

            void Text(__in USHORT decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%u", static_cast<ULONG>(decimal));
            }

            void Text(__in UINT decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%u", decimal);
            }

            void Text(__in ULONG decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%u", decimal);
            }

            void Text(__in ULONGLONG decimal)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%I64u", decimal);
            }

            void Text(__in double decimal, int precision = 3)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%.*f", precision, decimal);
            }

            void TextHex(__in BYTE hex)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "0x%02x", static_cast<ULONG>(hex));
            }

            void TextHex(__in USHORT hex)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "0x%04x", static_cast<ULONG>(hex));
            }

            void TextHex(__in UINT hex)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "0x%08x", hex);
            }

            void TextHex(__in ULONG hex)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "0x%08x", hex);
            }

            void TextHex(__in ULONGLONG hex)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "0x%016I64x", hex);
            }

            void TextChar(__in CHAR ch)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%hc", ch);
            }

            void TextChar(__in WCHAR wch)
            {
                _CloseAttrOpenInline();
                fprintf(m_pFile, "%wc", wch);
            }

            void TextTrueFalse(__in BOOL boolean)
            {
                Text(boolean ? L"true" : L"false");
            }
            
            void TextYesNo(__in BOOL boolean)
            {
                Text(boolean ? L"yes" : L"no");
            }
            
            void TextOnOff(__in BOOL boolean)
            {
                Text(boolean ? L"on" : L"off");
            }
            
            void TextEnabledDisabled(__in BOOL boolean)
            {
                Text(boolean ? L"enabled" : L"disabled");
            }

        protected:
            void _CheckAttr()
            {
                if (!m_fAttr) {
                    throw out_of_order();
                }
            }

            void _CloseAttrOpenInline()
            {
                if (m_fAttr) {
                    fprintf(m_pFile, ">");
                }
                m_fAttr = false;
                m_fInline = true;
            }
        public:

            void Attr(__in LPCWSTR szName, __in LPCWSTR szValue)
            {
                _CheckAttr();
                EscapeXml(m_sCachedValue, szValue, ATL_ESC_FLAG_ATTR);
                fprintf(m_pFile, " %ws=\"%ws\"", szName, m_sCachedValue.GetString());
            }

            void Attr(__in LPCWSTR szName, __in TimeStampDelta dt)
            {
                _CheckAttr();
                TimeConfig.TimePresenter.PrintAttr(m_pFile, szName, dt);
            }

            void Attr(__in LPCWSTR szName, __in TimeStamp ts)
            {
                Attr(szName, TimeStampDelta(ts.nsec));
            }

            void Attr(__in LPCWSTR szName, __in signed char decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%d\"", szName, static_cast<LONG>(decimal));
            }

            void Attr(__in LPCWSTR szName, __in SHORT decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%d\"", szName, static_cast<LONG>(decimal));
            }

            void Attr(__in LPCWSTR szName, __in INT decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%d\"", szName, decimal);
            }

            void Attr(__in LPCWSTR szName, __in LONG decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%d\"", szName, decimal);
            }

            void Attr(__in LPCWSTR szName, __in LONGLONG decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%I64d\"", szName, decimal);
            }

            void Attr(__in LPCWSTR szName, __in BYTE decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%u\"", szName, static_cast<ULONG>(decimal));
            }

            void Attr(__in LPCWSTR szName, __in USHORT decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%u\"", szName, static_cast<ULONG>(decimal));
            }

            void Attr(__in LPCWSTR szName, __in UINT decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%u\"", szName, decimal);
            }

            void Attr(__in LPCWSTR szName, __in ULONG decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%u\"", szName, decimal);
            }

            void Attr(__in LPCWSTR szName, __in ULONGLONG decimal)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%I64u\"", szName, decimal);
            }

            void Attr(__in LPCWSTR szName, __in double decimal, int precision = 3)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%.*f\"", szName, precision, decimal);
            }

            void AttrHex(__in LPCWSTR szName, __in BYTE hex)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"0x%02x\"", szName, static_cast<ULONG>(hex));
            }

            void AttrHex(__in LPCWSTR szName, __in USHORT hex)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"0x%04x\"", szName, static_cast<ULONG>(hex));
            }

            void AttrHex(__in LPCWSTR szName, __in UINT hex)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"0x%08x\"", szName, hex);
            }

            void AttrHex(__in LPCWSTR szName, __in ULONG hex)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"0x%08x\"", szName, hex);
            }

            void AttrHex(__in LPCWSTR szName, __in ULONGLONG hex)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"0x%016I64x\"", szName, hex);
            }

            void AttrChar(__in LPCWSTR szName, __in CHAR ch)
            {
                _CheckAttr();
                fprintf(m_pFile, "%ws=\"%hc\"", szName, ch);
            }

            void AttrChar(__in LPCWSTR szName, __in WCHAR wch)
            {
                _CheckAttr();
                fprintf(m_pFile, " %ws=\"%wc\"", szName, wch);
            }

            void AttrTrueFalse(__in LPCWSTR szName, __in BOOL boolean)
            {
                Attr(szName, boolean ? L"true" : L"false");
            }
            
            void AttrYesNo(__in LPCWSTR szName, __in BOOL boolean)
            {
                Attr(szName, boolean ? L"yes" : L"no");
            }
            
            void AttrOnOff(__in LPCWSTR szName, __in BOOL boolean)
            {
                Attr(szName, boolean ? L"on" : L"off");
            }
            
            void AttrEnabledDisabled(__in LPCWSTR szName, __in BOOL boolean)
            {
                Attr(szName, boolean ? L"enabled" : L"disabled");
            }
            
            UINT32 GetIndent() const
            {
                return m_cIndent;
            }
            __declspec(property(get=GetIndent)) UINT32 Indent;

        public:
            CTimeConfig TimeConfig;

        private:
            CStringW    m_sCachedValue;
            bool        m_fAttr;
            bool        m_fInline;
            UINT32      m_cIndent;
            FILE*       m_pFile;
        };


    };
};

#endif // __XPERFINFODEV_XMLACTIONS_HPP__
