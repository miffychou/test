/*++

Copyright (c) 2006 Microsoft Corporation

Module Name:

    XPerfAddIn_CoreDev.hpp

Abstract:

    C++ client-side support for XPerfAddIn_Core.hpp

Author:

    Cristian Levcovici (CrisL)

Revision History:

--*/

#pragma once

#include <XPerfCoreDev.hpp>
#include <XPerfAddIn_Core.hpp>

#include <iterator>
#include <vector>
#include <map>
#include <functional>
#include <algorithm>
#include <stack>
#include <map>
#include <set>
#include <vector>
#include <cwchar>


namespace XPerfAddIn
{
    //
    // Client side support for CurrentThread Context infosource
    //

    class CCurrentThreadCtx
    {
    public:
        HRESULT OnSessionConnect(
            __in  ISession* pSession
            )
        {
            COMGUARD(pSession->QueryService(&m_spCurrentThreadIS, XPC_QS_Context));
            COMGUARD(m_spCurrentThreadIS->GetCurrentThreadIds(&m_nCpus, &m_rgCurrentThreads));

            return S_OK;
        }

    public:
        ULONG size() const
        {
            return m_nCpus;
        }

        ULONG operator[](ULONG iCpu) const
        {
            return (iCpu < m_nCpus) ? m_rgCurrentThreads[iCpu] : ULONG_MAX;
        }

        ULONG operator[](__in const EVENT_RECORD* pEventRecord) const
        {
            return operator[](GetEventProcessorIndex(pEventRecord));
        }

    public:
        CCurrentThreadCtx() 
            : m_nCpus()
            , m_rgCurrentThreads()
        {
        }

    private:
        CComPtr<ICurrentThreadCtxInfoSource>    m_spCurrentThreadIS;

        // Shared state owned and maintained by ICurrentThreadCtxInfoSource
        ULONG                                   m_nCpus;
        const ULONG*                            m_rgCurrentThreads;
    };


    //
    // Ordering CSwitch events by SwitchOutTime
    //

    struct lessCSwitchDataBySwitchOutTime
    {
        bool operator()(__in  const ICSwitchInfoSource::CSwitchData& lhs, __in  const ICSwitchInfoSource::CSwitchData& rhs) const
        {
            return lhs.SwitchOutTime < rhs.SwitchOutTime;
        }

        bool operator()(__in  const TimeStamp& ts, __in  const ICSwitchInfoSource::CSwitchData& rhs) const
        {
            return ts < rhs.SwitchOutTime;
        }

        bool operator()(__in  const ICSwitchInfoSource::CSwitchData& lhs, __in  const TimeStamp& ts) const
        {
            return lhs.SwitchOutTime < ts;
        }
    };


    //
    // Ordering ReadyThread events by Time
    //

    struct lessReadyThreadDataByTime
    {
        bool operator()(const IReadyThreadInfoSource::ReadyThreadData& lhs, const IReadyThreadInfoSource::ReadyThreadData& rhs) const
        {
            return lhs.Time < rhs.Time;
        }

        bool operator()(__in  const TimeStamp& ts, __in  const IReadyThreadInfoSource::ReadyThreadData& rhs) const
        {
            return ts < rhs.Time;
        }

        bool operator()(__in  const IReadyThreadInfoSource::ReadyThreadData& lhs, __in  const TimeStamp& ts) const
        {
            return lhs.Time < ts;
        }
    };

    //
    // Ordering ClockInterrupt events by StartTime
    // 

    struct lessClockInterruptDataByStartTime
    {
        bool operator()(const IClockInterruptInfoSource::ClockInterruptData& lhs, const IClockInterruptInfoSource::ClockInterruptData& rhs) const   
        {
            return lhs.StartTime < rhs.StartTime;
        }
        bool operator()(const IClockInterruptInfoSource::ClockInterruptData& lhs, const TimeStamp& ts) const   
        {
            return lhs.StartTime < ts;
        }
        bool operator()(const TimeStamp& ts, const IClockInterruptInfoSource::ClockInterruptData& rhs) const
        {
            return ts < rhs.StartTime;
        }
    };

    //
    // Ordering Scheduler Analysis events by Time
    //

    struct lessSchedulerAnalysisEventByTime
    {
        bool operator()(__in const ISchedulerAnalysisInfoSource::SchedulerAnalysisEvent& lhs, __in const ISchedulerAnalysisInfoSource::SchedulerAnalysisEvent& rhs)
        {
            return lhs.EventTime < rhs.EventTime;
        }

        bool operator()(__in const TimeStamp& lhs, __in const ISchedulerAnalysisInfoSource::SchedulerAnalysisEvent& rhs)
        {
            return lhs < rhs.EventTime;
        }

        bool operator()(__in const ISchedulerAnalysisInfoSource::SchedulerAnalysisEvent& lhs, __in const TimeStamp& rhs)
        {
            return lhs.EventTime < rhs;
        }
    };

    //
    // Ordering Ipi events by StartTime
    // 

    struct lessIpiDataByStartTime
    {
        bool operator()(const IIpiInfoSource::IpiData& lhs, const IIpiInfoSource::IpiData& rhs) const   
        {
            return lhs.StartTime < rhs.StartTime;
        }
        bool operator()(const IIpiInfoSource::IpiData& lhs, const TimeStamp& ts) const   
        {
            return lhs.StartTime < ts;
        }
        bool operator()(const TimeStamp& ts, const IIpiInfoSource::IpiData& rhs) const
        {
            return ts < rhs.StartTime;
        }
    };

    //
    // Ordering TimerExpiration events by StartTime
    // 

    struct lessTimerExpirationDataByStartTime
    {
        bool operator()(const ITimerExpirationInfoSource::TimerExpirationData& lhs, const ITimerExpirationInfoSource::TimerExpirationData& rhs) const   
        {
            return lhs.StartTime < rhs.StartTime;
        }
        bool operator()(const ITimerExpirationInfoSource::TimerExpirationData& lhs, const TimeStamp& ts) const   
        {
            return lhs.StartTime < ts;
        }
        bool operator()(const TimeStamp& ts, const ITimerExpirationInfoSource::TimerExpirationData& rhs) const
        {
            return ts < rhs.StartTime;
        }
    };

    //
    // Ordering CState events by EndTime
    // 
    
    struct lessCStateDataByEndTime
    {
        bool operator()(const ICStateInfoSource::CStateData& lhs, const ICStateInfoSource::CStateData& rhs) const   
        {
            return lhs.EndTime < rhs.EndTime;
        }
        bool operator()(const ICStateInfoSource::CStateData& lhs, const TimeStamp& ts) const   
        {
            return lhs.EndTime < ts;
        }
        bool operator()(const TimeStamp& ts, const ICStateInfoSource::CStateData& rhs) const
        {
            return ts < rhs.EndTime;
        }
    };

    //
    // Computing CSwitch TimeSinceLast
    //

    class CCSwitchTimeSinceLastProperty
    {
    public:

        CCSwitchTimeSinceLastProperty(const TimeStamp FirstReliableCSwitch)
            : m_FirstReliableCSwitch(FirstReliableCSwitch)
        {}

        void Reset()
        {
            m_mLastSwitchOutTime.clear();
        }

        void OnSwitchOut(
            __in  TimeStamp now,
            __in  const IProcessInfoSource::ThreadData* pThread
            )
        {
            if (pThread && pThread->ThreadId) {
                m_mLastSwitchOutTime[pThread] = now;
            }
        }

        TimeStampDelta OnSwitchIn(
            __in  TimeStamp now,
            __in  const IProcessInfoSource::ThreadData* pThread
            )
        {            
            if (pThread && pThread->ThreadId) {
                CLastSwitchOutTime::iterator it = m_mLastSwitchOutTime.find(pThread);
                TimeStamp lastSwitchOutTime;
                if (it != m_mLastSwitchOutTime.end()) {
                    lastSwitchOutTime = it->second;
                    m_mLastSwitchOutTime.erase(it);
                } else {
                    lastSwitchOutTime = (pThread->StartTime > now ) ? now :
                                        (pThread->StartTime > m_FirstReliableCSwitch) ? pThread->StartTime :
                                        m_FirstReliableCSwitch;                            
                }

                return (now - lastSwitchOutTime);
            }
            return TimeStampDelta::Zero;
        }

    private:
        typedef std::map<const IProcessInfoSource::ThreadData*, TimeStamp> CLastSwitchOutTime;
        CLastSwitchOutTime  m_mLastSwitchOutTime;
        TimeStamp m_FirstReliableCSwitch;
    };


    //
    // Interlacing of multiple ordered streams: CMultiStreamT<TIterator, TLessStreamValue>
    //

    template <typename TStream, typename TLessStreamValue = std::less<typename TStream::value_type> >
    class CMultiStreamIteratorT
    {
        typedef typename TStream::iterator Iterator;

        class AutoIterator
        {
            Iterator    m_it;
            Iterator    m_end;
            Iterator    m_begin;

        public:
            AutoIterator(
                Iterator _First,
                Iterator _Last
                )
                : m_it(_First)
                , m_end(_Last)
                , m_begin(_First)
            {
            }

            AutoIterator& operator--()
            {
                --m_it;
                return *this;
            }

            AutoIterator& operator++()
            {
                ++m_it;
                return *this;
            }

            const Iterator& GetStreamIterator() const
            {
                return m_it;
            }

            typename Iterator::reference operator*() const
            {
                return *m_it;
            }

            Iterator operator->() const
            {
                return m_it;
            }

            bool operator==(const AutoIterator& other) const
            {
                return (m_it == other.m_it) && (m_end == other.m_end);
            }

            bool operator!=(const AutoIterator& other) const
            {
                return !operator==(other);
            }

            bool IsAtBegin() const
            {
                return (m_it == m_begin);
            }

            bool IsAtEnd() const
            {
                return (m_it == m_end);
            }
        };

        typedef std::vector<AutoIterator> CWaveFront;

        CWaveFront  m_vWaveFront;

        class CGreaterAutoIterator
        {
            TLessStreamValue    m_pred;
        
        public:
            CGreaterAutoIterator(TLessStreamValue pred)
                : m_pred(pred)
            {
            }

            bool operator()(const AutoIterator& lhs, const AutoIterator& rhs) const
            {
                return m_pred(*rhs.GetStreamIterator(), *lhs.GetStreamIterator()); // less to greater conversion
            }
        };

        CGreaterAutoIterator    m_GreaterAutoIterator;

    public:
        CMultiStreamIteratorT(
            )
            : m_GreaterAutoIterator(TLessStreamValue())
        {
        }

        template <typename TStreamCollIterator>
        CMultiStreamIteratorT(
            TStreamCollIterator _First,
            TStreamCollIterator _Last,
            TLessStreamValue pred = TLessStreamValue()
            )
            : m_GreaterAutoIterator(pred)
        {
            for (typename TStreamCollIterator it = _First; it != _Last; ++it) {
                if (!it->empty()) {
                    m_vWaveFront.push_back(AutoIterator(it->begin(), it->end()));
                }
            }
            std::make_heap(m_vWaveFront.begin(), m_vWaveFront.end(), m_GreaterAutoIterator);
        }

        CMultiStreamIteratorT& operator++()
        {
            if (!m_vWaveFront.empty()) {
                std::pop_heap(m_vWaveFront.begin(), m_vWaveFront.end(), m_GreaterAutoIterator);
                ++m_vWaveFront.back();
                if (m_vWaveFront.back().IsAtEnd()) {
                    m_vWaveFront.pop_back();
                } else {
                    std::push_heap(m_vWaveFront.begin(), m_vWaveFront.end(), m_GreaterAutoIterator);
                }
            }
            return *this;
        }

        bool IsFirstOnStream() const
        {
            return m_vWaveFront.front().IsAtBegin();
        }

        Iterator GetPrevOnStream() const
        {
            AutoIterator it = m_vWaveFront.front();
            --it;
            return it.GetStreamIterator();
        }

        bool IsLastOnStream() const
        {
            AutoIterator it = m_vWaveFront.front();
            ++it;
            return it.IsAtEnd();
        }

        Iterator GetNextOnStream() const
        {
            AutoIterator it = m_vWaveFront.front();
            ++it;
            return it.GetStreamIterator();
        }

        typename Iterator::value_type& operator*() const
        {
            return m_vWaveFront.front().operator *();
        }

        Iterator operator->() const
        {
            return m_vWaveFront.front().operator->();
        }

        bool operator==(const CMultiStreamIteratorT& other) const
        {
            if (m_vWaveFront.size() != other.m_vWaveFront.size()) {
                return false;
            }

            for (CWaveFront::size_type i = 0; i < m_vWaveFront.size(); ++i) {
                if (m_vWaveFront[i] != other.m_vWaveFront[i]) {
                    return false;
                }
            }

            return true;
        }

        bool operator!=(const CMultiStreamIteratorT& other) const
        {
            return ! operator==(other);
        }

        bool IsAtEnd() const
        {
            return m_vWaveFront.empty();
        }
    };


    template <typename TIterator, typename TLessStreamValue = std::less<typename TStream::value_type> >
    class CMultiStreamT
    {
        TIterator           m_First;
        TIterator           m_Last;
        TLessStreamValue    m_pred;

    public:
        typedef CMultiStreamIteratorT<typename std::iterator_traits<TIterator>::value_type, TLessStreamValue> const_iterator;

        CMultiStreamT(
            __in  TIterator _First,
            __in  TIterator _Last,
            __in  TLessStreamValue pred = TLessStreamValue()
            )
            : m_First(_First)
            , m_Last(_Last)
            , m_pred(pred)
        {
        }

        const_iterator begin() const 
        {
            return const_iterator(m_First, m_Last, m_pred);
        }

        // Note: Using CMultiStreamIteratorT<,>::IsAtEnd() is the preferred way to check for end of sequence
        const_iterator end() const 
        {
            return const_iterator();
        }
    };

    typedef CMultiStreamT<const ICSwitchInfoSource::StridedCSwitchDatas*, lessCSwitchDataBySwitchOutTime> CCSwitchMultiStream;
    typedef CMultiStreamT<const ICSwitchInfoSource2::StridedCSwitchDatas2*, lessCSwitchDataBySwitchOutTime> CCSwitchMultiStream2;
    typedef CMultiStreamT<const IReadyThreadInfoSource::StridedReadyThreadDatas*, lessReadyThreadDataByTime> CReadyThreadMultiStream;


    //
    // CSwitch ReadyThread Interlacer
    //

    struct CCSwitchPair
    {
        __field_ecount(1) const ICSwitchInfoSource2::CSwitchData2* pOld;
        __field_ecount_opt(1) const ICSwitchInfoSource2::CSwitchData2* pNew;

        CCSwitchPair(
            __in  const ICSwitchInfoSource2::CSwitchData2* _pOld,
            __in_opt const ICSwitchInfoSource2::CSwitchData2* _pNew
            )
            : pOld(_pOld)
            , pNew(_pNew)
        {
        }
    };


    struct CCSwitchPairOpt
    {
        __field_ecount_opt(1) const ICSwitchInfoSource2::CSwitchData2* pOld;
        __field_ecount_opt(1) const ICSwitchInfoSource2::CSwitchData2* pNew;

        CCSwitchPairOpt(
            __in_opt const ICSwitchInfoSource2::CSwitchData2* _pOld = NULL,
            __in_opt const ICSwitchInfoSource2::CSwitchData2* _pNew = NULL
            )
            : pOld(_pOld)
            , pNew(_pNew)
        {
        }

        CCSwitchPairOpt(
            __in  const CCSwitchPair& CSwitchPair
            )
            : pOld(CSwitchPair.pOld)
            , pNew(CSwitchPair.pNew)
        {
        }
    };


    template <typename _Derived>
    class CCSwitchReadyThreadInterlacer
    {
    public:
        CCSwitchReadyThreadInterlacer(
            __in  SIZE_T nCpus,
            __in_ecount(nCpus) const ICSwitchInfoSource2::StridedCSwitchDatas2 rgStridedCSwitchDatas[],
            __in_ecount(nCpus) const IReadyThreadInfoSource::StridedReadyThreadDatas rgStridedReadyThreadDatas[]
            )
            : m_CSwitchMultiStream(rgStridedCSwitchDatas, rgStridedCSwitchDatas + nCpus)
            , m_ReadyThreadMultiStream(rgStridedReadyThreadDatas, rgStridedReadyThreadDatas + nCpus)
        {
        }

        void
        Run()
        {
            CReadyThreadMultiStream::const_iterator itReadyThread = m_ReadyThreadMultiStream.begin();
            CCSwitchMultiStream2::const_iterator itCSwitch = m_CSwitchMultiStream.begin();

            while (!itCSwitch.IsAtEnd() && !itReadyThread.IsAtEnd())
            {
                if (itCSwitch->SwitchOutTime <= itReadyThread->Time)
                {
                    if(!_This()->OnCSwitch(GetCSwitchPair(itCSwitch))) return;
                    ++itCSwitch;
                }
                else
                {   
                    if(!_This()->OnReadyThread(&*itReadyThread)) return;
                    ++itReadyThread;
                }
            }

            // Uneven tails, enumerate in the rest of the CSwitches
            while (!itCSwitch.IsAtEnd())
            {
                if(!_This()->OnCSwitch(GetCSwitchPair(itCSwitch))) return;
                ++itCSwitch;
            }

            // Uneven tails, enumerate in the rest of the ReadyThreads
            while (!itReadyThread.IsAtEnd())
            {
                if(!_This()->OnReadyThread(&*itReadyThread)) return;
                ++itReadyThread;
            }
        }

    protected:
        bool 
        OnCSwitch(
            __in  const CCSwitchPair& CSwitchPair
            )
        {
            UNREFERENCED_PARAMETER(&CSwitchPair);
            return true;
        }

        bool
        OnReadyThread(
            __in  const IReadyThreadInfoSource::ReadyThreadData* pReadyThread
            )
        {
            UNREFERENCED_PARAMETER(pReadyThread);
            return true;
        }

        _Derived* _This()
        {
            return static_cast<_Derived*>(this);
        }

    private:
        static CCSwitchPair GetCSwitchPair(CCSwitchMultiStream2::const_iterator itCSwitch)
        {
            return CCSwitchPair(&*itCSwitch, itCSwitch.IsLastOnStream() ? NULL : &*itCSwitch.GetNextOnStream());
        }

    private:
        CCSwitchMultiStream2        m_CSwitchMultiStream;
        CReadyThreadMultiStream     m_ReadyThreadMultiStream;
    };


    template <typename _Derived>
    class CCSwitchReadyThreadInterlacerWithContext
        : public CCSwitchReadyThreadInterlacer<_Derived>
    {
    private:
        typedef CCSwitchReadyThreadInterlacer<_Derived> _Base;

    public:
        CCSwitchReadyThreadInterlacerWithContext(
            __in  SIZE_T nCpus,
            __in_ecount(nCpus) const ICSwitchInfoSource2::StridedCSwitchDatas2 rgStridedCSwitchDatas[],
            __in_ecount(nCpus) const IReadyThreadInfoSource::StridedReadyThreadDatas rgStridedReadyThreadDatas[]
            )
            : _Base(nCpus, rgStridedCSwitchDatas, rgStridedReadyThreadDatas)
            , m_FirstReliableContextSwitchTime(_I64_MIN)
        {
            m_vCurrentCSwitch.resize(nCpus);

            //
            // Compute First Reliable Context Switch
            //

            for (SIZE_T iCpu = 0; iCpu < nCpus; ++iCpu)
            {
                const TimeStamp FirstContextSwitchTime = (rgStridedCSwitchDatas[iCpu].empty() ? TimeStamp::Max : rgStridedCSwitchDatas[iCpu][0].SwitchOutTime);
                m_FirstReliableContextSwitchTime = (std::max)(m_FirstReliableContextSwitchTime, FirstContextSwitchTime);
            }
        }

    protected:
        bool
        OnCSwitch(
            __in  const CCSwitchPair& CSwitchPair
            )
        {
            if (CSwitchPair.pNew && CSwitchPair.pNew->Thread && CSwitchPair.pNew->Thread->ThreadId)
            {  
                // Find the previous CSwitch per thread
                CCSwitchPairOpt& PreviousCSwitchPairOnThread = m_mPreviousCSwitchPairOnThread[CSwitchPair.pNew->Thread];

                // Find the ReadyThread that readied the thread switched-in in this CSwitch
                CReadyThreadContextPerThread::iterator const itPendingReadyThread = m_mPendingReadyThreads.find(CSwitchPair.pNew->Thread);
                if (itPendingReadyThread != m_mPendingReadyThreads.end())
                {
                    //
                    // CSwitch has an associated ReadyThread
                    //

                    if(!_Base::_This()->OnCSwitchContext(CSwitchPair, itPendingReadyThread->second.first, itPendingReadyThread->second.second, PreviousCSwitchPairOnThread)) return false;
                    
                    // Remove ReadyThread since it was matched
                    m_mPendingReadyThreads.erase(itPendingReadyThread);
                }
                else
                {
                    //
                    // CSwitch doesn't have an associated ReadyThread
                    //

                    if(!_Base::_This()->OnCSwitchContext(CSwitchPair, NULL, NULL, PreviousCSwitchPairOnThread)) return false;
                }

                // Update the previous CSwitch per thread
                PreviousCSwitchPairOnThread = CSwitchPair;
            }
            else
            {
                //
                // Unknown or Idle thread or Last CSwitch on stream
                //

                if(!_Base::_This()->OnCSwitchContext(CSwitchPair, NULL, NULL, CCSwitchPairOpt())) return false;
            }

            // Update Current CSwitch on CPU
            m_vCurrentCSwitch[CSwitchPair.pOld->Processor] = CSwitchPair;

            return true;
        }

        bool
        OnReadyThread(
            __in  const IReadyThreadInfoSource::ReadyThreadData* pReadyThread
            )
        {
            const CCSwitchPairOpt& RunningCSwitchPair = m_vCurrentCSwitch[pReadyThread->Processor];

            if (pReadyThread->Time >= m_FirstReliableContextSwitchTime)
            {
                CReadyThreadData& PreviousReadyThreadOnThread = m_mPendingReadyThreads[pReadyThread->Thread];

                if(!_Base::_This()->OnReadyThreadContext(pReadyThread, PreviousReadyThreadOnThread.first, RunningCSwitchPair)) return false;

                // Update pending ReadyThreads
                PreviousReadyThreadOnThread = std::make_pair(pReadyThread, (RunningCSwitchPair.pNew ? RunningCSwitchPair.pNew->Thread : NULL));
            }
            else
            {
                if(!_Base::_This()->OnReadyThreadContext(pReadyThread, NULL, RunningCSwitchPair)) return false;
            }

            return true;
        }

        friend class _Base;

    protected:
        bool
        OnCSwitchContext(
            __in  const CCSwitchPair& CSwitchPair,
            __in_opt const IReadyThreadInfoSource::ReadyThreadData* pReadyThread,
            __in_opt const IProcessInfoSource::ThreadData* pReadyingThread,
            __in  const CCSwitchPairOpt& PreviousCSwitchPairOnThread
            )
        {
            UNREFERENCED_PARAMETER(&CSwitchPair);
            UNREFERENCED_PARAMETER(pReadyingThread);
            UNREFERENCED_PARAMETER(pReadyThread);
            UNREFERENCED_PARAMETER(&PreviousCSwitchPairOnThread);

            return true;
        }

        bool
        OnReadyThreadContext(
            __in  const IReadyThreadInfoSource::ReadyThreadData* pReadyThread,
            __in_opt const IReadyThreadInfoSource::ReadyThreadData* pPreviousPendingReadyThread,
            __in  const CCSwitchPairOpt& RunningCSwitchPair
            )
        {
            UNREFERENCED_PARAMETER(pPreviousPendingReadyThread);

            return _Base::_This()->OnReadyThreadContext(pReadyThread, RunningCSwitchPair);
        }

        bool
        OnReadyThreadContext(
            __in  const IReadyThreadInfoSource::ReadyThreadData* pReadyThread,
            __in  const CCSwitchPairOpt& RunningCSwitchPair
            )
        {
            UNREFERENCED_PARAMETER(pReadyThread);
            UNREFERENCED_PARAMETER(&RunningCSwitchPair);

            return true;
        }

    private:

        //
        // Local context
        //

        typedef std::map<const IProcessInfoSource::ThreadData*, CCSwitchPairOpt> CCSwitchContextPerThread;
        typedef std::pair<const IReadyThreadInfoSource::ReadyThreadData*, const IProcessInfoSource::ThreadData*> CReadyThreadData;
        typedef std::map<const IProcessInfoSource::ThreadData*, CReadyThreadData> CReadyThreadContextPerThread;
        typedef std::vector<CCSwitchPairOpt> CCSwitchContextPerCpu;

        CReadyThreadContextPerThread m_mPendingReadyThreads;
        CCSwitchContextPerThread     m_mPreviousCSwitchPairOnThread;
        CCSwitchContextPerCpu        m_vCurrentCSwitch;
    protected:
        TimeStamp                    m_FirstReliableContextSwitchTime;
    };


    //
    // Client side support for automtic cache reset
    //

    template <class T>
    class CAutoClearCache
    {
    public:
        CAutoClearCache(
            T* p
            )
            : m_p(p)
        {
        }

        void Cancel()
        {
            m_p = NULL;
        }

        ~CAutoClearCache()
        {
            if (m_p)
            {
                m_p->OnClearCache();
            }
        }

    private:
        T* m_p;
    };

    //
    // Client side support for CSwitch Navigation
    //

    template <class TInfoSource, class TStridedData, class TData>
    class CCSwitchNavigatorTemplate
    {
    protected:
        CComPtr<TInfoSource>    m_spCSwitch;

    public:
        HRESULT OnSessionConnect(
            __in  ISession* pSession,
            DWORD dwDependencyFlags = 0
            )
        {
            CComPtr<ITraceInfo> spTraceInfo;
            COMGUARD(pSession->QueryInterface(&spTraceInfo));
            
            m_nCpus = spTraceInfo->NumberOfProcessors;

            COMGUARD(pSession->QueryService(&m_spCSwitch, dwDependencyFlags));

            return S_OK;
        }

        HRESULT OnPrepareCache()
        {
            //
            // Allocate buffers
            //

            CAutoVectorPtr<TStridedData> rgvStridedCSwitchDatas;

            if (!rgvStridedCSwitchDatas.Allocate(m_nCpus))
            {
                return E_OUTOFMEMORY;
            }

            //
            // Retrieve strided arrays
            //

            SIZE_T nCpus = m_nCpus;

            COMGUARD(m_spCSwitch->QueryStridedData(rgvStridedCSwitchDatas, nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

            if (nCpus != m_nCpus)
            {
                return E_UNEXPECTED;
            }

            //
            // Transfer ownership
            //

            m_rgvStridedCSwitchDatas = rgvStridedCSwitchDatas;

            return S_OK;
        }

        void OnClearCache()
        {
            m_rgvStridedCSwitchDatas.Free();
        }

    public:
        _Ret_maybenull_ const TData*
        GetPreviousCSwitchOnCpu(
            __in  const TData* const pCSwitch
            ) const throw()
        {
            const SIZE_T iCpu = pCSwitch->Processor;
            const SIZE_T cbStride = m_rgvStridedCSwitchDatas[iCpu].stride();

            const SIZE_T iCSwitch = (TStridedData::iterator(pCSwitch, cbStride) - m_rgvStridedCSwitchDatas[iCpu].begin());

            return (iCSwitch > 0) ? &m_rgvStridedCSwitchDatas[iCpu][iCSwitch-1] : NULL;
        }

        _Ret_maybenull_ const TData*
        GetNextCSwitchOnCpu(
            __in  const TData* const pCSwitch
            ) const throw()
        {
            const SIZE_T iCpu = pCSwitch->Processor;
            const SIZE_T cbStride = m_rgvStridedCSwitchDatas[iCpu].stride();

            const SIZE_T iCSwitch = (TStridedData::iterator(pCSwitch, cbStride) - m_rgvStridedCSwitchDatas[iCpu].begin());

            return (iCSwitch < (m_rgvStridedCSwitchDatas[iCpu].size() - 1)) ? &m_rgvStridedCSwitchDatas[iCpu][iCSwitch+1] : NULL;
        }        

        // it is assumed to be known that the given thread id is running at the specified time on the specified CPU
        // otherwise NULL will be returned.
        _Ret_maybenull_ const TData*
        FindNextCSwitchOutOnThreadRunningAtTimeOnCpu_slow_(
            __in  const IProcessInfoSource::ThreadData* pThread,
            __in  TimeStamp timestamp,
            __in  SIZE_T nCpu
            ) const throw()
        {
            if (nCpu >= m_nCpus)
            {
                return NULL;
            }
            
            TStridedData& stridedCSwitchDatas = m_rgvStridedCSwitchDatas[nCpu];

            const TStridedData::iterator itFound = std::lower_bound(stridedCSwitchDatas.begin(), stridedCSwitchDatas.end(), timestamp, lessCSwitchDataBySwitchOutTime());
                                
            if (itFound != stridedCSwitchDatas.end()) 
            {
                const TData* current = &*itFound;

                if (current->Thread == pThread)
                {
                    return current;
                }
            }            

            return NULL;
        }

        // it is assumed to be known that the given thread id is running at the specified time
        // otherwise NULL will be returned.
        _Ret_maybenull_ const TData*
        FindNextCSwitchOutOnThreadRunningAtTime_slow_(
            __in  const IProcessInfoSource::ThreadData* pThread,
            __in  TimeStamp timestamp
            ) const throw()
        {
            for (SIZE_T iCpu = 0; iCpu < m_nCpus; ++iCpu)
            {
                const TData* result = FindNextCSwitchOutOnThreadRunningAtTimeOnCpu_slow_(pThread, timestamp, iCpu);
                if (result != NULL)
                {
                    return result;
                }
            }

            return NULL;
        }

        // it is assumed to be known that the given thread id is running at the specified time
        // otherwise NULL will be returned.
        _Ret_maybenull_ const TData*
        GetCurrentCSwitchInOnThreadOrFindNext_slow_(
            __in  const IProcessInfoSource::ThreadData* pThread,
            __in  TimeStamp timestamp
            ) const throw()
        {
            const TData* pCurrentResult = NULL;

            for (SIZE_T iCpu = 0; iCpu < m_nCpus; ++iCpu)
            {
                TStridedData& stridedCSwitchDatas = m_rgvStridedCSwitchDatas[iCpu];                

                TStridedData::iterator itFound = std::lower_bound(stridedCSwitchDatas.begin(), stridedCSwitchDatas.end(), timestamp, lessCSwitchDataBySwitchOutTime());
                                
                for (; itFound != stridedCSwitchDatas.end(); ++itFound) 
                {
                    const TStridedData::iterator itNextCSwitch = itFound+1;
                    const TData* pCSwitchIn = &*itFound;
                    TData const* pCSwitchOut = (itNextCSwitch != stridedCSwitchDatas.end()) ? &(*itNextCSwitch) : NULL;
                    
                    if (!pCSwitchOut)
                    {
                        continue;
                    }

                    if (pCSwitchOut->Thread == pThread)
                    {
                        if (pCSwitchIn->SwitchOutTime == timestamp)
                        {
                            return pCSwitchIn;                            
                        }
                        if ( (pCurrentResult == NULL) || 
                             (pCSwitchIn->SwitchOutTime < pCurrentResult->SwitchOutTime) )
                        {
                            pCurrentResult = pCSwitchIn;                            
                        }
                        break;
                    }                                        
                }
            }

            return pCurrentResult;
        }

    public:
        CCSwitchNavigatorTemplate()
            : m_nCpus()
        {
        }

    protected:
        ULONG   m_nCpus;
        CAutoVectorPtr<TStridedData> m_rgvStridedCSwitchDatas;
    };

    typedef CCSwitchNavigatorTemplate<
        ICSwitchInfoSource,
        ICSwitchInfoSource::StridedCSwitchDatas,
        ICSwitchInfoSource::CSwitchData> CCSwitchNavigator;

    typedef CCSwitchNavigatorTemplate<
        ICSwitchInfoSource2,
        ICSwitchInfoSource2::StridedCSwitchDatas2,
        ICSwitchInfoSource2::CSwitchData2> CCSwitchNavigator2;

    //
    // Client side support CSwitch Extension Lookup
    //

    template <class TInfoSource, class TStridedData, class TData>
    class CCSwitchExtLookupTemplate : public CCSwitchNavigatorTemplate<TInfoSource, TStridedData, TData>
    {
    protected:
        CComPtr<ICSwitchExtInfoSource> m_spCSwitchExt;

    public:
        HRESULT OnSessionConnect(
            __in  ISession* pSession
            )
        {
            COMGUARD(CCSwitchNavigatorTemplate::OnSessionConnect(pSession));
            COMGUARD(pSession->QueryService(&m_spCSwitchExt));

            return S_OK;
        }

        HRESULT OnPrepareCache()
        {
            COMGUARD(CCSwitchNavigatorTemplate::OnPrepareCache());

            //
            // Setup automatic cache reset
            //

            CAutoClearCache<CCSwitchNavigatorTemplate<TInfoSource, TStridedData, TData>> AutoClearCache(this);

            //
            // Allocate buffers
            //

            CAutoVectorPtr<ICSwitchExtInfoSource::StridedCSwitchExts> rgvStridedCSwitchExts;

            if (!rgvStridedCSwitchExts.Allocate(m_nCpus))
            {
                return E_OUTOFMEMORY;
            }

            //
            // Retrieve strided arrays
            //

            SIZE_T nCpus = m_nCpus;

            COMGUARD(m_spCSwitchExt->QueryStridedData(rgvStridedCSwitchExts, nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

            if (nCpus != m_nCpus)
            {
                return E_UNEXPECTED;
            }

            //
            // Cancel cache reset
            //

            AutoClearCache.Cancel();

            //
            // Transfer ownership
            //

            m_rgvStridedCSwitchExts = rgvStridedCSwitchExts;

            return S_OK;
        }

        void OnClearCache()
        {
            m_rgvStridedCSwitchExts.Free();
            CCSwitchNavigatorTemplate<TInfoSource, TStridedData, TData>::OnClearCache();
        }

    public:
        _Ret_notnull_ const ICSwitchExtInfoSource::CSwitchExt*
        GetCSwitchExtension(
            __in  const TData* const pCSwitch
            ) const throw()
        {
            const SIZE_T iCpu = pCSwitch->Processor;
            const SIZE_T cbStride = m_rgvStridedCSwitchDatas[iCpu].stride();

            const SIZE_T iCSwitch = (TStridedData::iterator(pCSwitch, cbStride) - m_rgvStridedCSwitchDatas[iCpu].begin());

            return &m_rgvStridedCSwitchExts[iCpu][iCSwitch];
        }

    public:
        CCSwitchExtLookupTemplate()
        {
        }

    protected:
        CAutoVectorPtr<ICSwitchExtInfoSource::StridedCSwitchExts> m_rgvStridedCSwitchExts;
    };

    typedef CCSwitchExtLookupTemplate<
        ICSwitchInfoSource,
        ICSwitchInfoSource::StridedCSwitchDatas,
        ICSwitchInfoSource::CSwitchData> CCSwitchExtLookup;

    typedef CCSwitchExtLookupTemplate<
        ICSwitchInfoSource2,
        ICSwitchInfoSource2::StridedCSwitchDatas2,
        ICSwitchInfoSource2::CSwitchData2> CCSwitchExtLookup2;

    //
    // Client side support ReadyThread Extension Lookup
    //

    class CReadyThreadExtLookup
    {
    protected:
        CComPtr<IReadyThreadInfoSource>    m_spReadyThread;
        CComPtr<IReadyThreadExtInfoSource2> m_spReadyThreadExt;

    public:
        HRESULT OnSessionConnect(
            __in  ISession* pSession
            )
        {
            CComPtr<ITraceInfo> spTraceInfo;
            COMGUARD(pSession->QueryInterface(&spTraceInfo));
            
            m_nCpus = spTraceInfo->NumberOfProcessors;

            COMGUARD(pSession->QueryService(&m_spReadyThread));
            COMGUARD(pSession->QueryService(&m_spReadyThreadExt));

            return S_OK;
        }

        HRESULT OnPrepareCache()
        {
            //
            // Allocate buffers
            //

            CAutoVectorPtr<IReadyThreadInfoSource::StridedReadyThreadDatas> rgvStridedReadyThreadDatas;
            CAutoVectorPtr<IReadyThreadExtInfoSource2::StridedReadyThreadExts2> rgvStridedReadyThreadExts;

            if (!rgvStridedReadyThreadDatas.Allocate(m_nCpus) || !rgvStridedReadyThreadExts.Allocate(m_nCpus))
            {
                return E_OUTOFMEMORY;
            }

            //
            // Retrieve strided arrays
            //

            SIZE_T nCpus = m_nCpus;

            COMGUARD(m_spReadyThread->QueryStridedData(rgvStridedReadyThreadDatas, nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

            if (nCpus != m_nCpus)
            {
                return E_UNEXPECTED;
            }

            COMGUARD(m_spReadyThreadExt->QueryStridedData(rgvStridedReadyThreadExts, nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

            if (nCpus != m_nCpus)
            {
                return E_UNEXPECTED;
            }

            //
            // Transfer ownership
            //

            m_rgvStridedReadyThreadDatas = rgvStridedReadyThreadDatas;
            m_rgvStridedReadyThreadExts = rgvStridedReadyThreadExts;

            return S_OK;
        }

        void OnClearCache()
        {
            m_rgvStridedReadyThreadDatas.Free();
            m_rgvStridedReadyThreadExts.Free();
        }

    public:
        _Ret_notnull_ const IReadyThreadExtInfoSource2::ReadyThreadExt2*
        GetReadyThreadExtension(
            __in  const IReadyThreadInfoSource::ReadyThreadData* const pReadyThread
            ) const throw()
        {
            const ULONG iCpu = pReadyThread->Processor;
            const SIZE_T cbStride = m_rgvStridedReadyThreadDatas[iCpu].stride();

            const SIZE_T iReadyThread = (IReadyThreadInfoSource::StridedReadyThreadDatas::iterator(pReadyThread, cbStride) - m_rgvStridedReadyThreadDatas[iCpu].begin());
            
            return &m_rgvStridedReadyThreadExts[iCpu][iReadyThread];
        }

    public:
        CReadyThreadExtLookup() 
            : m_nCpus()
        {
        }

    protected:
        ULONG   m_nCpus;
        CAutoVectorPtr<IReadyThreadInfoSource::StridedReadyThreadDatas> m_rgvStridedReadyThreadDatas;
        CAutoVectorPtr<IReadyThreadExtInfoSource2::StridedReadyThreadExts2> m_rgvStridedReadyThreadExts;
    };

    class CDpcIsrLookup
    {

    public:

        CDpcIsrLookup()
            : m_nCpus()
            , m_fDpcDataAvailable()
        {}    

        HRESULT OnSessionConnect(
            __in  ISession* pSession
            )
        {
            COMGUARD(pSession->QueryService(&m_spDpcIsr));

            return S_OK;
        }

        void OnClearCache()
        {
            m_rgStridedDpcIsrDatas.Free();
        }

        HRESULT OnPrepareCache()
        {
            COMGUARD(m_spDpcIsr->QueryStridedData(NULL, m_nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

            if (!m_rgStridedDpcIsrDatas.Allocate(m_nCpus))
            {
                return E_OUTOFMEMORY;
            }

            {
                SIZE_T nCpus = m_nCpus;

                COMGUARD(m_spDpcIsr->QueryStridedData(m_rgStridedDpcIsrDatas, nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

                if (nCpus != m_nCpus)
                {
                    return E_UNEXPECTED;
                }
            }

            m_fDpcDataAvailable = (m_spDpcIsr->IsDataAvailable(IDpcIsrInfoSource::Dpc) ? true : false);

            return S_OK;
        }

        bool
        IsDpcDataAvailable() const
        {
            return m_fDpcDataAvailable;
        }

        bool
        IsDpcInRangeAt(
            __in  TimeStamp Time,
            __in  ULONG Processor
            ) const
        {
            if (Processor >= m_nCpus)
            {
                return false;
            }

            const IDpcIsrInfoSource2::StridedDpcIsrDatas& StridedDpcIsrDatas = m_rgStridedDpcIsrDatas[Processor];

            return (!StridedDpcIsrDatas.empty() && (StridedDpcIsrDatas[0].EnterTime <= Time) && (StridedDpcIsrDatas[StridedDpcIsrDatas.size() - 1].ExitTime >= Time));
        }

        _Ret_maybenull_ const IDpcIsrInfoSource::DpcIsrData*
        GetDpcAt(
            __in  TimeStamp Time,
            __in  ULONG Processor
            ) const
        {
            if (Processor >= m_nCpus)
            {
                AtlThrow(E_UNEXPECTED);
            }

            const IDpcIsrInfoSource2::StridedDpcIsrDatas& StridedDpcIsrDatas = m_rgStridedDpcIsrDatas[Processor];

            IDpcIsrInfoSource2::StridedDpcIsrDatas::iterator it = std::lower_bound(StridedDpcIsrDatas.begin(), StridedDpcIsrDatas.end(), Time, lessDpcIsrDataByExitTime());
            
            while ((it != StridedDpcIsrDatas.end()) && (it->Type != IDpcIsrInfoSource::Dpc) && ((it->ExitTime == Time) || it->Overlap))
            {
                ++it;
            }

            if ((it != StridedDpcIsrDatas.end()) && (it->Type == IDpcIsrInfoSource::Dpc) && (it->EnterTime <= Time) && (it->ExitTime >= Time))
            {
                return &*it;
            }

            return NULL;
        }

        bool
        IsrDpcExecInTimeRange(
            __in  TimeStamp TimeStart,
            __in  TimeStamp TimeEnd,
            __in  ULONG Processor
            ) const
        {
            if (Processor >= m_nCpus)
            {
                AtlThrow(E_UNEXPECTED);
            }

            const IDpcIsrInfoSource2::StridedDpcIsrDatas& StridedDpcIsrDatas = m_rgStridedDpcIsrDatas[Processor];

            IDpcIsrInfoSource2::StridedDpcIsrDatas::iterator it = std::lower_bound(StridedDpcIsrDatas.begin(), StridedDpcIsrDatas.end(), TimeStart, lessDpcIsrDataByExitTime());
            
            while ((it != StridedDpcIsrDatas.end()) && ((it->ExitTime == TimeStart) || it->Overlap))
            {
                ++it;
            }

            if ((it != StridedDpcIsrDatas.end()) && (it->ExitTime <= TimeEnd))
            {
                return true;
            }

            return false;
        }
 
    protected:
        struct lessDpcIsrDataByExitTime
        {
            bool operator()(__in const IDpcIsrInfoSource::DpcIsrData& lhs, __in const TimeStamp& rhs) const
            {
                return lhs.ExitTime < rhs;
            }

            bool operator()(__in const TimeStamp& lhs, __in const IDpcIsrInfoSource::DpcIsrData& rhs) const
            {
                return lhs < rhs.ExitTime;
            }
        };

        CComPtr<IDpcIsrInfoSource3>         m_spDpcIsr;

        SIZE_T m_nCpus;
        CAutoVectorPtr<IDpcIsrInfoSource2::StridedDpcIsrDatas> m_rgStridedDpcIsrDatas;
        bool   m_fDpcDataAvailable;    
    };

    inline
    HRESULT ExpandToolsFilename(
        _In_ LPCWSTR wcsFileName,
        _Out_writes_z_(cchFullyQualifiedName) LPWSTR wcsFullyQualifiedName,
        _Inout_ SIZE_T cchFullyQualifiedName)
    {
        SIZE_T filenameLength = wcslen(wcsFileName);
        if (filenameLength >= cchFullyQualifiedName)
        {
            return AtlHresultFromWin32(ERROR_INSUFFICIENT_BUFFER);
        }

        SIZE_T remainingBuffer = cchFullyQualifiedName - filenameLength;
        if (remainingBuffer > DWORD_MAX)
        {
            return E_FAIL;
        }

        DWORD maxModuleFilenameSize = static_cast<DWORD>(remainingBuffer);

        // retrieve fully qualified application path
        DWORD cAppDir = GetModuleFileNameW(GetModuleHandleW(NULL), wcsFullyQualifiedName, maxModuleFilenameSize);
        if (cAppDir == maxModuleFilenameSize)
        {
            return AtlHresultFromWin32(ERROR_INSUFFICIENT_BUFFER);
        }
        else if (cAppDir == 0)
        {
            return AtlHresultFromLastError();
        }

        wcsFullyQualifiedName[cAppDir] = L'\0'; // make sure string is terminated
        // find begining of filename
        WCHAR* wszAppFileName = wcsrchr(wcsFullyQualifiedName, L'\\');
        if (wszAppFileName == NULL)
        {
            return E_FAIL;
        }

        // advance past '\\' char
        ++wszAppFileName;
        
        // append file name
        return StringCchCopy(wszAppFileName, 
                cchFullyQualifiedName - (wszAppFileName - wcsFullyQualifiedName), 
                wcsFileName);
    }  

    class CReadyThreadFLinkLookup
    {
    protected:
        CComPtr<IReadyThreadInfoSource>    m_spReadyThread;
        CComPtr<IReadyThreadForwardLinkInfoSource> m_spReadyThreadFLink;

    public:
        HRESULT OnSessionConnect(
            __in  ISession* pSession
            )
        {
            CComPtr<ITraceInfo> spTraceInfo;
            COMGUARD(pSession->QueryInterface(&spTraceInfo));
            
            m_nCpus = spTraceInfo->NumberOfProcessors;

            COMGUARD(pSession->QueryService(&m_spReadyThread));
            COMGUARD(pSession->QueryService(&m_spReadyThreadFLink));
            return S_OK;
        }

        HRESULT
        OnPrepareCache (
            VOID
            )
        {

            //
            // Allocate buffers.
            //

            CAutoVectorPtr<IReadyThreadInfoSource::StridedReadyThreadDatas> rgvStridedReadyThreadDatas;
            CAutoVectorPtr<IReadyThreadForwardLinkInfoSource::StridedReadyThreadFLinks> rgvStridedReadyFLinks;

            if (!rgvStridedReadyThreadDatas.Allocate(m_nCpus) || !rgvStridedReadyFLinks.Allocate(m_nCpus))
            {
                return E_OUTOFMEMORY;
            }

            //
            // Retrieve strided arrays.
            //

            SIZE_T nCpus = m_nCpus;
            COMGUARD(m_spReadyThread->QueryStridedData(rgvStridedReadyThreadDatas, nCpus, TimeStamp(_I64_MIN), TimeStamp(_I64_MAX)));

            if (nCpus != m_nCpus)
            {
                return E_UNEXPECTED;
            }

            COMGUARD(m_spReadyThreadFLink->QueryStridedData(rgvStridedReadyFLinks, nCpus));
            if (nCpus != m_nCpus)
            {
                return E_UNEXPECTED;
            }

            //
            // Transfer ownership.
            //

            m_rgvStridedReadyThreadDatas = rgvStridedReadyThreadDatas; 
            m_rgvStridedReadyFLinks = rgvStridedReadyFLinks;
            return S_OK;
        }

        void OnClearCache()
        {
            m_rgvStridedReadyThreadDatas.Free();
            m_rgvStridedReadyFLinks.Free();
        }

        _Ret_notnull_ const IReadyThreadForwardLinkInfoSource::ReadyThreadForwardLink*
        GetReadyThreadFLink(
            __in  const IReadyThreadInfoSource::ReadyThreadData* const pReadyThread
            ) const throw()
        {
            const ULONG iCpu = pReadyThread->Processor;
            const SIZE_T cbStride = m_rgvStridedReadyThreadDatas[iCpu].stride();

            const SIZE_T iReadyThread = (IReadyThreadInfoSource::StridedReadyThreadDatas::iterator(pReadyThread, cbStride) - m_rgvStridedReadyThreadDatas[iCpu].begin());
            
            return &m_rgvStridedReadyFLinks[iCpu][iReadyThread];
        }

        CReadyThreadFLinkLookup()
            : m_nCpus()
        {
        }

    protected:
        ULONG   m_nCpus;
        CAutoVectorPtr<IReadyThreadInfoSource::StridedReadyThreadDatas> m_rgvStridedReadyThreadDatas;
        CAutoVectorPtr<IReadyThreadForwardLinkInfoSource::StridedReadyThreadFLinks> m_rgvStridedReadyFLinks;
    };



class CStarvationAnalysis
{
public:
    
    enum CStarvationType
    {
        StarvationType_None,
        StarvationType_Starvation,
        
        StarvationType_CSwitchDelay,
        StarvationType_DpcIsrDelay,
        StarvationType_ImbalanceOnReady,
        StarvationType_ImbalanceOnCSwitch,

        StarvationType_PushLockDonation,
        StarvationType_EResourceDonation,
        StarvationType_KeyedEventDonation,
        StarvationType_FastMutexDonation,
        StarvationType_GuardedMutexDonation,
        StarvationType_CriticalSection,
        StarvationType_LpcReply,
        StarvationType_FltMessage,
        StarvationType_WorkQueue,
       
        StarvationType__count
    };


    typedef struct _CStarvationStats
    {
      public:
        TimeStampDelta  TimeInImbalance;
        TimeStampDelta  TimeInInheritance;
        TimeStampDelta  TimeInStarvation;
        
        TimeStampDelta TimeinLowerPri;
        TimeStampDelta TimeinEqualPri;
        TimeStampDelta TimeinHigherPri;

        CStarvationType ImbalanceType;
        CStarvationType InheritanceType;

        _CStarvationStats()
        {
            Init();
        }

        void Init()
        {
            TimeInImbalance = TimeStampDelta::Zero;
            TimeInInheritance = TimeStampDelta::Zero;
            TimeInStarvation = TimeStampDelta::Zero;
            
            TimeinLowerPri=TimeStampDelta::Zero;
            TimeinEqualPri=TimeStampDelta::Zero;
            TimeinHigherPri=TimeStampDelta::Zero;

            ImbalanceType = StarvationType_None;
            InheritanceType = StarvationType_None;
        }
    } CStarvationStats;


    CStarvationAnalysis()
    {
    }

    HRESULT OnSessionConnect(
            __in  ISession* pSession
            )
    {
           COMGUARD(pSession->QueryService(&m_spSchedulerAnalysis));
           COMGUARD(m_CSwitchExtLookup.OnSessionConnect(pSession));
           COMGUARD(m_ReadyFlinkLookup.OnSessionConnect(pSession));
           return S_OK;
     }
      
     HRESULT OnPrepareCache()
     {
          COMGUARD(m_CSwitchExtLookup.OnPrepareCache());
          COMGUARD(m_ReadyFlinkLookup.OnPrepareCache());
          return S_OK;
     }

    HRESULT
    OnNewWaitLevel(
        __in  IWaitAnalysisResults::StridedResults& StridedResults,
        __in  IWaitAnalysisResults::StridedResults::iterator itResult,
        __in  SIZE_T IndentationLevel,
        __inout UCHAR& HighestPriority,
        __inout UCHAR& WaitType
        )
    {
        try
        {

            if (itResult->WaitType == IWaitAnalysisResults::WaitType_Inherit_LpcReply ||
                itResult->WaitType == IWaitAnalysisResults::WaitType_Inherit_FltMessage)
            {
                //
                // Inheritance chain.
                //

                UCHAR HighestThreadPriority = 0;                    
                const ICSwitchInfoSource2::CSwitchData2* pCSwitchInT = NULL;
                const ICSwitchInfoSource2::CSwitchData2* pCSwitchOutT = NULL;

                pCSwitchInT = m_ReadyFlinkLookup.GetReadyThreadFLink(itResult->Ext.Wait.pReadyThread)->pCSwitchIn;

                if (pCSwitchInT)
                {
                    pCSwitchOutT = m_CSwitchExtLookup.GetCSwitchExtension(pCSwitchInT)->pPreviousCSwitchOut;

                    if (pCSwitchOutT)
                    {
                        HighestThreadPriority = pCSwitchOutT->Priority - ((pCSwitchOutT->Quantum << 4) >> 4);
                    }
                }

                //
                // Consider any synchronous priority inheritance mechanisms chainable.
                //
            
                if ((WaitType == IWaitAnalysisResults::WaitType_Inherit_LpcReply ||
                    WaitType == IWaitAnalysisResults::WaitType_Inherit_FltMessage) &&
                    HighestPriority > HighestThreadPriority)
                {
                    HighestThreadPriority = HighestPriority;
                }                                         
                HighestPriority = HighestThreadPriority;
                WaitType = itResult->WaitType;
            }
            else if (itResult->InheritPriority > 0)
            {
                UCHAR HighestThreadPriority = itResult->InheritPriority;

                //
                // Asynchronous priority inheritance is only chainable with itself.
                //
            
                if (WaitType == IWaitAnalysisResults::WaitType_Inherit_WorkQueue &&
                    HighestPriority > HighestThreadPriority)
                {
                    HighestThreadPriority = HighestPriority;
                }
            
                HighestPriority = HighestThreadPriority;
                WaitType = IWaitAnalysisResults::WaitType_Inherit_WorkQueue;
            }
            else if (itResult->WaitType & IWaitAnalysisResults::WaitType_Lock__mask)
            {
                //
                // New lock chain.
                //

                if (itResult->WaitType != WaitType)
                {
                    UCHAR HighestColliderPriority = 0;
                    SIZE_T IndentationLevelT = IndentationLevel;
                    std::vector<SIZE_T> vIgnoreStack;
                    const ICSwitchInfoSource2::CSwitchData2* pCSwitchInT = NULL;
                    const ICSwitchInfoSource2::CSwitchData2* pCSwitchOutT = NULL;

                    pCSwitchInT = m_ReadyFlinkLookup.GetReadyThreadFLink(itResult->Ext.Wait.pReadyThread)->pCSwitchIn;

                    if (pCSwitchInT)
                    {
                        pCSwitchOutT = m_CSwitchExtLookup.GetCSwitchExtension(pCSwitchInT)->pPreviousCSwitchOut;
            
                        if (pCSwitchOutT)
                        {
                            HighestColliderPriority = pCSwitchOutT->Priority;
                        }
                    }

                    if ((WaitType & IWaitAnalysisResults::WaitType_Inherit__mask) &&
                        HighestPriority > HighestColliderPriority)
                    {
                        HighestColliderPriority = HighestPriority;
                    }

                    //
                    // The model interprets a chain as a series of waits that all have the same wait reason.
                    // This isn't 100% correct, a thread could be waiting on a EResource held by another thread,
                    // and that thread could then wait on a different EResource. There really is not any other
                    // way to determine cascaded locks, as we don't get specific lock information and stacks
                    // won't be the same. This is the lesser of two evils, as the number of times the model is right
                    // should dwarf the incorrect.
                    //

                    for (IWaitAnalysisResults::StridedResults::iterator itResultT = (itResult + 1); itResultT != StridedResults.end(); ++itResultT)
                    {
                        if (itResultT->Flags & IWaitAnalysisResults::Flag_Level_Descend)
                        {
                            ++IndentationLevelT;
                        }

                        if (vIgnoreStack.size() == 0 &&
                            itResultT->Cause == IWaitAnalysisResults::Cause_Wait)
                        {
                            if (itResultT->WaitType != itResult->WaitType)
                            {
                                vIgnoreStack.push_back(IndentationLevelT);
                            }
                            else
                            {
                                pCSwitchInT = m_ReadyFlinkLookup.GetReadyThreadFLink(itResultT->Ext.Wait.pReadyThread)->pCSwitchIn;

                                if (pCSwitchInT)
                                {
                                    pCSwitchOutT = m_CSwitchExtLookup.GetCSwitchExtension(pCSwitchInT)->pPreviousCSwitchOut;
                        
                                    if (pCSwitchOutT &&
                                        pCSwitchOutT->Priority > HighestColliderPriority)
                                    {
                                        HighestColliderPriority = pCSwitchOutT->Priority;
                                    }
                                }
                            }
                        }

                        if (IndentationLevelT < itResultT->Ascend)
                        {
                            IndentationLevelT = 0;
                        }
                        else
                        {
                            IndentationLevelT -= itResultT->Ascend;
                        }

                        if (vIgnoreStack.size() > 0 &&
                            IndentationLevelT < vIgnoreStack.back())
                        {
                            vIgnoreStack.pop_back();
                        }

                        if (IndentationLevelT < IndentationLevel)
                        {
                            break;
                        }
                    }

                    HighestPriority = HighestColliderPriority;
                    WaitType = itResult->WaitType;
                }
            }
            else
            {
               HighestPriority = 0;
               WaitType = IWaitAnalysisResults::WaitType_Unclassified;
            }
        } 
        catch (std::bad_alloc&)
        {
            return E_OUTOFMEMORY;
        }
        return S_OK;
    }



    HRESULT
    ProcessForwardPriorityInheritance(
        __in  IWaitAnalysisResults* pWaitAnalysisResults
        ) 
    {
        IWaitAnalysisResults::StridedResults StridedResults;
        COMGUARD(pWaitAnalysisResults->QueryStridedData(&StridedResults));

        std::vector<SIZE_T> vInheritStack;
        std::vector<UCHAR> vInheritPriorityStack;

        SIZE_T IndentationLevel = 0;
        UCHAR InheritPriorityTop = 0;
        UCHAR LastRunningThreadPriority = 0;
        if (StridedResults.empty())
        {
            return S_OK;
        }
        try
        {
            for (IWaitAnalysisResults::StridedResults::iterator itResult = (StridedResults.end() - 1); itResult >= StridedResults.begin(); --itResult)
            {
                //
                // Move forwards in time to assign priority inheritance priorities.
                //

                if (itResult->Cause >= IWaitAnalysisResults::Cause__count)
                {
                    continue;
                }

                if (itResult->Cause == IWaitAnalysisResults::Cause_CpuUsage)
                {
                    //
                    // Remember the last running thread priority.
                    //
            
                    if (itResult->Ext.CpuUsage.pCSwitchOut)
                    {                
                        LastRunningThreadPriority = itResult->Ext.CpuUsage.pCSwitchOut->Priority -
                                                    ((itResult->Ext.CpuUsage.pCSwitchOut->Quantum << 4) >> 4);
                    }
                    else
                    {
                        LastRunningThreadPriority = 0;
                    }
                }

                if (itResult->Cause == IWaitAnalysisResults::Cause_Wait &&
                    itResult->Type == IWaitAnalysisResults::Type_Wait_WaitQueue)
                {
                    //
                    // This is pretty awkward. Since real wait analysis moves backwards, we need to
                    // stuff the transferred priority at the end handoff instead of the real transfer.
                    // Yuck, yuck, yuck.
                    //
            
                    itResult->InheritPriority = (vInheritStack.size() > 0) ?
                                                 vInheritPriorityStack.back() :
                                                 InheritPriorityTop;
            
                    if (itResult->WaitType == IWaitAnalysisResults::WaitType_Inherit_WorkQueue)
                    {
                        if (vInheritStack.size() > 0)
                        {
                            if (LastRunningThreadPriority > vInheritPriorityStack.back())
                            {
                                vInheritPriorityStack.pop_back();
                                vInheritPriorityStack.push_back(LastRunningThreadPriority);
                            }
                        }
                        else
                        {
                            InheritPriorityTop = (LastRunningThreadPriority > InheritPriorityTop) ?
                                                  LastRunningThreadPriority :
                                                  InheritPriorityTop;
                        }
                    }
                    else
                    {
                        if (vInheritStack.size() > 0)
                        {
                            vInheritPriorityStack.pop_back();
                            vInheritPriorityStack.push_back(0);
                        }
                        else
                        {
                            InheritPriorityTop = 0;
                        }
                    }
                }

                if (itResult->Ascend)
                {
                    if (!(itResult->Cause == IWaitAnalysisResults::Cause_Wait &&
                        itResult->Type == IWaitAnalysisResults::Type_Wait_WaitQueue))
                    {
                        //
                        // All other waits are assumed to be synchronous. Synchronous waits break up the
                        // work item inheritance chain, but it should be continued when we pop back up.
                        //

                        vInheritStack.push_back(IndentationLevel);
                        vInheritPriorityStack.push_back(0);
                    }
        
                    IndentationLevel += itResult->Ascend;
                }
        
                if (itResult->Flags & IWaitAnalysisResults::Flag_Level_Descend)
                {
                    //
                    // *grumble, grumble*. You'd think this would be an "else if" with the ascend
                    // conditional, but no. Ascend takes the simultaneous descend into account.
                    //
            
                    IndentationLevel--;
                }
        
                //
                // Check if any wait levels have been unwound.
                //

                while (vInheritStack.size() > 0 &&
                    IndentationLevel <= vInheritStack.back())
                {   
                    vInheritStack.pop_back();
                    vInheritPriorityStack.pop_back();
                }
            }
        }
        catch (std::bad_alloc&)
        {
            return E_OUTOFMEMORY;
        }
        return S_OK;
    }


    CStarvationType GetPriorityInheritanceType(UCHAR WaitType)
    {
        CStarvationType starvationType = StarvationType_Starvation; 

        switch (WaitType)
        {
            case IWaitAnalysisResults::WaitType_Lock_CriticalSection:
                starvationType = StarvationType_CriticalSection;
                break;

            case IWaitAnalysisResults::WaitType_Lock_EResource:
                starvationType = StarvationType_EResourceDonation;
                break;

            case IWaitAnalysisResults::WaitType_Lock_FastMutex:
                starvationType = StarvationType_FastMutexDonation;
                break;

            case IWaitAnalysisResults::WaitType_Lock_GuardedMutex:
                starvationType = StarvationType_GuardedMutexDonation;
                break;

            case IWaitAnalysisResults::WaitType_Lock_KeyedEvent:
                starvationType = StarvationType_KeyedEventDonation;
                break;

            case IWaitAnalysisResults::WaitType_Lock_PushLock:
                starvationType = StarvationType_PushLockDonation;
                break;

            case IWaitAnalysisResults::WaitType_Inherit_LpcReply:
                starvationType = StarvationType_LpcReply;
                break;

            case IWaitAnalysisResults::WaitType_Inherit_FltMessage:
                starvationType = StarvationType_FltMessage;
                break;

            case IWaitAnalysisResults::WaitType_Inherit_WorkQueue:
                starvationType = StarvationType_WorkQueue;
                break;

            default:
                break;
        }
        return starvationType;
    }

   

     HRESULT
     CalculateStarvationStats(
            __in TimeStamp StartTime,
            __in TimeStamp EndTime,
            __in UCHAR ThreadPriority,
            __in TimeStamp ReadyTime,
            __in ULONG Processor,
            __in UCHAR HighestPriority,
            __in UCHAR WaitType,  
            __inout CStarvationStats& StarvationStats
        )
     {
 
        ISchedulerAnalysisInfoSource::StridedSchedulerAnalysisEvents StridedSchedulerAnalysisEvents;

        COMGUARD(m_spSchedulerAnalysis->QueryStridedData(&StridedSchedulerAnalysisEvents,
                                                 ReadyTime,
                                                 EndTime));
   
       
        ISchedulerAnalysisInfoSource::StridedSchedulerAnalysisEvents::iterator itSchedulerAnalysisEvent = StridedSchedulerAnalysisEvents.begin();

        // find the first relevant scheduler event
        while ( itSchedulerAnalysisEvent != StridedSchedulerAnalysisEvents.end() && itSchedulerAnalysisEvent->EventTime == ReadyTime)
        {
            if (itSchedulerAnalysisEvent->Processor == Processor)
            {
                break;
            }
            itSchedulerAnalysisEvent++;
        }
        if (itSchedulerAnalysisEvent->EventTime != ReadyTime)
        {
            return E_UNEXPECTED; 
        }

        CStarvationType InitialStarvationType = StarvationType_Starvation;

        if (itSchedulerAnalysisEvent->CSwitchDelay == TRUE)
        {
            InitialStarvationType = StarvationType_CSwitchDelay;
        }
        else if (itSchedulerAnalysisEvent->DpcIsrDelay == TRUE)
        {
            InitialStarvationType = StarvationType_DpcIsrDelay;
        }
        else if (itSchedulerAnalysisEvent->ImbalanceOnReady == TRUE)
        {
            InitialStarvationType = StarvationType_ImbalanceOnReady;
        }

        TimeStamp PrevEventTime =  StartTime; 
        CStarvationType PrevStarvationType = InitialStarvationType;
        CStarvationType StarvationType = InitialStarvationType;
        CStarvationType InheritanceType = GetPriorityInheritanceType(WaitType); 
       
        UCHAR PrevMinRunningPriority = itSchedulerAnalysisEvent->MinRunningPriority;
       
        for (;
             itSchedulerAnalysisEvent != StridedSchedulerAnalysisEvents.end();
             itSchedulerAnalysisEvent++)            
        {

            TimeStamp EventTime = itSchedulerAnalysisEvent->EventTime;
                
            if (EventTime < StartTime)
            {
                //Skip events that happened earlier than the start of starvation interval
                continue;
            }
           
            if (ThreadPriority > PrevMinRunningPriority ) 
            {
                StarvationStats.TimeinLowerPri += EventTime - PrevEventTime;   
            }
            else if (ThreadPriority == PrevMinRunningPriority)
            {
                StarvationStats.TimeinEqualPri += EventTime - PrevEventTime;
            }
            else if (ThreadPriority < PrevMinRunningPriority)
            {
                StarvationStats.TimeinHigherPri += EventTime - PrevEventTime;
            }
            
            if (PrevStarvationType == StarvationType_Starvation)
            {
                StarvationStats.TimeInStarvation += EventTime - PrevEventTime; 
            }
            else if (PrevStarvationType >   StarvationType_ImbalanceOnCSwitch)
            {
                ASSERT (StarvationStats.InheritanceType == PrevStarvationType || StarvationStats.InheritanceType == StarvationType_None);
                StarvationStats.InheritanceType = PrevStarvationType;
                StarvationStats.TimeInInheritance += EventTime - PrevEventTime; 
            }
            else
            {
                ASSERT (StarvationStats.ImbalanceType == PrevStarvationType || StarvationStats.ImbalanceType == StarvationType_None);
                StarvationStats.ImbalanceType = PrevStarvationType;
                StarvationStats.TimeInImbalance += EventTime - PrevEventTime; 
            }

            if(ThreadPriority >= itSchedulerAnalysisEvent->MinNRunnablePriorityIncl  )
            {
                if(InitialStarvationType != StarvationType_Starvation)
                {
                    StarvationType = InitialStarvationType;
                    
                }
                else 
                {
                    // there was no imbalance when the thread became ready but later on cswitch imbalance occurred
                    StarvationType = StarvationType_ImbalanceOnCSwitch;
                }
            }
            else if (WaitType &&
                     HighestPriority >= itSchedulerAnalysisEvent->MinNRunnablePriorityExcl)
            {
                //
                // Wait (Lock priority donation or priority inheritance).
                //
                StarvationType = InheritanceType;
              
            }   
            else
            {
                StarvationType = StarvationType_Starvation;
            }

            PrevMinRunningPriority = itSchedulerAnalysisEvent->MinRunningPriority;  
            PrevStarvationType = StarvationType;
            PrevEventTime = EventTime;
        } 
        return S_OK;
   }

protected:
    CComPtr<ISchedulerAnalysisInfoSource>   m_spSchedulerAnalysis;
    CCSwitchExtLookup m_CSwitchExtLookup;
    CReadyThreadFLinkLookup m_ReadyFlinkLookup;
};

    //
    // helper methods for decoding wait analysis typenames
    //
    namespace WaitAnalysisHelpers
    {         
        struct CMessageArray
        {
            LPCWSTR const*  m_rgwszMessages;
            LPCSTR  const*  m_rgszMessages;
            SIZE_T          m_cMessages;

        public:
            template <SIZE_T cMessages>
            CMessageArray(LPCWSTR const (&rgwszMessages)[cMessages])
                : m_rgwszMessages(rgwszMessages)
                , m_rgszMessages(NULL)
                , m_cMessages(cMessages)
            {
            }
            template <SIZE_T cMessages>
            CMessageArray(LPCSTR const (&rgszMessages)[cMessages])
                : m_rgwszMessages(NULL)
                , m_rgszMessages(rgszMessages)
                , m_cMessages(cMessages)
            {
            }
        };

        static
        inline
        _Ret_maybenull_ LPCWSTR
        GetCauseTypeName(UCHAR Cause, UCHAR Type)
        {
            static const LPCWSTR rgwszMetaTypes[] = 
            {
                L"Meta",
                L"Outside Bounds",
                L"Time Inversion",
                L"Broken Causality",
                L"Missing ReadyThread",
                L"Missing Wait",
                L"Unaccounted Time",
            };

            static const LPCWSTR rgwszPreemptedTypes[] = 
            {
                L"Preempted",
            };

            static const LPCWSTR rgwszPostWaitTypes[] = 
            {
                L"Ready",					
            };

            static const LPCWSTR rgwszWaitTypes[] =
            {
                L"Wait",
                L"Wait [Work Item]",
                L"Thread Creation",
                L"Wait [Readying]",
            };

            static const LPCWSTR rgwszDpcTypes[] = 
            {
                L"DPC",
                L"DPC [Network]",
                L"DPC [Disk]",
                L"DPC [Timer]",
                L"DPC [Other]",
            };

            static const LPCWSTR rgwszDpcSchedulesWorkItemTypes[] = 
            {
                L"DPCSchedulesWorkItem",
            };

            static const LPCWSTR rgwszCpuUsageTypes[] = 
            {
                L"CPU Usage",
            };

            static const LPCWSTR rgwszPostWorkItemReadyTypes[] = 
            {
                L"Work Ready",
            };

            static const LPCWSTR rgwszWorkItemTypes[] = 
            {
                L"Work Transfer",
            };

            static const LPCWSTR rgwszMetaWorkItem[] = 
            {
                L"MetaWorkItem",
                L"Unable to Follow Work Item Handoff",
            };    
            
            static const CMessageArray rgCauses[] =
            {
                rgwszMetaTypes,
                rgwszPreemptedTypes,
                rgwszPostWaitTypes,
                rgwszWaitTypes,
                rgwszDpcTypes,
                rgwszCpuUsageTypes,
                rgwszPostWorkItemReadyTypes,
                rgwszWorkItemTypes,
                rgwszDpcSchedulesWorkItemTypes,
                rgwszMetaWorkItem,
            };    

            return ((Cause < ARRAYSIZE(rgCauses)) && (Type < rgCauses[Cause].m_cMessages)) ? rgCauses[Cause].m_rgwszMessages[Type] : NULL;
        }

        static
        inline
        _Ret_maybenull_ LPCWSTR
        GetCauseName(UCHAR Cause)
        {
            return GetCauseTypeName(Cause, 0);
        }        

        static
        inline
        _Ret_maybenull_ LPCWSTR
        GetCategoryName(UCHAR Category)
        {
            static const LPCWSTR rgwszWaitCategories[] =
            {
                L"Unclassified Wait",
                L"CPU Usage",
                L"Starvation",
                L"DPC [Network]",
                L"DPC [Disk]",
                L"DPC [Timer]",
                L"DPC [Other]",
                L"Other Wait",
            };

            return (Category < ARRAYSIZE(rgwszWaitCategories)) ? rgwszWaitCategories[Category] : NULL;
        }

        static
        inline
        UCHAR
        GetCategoryId(const LPCWSTR& CategoryText)
        {
            static const LPCWSTR rgwszWaitCategories[] =
            {
                L"Unclassified Wait",
                L"CPU Usage",
                L"Starvation",
                L"DPC [Network]",
                L"DPC [Disk]",
                L"DPC [Timer]",
                L"DPC [Other]",
                L"Other Wait",
            };

            for (unsigned int i = 0; i < ARRAYSIZE(rgwszWaitCategories); i++)
            {
                if (wcscmp(rgwszWaitCategories[i], CategoryText) == 0)
                {
                    return (UCHAR) i;
                }
            }
            return 0;
        }

        static
        inline
        _Ret_maybenull_ LPCSTR
        GetMetadataHeaderColumnName(UCHAR Category, UINT MetadataColumnIndex)
        {
            static const LPCSTR rgszUnclassifiedColumns[] = 
            {
                "Unclassified",
            };

            static const LPCSTR rgszCpuUsageColumns[] = 
            {
                "CpuUsageColumns",
            };

            static const LPCSTR rgszStarvationColumns[] = 
            {
                "Starvation",
            };

            static const LPCSTR rgszDpcNetworkColumns[] =
            {
                "DPC [Network]",
                "Request URI",
                "I/O Size",
                "Transaction State",
                "Request Header",
                "Response Code",
            };

            static const LPCSTR rgszDpcDiskColumns[] = 
            {
                "DPC [Disk]",
                "File Path",
                "I/O Size",
                "I/O Type",
                "I/O Priority",
                "I/O Category"
            };

            static const LPCSTR rgszDpcTimerColumns[] = 
            {
                "DPC [Timer]",
                "Timer Duration"
            };

            static const LPCSTR rgszDpcOtherColumns[] = 
            {
                "DPC [Other]",
                "Module/Function"
            };

            static const LPCSTR rgszOtherColumns[] = 
            {
                "Other",
            };
            
            static const CMessageArray rgColumns[] =
            {
                rgszUnclassifiedColumns,
                rgszCpuUsageColumns,
                rgszStarvationColumns,
                rgszDpcNetworkColumns,
                rgszDpcDiskColumns,
                rgszDpcTimerColumns,
                rgszDpcOtherColumns,
                rgszOtherColumns,
            };    

            return ((Category < ARRAYSIZE(rgColumns)) && (MetadataColumnIndex < rgColumns[Category].m_cMessages)) ? rgColumns[Category].m_rgszMessages[MetadataColumnIndex] : "-";
        }
    }

    //
    // CSegmentedVector<T, nElementCountPerSegment = 64kB / size(T)>
    //

    template <typename T, unsigned nElementCountPerSegment = 64 * 1024 / sizeof(T)>
    class CSegmentedVector
    {
        std::vector<T*> m_vSegments;
        unsigned m_cAvailableElementsInBackSegment;
    
    public:

        CSegmentedVector()
            : m_cAvailableElementsInBackSegment()
        {
        }

        CSegmentedVector(CSegmentedVector<T, nElementCountPerSegment>&& other)
        {
            std::swap(m_vSegments, other.m_vSegments);

            m_cAvailableElementsInBackSegment = other.m_cAvailableElementsInBackSegment;
            other.m_cAvailableElementsInBackSegment = 0;
        }

    private:

        CSegmentedVector(CSegmentedVector<T, nElementCountPerSegment> const& other);
        CSegmentedVector<T, nElementCountPerSegment>& operator =(CSegmentedVector<T, nElementCountPerSegment> const& other);

    public:

        void swap(CSegmentedVector<T>& other)
        {
            std::swap(m_vSegments, other.m_vSegments);
            std::swap(m_cAvailableElementsInBackSegment, other.m_cAvailableElementsInBackSegment);
        }

        bool empty() const
        {
            return m_vSegments.empty();
        }

        size_t size() const
        {
            if (!m_vSegments.empty())
            {
                unsigned const nElementCountPerSegment = segment_size();

                return (m_vSegments.size() - 1) * nElementCountPerSegment + (nElementCountPerSegment - m_cAvailableElementsInBackSegment);
            }
            else
            {
                return 0;
            }
        }

        static unsigned segment_size()
        {
            return nElementCountPerSegment;
        }

        template <typename TFunction>
        void for_each(TFunction function) const
        {
            if (!m_vSegments.empty())
            {
                auto const itLastSegment = m_vSegments.end() - 1;

                unsigned const nElementCountPerSegment = segment_size();

                for (auto itSegment = m_vSegments.begin(); itSegment != itLastSegment; ++itSegment)
                {
                    T* const rgElements = *itSegment;

                    for (unsigned iElement = 0; iElement < nElementCountPerSegment; ++iElement)
                    {
                        function(rgElements[iElement]);
                    }
                }

                {
                    T* const rgElements = *itLastSegment;
                    unsigned const cElementCountInLastSegment = (nElementCountPerSegment - m_cAvailableElementsInBackSegment);

                    for (unsigned iElement = 0; iElement < cElementCountInLastSegment; ++iElement)
                    {
                        function(rgElements[iElement]);
                    }
                }
            }
        }

        template <typename TFunction>
        void reverse_for_each(TFunction function) const
        {
            if (!m_vSegments.empty())
            {
                auto const itLastSegment = m_vSegments.end() - 1;

                unsigned const nElementCountPerSegment = segment_size();

                {
                    T* const rgElements = *itLastSegment;
                    unsigned const cElementCountInLastSegment = (nElementCountPerSegment - m_cAvailableElementsInBackSegment);

                    for (unsigned iElement = cElementCountInLastSegment; iElement > 0; )
                    {
                        --iElement;

                        function(rgElements[iElement]);
                    }
                }

                auto const itFirstSegment = m_vSegments.begin();

                for (auto itSegment = itLastSegment; itSegment != itFirstSegment; )
                {
                    --itSegment;

                    T* const rgElements = *itSegment;

                    for (unsigned iElement = nElementCountPerSegment; iElement > 0; )
                    {
                        --iElement;

                        function(rgElements[iElement]);
                    }
                }
            }
        }

        T& back() const
        {
            ASSERT(!empty());

            unsigned const nElementCountPerSegment = segment_size();

            ASSERT(m_cAvailableElementsInBackSegment < nElementCountPerSegment);

            return m_vSegments.back()[nElementCountPerSegment - 1 - m_cAvailableElementsInBackSegment];
        }

        void push_back(T value)
        {
            if (m_cAvailableElementsInBackSegment)
            {
                unsigned const nElementCountPerSegment = segment_size();

                new (m_vSegments.back() + (nElementCountPerSegment - m_cAvailableElementsInBackSegment)) T(value);

                --m_cAvailableElementsInBackSegment;
            }
            else
            {
                _slow_push_back(static_cast<T&&>(value));
            }
        }

    private:

        void _slow_push_back(T&& value)
        {
            ASSERT(m_cAvailableElementsInBackSegment == 0);

            unsigned nElementCountPerSegment = segment_size();

            T* const pElements = allocate_uninitialized(nElementCountPerSegment);

            try
            {
                m_vSegments.push_back(pElements);
            }
            catch (std::bad_alloc&)
            {
                deallocate_uninitialized(pElements);
                throw;
            }

            new (pElements + 0) T(value);

            m_cAvailableElementsInBackSegment = (nElementCountPerSegment - 1);
        }

        static T* allocate_uninitialized(size_t cElements)
        {
            return reinterpret_cast<T*>(new char[sizeof(T) * cElements]);
        }

        static void deallocate_uninitialized(T* p)
        {
            delete[] reinterpret_cast<char*>(p);
        }

    public:

        void clear()
        {
            this->reverse_for_each([](T& value) { UNREFERENCED_PARAMETER(value); value.~T(); });

            for (auto ritSegment = m_vSegments.rbegin(); ritSegment != m_vSegments.rend(); ++ritSegment)
            {
                T* const pElements = *ritSegment;

                deallocate_uninitialized(pElements);
            }

            m_vSegments.clear();
        }

        ~CSegmentedVector()
        {
            clear();
        }
    };
}
