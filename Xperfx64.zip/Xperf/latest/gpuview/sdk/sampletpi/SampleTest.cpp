#include "Testplugin.hxx"

//
// Base class that handles the Handler for all the Non-Optimal classes.
//
//
#define MAX_RESULTS_STR 1024

//------------------------------------------------------------------------------
//
// This test class checks for extra long DMA buffers.
//

CSampleTest::CSampleTest():
    m_pOutput(NULL)
{
}
CSampleTest::~CSampleTest()
{
    Clear();
}

//------------------------------------------------------------------------------
// Description:
//
//    Returns the friendly name of this test.
//
// Parameters:
//
//    _ppResultOut - [out] pointer to a character pointer that gets filled on success.
//
// Returns:
//
//    ERROR_SUCCESS on success, error otherwise.
//
// Remarks:
//
//    N/A.
//
HRESULT 
CSampleTest::GetFriendlyName(__inout char** _ppResultOut,
                             __inout char** _ppDescription)
{
    HRESULT hr = ERROR_SUCCESS;
    IF_TRUE_ACTION_JUMP(NULL == _ppResultOut,
                        PATH_TRAP();
                        hr = ERROR_INVALID_PARAMETER,
                            GetFriendlyName_Ret);
    *_ppResultOut = "Sample Test Flip Counting";
    *_ppDescription = "This test simply counts the number of Flip events in the file.";

GetFriendlyName_Ret:
    return hr;
}

//------------------------------------------------------------------------------
// Description:
//
//    Returns a GUID that identifies the events that this test wants to track.
//
// Parameters:
//
//    _uiIdx - [in] zero based index that represents the GUID to return.
//    _ppGuid - [out] pointer to GUID pointer that will get filled on success.
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    ERROR_NOT_SUPPORTED if the index has exceeded the number of supported GUIDs,
//    error otherwise.
//
// Remarks:
//
//    _uiIdx of zero should return the first supported GUID, one returns the second
//  and so on. The caller will use the pointer and it will remain valid as long
//  as the class is active.
//
HRESULT 
CSampleTest::GetTrackingGuids(UINT _uiIdx,
                                              GUID** _ppGuid)
{
    HRESULT hr = ERROR_SUCCESS;
    IF_TRUE_ACTION_JUMP(_uiIdx != 0,
                        hr = ERROR_NOT_SUPPORTED,
                            GetTrackingGuids_Ret);
    *_ppGuid = (GUID*)&ETWGUID_DXGKFLIP;

GetTrackingGuids_Ret:
    return hr;
}

//------------------------------------------------------------------------------
// Description:
//
//    Returns a Presentation method descibing how this test wants it's events
//  sent.
//
// Parameters:
//
//    _pPesentationMethod - [out] pointer to a PresentationMethod to fill on success
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    error otherwise.
//
// Remarks:
//
//    This test class doesn't want any sorting, it looks directly at the events.
//
HRESULT 
CSampleTest::GetPresentationMethod(PresentationMethod* _pPesentationMethod)
{
    *_pPesentationMethod = NoFilterLinear;
    return ERROR_SUCCESS;
}



//------------------------------------------------------------------------------
// Description:
//
//    Retrieves the StatisticalPreferences structure that provides user input.
//
// Parameters:
//
//    _psp - [in] pointer to the structure.
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    error otherwise.
//
// Remarks:
//
//    This method also allocates our CStandardInterval class that will be used
//  for counting and analysis. It's cleaned up in the destructor and in the Clear()
//  method.
//
HRESULT 
CSampleTest::PreProcess(ITestPreferences* _ptp)
{
    HRESULT hr = ERROR_SUCCESS;

#ifdef DBG
    bool bSort;
    // Check to see if the sort is checked in the Dialog. If so, we display that
    // fact. Note that this is provided as a simple example.
    _ptp->IsSort(&bSort);

    char szBuf[MAX_PATH];
    szBuf[0]=(char)NULL;
    StringCchPrintf(szBuf,MAX_PATH,"Getting ready to start counting! Sort=%s\n",
                    (bSort?"TRUE":"FALSE"));
    OutputDebugString(szBuf);
#endif

    return hr;
}

//------------------------------------------------------------------------------
// Description:
//
//    Called after all events have been processed so analysis can take place.
//
// Parameters:
//
//    _ppOutOfBounds - [in] pointer to the out-of-bounds list.
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    error otherwise.
//
// Remarks:
//
//    This method is where the post processing occurs. Any 'outliers' saved in
//  our m_OutOfBoundsList will be handed back to the caller through the parameter.
//
// Note that if this code is modified so that there are no events in the Outlier
// list, the routine will have to return ERROR_NO_DATA.
//
HRESULT 
CSampleTest::PostProcess(std::list<CONST IEventData2*>** _ppOutOfBounds)
{
#ifdef DBG
    char szBuf[MAX_PATH];
    szBuf[0]=(char)NULL;
    StringCchPrintf(szBuf,MAX_PATH,"Counted %d events!\n",m_iCount);
    OutputDebugString(szBuf);
#endif

    // Now write back anything that we've gathered in our OutOfBounds list. Since
    // we copied everything into the list, we'll write it back here.
    *_ppOutOfBounds = &m_OutOfBoundsList;

    return ERROR_SUCCESS;
}

//------------------------------------------------------------------------------
// Description:
//
//    Called after a first run but before a second to allow for cleanup of dynamic
//  variables.
//
// Parameters:
//
//    N/A.
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    error otherwise.
//
// Remarks:
//
//    N/A.
//
HRESULT 
CSampleTest::Clear()
{
    HRESULT hr = ERROR_SUCCESS;
    SAFE_DELETE_OBJECT(m_pOutput);
    m_iCount=0;
    m_OutOfBoundsList.clear();
    return hr;
}

//------------------------------------------------------------------------------
// Description:
//
//    Called to handle each event in question.
//
// Parameters:
//
//    _pEvt - [in] pointer to an IEventData2 structure.
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    error otherwise.
//
// Remarks:
//
//    If this routine returns an error, processing will terminate.
//    
//    This routine will get called for each different registered GUID. If multiple
//  GUIDs are desired, this routine will have to destinguish between them each time.
//
HRESULT 
CSampleTest::Handler(IN CONST IEventData2* _pEvt,GUID* _pGuid)
{
    // Just add these events to our list.
    m_iCount++;
    m_OutOfBoundsList.push_back(_pEvt);

    return ERROR_SUCCESS;
}


//------------------------------------------------------------------------------
// Description:
//
//    Used to return general statistics about the processing.
//
// Parameters:
//
//    _ppResultOut - [in] pointer to a character pointer filled on success.
//
// Returns:
//
//    ERROR_SUCCESS on success,
//    error otherwise.
//
// Remarks:
//
//    After processing has taken place, this routine will get called.
//
HRESULT 
CSampleTest::OverAllStatistics(__inout char** _ppResultOut)
{
    HRESULT hr = ERROR_SUCCESS;
    UINT uiLen = 0;

    m_pOutput = new char[MAX_RESULTS_STR];
    IF_TRUE_ACTION_JUMP(NULL == m_pOutput,
                        PATH_TRAP();
                        hr = ERROR_NOT_ENOUGH_MEMORY,
                            OverAllStatistics_Ret);

    uiLen = sprintf_s(m_pOutput, MAX_RESULTS_STR, "Count %d\r\n", 
                      (int)m_iCount);
    uiLen += sprintf_s(&m_pOutput[uiLen], MAX_RESULTS_STR - uiLen, "Outliers: %d\r\n", 
                       (int)m_OutOfBoundsList.size());

    *_ppResultOut = m_pOutput;

OverAllStatistics_Ret:
    return ERROR_SUCCESS;

}



