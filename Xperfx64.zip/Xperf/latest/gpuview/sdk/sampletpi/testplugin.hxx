#ifndef _PLUGINETWEVT_H_
#define _PLUGINETWEVT_H_

#include <nt.h>
#include <ntrtl.h>
#include <nturtl.h>

#include <windows.h>
#include <winerror.h>

// WMI Headers.
#include <evntcons.h>
#include <ntwmi.h>
#include <tdh.h>

#include <assert.h>
#include <list>
#include <vector>
#include <strsafe.h>

using namespace std;

#include "banned.h"
#include <CommonMacros.h> // For IF_TRUE_ACTION_JUMP() etc....
#include "Plugin.h"
#include "eventdata.h"
#include "TestPlugin.h"

#define INITGUID
#include <guiddef.h>
//
//Dxgkrnl Flip Event Guid
//{22412531-670b-4cd3-81d1-e709c154ae3d}
DEFINE_GUID(ETWGUID_DXGKFLIP,
0x22412531, 0x670b, 0x4cd3, 0x81, 0xd1, 0xe7, 0x09, 0xc1, 0x54, 0xae, 0x3d);



//------------------------------------------------------------------------------
//
// Test classes here.
//

class CSampleTest : public ITestPlugin
{
private:
    // An out of bounds list.
    std::list<const IEventData2*> m_OutOfBoundsList;
    int m_iCount;

    char* m_pOutput;
public:
    CSampleTest();
    ~CSampleTest();
    HRESULT GetFriendlyName(__inout char** _ppFriendlyName,__inout char** _ppDescription);
    HRESULT GetTrackingGuids(UINT _uiIdx,GUID** _ppGuid);
    HRESULT GetPresentationMethod(PresentationMethod* _pPesentationMethod);
    HRESULT PreProcess(ITestPreferences* _ptp);
    HRESULT PostProcess(std::list<CONST IEventData2*>** _ppOutOfBounds);
    HRESULT Handler(IN CONST IEventData2*,GUID* _pGuid);
    HRESULT Clear();
    HRESULT OverAllStatistics(__inout char** _ppResultOut);
};


#endif  //_PLUGINETWEVT_H_
