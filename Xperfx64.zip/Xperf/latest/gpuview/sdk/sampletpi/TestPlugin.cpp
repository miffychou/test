#include "Testplugin.hxx"

// All the different test classes that this dll supports.

CSampleTest  m_SampleTest;

struct _TestInterfaceTable
{
    ITestPlugin* pITestPlugin;
};

_TestInterfaceTable g_TestInfo[] =
{
    {static_cast<ITestPlugin*>(&m_SampleTest)}
};


HRESULT GetTestInterface(IN UINT _uiIdx,
                         OUT ITestPlugin** _ppITestPlugin)
{
    HRESULT hr = ERROR_SUCCESS;

    if( _uiIdx >= sizeof(g_TestInfo)/sizeof(_TestInterfaceTable))
    {
        hr = ERROR_NOT_SUPPORTED;
    }
    else
    {
        *_ppITestPlugin = g_TestInfo[_uiIdx].pITestPlugin;
    }
    return hr;
}

HRESULT APIENTRY Plugin_Main(TestPluginData* pData)
{
    pData->dwSize = sizeof(TestPluginData) ;
    pData->wFlags = TESTPLUGIN_FLAGS;
    pData->wVersion = TESTPLUGIN_VERSION;
    pData->pfnGetTestInterface = GetTestInterface;

    return S_OK;
}
