
#ifdef INCLUDE_ALL_HEADERS
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <winerror.h>

#include <strsafe.h>

#include <math.h>
#include <assert.h>
#include <list>
              
using namespace std;
                       
// WMI Headers.
#include <evntcons.h>

#include "CommonMacros.h"
#include "plugin.h"
#endif         
void
CBaseHandler::FreeString(__inout char** _ppString)
{
    if(NULL != *_ppString)
    {
        delete [] *_ppString;
        *_ppString = NULL;
    }
}

char* 
CBaseHandler::AllocHeader(UINT _uiSize)
{
    char* cbuf = new char[_uiSize];
    if (NULL == cbuf) 
    {
        PATH_TRAP();
        return NULL;
    }
    // Null the buffer
    cbuf[0]=(char)NULL;
    return cbuf;
}

//
// Utility routine used by the "Event Data" listbox when private data is dumped
// in hex format. like: 00 00 D9 AF 00 01 2C 00. This routine returns one character.
// 
char 
CBaseHandler::GetHexDigit(int Input)
{
    if(Input >= 0 && Input <= 9)
    { 
        return char(Input + '0');
    }
    if(Input >= 10 && Input <= 15)
    { 
        return char(Input - 10 + 'A');
    }
    return '?';
}

// _pDest is destination location for data, it's the starting offset of the buffer
// _iLen is the offset into the buffer where to write data
// _iEventData is the offset in the MofData to start reading from
// _pEvent the event.
//
// The routine is limited to 512 bytes of MofData. Note that _pDest is compiled using
// OUR_STRING (below) which allows for 2048 characters.
#define MAX_MOFDATA_LEN 512

int
CBaseHandler::ParseRemainder(__inout char* _pDest,
                             UINT _iLen,
                             int _iEventData,
                             IN CONST IEventData* _pEvent)
{
    char szChars[9];

    if( _iLen >= OUR_STRING )
    {
        // Since we know our string buffer is OUR_STRING length, we can't write to
        // a location that's past the end of the buffer.
        PATH_TRAP();
        return 0;
    }
    _iLen += sprintf_s(&_pDest[_iLen], OUR_STRING - _iLen, "Private data length: %d, Remainder: %d",
                       _pEvent->GetMofDataLen(),_pEvent->GetMofDataLen()-_iEventData);

    if( _pEvent->GetMofDataLen() > MAX_MOFDATA_LEN )
    {
        // Currently, this code only supports 256 bytes of MofData. If the plugin
        // has events that store more then this, they will need to modify this code
        // to allow for a larger buffer.
        PATH_TRAP();
        _iLen += sprintf_s(&_pDest[_iLen], OUR_STRING - _iLen, "\r\n!!Buffer to small for MofData!!\r\n");
        return _iLen;
    }

    szChars[0]=(char)NULL;
    for(UINT i=_iEventData;i<_pEvent->GetMofDataLen() && i < MAX_MOFDATA_LEN;i++)
    {
        if(i % 8 == 0)
        {
            _iLen += sprintf_s(&_pDest[_iLen], OUR_STRING - _iLen, " %s\r\n",szChars);
            if( -1 == _iLen )
            {
                // Most likely exceeded our buffer length.
                PATH_TRAP();
                return 0;
            }
            szChars[0]=(char)NULL;
        }
        UCHAR ThisByte = ((UCHAR*)_pEvent->GetMofData())[i];
        _iLen += sprintf_s(&_pDest[_iLen], OUR_STRING - _iLen, "%1c%1c ",
                          GetHexDigit((ThisByte & 0xF0) >> 4),
                          GetHexDigit(ThisByte & 0x0F));
        if( -1 == _iLen )
        {
            // Most likely exceeded our buffer length.
            PATH_TRAP();
            return 0;
        }
        // Now print out characters
        if( ThisByte >= ' ' && ThisByte <= '~' ) 
        {
            // we have character to display, add to character array
            szChars[i%8]=ThisByte;
            szChars[(i%8)+1]=(char)NULL;
        }
        else
        {
            // we have character to display, add to character array
            szChars[i%8]='.';
            szChars[(i%8)+1]=(char)NULL;
        }
    }

    if( szChars[0] != (char)NULL )
    {
        _iLen += sprintf_s(&_pDest[_iLen], OUR_STRING - _iLen, " %s\r\n",szChars);
    }
    else
    {
        _iLen += sprintf_s(&_pDest[_iLen], OUR_STRING - _iLen, "\r\n");
    }
    if( -1 == _iLen )
    {
        // Most likely exceeded our buffer length.
        PATH_TRAP();
        return 0;
    }

    return _iLen;
}

HRESULT                                                                 
CBaseHandler::EventStringHandler(IN CONST IEventData* _pEvent,
                                 ULONG _ulProcessId,
                                 ULONG _ulThreadId,
                                 __inout char** _ppOutput)
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(OUR_STRING);
    if( NULL == cbuf )
    {
        PATH_TRAP();
        return ERROR_NOT_ENOUGH_MEMORY;
    }

    ParseRemainder(cbuf,0,0,_pEvent);
    *_ppOutput = cbuf;
    return hr;
}

