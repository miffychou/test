#include "PiEtwEvt.hxx"

#define MAX_STRING 2048

#include "..\..\shr\basehandler.cpp"
C_ASSERT(MAX_STRING == OUR_STRING);
//                  
// Used to gather information about each GUID.
//
typedef struct _OurGUIDData
{
    GUID Guid;            //GUID    
    char * GuidDesc;      //text description of GUID
    IEventString* pIEventString; // EventString interface for interpreting the event.
    IEventProfiling* pIEventProfiling; 
} OurGUIDData;
               
                       
// Each Handler is namded after the function that it represents = _NAMER_
#define STANDARD_EVENT_HANDLER(_NAMER_,_ID_,_FRIENDLY_) \
class C##_NAMER_##_Handler : public CBaseHandler, public IEventString, public IEventProfiling \
{ \
public: \
    C##_NAMER_##_Handler(){} \
    ~C##_NAMER_##_Handler(){} \
    HRESULT EventStringHandler(IN CONST IEventData*,ULONG _ulProcessId,ULONG _ulThreadId,__inout __nullterminated char** _ppOutput); \
    void FreeString(__inout __nullterminated char** _ppString); \
    HRESULT ProfileHandler(IN const IEventData* pEvent,OUT UINT* _puiId,OUT PROFILE_EVENT_TYPE* _pType); \
    HRESULT ProfileFunctionName(IN CONST IEventData* pEvent,__deref_out __nullterminated char** _ppDescriptionString); \
    HRESULT ProfileGUIDName(IN CONST IEventData* pEvent,__inout __nullterminated char** _ppDescriptionString); \
    HRESULT ProfileFunctionNameById(PROFILE_EVENT_TYPE _eType,UINT _uiId,__deref_out __nullterminated char** _ppDescriptionString); \
    HRESULT IsProfileTypeSupported(PROFILE_EVENT_TYPE _eType,UINT _uiId); \
}; \
C##_NAMER_##_Handler g##_NAMER_##_Handler; \
HRESULT \
C##_NAMER_##_Handler::ProfileFunctionName(IN CONST IEventData* pEvent, __deref_out __nullterminated char** _ppDescriptionString) \
{ \
    HRESULT hr = ERROR_SUCCESS; \
    *_ppDescriptionString = _FRIENDLY_; \
    return hr; \
} \
HRESULT \
C##_NAMER_##_Handler::ProfileFunctionNameById(PROFILE_EVENT_TYPE _eType,UINT _uiId,__deref_out __nullterminated char** _ppDescriptionString) \
{ \
    HRESULT hr = ERROR_NOT_SUPPORTED; \
    if( (_eType == eEnter_DXVA || _eType == eLeave_DXVA) && _uiId == _ID_ ) \
    { \
        *_ppDescriptionString = _FRIENDLY_; \
        hr = ERROR_SUCCESS; \
    } \
    return hr; \
} \
HRESULT \
C##_NAMER_##_Handler::IsProfileTypeSupported(PROFILE_EVENT_TYPE _eType,UINT _uiId) \
{ \
    HRESULT hr = ERROR_NOT_SUPPORTED; \
    if( (_eType == eEnter_DXVA || _eType == eLeave_DXVA) && _uiId == _ID_ ) \
    { \
        hr = ERROR_SUCCESS; \
    } \
    return hr; \
} \
HRESULT \
C##_NAMER_##_Handler::ProfileGUIDName(IN CONST IEventData* pEvent, __inout __nullterminated char** _ppDescriptionString) \
{ \
    HRESULT hr = ERROR_SUCCESS; \
    PATH_TRAP(); \
    *_ppDescriptionString = "DXVA2 - "_FRIENDLY_; \
    return hr; \
} \
void \
C##_NAMER_##_Handler::FreeString(__inout __nullterminated char** _ppString) \
{ \
    CBaseHandler::FreeString(_ppString); \
} \
HRESULT \
C##_NAMER_##_Handler::ProfileHandler(IN const IEventData* pEvent,OUT UINT* _puiId,OUT PROFILE_EVENT_TYPE* _pType) \
{ \
    HRESULT hr = ERROR_SUCCESS; \
    *_puiId = _ID_; \
    LPVOID data = pEvent->GetMofData(); \
    DXVA2Trace_##_NAMER_##Data* event = (DXVA2Trace_##_NAMER_##Data*)data; \
    if (event->Enter) \
    { \
        *_pType = eEnter_DXVA; \
    } \
    else \
    { \
        *_pType = eLeave_DXVA; \
    } \
    return hr; \
} \
HRESULT \
C##_NAMER_##_Handler::EventStringHandler(IN CONST IEventData* pEventData,ULONG _ulProcessId,ULONG _ulThreadId,char** _ppOutput) 


// Now each handler

STANDARD_EVENT_HANDLER(DecodeDevCreated,0,"Decode Create Device")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    WCHAR wbuf[MAX_STRING] = {NULL};

    LPVOID data = pEventData->GetMofData();
    DXVA2Trace_DecodeDevCreatedData* event = (DXVA2Trace_DecodeDevCreatedData*) data;

    StringFromGUID2(event->DeviceGuid, wbuf, MAX_STRING);

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "D3D9 Object: 0x%I64X\r\n", event->pD3DDevice);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Device GUID: %S\r\n", wbuf);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Size: %dx%d\r\n", event->Width, event->Height);
    *_ppOutput = cbuf;
    return hr;
}

STANDARD_EVENT_HANDLER(DecodeDevDestroyed,1,"Decode Destroy Device")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2Trace_DecodeDevDestroyedData* event = (DXVA2Trace_DecodeDevDestroyedData*) data;

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);

    *_ppOutput = cbuf;
    return hr;
}

STANDARD_EVENT_HANDLER(DecodeDevBeginFrame,2,"Decode Begin Frame")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2Trace_DecodeDevBeginFrameData* event = (DXVA2Trace_DecodeDevBeginFrameData*) data;

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Render Target: 0x%I64X\r\n", event->pRenderTarget);

    *_ppOutput = cbuf;
    return hr;
}

STANDARD_EVENT_HANDLER(DecodeDevExecute,3,"Decode Execute")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();
    // Work here
    DXVA2Trace_DecodeDevExecuteData* event = (DXVA2Trace_DecodeDevExecuteData*) data;

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);

    *_ppOutput = cbuf;
    return hr;
}


char* g_BufferType[] =
{
    "DXVA2_PictureParametersBufferType",
    "DXVA2_MacroBlockControlBufferType",
    "DXVA2_ResidualDifferenceBufferType",
    "DXVA2_DeblockingControlBufferType",
    "DXVA2_InverseQuantizationMatrixBufferType",
    "DXVA2_SliceControlBufferType",
    "DXVA2_BitStreamDateBufferType",
    "DXVA2_MotionVectorBuffer",
    "DXVA2_FilmGrainBuffer"
};

STANDARD_EVENT_HANDLER(DecodeDevGetBuffer,4,"Decode Get Buffer")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2Trace_DecodeDevGetBufferData* event = (DXVA2Trace_DecodeDevGetBufferData*) data;

    char* btype = "DXVA2_*Unknown*BufferType";

    if (event->BufferType < sizeof(g_BufferType) / sizeof(g_BufferType[0]))
    {
        btype = g_BufferType[event->BufferType];
    }

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "BufferType: %s (%d)\r\n", btype, event->BufferType);

    *_ppOutput = cbuf;
    return hr;
}

STANDARD_EVENT_HANDLER(DecodeDevEndFrame,5,"Decode End Frame")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2Trace_DecodeDevEndFrameData* event = (DXVA2Trace_DecodeDevEndFrameData*) data;

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);

    *_ppOutput = cbuf;
    return hr;
}

STANDARD_EVENT_HANDLER(VideoProcessDevCreated,6,"VideoProcess Create Device")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    WCHAR wbuf[MAX_STRING] = {NULL};

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2Trace_VideoProcessDevCreatedData* event = (DXVA2Trace_VideoProcessDevCreatedData*) data;

    StringFromGUID2(event->DeviceGuid, wbuf, MAX_STRING);

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "D3D9 Object: 0x%I64X\r\n", event->pD3DDevice);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Device GUID: %S\r\n", wbuf);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Render Target FourCC: 0x%X\r\n", event->RTFourCC);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Size: %dx%d\r\n", event->Width, event->Height);

    *_ppOutput = cbuf;
    return hr;
}

STANDARD_EVENT_HANDLER(VideoProcessDevDestroyed,7,"VideoProcess Destroy Device")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2Trace_VideoProcessDevDestroyedData* event = (DXVA2Trace_VideoProcessDevDestroyedData*) data;

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);

    *_ppOutput = cbuf;
    return hr;
}

#define DXVA2Trace_VideoProcessBltData DXVA2TraceVideoProcessBltData
STANDARD_EVENT_HANDLER(VideoProcessBlt,8,"VideoProcess Blt")
{
    HRESULT hr = ERROR_SUCCESS;
    char* cbuf = AllocHeader(MAX_STRING);
    int clen = 0;

    LPVOID data = pEventData->GetMofData();

    // Work here
    DXVA2TraceVideoProcessBltData* event = (DXVA2TraceVideoProcessBltData*) data;
    RECT& rect = event->TargetRect;

    clen = sprintf_s(cbuf, MAX_STRING, "Call: %s\r\n", event->Enter ? "Enter" : "Leave");
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Object: 0x%I64X\r\n", event->pObject);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Render Target: 0x%I64X\r\n", event->pRenderTarget);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Target Frame Time: %I64d\r\n", event->TargetFrameTime);
    clen += sprintf_s(&cbuf[clen], MAX_STRING - clen, "Target Rect: (%d, %d, %d, %d)\r\n",
        rect.left, rect.top, rect.right, rect.bottom);

    *_ppOutput = cbuf;
    return hr;
}

//------------------------------------------------------------------------------

#define GIE(_NAMER_,_FRIENDLY_) { \
    DXVA2Trace_##_NAMER_, \
    "DXVA2 - "_FRIENDLY_, \
    static_cast<IEventString*>(&g##_NAMER_##_Handler), \
    static_cast<IEventProfiling*>(&g##_NAMER_##_Handler) } 

OurGUIDData g_GuidInfo[] = 
{
    GIE(DecodeDevCreated,        "Decode Create Device"),
    GIE(DecodeDevDestroyed,      "Decode Destroy Device"),
    GIE(DecodeDevBeginFrame,     "Decode Begin Frame"),
    GIE(DecodeDevExecute,        "Decode Execute"),
    GIE(DecodeDevGetBuffer,      "Decode Get Buffer"),
    GIE(DecodeDevEndFrame,       "Decode End Frame"),
    GIE(VideoProcessDevCreated,  "VideoProcess Create Device"),
    GIE(VideoProcessDevDestroyed,"VideoProcess Destroy Device"),
    GIE(VideoProcessBlt,         "VideoProcess Blt")
};

HRESULT GetGuidCount(ULONG * pulCount)
{
    *pulCount = sizeof(g_GuidInfo)/sizeof(g_GuidInfo[0]);
    return S_OK;
}

HRESULT GetGuidData(GUIDData *pGuidData)
{
    for (ULONG i = 0; i < sizeof(g_GuidInfo) / sizeof(g_GuidInfo[0]); i++)
    {
        PATH_TRAP();
        size_t iLen=0;
        HRESULT hr = StringCbLength(g_GuidInfo[i].GuidDesc,MAX_PATH,&iLen);
        if(S_OK != hr)
        {
            PATH_TRAP();
            return ERROR_OUTOFMEMORY;
        }

        size_t descsize = iLen + 1;
        pGuidData[i].Guid = g_GuidInfo[i].Guid;        
        pGuidData[i].GuidDesc = new char[descsize];
        if(NULL == pGuidData[i].GuidDesc) 
        {
            PATH_TRAP();
            // Safely return an error.
            return ERROR_OUTOFMEMORY;
        }

        strcpy_s(pGuidData[i].GuidDesc, descsize, g_GuidInfo[i].GuidDesc);
    }
    return S_OK;
}

// For each GUID, return our interfaces.
HRESULT GetInterfaces(IN GUID* _pGuid, 
                      OUT IEventString** _ppIEventString,
                      OUT IEventProfiling** _ppIEventProfiling)
{
    HRESULT hr = ERROR_SUCCESS;

    for (ULONG i = 0; i < sizeof(g_GuidInfo) / sizeof(g_GuidInfo[0]); i++)
    {
        if( *_pGuid == g_GuidInfo[i].Guid )
        {
            // we found our match.
            *_ppIEventString = g_GuidInfo[i].pIEventString;
            *_ppIEventProfiling = g_GuidInfo[i].pIEventProfiling;
            break;
        }
    }

    return hr;
}


void Cleanup(void * pVoid)
{
    if(NULL != pVoid)
    {
        delete [] pVoid;
        pVoid = NULL;
    }
}

HRESULT APIENTRY Plugin_Main(GPUViewPluginData* pData)
{
    pData->dwSize = sizeof(GPUViewPluginData) ;

    pData->wVersion = PLUGIN_VERSION_2;
    pData->wFlags = WANT_TO_USE_INTERFACES;
    pData->pfnGetGuidCount = GetGuidCount;
    pData->pfnGetGuidData = GetGuidData;
    pData->pfnGetInterfaces = GetInterfaces; 
    pData->pfnCleanup = Cleanup;

    return S_OK;
}
