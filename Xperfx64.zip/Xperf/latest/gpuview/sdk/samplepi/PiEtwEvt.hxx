#ifndef _PLUGINETWEVT_H_
#define _PLUGINETWEVT_H_

#include <nt.h>
#include <ntrtl.h>
#include <nturtl.h>

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <winerror.h>

// WMI Headers.
#include <wmistr.h>
#include <evntrace.h>

#include "initguid.h"

#define DXVA2Trace_PostProcessing
#include <dxva2trace.h>

#include <stdlib.h>
#include <exception>

#include <Strsafe.h>
using namespace std;

#include "banned.h"
#include "Commonmacros.h"
#include "Plugin.h"
#include "objbase.h"
          
#endif
