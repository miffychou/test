#pragma once
#ifndef EXCLUDE_INCLUDES
#include <windows.h>
#include <string.h>
#endif

//
// This header file outlines the basic information needed from a plugin dll so it
// can profile handlers for interacting with GPUView. Currently, the IEventProfiling
// and IEventString interfaces are supported. The IEventProfiling allows a plugin to
// register that the GUIDs represent 'enter' and 'leave' messages like standard profiling
// might imply. The profiling functionality shows up in main UI and the Profiling dialog.
// The IEventString interface provide event interpretation that you see in the main
// 'Event Listing' dialog. See details for both below.
//

//
// This class is slightly different within GPUView. Because this file is included
// for GPUView's building, we have this define.
//

//
// Interface for getting to event data information
//
__interface IEventData
{
    LARGE_INTEGER GetTime() const;
    UINT GetType() const;
    ULONG GetMofDataLen() const;
    LPVOID GetMofData() const;
    LPVOID GetAssociatedObject() const;
};


//
// If the add in DLL reports that it can support the IEventProfiling interface, they
// will need to uniquely identify the class for their componenet. In other words, if
// the registered GUID records Enter and Exit points in an API in a UserModeDriver,
// they would declare their event type as eEnter_UMD and their exit type eLeave_UMD.
//
// Colors: Callbacks get crosshairs of matching color.
// 
typedef enum _PROFILE_EVENT_TYPE
{
    eUndefined_None             = 0,  // no box drawn.
    eEnter_KMD                  = 1,  // Red
    eEnter_Dxgkernel            = 2,  // Blue
    eEnter_Kernel_Filter_Top    = 3,  
    eEnter_Kernel_Filter_Top_CB = 4,
    eEnter_Kernel_Filter_Mid    = 5,  
    eEnter_Kernel_Filter_Mid_CB = 6,  
    eEnter_App                  = 7,  
    eEnter_Runtime              = 8,  
    eEnter_UMFD                 = 9,  
    eEnter_UMFD_CB              = 10, 
    eEnter_UMD                  = 11, 
    eEnter_DXVA                 = 12, 
    eEnter_Shim                 = 13,
    eEnter_Legacy               = 14,

    eEnter_AECore               = 15,
    eEnter_Core                 = 16,
    eEnter_DWM                  = 17,
    eEnter_DWM_Frame            = 18,
    eEnter_MF                   = 19,
    eEnter_mpDxgkernel          = 20,  //CornflowerBlue

    eEnter_MAX,                // Denotes the end of the eEnter_* collection.

    eUndefined_Leave            = 10000,
    eLeave_KMD                  = eUndefined_Leave+eEnter_KMD,
    eLeave_Dxgkernel            = eUndefined_Leave+eEnter_Dxgkernel,
    eLeave_Kernel_Filter_Top    = eUndefined_Leave+eEnter_Kernel_Filter_Top,
    eLeave_Kernel_Filter_Top_CB = eUndefined_Leave+eEnter_Kernel_Filter_Top_CB,
    eLeave_Kernel_Filter_Mid    = eUndefined_Leave+eEnter_Kernel_Filter_Mid,
    eLeave_Kernel_Filter_Mid_CB = eUndefined_Leave+eEnter_Kernel_Filter_Mid_CB,
    eLeave_App                  = eUndefined_Leave+eEnter_App,
    eLeave_Runtime              = eUndefined_Leave+eEnter_Runtime,
    eLeave_UMFD                 = eUndefined_Leave+eEnter_UMFD,
    eLeave_UMFD_CB              = eUndefined_Leave+eEnter_UMFD_CB,
    eLeave_UMD                  = eUndefined_Leave+eEnter_UMD,
    eLeave_DXVA                 = eUndefined_Leave+eEnter_DXVA,
    eLeave_Shim                 = eUndefined_Leave+eEnter_Shim,
    eLeave_Legacy               = eUndefined_Leave+eEnter_Legacy,

    eLeave_AECore               = eUndefined_Leave+eEnter_AECore,
    eLeave_Core                 = eUndefined_Leave+eEnter_Core,
    eLeave_DWM                  = eUndefined_Leave+eEnter_DWM,
    eLeave_DWM_Frame            = eUndefined_Leave+eEnter_DWM_Frame,
    eLeave_MF                   = eUndefined_Leave+eEnter_MF,
    eLeave_mpDxgkernel          = eUndefined_Leave+eEnter_mpDxgkernel

} PROFILE_EVENT_TYPE;


// The profiling interface is registered against a GUID and that GUID is given 
// 'level' 1 - at the same level as the thread and other profiling messages so that
// it will be processed in order with all the other messages. When this handler is
// called, it will return the appropriate PROFILE_EVENT_TYPE. 
//
// Note: GPUView uses the PROFILE_EVENT_TYPE and uiId when looking up specific 
// profile events. In other words, the PROFILE_EVENT_TYPE is a set of functions in
// which it expects each function to have a unique identifier.
//
// Most of this information is used by the 'Profiler Statistics' dialog.
//
__interface IEventProfiling
{
    // takes an event and returns a unique ID and the type.
    HRESULT ProfileHandler(IN const IEventData* pEvent,
                           OUT UINT* _puiId,
                           OUT PROFILE_EVENT_TYPE* _pType);
    // This returns the 'function' name.
    HRESULT ProfileFunctionName(IN CONST IEventData* pEvent,
                                __deref_out __nullterminated char** _ppDescriptionString);
    // Get the function name based on the id values.
    HRESULT ProfileFunctionNameById(PROFILE_EVENT_TYPE _eType,
                                    UINT _uiId,
                                    __deref_out __nullterminated LPSTR * _ppDescriptionString);
    // When looking up function names
    HRESULT IsProfileTypeSupported(PROFILE_EVENT_TYPE _eType,
                                   UINT _uiId);
    // This returns the 'GUID' name
    HRESULT ProfileGUIDName(IN CONST IEventData* pEvent,
                            __inout char** _ppDescriptionString);
};

//
// The 'Event Listing' dialog uses the following interface to get the 'Event Data'
// associated with the actual event.
//
         
__interface IEventString
{
    // pEvent, _ulProcessId and _ulThreadId are all filled in before the call with
    // the expectation that a pointer to a string describing the event will be returned.
    HRESULT EventStringHandler(IN const IEventData* pEvent,
                               ULONG _ulProcessId,
                               ULONG _ulThreadId,
                               __inout char** _ppDescriptionString);
    // After each call to EventStringHandler() (above) this method will be called to
    // allow for cleanup of the description.
    void    FreeString(__inout char** _ppString);
};

//------------------------------------------------------------------------------

//
// GPUView supports a couple different formats with plugin dlls. The first types
// are now considered obsolete.
//
// Type 1: Version 1:
//
//  If the addin sets the GPUViewPluginData.Version field to PLUGIN_VERSION, 
// GPUView will call to get event string information in the format shown with
// PFN_GETEVENTSTRING below. The data provided to the plugin dll will only be
// the extra information following the header in the trace. For instance, if
// the Event tracks a ULONG worth of private data with each event, this callback
// will recieve a pointer to sizeof(ULONG) bytes that contains that ULONG worth 
// of information.
//
// Type 2: Version 2:
//
//  If the plugin dll needs either the header's class.type field or the extended 
// header information, it will need to use this version flag and supply the callback
// described by PFN_GETEVENTSTRING2. In this case, GPUView will save the header 
// based on the wFlags field of the GPUViewPluginData structure. In other words,
// set wVersion to PLUGIN_VERSION_2 and then either use  WANT_MOF_DATA_ONLY or 
// WANT_FULL_HEADER in the wFlags field. 
//
// Type 3: Version 2
//
//  If the plugin dll wants to use the interfaces listed above, it needs to set
// the GPUViewPluginData.Version field to PLUGIN_VERSION_2 and specify the 
// WANT_TO_USE_INTERFACES flag. When this happens, GPUView ignores the PFN_GETEVENTSTRING
// and PFN_GETEVENTSTRING2 declarations infavor of the PFN_GETHANDLERINTERFACES
// entry. In this case, for every GUID registered, the handler will get a callback
// through pfnGetInterfaces to get the interfaces.
//
// Type 4: Version 3
//
//  Version 3 is a superset of version 2. The only addition is that if the user specifies
// PLUGIN_VERSION_3, we'll call the Unload function before unloading the dll.
//
#define PLUGIN_VERSION    1
#define PLUGIN_VERSION_2  2
#define PLUGIN_VERSION_3  3

#define WANT_MOF_DATA_ONLY     0x0
#define WANT_FULL_HEADER       0x1
#define WANT_TO_USE_INTERFACES 0x2

// 
// If WANT_TO_USE_INTERFACES is declared with PLUGIN_VERSION_2, the following should
// be used to describe GPUViewPluginData.pfnGetInterfaces. GPUView will call this
// routine for every registered GUID the addin registers.
//
typedef HRESULT (APIENTRY *PFN_GETHANDLERINTERFACES) (IN GUID* _pGuid, 
                                                      OUT IEventString** _ppIEventString,
                                                      OUT IEventProfiling** _ppIEventProfiling);

//                  
// Used to gather information about each GUID.
//
typedef struct _GUIDData
{
    GUID Guid;            //GUID    
    char * GuidDesc;      //text description of GUID
} GUIDData;

//
// Old style callback format not used with interfaces.
//
typedef struct _EventData
{
     GUID Guid;
     LPVOID lpData;
     ULONG ulDataLength;
} EventData;

typedef HRESULT (APIENTRY *PFN_GETGUIDCOUNT) (OUT ULONG *);
typedef HRESULT (APIENTRY *PFN_GETGUIDDATA) (OUT GUIDData *);
typedef void (APIENTRY * PFN_CLEANUP)(IN void *);
typedef void (APIENTRY * PFN_UNLOAD)();

// If you register PLUGIN_VERSION you get called with these parameters.
typedef char * (APIENTRY *PFN_GETEVENTSTRING) (IN CONST EventData*);

// If you register PLUGIN_VERSION_2 you get called with these parameters.
typedef HRESULT (APIENTRY *PFN_GETEVENTSTRING2) (IN CONST EventData*, 
                                                 IN UINT  _uiType,
                                                 __inout char** _ppResultOut);
//
// This information is returned through the PFN_PLUGINMAIN callback.
//
typedef struct _GPUViewPluginData
{
    //
    // dwSize: should be set to sizeof(GPUViewPluginData)
    //
    DWORD dwSize;
    union {
        //
        // This union of wVersion+wFlags and Version is used to define verion 1 and verwsion 2
        // behavior. If Version is set to PLUGIN_VERSION, wVersion and wflags will be ignored.
        // if wVersion is PLUGIN_VERSION_2, wFlags can be either WANT_MOF_DATA_ONLY or
        // WANT_FULL_HEADER or WANT_TO_USE_INTERFACES.
        //
        struct {
            USHORT wVersion;
            USHORT wFlags;
        };
        ULONG Version;
    };
    //
    // Gets the count of supported GUIDs
    //
    PFN_GETGUIDCOUNT pfnGetGuidCount;
    //
    // Gets the name associated with the supported GUIDs
    //
    PFN_GETGUIDDATA pfnGetGuidData;
    //
    // If wVersion is PLUGIN_VERSION_2, pfnGetEventString2 is used.
    // If Version is PLUGIN_VERSION, pfnGetEventString is used.
    //
    union {
        PFN_GETEVENTSTRING  pfnGetEventString;
        PFN_GETEVENTSTRING2 pfnGetEventString2;
        PFN_GETHANDLERINTERFACES pfnGetInterfaces;
    };
    //
    // This call mirrors the pfnGetEventString or pfnGetEventString2 call. if one
    // of those routines allocates information associated with the event, this 
    // cleanup call allows for the free.
    //
    PFN_CLEANUP pfnCleanup;
    PFN_UNLOAD pfnUnload;
} GPUViewPluginData;

//
// Used to get the GPUViewPluginData structure information above.
//
typedef HRESULT (APIENTRY *PFN_PLUGINMAIN) (IN OUT GPUViewPluginData *);


//
// The following class can be used to dump the Data the handlers
//
#define OUR_STRING 2048

class CBaseHandler
{
public:
    CBaseHandler()
    {
    }
    ~CBaseHandler()
    {
    }
    char* AllocHeader(UINT _uiSize);
    // For IEventString interface.
    void FreeString(__inout char** _ppString);

    char GetHexDigit(int Input);
    HRESULT EventStringHandler(IN CONST IEventData* _pEvent,
                               ULONG _ulProcessId,
                               ULONG _ulThreadId,
                               __inout char** _ppOutput);
    int ParseRemainder(__inout __nullterminated char* _pDest,
                       UINT _iLen,
                       int _iEventData,
                       IN CONST IEventData* _pEvent);
};
                                

