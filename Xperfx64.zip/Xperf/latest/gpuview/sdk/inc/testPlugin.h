#ifndef _TestPlugin_
#define _TestPlugin_

//
// This header file is provided so 3rd party DLLs can interact with GPUView through
// the Statistical Options dialog. The items that are needed for the interattion is
// outlined in the ITestPlugin interface. Further descriptions below.
// 

// #include "plugin.h"  // This file requires plugin.h information

//
// This interface is passed to the test during the PreProcess call. The test should 
// use these routines to get the information that it needs from the TestManager.
//
__interface ITestPreferences
{
    // If the checkbox is checked, this will return true. 
    HRESULT IsSort(bool* _pIsSorted);

    // The "Use Threashold" checkbox and "Threshold Time" controls are linked, so
    // if true is returned, the time threshold should be used.
    HRESULT UseThreshold(bool* _pUseThreshold, 
                         ULONGLONG* _pullThreshold);

    // Will return the standard deviation.
    HRESULT StandardDeviation(int* _piDeviation);

    // Returns the start and end time values for the measuring period.  
    HRESULT GetTimes(ULONGLONG* _pullStartTime,
                     ULONGLONG* _pullEndTime);

    // Gets the "Upper" and "Lower" checkbox conditions.
    HRESULT GetTracking(bool* _pTrackUpper, 
                        bool* _pTrackLower);

    // If the statistical Dialog ever gets a "ThreadId Filter" item, this method will
    // allow the test to see what should be filtered.
    HRESULT GetProfileFilter(PROFILE_EVENT_TYPE* _peFilterType,
                             UINT* _puiFilterId,
                             UINT* _puiThreadFilter);
};

//
// The PresentationMethod describes how events will be filtered when GPUView calls
// the ITestPlugin Hander method. It should be noted that filtering simply directs
// GPUView to call the handler back in a particular way. For instance, if an event
// is known to be process specific, by stating FilterPerProcess, the handler will
// get called with all events that correspond to a process before calling the handler
// with all events that correspond to the next process and so on. Effectively, 
// events are carved up per process.
//
// Note that not all messages are catigorized, thus NoFilterLinear is the most common
// PresentationMethod.
//
typedef enum _PresentationMethod
{
    // NoFilterLinear: This instructs the TestManager to simply walk the main event
    // list and call the test class back with every message regardless of context.
    NoFilterLinear,

    // FilterPerAdapter: This instructs the TestManager to walk the list as many
    // times as there are adapters in the system and only send messages that are
    // associated with the corresponding adapter.
    FilterPerAdapter,

    // FilterPerDevice: Subset of FilterPerAdapter. This instructs the TestManager 
    // to walk the list of events, first filtering by adapter and then filtering by
    // device. The end result is you get events 'tagged' as specific to the device within
    // each adapter.
    FilterPerDevice,

    // FilterPerProcess: Independent of the Adapter and Device filtering, FilterPerProcess
    // instructs the test manager to call the Handler with messages that are specific 
    // to a proc
    FilterPerProcess,

    // FilterPerThread: Subset of FilterPerProcess that applies a thread filter to the 
    // process filtered events.
    FilterPerThread,

    PresentationMethodMax,
} PresentationMethod;

               
//
// ITestPlugin - interface used for Statistical analysis dialog
//
__interface ITestPlugin
{
    // This gets the friendly name and the test description. The FriendlyName is
    // displayed in the 'Test List' listbox which should uniquely identify the test
    // and the Description is diaplayed in the 'Test Data' control when the user single
    // clicks on the Friendly Name. 
    HRESULT GetFriendlyName(__inout char** _ppFriendlyName,
                            __inout char** _ppDescription);

    // This is the method that is used to determine what events this test wants to
    // track. The TestManager will call this routine repeatedly until it returns
    // ERROR_NOT_SUPPORTED to indicate that there are no more GUIDs to process.
    // The first call will be for GUID 0, every call will increment the 'index'.
    // For a list of all GUIDs that GPUView currently knows about, read the 
    // 'GuidStats.txt' file that GPUView writes on boot.
    HRESULT GetTrackingGuids(UINT _uiIdx,
                             __inout GUID** _ppGuid);

    // This method is called to get how the test wants the information presented
    // during the callback. See PresentationMethod above.
    HRESULT GetPresentationMethod(__in PresentationMethod* _pPesentationMethod);

    // This method is called before processing the master list of events. The test
    // is expected to cash this data and use accordingly.
    HRESULT PreProcess(__in ITestPreferences* _ptp);

    // This method is called for each event in the list that matches the GUIDs retrieved
    // through GetTrackingGuids() above. The events will be filtered according to the
    // PresentationMethod.
    HRESULT Handler(CONST IEventData2* _pEvt,
                    __in GUID* _pGuid);

    // This method is called after all events have been processed. It allows the 
    // test to write back all the interesting events (Outliers). If the test doesn't
    // find any outliers, it will need to return ERROR_NO_DATA. The TestManager will
    // interpret that error message as SUCCESS, but that there is no data list to 
    // display.
    //
    // ERROR_SUCCESS - Test passed and there is out Outlier list 
    // ERROR_NO_DATA - Test passed and there is NO Outlier list to look at.
    // Other Error - Test failed.
    //
    HRESULT PostProcess(__inout std::list<CONST IEventData2*>** _ppOutOfBounds);

    // This Method is called before processing a second time. It gives the Test class
    // a chance to cleanup.
    HRESULT Clear();

    // This method returns a string describing the over all results of the processing.
    HRESULT OverAllStatistics(__inout char** _ppResultOut);
};

//
// Defines the TestPlugin Version, Flags (of which there are non yet) and the declaration
// of the routine that returns the ITestPlugin Interface.
//
#define TESTPLUGIN_VERSION 1

#define TESTPLUGIN_FLAGS 0

typedef HRESULT (APIENTRY *PFN_GETTESTINTERFACE) (IN UINT, 
                                                  OUT ITestPlugin** _ppITestPlugin);
//
//  This structure is returned by the main entry point. See the sample code and the
// definitions file for the DLL.
//
struct TestPluginData
{
    //
    // dwSize: should be set to sizeof(TestPluginData)
    //
    DWORD dwSize;

    // wVersion: should be TESTPLUGIN_VERSION.
    USHORT wVersion;

    // wFlags: should be TESTPLUGIN_FLAGS.
    USHORT wFlags;

    // Gets the test intefaces supported by this dll. It is assumed that the 
    // interfaces are in some standard 'array' form, thus the first parameter is
    // the index and the second parameter is the ITestPlugin interface. The 
    // dll should return ERROR_SUCCESS if it returns an interface for the corresponding
    // index, ERROR_NOT_SUPPORTED if that index is not supported. or an error
    // otherwise. When the test manager queries for interfaces, it will start with 
    // index zero and continuaully increment the index until the dll fails with 
    // ERROR_NOT_SUPPORTED.
    //
    PFN_GETTESTINTERFACE pfnGetTestInterface;
};

//
// Used to get the GPUViewPluginData structure information above.
//
typedef HRESULT (APIENTRY *PFN_TESTPLUGINMAIN) (IN OUT TestPluginData *);


#endif _TestPlugin_
