// This flag turns on PATH_TRAP functionality.
#define ENABLE_PATH_TRAP

// For path verification development testing
#ifndef PATH_TRAP

#ifdef _X86_

#ifdef ENABLE_PATH_TRAP

#ifdef DBG
#define PATH_TRAP() { if(IsDebuggerPresent()) { _asm int 3 } }
#else
#define PATH_TRAP()
#endif

#else
#define PATH_TRAP()
#endif

#else
// KdBreakpoint doesn't work nearly as nicely as int 3 on x86, but at least we 
// can trap this way
#ifdef ENABLE_PATH_TRAP

#ifdef DBG

#define PATH_TRAP() { if(IsDebuggerPresent()) { DbgBreakPoint(); } }
#else
#define PATH_TRAP()
#endif

#else // else of _DEBUG
#define PATH_TRAP() 
#endif


#endif  // end of #ifdef _X86_

#endif // end of #ifndef PATH_TRAP
             
#define ASSERT_REALTIME()    // Used to mark real-time code.
#define ASSERT_NONREALTIME() // Used to mark non-real time code

// TODO: once we get RT back again, remove these.
// These are copied out of the old AvRt.h file.
#define AVRT_CODE_BEGIN   code_seg( push, "RT_CODE" )
#define AVRT_DATA_BEGIN   data_seg( push, "RT_DATA" )
#define AVRT_BSS_BEGIN    bss_seg( push, "RT_BSS" )
#define AVRT_CONST_BEGIN  const_seg( push, "RT_CONST" )
#define AVRT_VTABLES_BEGIN AVRT_CONST_BEGIN
#define AVRT_CODE_END   code_seg( pop )
#define AVRT_DATA_END   data_seg( pop )
#define AVRT_BSS_END    bss_seg( pop )
#define AVRT_CONST_END  const_seg( pop )
#define AVRT_VTABLES_END AVRT_CONST_END
#define AVRT_DATA __declspec(allocate("RT_DATA"))
#define AVRT_BSS __declspec(allocate("RT_BSS"))
#define AVRT_CONST __declspec(allocate("RT_CONST"))

// Now declare our sections to the compiler so AVRT_DATA, AVRT_BSS and
// AVRT_CONST work.

#if defined(_IA64_)
#pragma section( "RT_CONST", read, long)
#endif

#pragma AVRT_CODE_BEGIN
#pragma AVRT_CODE_END
#pragma AVRT_CONST_BEGIN
#pragma AVRT_CONST_END
#pragma AVRT_BSS_BEGIN
#pragma AVRT_BSS_END
#pragma AVRT_DATA_BEGIN
#pragma AVRT_DATA_END
             
             
//------------------------------------------------------------------------------
// Description:
//
// If the condition evaluates to TRUE, perform the given statement
// then jump to the given label.
//
// Parameters:
//
//      condition - [in] Code that fits in if statement
//      action - [in] action to perform in body of if statement
//      label - [in] label to jump if condition is met
//
#define IF_TRUE_ACTION_JUMP(condition, action, label)           \
    if(condition)                                               \
    {                                                           \
        action;                                                 \
        goto label;                                             \
    }

//------------------------------------------------------------------------------
// Description:
//
// If the condition evaluates to TRUE, jump to the given label.
//
// Parameters:
//
//      condition - [in] code that fits in if statement
//      label - [in] label to jump if condition is met
//
#define IF_TRUE_JUMP(condition, label)                          \
    if(condition)                                               \
    {                                                           \
        goto label;                                             \
    }


//------------------------------------------------------------------------------
// Description:
//
// If the object exists, it's deleted and the variable it NULLed out.
//
// Parameters:
//
//      _obj_ - [in] object to delete
//
#define SAFE_DELETE_OBJECT(_obj_) { if( NULL != _obj_ ) { delete _obj_; _obj_ = NULL; } }


